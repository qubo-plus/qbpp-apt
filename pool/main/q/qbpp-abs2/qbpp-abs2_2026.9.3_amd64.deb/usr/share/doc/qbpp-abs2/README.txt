QUBO++ ABS2 plugin (unofficial) 2026.09.03

ABS2 is a GPU-only QUBO solver distributed separately from QUBO++.
It is UNOFFICIAL: it may change or be removed without notice, and no
performance is guaranteed.

Install
  Copy the contents of lib/ into the directory that holds the QUBO++
  shared libraries (typically /usr/lib/qbpp), or point QBPP_LIB_DIR at a
  directory containing both QUBO++ and these files. All three kinds of
  file must sit in the same directory:

    libabs2.so, libabs2c.so, qubo<n>_<w>_<d>.so

Requirements
  - QUBO++ 2026.09.03 or later
  - An NVIDIA GPU (there is no CPU path)

Usage
  C++     #include <qbpp/abs2_solver.hpp>   ->  qbpp::ABS2Solver
  Python  qbpp.ABS2Solver

See the ABS2 page in the QUBO++ documentation for the limitations
(QUBO only, no qbpp::cons(), 32-bit coefficients, variable-count cap).
