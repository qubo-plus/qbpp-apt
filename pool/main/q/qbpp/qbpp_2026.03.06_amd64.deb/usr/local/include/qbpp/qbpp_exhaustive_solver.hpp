/// @file qbpp_exhaustive_solver.hpp
/// @author Koji Nakano
/// @brief Exhaustive HUBO Solver for solving HUBO problems.
/// @details The ExhaustiveSolver class provides a straightforward HUBO solver
/// that evaluates all possible solutions. This solver is primarily intended
/// for testing the correctness of HUBO expressions.
/// For more details on the algorithm, please refer to the following paper:
/// Masaki Tao et al., "A Work-Time Optimal Parallel Exhaustive Search
/// Algorithm for the QUBO and the Ising Model, with GPU Implementation," IPDPS
/// Workshops 2020: 557-566. https://doi.org/10.1109/IPDPSW50202.2020.00098
/// @version 2026.02.28

#pragma once

#include <tbb/blocked_range.h>
#include <tbb/parallel_for.h>

#include <atomic>

#include "qbpp.hpp"

namespace qbpp {

/// @brief Namespace for the QUBO++ exhaustive solver.
/// @details The exhaustive solver provides a simple QUBO solver for the QUBO++
/// library. This solver is intended to be used for testing the QUBO++ library
/// and for testing, evaluation, and leaning purpose.
namespace exhaustive_solver {

// __int128 用 operator<< を親の namespace qbpp から引き込む
// （このnamespace内に別の operator<< があると名前隠蔽が起きるため）
#if defined(__SIZEOF_INT128__)
using qbpp::operator<<;
#endif

//=====================
//  Class Prototypes
// ====================

class SolDelta;
class Sol;
class SearchAlgorithm;
class ExhaustiveSolver;

/// @brief Class to store a solution of a QUBO model.
/// @details Derived from the qbpp::Sol class. all_solutions_ is used to store
/// all solutions or all optimal solutions.
class Sol : public qbpp::Sol {
  /// @brief True if all solutions are stored.
  bool is_all_solutions_ = false;

  /// @brief True if all optimal solutions are stored.
  bool is_optimal_solutions_ = false;

  /// @brief A vector to store all solutions or all optimal solutions.
  std::vector<qbpp::Sol> all_solutions_;

 public:
  /// @brief SolDelta constructor: constructs a Sol object with the
  /// specified HuboModel object.
  /// @param hubo_model The HuboModel object.
  /// @note The Model object is also accepted as an argument by the implicit]
  /// conversion.
  explicit Sol(const HuboModel& hubo_model) : qbpp::Sol(hubo_model) {};

  /// @brief Default copy constructor
  /// @note The copy constructor may be used to return a Sol object.
  Sol(const Sol&) = default;

  /// @brief Default move constructor
  /// @note The move constructor may be used to return a Sol object.
  Sol(Sol&&) = default;

  /// @brief Default copy assignment operator
  Sol& operator=(const Sol&) = default;

  /// @brief Default move assignment operator
  Sol& operator=(Sol&&) = default;

  /// @brief Returns the reference all_solutions_.
  /// @return The reference all_solutions_.
  std::vector<qbpp::Sol>& all_solutions() { return all_solutions_; }

  /// @brief Sets the all_solutions_ flag to true.
  void all_solution_mode() {
    is_optimal_solutions_ = false;
    is_all_solutions_ = true;
  }

  /// @brief Sets the optimal_solutions_ flag to true.
  void optimal_solution_mode() {
    is_optimal_solutions_ = true;
    is_all_solutions_ = false;
  }

  /// @brief Set all_solutions_ by moving the specified vector.
  /// @param all_solutions The vector of all solutions.
  void all_solutions(std::vector<qbpp::Sol>&& all_solutions) {
    all_solutions_ = std::move(all_solutions);
    qbpp::Sol::operator=(all_solutions_.front());
  }

  /// @brief Returns the string representation of the Sol object.
  /// @return The string representation of the Sol object.
  std::string str() const {
    if (is_all_solutions_ || is_optimal_solutions_) {
      std::ostringstream oss;
      uint32_t count = 0;
      for (const auto& sol : all_solutions_) {
        oss << "(" << count++ << ") " << sol;
        if (count < all_solutions_.size()) oss << std::endl;
      }
      return oss.str();
    }
    return qbpp::str(static_cast<const qbpp::Sol&>(*this));
  }

  /// @brief Returns the iterator to the beginning of the all_solutions_ vector
  std::vector<qbpp::Sol>::const_iterator begin() const {
    return all_solutions_.begin();
  }

  /// @brief Returns the iterator to the end of the all_solutions_ vector.
  std::vector<qbpp::Sol>::const_iterator end() const {
    return all_solutions_.end();
  }

  /// @brief Returns the number of solutions in the all_solutions_ vector
  size_t size() const { return all_solutions_.size(); }

  const qbpp::Sol& operator[](size_t i) const { return all_solutions_[i]; }

  qbpp::Sol& operator[](size_t i) { return all_solutions_[i]; }
};

/// @brief ostream operator for Sol objects.
/// @param os The output stream object.
/// @param sol The Sol object to output.
/// @return The output stream object.
inline std::ostream& operator<<(std::ostream& os, const Sol& sol) {
  os << sol.str();
  return os;
}

/// @brief Class for exhaustive solver for QUBO models
/// @details The solver uses the Positive Min algorithm running on a CPU.
class ExhaustiveSolver {
 protected:
  /// @brief A reference to the HuboModel object.
  const HuboModel hubo_model_;

  /// @brief Flag
  bool enable_default_callback_ = false;

  bool verbose_ = false;

  /// @brief Target energy for early termination.
  std::optional<energy_t> target_energy_;

 public:
  /// @defgroup exhaustive_solver ExhaustiveSolver for Solving QUBO Models
  /// @brief A set of functions for solving QUBO models using exhaustive
  /// search.
  /// @details The ExhaustiveSolver class provides a simple solver for QUBO
  /// models, evaluating all possible solutions with a time complexity of
  /// @f$2^n@f$, where @f$n@f$ is the number of variables. It offers three
  /// functions for finding solutions:
  /// - search(): returns one of the optimal solutions.
  /// - search_optimal_solutions(): returns all optimal solutions.
  /// - search_all_solutions(): returns all @f$2^n@f$ solutions.
  ///
  /// Since all solutions are evaluated, the results are guaranteed to be
  /// correct. However, for large problems, the computation time may become
  /// impractically long.
  ///
  /// For more details on the algorithm, please refer to the following
  /// paper:
  /// Masaki Tao et al., "A Work-Time Optimal Parallel Exhaustive Search
  /// Algorithm for the QUBO and the Ising Model, with GPU Implementation,"
  /// IPDPS Workshops 2020: 557-566.
  /// https://doi.org/10.1109/IPDPSW50202.2020.00098
  ///
  /// Below is an example of how to use the ExhaustiveSolver:
  /// @code
  /// #include "qbpp/qbpp.hpp"
  /// #include "qbpp/qbpp_exhaustive_solver.hpp"
  ///
  /// int main() {
  ///   auto a = qbpp::var("a");
  ///   auto b = qbpp::var("b");
  ///   auto c = qbpp::var("c");
  ///   auto f = -(a * b + (1 - b) * c);
  ///   f.simplify_as_binary();
  ///   std::cout << "f = " << f << std::endl;
  ///
  ///   qbpp::exhaustive_solver::ExhaustiveSolver solver(f);
  ///
  ///   auto sol_search = solver.search();
  ///   std::cout << "Solution from search() = " << sol_search << std::endl;
  ///
  ///   auto sol_optimal = solver.search_optimal_solutions();
  ///   std::cout << "Solutions from search_optimal_solutions()" << std::endl;
  ///   std::cout << sol_optimal;
  ///
  ///   auto sol_all = solver.search_all_solutions();
  ///   std::cout << "Solutions from search_all_solutions()" << std::endl;
  ///   std::cout << sol_all;
  /// }
  /// @endcode
  /// The output of the above code is:
  /// @code
  /// f = -c -a*b +b*c
  /// Solution from search() = -1:{{a,1},{b,1},{c,0}}
  /// Solutions from search_optimal_solutions()
  /// 0:-1:{{a,0},{b,0},{c,1}}
  /// 1:-1:{{a,1},{b,0},{c,1}}
  /// 2:-1:{{a,1},{b,1},{c,0}}
  /// 3:-1:{{a,1},{b,1},{c,1}}
  /// Solutions from search_all_solutions()
  /// 0:-1:{{a,0},{b,0},{c,1}}
  /// 1:-1:{{a,1},{b,0},{c,1}}
  /// 2:-1:{{a,1},{b,1},{c,0}}
  /// 3:-1:{{a,1},{b,1},{c,1}}
  /// 4:0:{{a,0},{b,0},{c,0}}
  /// 5:0:{{a,0},{b,1},{c,0}}
  /// 6:0:{{a,0},{b,1},{c,1}}
  /// 7:0:{{a,1},{b,0},{c,0}}
  /// @endcode
  /// @note This solver is primarily intended for testing the QUBO++ library,
  /// as well as for evaluation, experimentation, and educational purposes.
  /// @{

  /// @brief Constructor to creates an ExhaustiveSolver object with the
  /// specified HuboModel object.
  /// @param hubo_model The HuboModel object.
  /// @note The Model object is also accepted as an argument by the implicit
  /// conversion to HuboModel object.
  ExhaustiveSolver(const HuboModel& hubo_model) : hubo_model_(hubo_model) {
    if (hubo_model_.var_count() >= 50) {
      throw std::invalid_argument(
          "ExhaustiveSolver: The number of variables exceeds the limit (50).");
    }
  }

  mutable std::mutex callback_mutex_;
  mutable std::optional<energy_t> prev_callback_energy_ = std::nullopt;

  /// @brief Default Destructor
  virtual ~ExhaustiveSolver() = default;

  /// @brief Default callback function
  virtual void callback(const SolHolder& sol_holder) const {
    std::lock_guard<std::mutex> lock(callback_mutex_);
    if (enable_default_callback_) {
      if (!prev_callback_energy_.has_value() ||
          sol_holder.energy() < prev_callback_energy_.value()) {
        prev_callback_energy_ = sol_holder.energy();
        std::cout << "TTS = " << std::fixed << std::setprecision(3)
                  << std::setfill('0') << sol_holder.tts()
                  << "s Energy = " << sol_holder.energy() << std::endl;
      }
    }
  }

  /// @brief Returns the number of variables in the model.
  vindex_t var_count() const { return hubo_model_.var_count(); }

  /// @brief Finds one of the optimal solutions by exhaustive search.
  /// @return The qbpp::Sol object with the optimal solution.
  qbpp::Sol search();

  /// @brief Finds all optimal solutions.
  /// @return The Sol object with all optimal solutions.
  Sol search_optimal_solutions();

  /// @brief  Evaluates all solutions.
  /// @return The Sol object with all solutions.
  Sol search_all_solutions();

  /// @brief Enables or disables the default callback function.
  /// @param enable True to enable the default callback function.
  /// @details The default callback function outputs the tts and energy when a
  /// new best solution is found.
  void enable_default_callback(bool enable = true) {
    enable_default_callback_ = enable;
  }

  /// @brief Enables or disables verbose mode.
  void verbose(bool enable = true) { verbose_ = enable; }

  /// @brief Returns true if verbose mode is enabled.
  bool is_verbose() const { return verbose_; }

  /// @brief Sets the target energy for early termination.
  void target_energy(energy_t energy) { target_energy_ = energy; }

  /// @brief Returns the target energy.
  std::optional<energy_t> target_energy() const { return target_energy_; }

  /// @}

  /// @brief Returns the reference to the HuboModel object.
  /// @return The reference to the HuboModel object.
  const HuboModel& hubo_model() const { return hubo_model_; }
};

/// @brief Class for the search algorithm.
/// @details The SearchAlgorithm class provides an exhaustive search algorithm
/// for QUBO models.
class SearchAlgorithm {
  /// @brief A reference to the ExhaustiveSolver object.
  /// @note This object is used to call the callback function.
  const ExhaustiveSolver& exhaustive_solver_;

  /// @brief A reference to the HuboModel object.
  /// @note This object is a reference to the HuboModel object in the
  /// ExhaustiveSolver object.
  const HuboModel& hubo_model_;

  /// @brief Sorted Sequence of variable indexes.
  /// @details The variable order is determined by the degree of the variables.
  const std::vector<vindex_t> var_order_;

  /// @brief A SolHolder object to store the best solution.
  /// @details Enabled if is_all_solutions is false.
  qbpp::SolHolder sol_holder_;

  /// @brief True if all solutions are stored.
  bool is_all_solutions_ = false;

  /// @brief True if all optimal solutions are stored.
  bool is_optimal_solutions_ = false;

  /// @brief A vector to store all solutions.
  /// @details Enabled if is_all_solutions is true.
  std::vector<qbpp::Sol> all_solutions_;

  /// @brief A mutex to protect all_solutions_.
  mutable std::mutex all_solutions_mutex_;

  /// @brief A vector to store the deltas for parallel search.
  std::vector<SolDelta> sol_deltas;

  mutable std::atomic<uint64_t> total_flip_count_{0};
  double prev_percent_ = 0.0;
  std::mutex progress_mutex_;

  /// @brief Target energy for early termination (copied from ExhaustiveSolver).
  const std::optional<energy_t> target_energy_;

  /// @brief Atomic flag for early termination when target energy is reached.
  mutable std::atomic<bool> target_reached_{false};

  /// @brief Compute var_order_ from the degree of the variables.
  /// @param hubo_model The HuboModel object.
  /// @return vector to store the variable order.
  std::vector<vindex_t> init_var_order(const HuboModel& hubo_model) {
    std::vector<std::pair<size_t, vindex_t>> cost_var;
    cost_var.resize(hubo_model.var_count());
    for (vindex_t i = 0; i < hubo_model.var_count(); ++i) {
      // Weighted flip cost: degree-k term costs O(k-1) per entry.
      size_t cost = hubo_model.term2(i).size() +
                    hubo_model.term3(i).size() * 2 +
                    hubo_model.term4(i).size() * 3;
      for (const auto& dtv : hubo_model.dyn_terms(i))
        cost += dtv.size() * dtv.degree_minus_one();
      cost_var[i] = std::make_pair(cost, i);
    }
    std::sort(cost_var.begin(), cost_var.end());
    std::vector<vindex_t> var_order;
    var_order.resize(hubo_model.var_count());
    for (vindex_t i = 0; i < hubo_model.var_count(); ++i) {
      var_order[i] = cost_var[i].second;
    }
    return var_order;
  }

 public:
  /// @brief Constructor to creates an EasySolver object with the
  /// specified HuboModel object.
  /// @param exhaustive_solver The ExhaustiveSolver object.q
  /// @note The Model object is also accepted as an argument by the implicit
  /// conversion to HuboModel object.
  explicit SearchAlgorithm(const ExhaustiveSolver& exhaustive_solver)
      : exhaustive_solver_(exhaustive_solver),
        hubo_model_(exhaustive_solver_.hubo_model()),
        var_order_(init_var_order(hubo_model_)),
        sol_holder_(hubo_model_),
        target_energy_(exhaustive_solver.target_energy()) {}

  /// @brief Returns the reference to the HuboModel object.
  const HuboModel& hubo_model() const { return hubo_model_; }

  const std::vector<vindex_t>& var_order() const { return var_order_; }

  /// @brief Returns the number of variables in the model.
  vindex_t var_count() const { return hubo_model_.var_count(); }

  /// @brief Returns the reference all_solutions_.
  /// @return The reference all_solutions_.
  std::vector<qbpp::Sol>& all_solutions() { return all_solutions_; }

  /// @brief Returns the reference sol_holder_.
  /// @return The reference sol_holder_.
  qbpp::SolHolder& sol_holder() { return sol_holder_; }

  /// @brief Returns true if the target energy has been reached.
  bool reach_target_energy() const {
    if (is_all_solutions_ || is_optimal_solutions_) return false;
    if (target_reached_.load(std::memory_order_relaxed)) return true;
    if (!target_energy_.has_value()) return false;
    if (sol_holder_.energy() <= target_energy_.value()) {
      target_reached_.store(true, std::memory_order_relaxed);
      return true;
    }
    return false;
  }

  /// @brief Registers a new solution if it is better than the current best
  /// solution.
  void register_new_sol(const qbpp::Sol& sol) {
    if (!is_all_solutions_ && sol_holder_.energy() < sol.energy()) return;
    std::lock_guard<std::mutex> lock(all_solutions_mutex_);
    if (is_all_solutions_) {
      all_solutions_.push_back(sol);
    } else if (is_optimal_solutions_) {
      if (sol_holder_.energy() == sol.energy()) {
        all_solutions_.push_back(sol);
      } else if (sol_holder_.energy() > sol.energy()) {
        all_solutions_.clear();
        all_solutions_.push_back(sol);
      }
    }
    if (sol_holder_.set_if_better(sol)) {
      exhaustive_solver_.callback(sol_holder_);
    }
  }

  /// @brief Finds one of the optimal solutions by exhaustive search.
  void search();

  /// @brief Finds all optimal solutions.
  void search_optimal_solutions();

  /// @brief Evaluates all solutions.
  void search_all_solutions();

  /// @brief Creates the delta vectors for parallel search.
  /// @param sol_delta The SolDelta object.
  /// @param index The variable index.
  /// @details The function creates the delta vectors for parallel search.
  void gen_sol_deltas(SolDelta& sol_delta, vindex_t index);

  void add_flip_count(uint64_t count) {
    total_flip_count_ += count;
    if (exhaustive_solver_.is_verbose()) {
      std::lock_guard<std::mutex> lock(progress_mutex_);
      double percent = 100.0 * static_cast<double>(total_flip_count_) /
                       static_cast<double>(1ULL << var_count());
      if (percent - prev_percent_ >= 0.1) {
        prev_percent_ = percent;
        std::cout << "Progress: " << std::fixed << std::setprecision(1)
                  << percent << "%\r" << std::flush;
      }
    }
  }
};

/// @brief Class for solution with delta updates.
class SolDelta : public Sol {
 protected:
  /// @brief A reference to the HuboModel object.
  const HuboModel& hubo_model_;

  /// @brief A reference to the SearchAlgorithm object.
  SearchAlgorithm& search_algorithm_;

  /// @brief Sorted Sequence of variable indexes.
  const std::vector<vindex_t>& var_order_ = search_algorithm_.var_order();

  /// @brief A vector to store the delta values for each variable.
  std::vector<energy_t> delta_;

  /// @brief A vector to store the delta changes for each variable.
  std::vector<energy_t> delta_delta_;

  /// @brief Indices of non-zero entries in delta_delta_.
  std::vector<vindex_t> dirty_indices_;

  /// @brief A counter for the number of flips.
  uint64_t flip_count_ = 0;

 public:
  explicit SolDelta(SearchAlgorithm& search_algorithm)
      : Sol(search_algorithm.hubo_model()),
        hubo_model_(search_algorithm.hubo_model()),
        search_algorithm_(search_algorithm),
        delta_(var_count()),
        delta_delta_(var_count(), 0) {
    // Initial delta at all-zeros state.
    // For quadratic+ terms, contributions exist only when ALL secondary
    // variables are negated (effective value 1 at all-zeros).
    for (vindex_t i = 0; i < var_count(); ++i) {
      delta_[i] = hubo_model_.term1(i);
      // degree-2: single secondary
      const auto& t2 = hubo_model_.term2(i);
      for (size_t j = 0; j < t2.size(); ++j) {
        if (t2.indices(j)[0] & qbpp::vindex_neg_bit)
          delta_[i] += t2.coeff(j);
      }
      // degree-3: both secondaries must be negated
      const auto& t3 = hubo_model_.term3(i);
      for (size_t j = 0; j < t3.size(); ++j) {
        const auto& inds = t3.indices(j);
        if ((inds[0] & qbpp::vindex_neg_bit) && (inds[1] & qbpp::vindex_neg_bit))
          delta_[i] += t3.coeff(j);
      }
      // degree-4: all 3 secondaries must be negated
      const auto& t4 = hubo_model_.term4(i);
      for (size_t j = 0; j < t4.size(); ++j) {
        const auto& inds = t4.indices(j);
        if ((inds[0] & qbpp::vindex_neg_bit) &&
            (inds[1] & qbpp::vindex_neg_bit) &&
            (inds[2] & qbpp::vindex_neg_bit))
          delta_[i] += t4.coeff(j);
      }
      // degree 5+: all secondaries must be negated
      for (const auto& dtv : hubo_model_.dyn_terms(i)) {
        const uint32_t nm1 = dtv.degree_minus_one();
        const vindex_t* dbase = dtv.indices_data();
        for (uint32_t j = 0; j < dtv.size(); ++j) {
          const vindex_t* idx = dbase + static_cast<size_t>(j) * nm1;
          bool all_neg = true;
          for (uint32_t k = 0; k < nm1; ++k) {
            if (!(idx[k] & qbpp::vindex_neg_bit)) { all_neg = false; break; }
          }
          if (all_neg) delta_[i] += dtv.coeffs_[j];
        }
      }
    }
  }

  template <size_t N>
  inline void update_delta_delta(const TermVector<N - 1>& terms,
                                 std::vector<energy_t>& delta_delta,
                                 energy_t flip_bit_sign) {
    static_assert(N >= 3, "N must be >= 3");

    for (size_t i = 0; i < terms.size(); ++i) {
      std::array<vindex_t, N - 1> idx{};
      std::array<uint8_t, N - 1> val{};
      uint8_t sum = 0;

      const auto& inds = terms.indices(i);

      for (size_t j = 0; j < N - 1; ++j) {
        idx[j] = inds[j] & qbpp::vindex_mask;
        uint8_t v = static_cast<uint8_t>(get(idx[j]));
        if (inds[j] & qbpp::vindex_neg_bit) v = static_cast<uint8_t>(1 - v);
        val[j] = v;
        sum = static_cast<uint8_t>(sum + val[j]);
      }

      const energy_t factor = terms.coeff(i) * flip_bit_sign;

      if (sum <= static_cast<uint8_t>(N - 3)) continue;

      if (sum == static_cast<uint8_t>(N - 1)) {
        for (size_t j = 0; j < N - 1; ++j) {
          if (delta_delta[idx[j]] == 0) dirty_indices_.push_back(idx[j]);
          delta_delta[idx[j]] -= factor;
        }
        continue;
      }

      // sum == N-2: exactly one zero exists among N-1 variables
      for (uint8_t target = 0; target < N - 1; ++target) {
        if (val[target] == 0) {
          if (delta_delta[idx[target]] == 0)
            dirty_indices_.push_back(idx[target]);
          delta_delta[idx[target]] += factor;
          break;
        }
      }
    }
  }

  /// @brief Dynamic version of update_delta_delta for degree 5+ terms.
  inline void update_delta_delta_dyn(const DynTermVector& terms,
                                     std::vector<energy_t>& delta_delta,
                                     energy_t flip_bit_sign) {
    const uint32_t nm1 = terms.degree_minus_one();
    const vindex_t* raw_base = terms.indices_data();
    const coeff_t* coeffs = terms.coeffs_data();
    for (size_t i = 0; i < terms.size(); ++i) {
      const vindex_t* raw_idx = raw_base + i * nm1;
      uint32_t sum = 0;
      for (uint32_t j = 0; j < nm1; ++j) {
        vindex_t base_j = raw_idx[j] & qbpp::vindex_mask;
        uint32_t v = static_cast<uint32_t>(get(base_j));
        if (raw_idx[j] & qbpp::vindex_neg_bit) v = 1 - v;
        sum += v;
      }
      if (sum + 2 <= nm1) continue;
      const energy_t factor = coeffs[i] * flip_bit_sign;
      if (sum == nm1) {
        for (uint32_t j = 0; j < nm1; ++j) {
          vindex_t base_j = raw_idx[j] & qbpp::vindex_mask;
          if (delta_delta[base_j] == 0) dirty_indices_.push_back(base_j);
          delta_delta[base_j] -= factor;
        }
        continue;
      }
      // sum == nm1 - 1: exactly one zero
      for (uint32_t j = 0; j < nm1; ++j) {
        vindex_t base_j = raw_idx[j] & qbpp::vindex_mask;
        uint32_t v = static_cast<uint32_t>(get(base_j));
        if (raw_idx[j] & qbpp::vindex_neg_bit) v = 1 - v;
        if (v == 0) {
          if (delta_delta[base_j] == 0) dirty_indices_.push_back(base_j);
          delta_delta[base_j] += factor;
          break;
        }
      }
    }
  }

  void inc_flip_count() {
    constexpr uint64_t iteration = 1000;
    if (++flip_count_ >= iteration) {
      search_algorithm_.add_flip_count(flip_count_);
      flip_count_ -= iteration;
    }
  }

  void clear_flip_count() {
    if (flip_count_ > 0) {
      search_algorithm_.add_flip_count(flip_count_);
      flip_count_ = 0;
    }
  }

  void flip(vindex_t flip_index) override {
    assert(flip_index < var_order_.size());
    vindex_t index = var_order_[flip_index];
    assert(index < var_count());
    energy_ = energy() + delta_[index];

    int32_t flip_bit_sign = 1 - 2 * get(index);

    dirty_indices_.clear();

    const auto& t2 = hubo_model_.term2(index);
    for (size_t i = 0; i < t2.size(); ++i) {
      vindex_t raw_j = t2.indices(i)[0];
      vindex_t j = raw_j & qbpp::vindex_mask;
      coeff_t coeff = t2.coeff(i);
      int32_t val_j = get(j);
      if (raw_j & qbpp::vindex_neg_bit) val_j = 1 - val_j;
      energy_t dd = coeff * flip_bit_sign * (1 - 2 * val_j);
      if (dd != 0 && delta_delta_[j] == 0) dirty_indices_.push_back(j);
      delta_delta_[j] += dd;
    }

    if (hubo_model_.max_power() <= 2) goto post_process;
    update_delta_delta<3>(hubo_model_.term3(index), delta_delta_, flip_bit_sign);

    if (hubo_model_.max_power() <= 3) goto dyn_process;
    update_delta_delta<4>(hubo_model_.term4(index), delta_delta_, flip_bit_sign);

  dyn_process:
    // Dynamic terms for degree 5+ (via dyn_terms)
    for (const auto& dtv : hubo_model_.dyn_terms(index))
      update_delta_delta_dyn(dtv, delta_delta_, flip_bit_sign);

  post_process:

    for (vindex_t i : dirty_indices_) {
      if (delta_delta_[i] == 0) continue;
      assert(i != index);
      delta_[i] += delta_delta_[i];
      delta_delta_[i] = 0;
    }

    delta_[index] = -delta_[index];
    if (!energy_.has_value()) {
      throw std::out_of_range(THROW_MESSAGE("energy_ is not set."));
    }

    // should not change!
    bit_vector_.flip(index);

    inc_flip_count();
  }

  /// @brief Recursively searches for the optimal solution.
  /// @param index The variable index to be flipped.
  void search(vindex_t index) {
    if (index >= 1) search(index - 1);
    if (search_algorithm_.reach_target_energy()) return;
    flip(index);
    search_algorithm_.register_new_sol(*this);
    if (index >= 1) search(index - 1);
  }

  /// @brief Returns the delta of the specified variable index.
  /// @details Simply calls search algorithm
  void search() {
    search_algorithm_.register_new_sol(*this);
    search(var_count() - 1);
    clear_flip_count();
  }

};

//========================================
// Class ExhausiveSolver Member Functions
//========================================

inline qbpp::Sol ExhaustiveSolver::search() {
  SearchAlgorithm search_algorithm(*this);
  search_algorithm.search();
  return search_algorithm.sol_holder().sol();
}

inline Sol ExhaustiveSolver::search_optimal_solutions() {
  SearchAlgorithm search_algorithm(*this);
  search_algorithm.search_optimal_solutions();
  Sol sol(hubo_model_);
  sol.optimal_solution_mode();
  sol.all_solutions(std::move(search_algorithm.all_solutions()));
  return sol;
}

inline Sol ExhaustiveSolver::search_all_solutions() {
  SearchAlgorithm search_algorithm(*this);
  search_algorithm.search_all_solutions();
  Sol sol(hubo_model_);
  sol.all_solution_mode();
  sol.all_solutions(std::move(search_algorithm.all_solutions()));
  return sol;
}

//========================================
// Class SearchAlgorithm Member Functions
//========================================

inline void SearchAlgorithm::gen_sol_deltas(SolDelta& sol_delta,
                                            vindex_t index) {
  if (var_count() == index) return;
  gen_sol_deltas(sol_delta, index + 1);
  sol_delta.flip(index);
  sol_deltas.push_back(sol_delta);
  gen_sol_deltas(sol_delta, index + 1);
}

inline void SearchAlgorithm::search() {
  /// @brief Parameter for parallel search
  /// @details The search space is partitioned into parallel_param ** 2 parts.
  static constexpr int parallel_param = 8;
  SolDelta sol_delta(*this);
  // if the number of variables is less than or equal to 16, sequential search
  // is used.
  if (hubo_model_.term_count() == 0) {
    register_new_sol(sol_delta);
    return;
  }
  if (var_count() <= 16) {
    register_new_sol(sol_delta);
    sol_delta.search(var_count() - 1);
    return;
  }
  sol_deltas.reserve(1 << parallel_param);
  sol_deltas.push_back(sol_delta);
  gen_sol_deltas(sol_delta, var_count() - parallel_param);

  tbb::parallel_for(
      tbb::blocked_range<size_t>(0, sol_deltas.size()),
      [&](const tbb::blocked_range<size_t>& range) {
        for (size_t i = range.begin(); i < range.end(); ++i) {
          if (reach_target_energy()) break;
          register_new_sol(sol_deltas[i]);
          sol_deltas[i].search(var_count() - (parallel_param + 1));
        }
      });
}

inline void SearchAlgorithm::search_optimal_solutions() {
  is_optimal_solutions_ = true;
  search();
  tbb::parallel_sort(all_solutions_.begin(), all_solutions_.end());
}

inline void SearchAlgorithm::search_all_solutions() {
  is_all_solutions_ = true;
  search();
  tbb::parallel_sort(all_solutions_.begin(), all_solutions_.end());
}

}  // namespace exhaustive_solver
}  // namespace qbpp
