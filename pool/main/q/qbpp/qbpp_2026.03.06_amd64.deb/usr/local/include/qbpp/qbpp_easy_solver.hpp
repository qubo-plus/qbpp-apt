/// @file qbpp_easy_solver.hpp
/// @author Koji Nakano
/// @brief HUBO Solver for solving HUBO problems
/// @details High Order Unconstrained Binary Optimization (HUBO) solver.
/// @version 2026.02.21

#pragma once

#include <string_view>
#include <unordered_set>

#include "qbpp.hpp"
#include "qbpp_defs.hpp"
#include "qbpp_misc.hpp"

namespace qbpp {

namespace easy_solver {

constexpr double kDefaultTimeLimit = 10.0;  // seconds

//=====================================
//  Class Prototypes
//=====================================

class BestSols;
class EasySolver;
class SolDelta;

/// @brief Class to compute xxhash for Sol object.
/// @details This class is used to compute the hash value of a Sol object to
/// check the equality of the Sol objects.
struct SolHash {
  /// @brief Computes the 64-bit hash value of a Sol object.
  uint64_t operator()(const qbpp::Sol& sol) const noexcept {
    return static_cast<uint64_t>(
        qbpp_hash(sol.bit_vector().size64(), sol.bit_vector().bits_ptr()));
  }
};

enum class SavePolicy {
  BestSolsOnly,        // Save only the best solutions found so far.
  All,                 // Save any solution, regardless of local optimality.
  WeakLocalMinimum,    // Save only solutions not worse than any neighbor (≤).
  StrictLocalMinimum,  // Save only solutions strictly better than all neighbors
                       // (<).
};

/// @brief Class to store the best solutions.
/// @details This class is used to store the best solutions found so far.
/// @note The class uses SolHash to compute the hash value of a Sol object.
class BestSols {
  /// @brief The maximum number of best solutions to store.
  const size_t capacity_;

  SavePolicy save_policy_;

  /// @brief The vector to store the best solutions.
  std::vector<qbpp::Sol> sol_vector_;

  /// @brief The set to store the hash values of the best solutions.
  /// @note The set is used to check if the solution is already stored.
  std::unordered_set<qbpp::Sol, SolHash> sol_set_;

  /// @brief The worst energy of the best solutions.
  std::optional<energy_t> worst_energy_;

  /// @brief The mutex to protect the sol_vector_ and sol_set_.
  std::mutex mutex_;

 public:
  /// @brief Constructor to initialize the BestSols object.
  /// @param capacity The maximum number of best solutions to store.
  explicit BestSols(size_t capacity = 0,
                    SavePolicy save_policy = SavePolicy::All)
      : capacity_(capacity), save_policy_(save_policy) {}

  /// @brief Inserts the solution into the best solutions if it is local minimum
  /// and better than the worst solution in the set.
  void insert_if_better(const qbpp::Sol& sol,
                        const misc::MinHeap<energy_t>& neg_set,
                        const misc::MinHeap<energy_t>& pos_set) {
    if (save_policy_ != SavePolicy::BestSolsOnly && capacity_ == 0) return;
    if (save_policy_ == SavePolicy::WeakLocalMinimum && !neg_set.empty())
      return;
    if (save_policy_ == SavePolicy::StrictLocalMinimum &&
        pos_set.heap_size() < sol.var_count())
      return;
    std::lock_guard<std::mutex> lock(mutex_);
    if (worst_energy_ && *worst_energy_ < sol.energy()) return;
    if (sol_set_.count(sol)) return;  // Already exists
    if (save_policy_ == SavePolicy::BestSolsOnly && worst_energy_ &&
        sol.energy() < *worst_energy_) {
      sol_vector_.clear();
      sol_set_.clear();
    }

    if (sol_vector_.size() < capacity_ || capacity_ == 0) {
      sol_vector_.push_back(sol);
      sol_set_.insert(sol);
    } else {
      if (sol.energy() >= sol_vector_.back().energy()) return;
      const auto& removed = sol_vector_.back();
      sol_set_.erase(removed);
      sol_vector_.back() = sol;
      sol_set_.insert(sol);
    }

    for (size_t i = sol_vector_.size() - 1; i > 0; --i) {
      if (sol_vector_[i].energy() < sol_vector_[i - 1].energy()) {
        std::swap(sol_vector_[i], sol_vector_[i - 1]);
      } else {
        break;
      }
    }

    worst_energy_ = sol_vector_.back().energy();
  }

  const std::vector<qbpp::Sol>& sol_vector() const { return sol_vector_; }

  std::vector<qbpp::Sol>& sol_vector() { return sol_vector_; }
};

/// @brief Class to store the solution with delta vector, neg_set, and
/// pos_set.
class SolDelta : public Sol {
 protected:
  /// @brief A reference to the EasySolver object calling this class.
  const EasySolver& easy_solver_;

  /// @brief A reference to the HuboModel object for this class.
  const HuboModel& hubo_model_;

  /// @brief The vector to store the delta of each variable in the model.
  std::vector<energy_t> delta_;

  /// @brief The MinHeap object to store the variables with negative deltas.
  misc::MinHeap<energy_t> neg_set_;

  /// @brief The MinHeap object to store the variables with positive deltas.
  misc::MinHeap<energy_t> pos_set_;

  /// @brief Reusable buffer for delta updates during flip operations.
  std::vector<energy_t> delta_delta_;

  /// @brief Reusable buffer to track indices modified in delta_delta_.
  std::vector<vindex_t> dirty_list_;

  /// @brief The Tabu object to store the tabu list.
  misc::Tabu tabu_;

  /// @brief The BestSols object to store the best solutions.
  const std::shared_ptr<qbpp::SolHolder> all_best_sol_ptr_;

  std::shared_ptr<qbpp::SolHolder> time_limited_best_sol_ptr_;

  uint64_t flip_count_ = 0;

 public:
  /// @brief Constructor to create a new SolDelta object for the specified
  /// EasySolver object.
  SolDelta(const EasySolver& easy_solver, size_t thread_id,
           size_t thread_count);

  SolDelta& set_all_one() {
    neg_set_.clear();
    pos_set_.clear();
    for (vindex_t i = 0; i < var_count(); ++i) {
      Sol::set(i, true);
      delta_[i] = -hubo_model_.coeff_sum(i);
      if (delta_[i] < 0) {
        neg_set_.insert(i, delta_[i]);
      } else if (delta_[i] > 0) {
        pos_set_.insert(i, delta_[i]);
      }
    }
    energy_ = hubo_model_.all_coeff_sum();
    return *this;
  }

  bool reach_time_limit() const;

  bool reach_target_energy() const;

  bool reach_end_time() const;

  bool should_stop() const {
    return reach_target_energy() || reach_time_limit() || reach_end_time();
  }

  double remaining_time() const;

  void set_if_better(std::string_view info);

  void set_if_better_neighbor(std::string_view info);

  void flip(vindex_t index) { flip_with_updated_vars(index, false); }

  uint64_t flip_count() const { return flip_count_; }

  template <size_t N>
  inline void update_delta_delta(
      const TermVector<N - 1>& terms,  // termN(index) の戻り（size(),
                                       // indices(i)[j], coeff(i) が使える）
      std::vector<energy_t>& delta_delta,
      int32_t flip_bit_sign)  // +1 or -1 only
  {
    static_assert(N >= 3, "N must be >= 3");

    for (size_t i = 0; i < terms.size(); ++i) {
      std::array<vindex_t, N - 1> idx{};
      std::array<uint8_t, N - 1> val{};
      uint8_t sum = 0;

      const auto inds = terms.indices(i);

      for (size_t j = 0; j < N - 1; ++j) {
        idx[j] = inds[j] & qbpp::vindex_mask;
        uint8_t v = static_cast<uint8_t>(get(idx[j]));
        if (inds[j] & qbpp::vindex_neg_bit) v = static_cast<uint8_t>(1 - v);
        val[j] = v;
        sum = static_cast<uint8_t>(sum + val[j]);
      }

      const energy_t factor = terms.coeff(i) * flip_bit_sign;

      if (sum <= static_cast<uint8_t>(N - 3)) continue;

      if (sum == static_cast<uint8_t>(N - 1)) {
        for (size_t j = 0; j < N - 1; ++j) {
          if (delta_delta[idx[j]] == 0) dirty_list_.push_back(idx[j]);
          delta_delta[idx[j]] -= factor;
        }
        continue;
      }

      // sum == (N - 2): 最初に 0 の位置へ +factor
      for (uint8_t target = 0; target < N - 1; ++target) {
        if (val[target] == 0) {
          if (delta_delta[idx[target]] == 0) dirty_list_.push_back(idx[target]);
          delta_delta[idx[target]] += factor;
          break;
        }
      }
    }
  }

  inline void update_delta_delta_dyn(const DynTermVector& terms,
                                     std::vector<energy_t>& delta_delta,
                                     int32_t flip_bit_sign) {
    const uint32_t nm1 = terms.degree_minus_one();
    const vindex_t* raw_base = terms.indices_data();
    const coeff_t* coeffs = terms.coeffs_data();
    for (size_t i = 0; i < terms.size(); ++i) {
      const vindex_t* raw_idx = raw_base + i * nm1;
      uint32_t sum = 0;
      for (uint32_t j = 0; j < nm1; ++j) {
        vindex_t base_j = raw_idx[j] & qbpp::vindex_mask;
        uint32_t v = static_cast<uint32_t>(get(base_j));
        if (raw_idx[j] & qbpp::vindex_neg_bit) v = 1 - v;
        sum += v;
      }
      if (sum <= nm1 - 2) continue;
      const energy_t factor = coeffs[i] * flip_bit_sign;
      if (sum == nm1) {
        for (uint32_t j = 0; j < nm1; ++j) {
          vindex_t base_j = raw_idx[j] & qbpp::vindex_mask;
          if (delta_delta[base_j] == 0) dirty_list_.push_back(base_j);
          delta_delta[base_j] -= factor;
        }
      } else {  // sum == nm1 - 1
        for (uint32_t j = 0; j < nm1; ++j) {
          vindex_t base_j = raw_idx[j] & qbpp::vindex_mask;
          uint32_t v = static_cast<uint32_t>(get(base_j));
          if (raw_idx[j] & qbpp::vindex_neg_bit) v = 1 - v;
          if (v == 0) {
            if (delta_delta[base_j] == 0) dirty_list_.push_back(base_j);
            delta_delta[base_j] += factor;
            break;
          }
        }
      }
    }
  }

  std::vector<vindex_t> flip_with_updated_vars(
      vindex_t index, bool track_updated_vars = false) {
    assert(index < var_count());
    std::vector<vindex_t> updated_vars;
    updated_vars.reserve(16);

    int32_t flip_bit_sign = 1 - 2 * get(index);

    auto& delta_delta = delta_delta_;
    dirty_list_.clear();

    const auto& t2 = hubo_model_.term2(index);
    for (size_t i = 0; i < t2.size(); ++i) {
      vindex_t raw_j = t2.indices(i)[0];
      vindex_t j = raw_j & qbpp::vindex_mask;
      coeff_t coeff = t2.coeff(i);
      int32_t val_j = get(j);
      if (raw_j & qbpp::vindex_neg_bit) val_j = 1 - val_j;
      if (delta_delta[j] == 0) dirty_list_.push_back(j);
      delta_delta[j] += coeff * flip_bit_sign * (1 - 2 * val_j);
    }

    auto mp = hubo_model_.max_power();
    if (mp > 2)
      update_delta_delta<3>(hubo_model_.term3(index), delta_delta,
                            flip_bit_sign);
    if (mp > 3)
      update_delta_delta<4>(hubo_model_.term4(index), delta_delta,
                            flip_bit_sign);

    // Dynamic terms for degree 5+
    for (const auto& dtv : hubo_model_.dyn_terms(index))
      update_delta_delta_dyn(dtv, delta_delta, flip_bit_sign);

    Sol::flip_bit_add_delta(index, delta_[index]);
    for (vindex_t i : dirty_list_) {
      if (delta_delta[i] == 0) continue;
      assert(i != index);
      if (track_updated_vars) {
        updated_vars.emplace_back(i);
      }
      if (delta_[i] < 0) {
        neg_set_.erase(i);
      } else if (delta_[i] > 0) {
        pos_set_.erase(i);
      }
      delta_[i] += delta_delta[i];
      delta_delta[i] = 0;
      if (delta_[i] < 0) {
        neg_set_.insert(i, delta_[i]);
      } else if (delta_[i] > 0) {
        pos_set_.insert(i, delta_[i]);
      }
    }

    if (delta_[index] < 0) {
      neg_set_.erase(index);
    } else if (delta_[index] > 0) {
      pos_set_.erase(index);
    }
    delta_[index] = -delta_[index];
    if (delta_[index] < 0) {
      neg_set_.insert(index, delta_[index]);
    } else if (delta_[index] > 0) {
      pos_set_.insert(index, delta_[index]);
    }

    tabu_.insert(index);
    ++flip_count_;
    return updated_vars;
  }

  /// @brief Greedy algorithm to flip the variables with negative deltas.
  void greedy() {
    // 0=always first, 1=always random, 2=per-flip coin toss
    uint32_t strategy = qbpp::random_gen(3u);
    while (!neg_set_.empty()) {
      if (should_stop()) {
        break;
      }
      bool use_first =
          (strategy == 0) || (strategy == 2 && qbpp::random_gen(2) == 0);
      vindex_t min_index;
      if (use_first) {
        min_index = neg_set_.first();
      } else {
        min_index = neg_set_.select_at_random();
      }
      flip(min_index);
      set_if_better(use_first ? "Greedy(first)" : "Greedy(random)");
    }
  }

  void pos_min(size_t iteration) {
    for (size_t i = 0; i < iteration; ++i) {
      if (should_stop()) {
        break;
      }
      std::optional<vindex_t> flip_index = std::nullopt;
      for (size_t j = 0; j < tabu_.capacity() * 2; ++j) {
        vindex_t candidate = vindex_limit;
        if (pos_set_.empty() || neg_set_.empty()) {
          candidate = qbpp::random_gen(var_count());
        } else if (qbpp::random_gen(neg_set_.heap_size() + 1) == 0) {
          candidate = pos_set_.first();
        } else {
          candidate = neg_set_.select_at_random();
        }
        if (candidate == vindex_limit) {
          throw std::runtime_error(THROW_MESSAGE("Unexpected error."));
        }
        if (!tabu_.has(candidate)) {
          flip_index = candidate;
          break;
        }
      }
      if (!flip_index.has_value()) {
        flip_index = tabu_.non_tabu_random();
      }
      flip(flip_index.value());
      set_if_better("PosMin");
    }
  }

  /// @brief Moves the solution toward the given destination.
  void move_to(const qbpp::Sol& destination);
  /// @brief Randomly flips the solution for the given number of iterations.
  void random_flip(size_t iteration);
};

class Sols : public qbpp::Sol {
  const std::vector<qbpp::Sol> best_sols_;

 public:
  explicit Sols(const qbpp::SolHolder& sol_holder,
                std::vector<qbpp::Sol> best_sols)
      : qbpp::Sol(sol_holder.sol()), best_sols_(best_sols) {}

  [[nodiscard]] size_t size() const noexcept { return best_sols_.size(); }

  const std::vector<qbpp::Sol>& best_sols() const noexcept {
    return best_sols_;
  }

  const std::vector<qbpp::Sol>& sols() const noexcept { return best_sols_; }

  const qbpp::Sol& operator[](size_t index) const {
    return best_sols_.at(index);
  }

  // iterator support
  auto begin() const noexcept { return best_sols_.begin(); }

  auto end() const noexcept { return best_sols_.end(); }

  auto cbegin() const noexcept { return best_sols_.cbegin(); }

  auto cend() const noexcept { return best_sols_.cend(); }
};

class EasySolver {
  const qbpp::HuboModel hubo_model_;

  double time_limit_ = kDefaultTimeLimit;

  std::optional<energy_t> target_energy_;

  std::shared_ptr<qbpp::SolHolder> all_best_sol_ptr_;

  size_t thread_count_{std::thread::hardware_concurrency() < 4
                           ? 4
                           : std::thread::hardware_concurrency()};

  bool enable_default_callback_{false};


  double start_time_;

  double base_time_{0.1};

  std::shared_ptr<BestSols> best_sols_ptr_ = std::make_shared<BestSols>(0);

  uint64_t flip_count_{0};

  mutable std::mutex flip_count_mutex_;

  double end_time_;

  void single_search(size_t thread_id);

  std::shared_ptr<qbpp::SolHolder> time_limited_best_sol_ptr_;

  void time_limited_search(double time_limit, bool use_best_sol);

  void add_flip_count(uint64_t flip_count) {
    std::lock_guard<std::mutex> lock(flip_count_mutex_);
    flip_count_ += flip_count;
  }

  mutable std::mutex cb_mutex_;
  mutable std::optional<energy_t> cb_prev_energy_;

 public:
  explicit EasySolver(const qbpp::Model& model)
      : hubo_model_(model),
        all_best_sol_ptr_(std::make_shared<qbpp::SolHolder>(hubo_model_)),
        best_sols_ptr_(std::make_shared<BestSols>(0)) {
    if (hubo_model_.term_count() == 0) {
      throw std::runtime_error(
          "The HUBO model has no terms. Please check the model.");
    }
  }

  const qbpp::HuboModel& hubo_model() const { return hubo_model_; }

  const std::shared_ptr<qbpp::SolHolder>& sol_holder_ptr() const {
    return all_best_sol_ptr_;
  }

  const qbpp::SolHolder& sol_holder() const { return *all_best_sol_ptr_; }

  const std::shared_ptr<qbpp::SolHolder>& time_limited_best_sol_ptr() const {
    return time_limited_best_sol_ptr_;
  }

  virtual ~EasySolver() = default;

  vindex_t var_count() const { return hubo_model_.var_count(); }

  void time_limit(double limit) { time_limit_ = limit; }

  void target_energy(energy_t energy) { target_energy_ = energy; }

  void base_time(double time = 0.0) { base_time_ = time; }

  bool reach_target_energy() const {
    if (!target_energy_.has_value()) {
      return false;
    }
    return all_best_sol_ptr_->energy() <= target_energy_.value();
  }

  bool reach_time_limit() const {
    if (time_limit_ == 0.0) {
      return false;
    }
    return qbpp::time() > start_time_ + time_limit_;
  }

  bool reach_end_time() const {
    if (base_time_ == 0.0) {
      return false;
    }
    return qbpp::time() >= end_time_;
  }

  bool should_stop() const {
    return reach_target_energy() || reach_time_limit() || reach_end_time();
  }

  double remaining_time() const {
    if (time_limit_ == 0.0) {
      return std::numeric_limits<double>::max();
    }
    return start_time_ + time_limit_ - qbpp::time();
  }

  const std::optional<energy_t>& target_energy() const {
    return target_energy_;
  }

  double time_limit() const { return time_limit_; }

  size_t thread_count() const { return thread_count_; }
  void thread_count(size_t count) { thread_count_ = count; }

  /// @brief Enables the default callback function.
  void enable_default_callback() { enable_default_callback_ = true; }

  uint64_t flip_count() const {
    std::lock_guard<std::mutex> lock(flip_count_mutex_);
    return flip_count_;
  }

  double tts() const { return all_best_sol_ptr_->tts(); }

  /// @brief Callback function called when the best solution is updated.
  /// @param sol The best solution.
  /// @param tts The time to solution.
  virtual void callback(const qbpp::Sol& sol, double tts,
                        std::string_view info) const {
    std::lock_guard<std::mutex> lock(cb_mutex_);
    if (enable_default_callback_) {
      if (!cb_prev_energy_.has_value() ||
          sol.energy() < cb_prev_energy_.value()) {
        std::cout << "TTS = " << std::fixed << std::setprecision(3)
                  << std::setfill('0') << tts << "s Energy = " << sol.energy()
                  << " thread = "
                  << tbb::this_task_arena::current_thread_index() << " " << info
                  << std::endl;
        cb_prev_energy_ = sol.energy();
      }
    }
  }

  void enable_best_energy_sols(size_t capacity = 0) {
    best_sols_ptr_ = std::make_shared<BestSols>(capacity, SavePolicy::BestSolsOnly);
  }

  void enable_topk_sols(size_t capacity) {
    best_sols_ptr_ = std::make_shared<BestSols>(capacity, SavePolicy::All);
  }

  std::shared_ptr<BestSols>& best_sols_ptr() { return best_sols_ptr_; }
  const std::shared_ptr<BestSols>& best_sols_ptr() const {
    return best_sols_ptr_;
  }

  const std::vector<qbpp::Sol>& best_sols() const {
    return best_sols_ptr_->sol_vector();
  }

  /// @brief Executes the PositiveMin search algorithm.
  /// @return The best solution found.
  Sols search(bool has_initial_sol = false);

  /// @brief Executes the PositiveMin search algorithm with the specified
  /// initial solution
  /// @param initial_sol Initial solution to be written in the best
  /// solution.
  qbpp::Sol search(const qbpp::Sol& initial_sol) {
    all_best_sol_ptr_->sol(initial_sol);
    return search(true);
  }

};

//=====================================
// Class EasySolver member functions
//=====================================

inline void EasySolver::single_search(size_t thread_id) {
  const size_t min_flip_count = 100;
  size_t max_flip_count = (var_count() / 2);
  SolDelta sol_delta(*this, thread_id, thread_count_);
  if (thread_count_ > 1) {
    // if multiple threads are used, the max_flip_count is varied from
    // min_flip_count to var_count/2 in an exponential manner.
    double k = std::pow(static_cast<double>(max_flip_count) / min_flip_count,
                        1.0 / static_cast<double>(thread_count_ - 1));
    max_flip_count =
        static_cast<size_t>(min_flip_count * std::pow(k, thread_id));
    if (max_flip_count < min_flip_count) max_flip_count = min_flip_count;
  }
  energy_t prev_energy = time_limited_best_sol_ptr_->energy();
  size_t random_flip_count = 1;

  if (thread_id % 2) {
    sol_delta.set_all_one();
  }

  while (!should_stop()) {
    sol_delta.random_flip(random_flip_count);
    sol_delta.greedy();
    sol_delta.move_to(*time_limited_best_sol_ptr_);
    sol_delta.random_flip(random_flip_count);
    sol_delta.greedy();
    sol_delta.pos_min(max_flip_count);
    sol_delta.greedy();
    sol_delta.random_flip(random_flip_count);
    sol_delta.greedy();

    if (prev_energy == time_limited_best_sol_ptr_->energy()) {
      // if the energy is not updated, the random_flip_count is increased
      random_flip_count = (random_flip_count + 1) % (max_flip_count / 2);
      if (random_flip_count == 0) random_flip_count = 1;
    } else {
      random_flip_count = 1;
    }
    prev_energy = time_limited_best_sol_ptr_->energy();
  }

  add_flip_count(sol_delta.flip_count());
}

inline void EasySolver::time_limited_search(double duration,
                                            bool use_best_sol) {
  end_time_ = qbpp::time() + duration;
  if (should_stop()) {
    return;
  }
  if (use_best_sol) {
    time_limited_best_sol_ptr_ =
        std::make_shared<qbpp::SolHolder>(all_best_sol_ptr_->sol());
  } else {
    time_limited_best_sol_ptr_ = std::make_shared<qbpp::SolHolder>(hubo_model_);
  }
  tbb::parallel_for(size_t(0), static_cast<size_t>(thread_count_),
                    [&](size_t thread_id) { single_search(thread_id); });
}

inline double compute_duration(size_t index, double base) {
  uint32_t k = static_cast<uint32_t>(
      std::ceil((std::sqrt(1 + 8.0 * static_cast<double>(index + 1)) - 1) / 2));

  uint32_t position = static_cast<uint32_t>(index) - k * (k - 1) / 2;

  return base * static_cast<double>(1ull << std::min(position, uint32_t(63)));
}

inline Sols EasySolver::search(bool has_initial_sol) {
  if (!has_initial_sol) {
    all_best_sol_ptr_ = std::make_shared<qbpp::SolHolder>(hubo_model_);
  }
  cb_prev_energy_ = std::nullopt;
  start_time_ = qbpp::time();

  for (size_t i = 0;; ++i) {
    if (reach_time_limit() || reach_target_energy()) break;
    double duration = compute_duration(i, base_time_);
    time_limited_search(duration, false);
    time_limited_search(duration, true);
  }
  return Sols(*all_best_sol_ptr_, best_sols_ptr_->sol_vector());
}

//=====================================
// Class SolDelta member functions
//=====================================

inline SolDelta::SolDelta(const EasySolver& easy_solver, size_t /*thread_id*/,
                          size_t /*thread_count*/)
    : Sol(easy_solver.hubo_model()),
      easy_solver_(easy_solver),
      hubo_model_(easy_solver_.hubo_model()),
      delta_(var_count()),
      neg_set_(var_count()),
      pos_set_(var_count()),
      delta_delta_(var_count(), 0),
      tabu_(var_count(), std::min(static_cast<vindex_t>(7), var_count() / 2)),
      all_best_sol_ptr_(easy_solver_.sol_holder_ptr()),
      time_limited_best_sol_ptr_(easy_solver_.time_limited_best_sol_ptr()) {
  // Initial delta at all-zeros state.
  // For quadratic+ terms, contributions exist only when ALL secondary
  // variables are negated (effective value 1 at all-zeros).
  for (vindex_t i = 0; i < var_count(); ++i) {
    delta_[i] = hubo_model_.term1(i);
    const auto& t2 = hubo_model_.term2(i);
    for (size_t j = 0; j < t2.size(); ++j) {
      if (t2.indices(j)[0] & qbpp::vindex_neg_bit)
        delta_[i] += t2.coeff(j);
    }
    const auto& t3 = hubo_model_.term3(i);
    for (size_t j = 0; j < t3.size(); ++j) {
      const auto& inds = t3.indices(j);
      if ((inds[0] & qbpp::vindex_neg_bit) && (inds[1] & qbpp::vindex_neg_bit))
        delta_[i] += t3.coeff(j);
    }
    const auto& t4 = hubo_model_.term4(i);
    for (size_t j = 0; j < t4.size(); ++j) {
      const auto& inds = t4.indices(j);
      if ((inds[0] & qbpp::vindex_neg_bit) &&
          (inds[1] & qbpp::vindex_neg_bit) &&
          (inds[2] & qbpp::vindex_neg_bit))
        delta_[i] += t4.coeff(j);
    }
    for (const auto& dtv : hubo_model_.dyn_terms(i)) {
      const uint32_t nm1 = dtv.degree_minus_one();
      const vindex_t* dbase = dtv.indices_data();
      for (uint32_t j = 0; j < dtv.size(); ++j) {
        const vindex_t* idx = dbase + static_cast<size_t>(j) * nm1;
        bool all_neg = true;
        for (uint32_t k = 0; k < nm1; ++k) {
          if (!(idx[k] & qbpp::vindex_neg_bit)) { all_neg = false; break; }
        }
        if (all_neg) delta_[i] += dtv.coeffs_[j];
      }
    }
    if (delta_[i] < 0) {
      neg_set_.insert(i, delta_[i]);
    } else if (delta_[i] > 0) {
      pos_set_.insert(i, delta_[i]);
    }
  }

}

inline void SolDelta::move_to(const Sol& destination) {
  misc::MinHeap to_be_flipped(var_count());
  for (vindex_t i = 0; i < var_count(); ++i) {
    if (should_stop()) {
      break;
    }
    if (get(i) != destination.get(i)) {
      to_be_flipped.insert(i, delta_[i]);
    }
  }
  while (!to_be_flipped.empty()) {
    if (should_stop()) {
      break;
    }
    vindex_t min_index = to_be_flipped.pop_first();
    std::vector<vindex_t> updated_vars =
        flip_with_updated_vars(min_index, true);
    set_if_better("MoveTo");
    for (const auto& index : updated_vars) {
      if (to_be_flipped.has(index)) {
        to_be_flipped.erase(index);
        to_be_flipped.insert(index, delta_[index]);
      }
    }
  }
}

inline void SolDelta::random_flip(size_t iteration) {
  for (vindex_t i = 0; i < iteration; ++i) {
    if (should_stop()) {
      break;
    }
    vindex_t flip_index = qbpp::random_gen(var_count());
    flip(flip_index);
    set_if_better("Random");
  }
}

inline void SolDelta::set_if_better(std::string_view info) {
  if (time_limited_best_sol_ptr_->set_if_better(*this, std::string(info))) {
    std::optional<double> tts =
        all_best_sol_ptr_->set_if_better(*this, std::string(info));
    if (tts.has_value()) {
      easy_solver_.callback(*this, tts.value(), info);
    }
    set_if_better_neighbor(info);
    if (easy_solver_.best_sols_ptr() != nullptr) {
      easy_solver_.best_sols_ptr()->insert_if_better(*this, neg_set_, pos_set_);
    }
  }
}

inline void SolDelta::set_if_better_neighbor(std::string_view info) {
  if (neg_set_.empty()) {
    return;
  }
  const auto& [min_delta, min_index] = neg_set_.min();
  if (energy() + min_delta < all_best_sol_ptr_->energy()) {
    Sol temp_sol = *this;
    temp_sol.flip_bit_add_delta(min_index, min_delta);
    std::string neighbor_info = std::string(info) + "(neighbor)";
    std::optional<double> tts =
        all_best_sol_ptr_->set_if_better(temp_sol, neighbor_info);
    if (tts.has_value()) {
      easy_solver_.callback(temp_sol, tts.value(), neighbor_info);
    }
  }
}

inline bool SolDelta::reach_time_limit() const {
  return easy_solver_.reach_time_limit();
}

inline double SolDelta::remaining_time() const {
  return easy_solver_.remaining_time();
}

inline bool SolDelta::reach_target_energy() const {
  return easy_solver_.reach_target_energy();
}

inline bool SolDelta::reach_end_time() const {
  return easy_solver_.reach_end_time();
}

}  // namespace easy_solver

}  // namespace qbpp
