/// @file qbpp_abs3_solver.hpp
/// @brief Header file for the ABS3 solver
/// @author Koji Nakano
/// @version 2026.02.22

#pragma once

#include <dlfcn.h>

#include "qbpp.hpp"

#define MAXPARAM 100

namespace qbpp {
namespace abs3 {

class ABS3Solver;

class Params {
  struct Pair {
    char* key;
    char* value;
  };
  Pair pairs_[MAXPARAM];

  Params(const Params&) = delete;
  Params(Params&&) = delete;
  Params& operator=(const Params&) = delete;
  Params& operator=(Params&&) = delete;

 public:
  Params() {
    for (int i = 0; i < MAXPARAM; i++) {
      pairs_[i].key = nullptr;
      pairs_[i].value = nullptr;
    }
  }
  ~Params() {
    for (int i = 0; i < MAXPARAM; i++) {
      if (pairs_[i].key != nullptr) {
        free(pairs_[i].key);
        pairs_[i].key = nullptr;
      }
      if (pairs_[i].value != nullptr) {
        free(pairs_[i].value);
        pairs_[i].value = nullptr;
      }
    }
  }

  void operator()(const char* key, const std::string& value) {
    add(key, value.c_str());
  }

  void add(const char* key, const std::string& value) {
    add(key, value.c_str());
  }

  void add(const char* key, const char* value) {
    if (pairs_[MAXPARAM - 1].key != nullptr) {
      throw std::runtime_error("Param overflow");
    }
    for (int i = 0; i < MAXPARAM; i++) {
      if (pairs_[i].key == nullptr && pairs_[i].value == nullptr) {
        pairs_[i].key = strdup(key);
        if (pairs_[i].key == nullptr) {
          throw std::runtime_error("strdup failed");
        }
        pairs_[i].value = strdup(value);
        if (pairs_[i].value == nullptr) {
          throw std::runtime_error("strdup failed");
        }
        break;
      }
    }
  }

  const Pair pairs(size_t i) const { return pairs_[i]; }
};

//=======================================
// カーネル引数
//=======================================

/// @brief ABS3内で解を表すクラス
/// @note ABI互換のためポインタのみのクラスとして定義
class ABS3Sol {
  /// @brief 変数の数
  qbpp::vindex_t* var_count_ptr_;
  /// @brief 64ビットでのワード数
  qbpp::vindex_t* size64_ptr_;
  /// @brief 解のIDを指すポインタ
  uint64_t* id_ptr_;
  /// @brief エネルギーを指すポインタ
  qbpp::energy_t* energy_ptr_;
  /// @brief ビット配列を指すポインタ
  uint64_t* bitarray_;
  /// @brief 解を得た時間
  double* tts_ptr_;
  /// @brief 1の数
  qbpp::vindex_t* popcount_ptr_;

 public:
  /// @brief コンストラクタ
  /// @details bitarray_の領域を確保する．
  ABS3Sol(qbpp::vindex_t var_count) {
    var_count_ptr_ = new qbpp::vindex_t;
    size64_ptr_ = new qbpp::vindex_t;
    *var_count_ptr_ = var_count;
    *size64_ptr_ = (var_count + 63) / 64;
    id_ptr_ = new uint64_t;
    energy_ptr_ = new qbpp::energy_t;
    bitarray_ = new uint64_t[*size64_ptr_];
    std::fill(bitarray_, bitarray_ + *size64_ptr_, 0ULL);
    tts_ptr_ = new double;
    popcount_ptr_ = new qbpp::vindex_t;
  }

  /// @brief コピーコンストラクタは禁止
  ABS3Sol(const ABS3Sol&) = delete;
  /// @brief 代入は禁止
  ABS3Sol& operator=(const ABS3Sol&) = delete;

  /// @brief ムーブコンストラクタ
  /// @note returnする際にムーブするため．
  ABS3Sol(ABS3Sol&& other) noexcept
      : var_count_ptr_(other.var_count_ptr_),
        size64_ptr_(other.size64_ptr_),
        id_ptr_(other.id_ptr_),
        energy_ptr_(other.energy_ptr_),
        bitarray_(other.bitarray_),
        tts_ptr_(other.tts_ptr_),
        popcount_ptr_(other.popcount_ptr_) {
    other.var_count_ptr_ = nullptr;
    other.size64_ptr_ = nullptr;
    other.id_ptr_ = nullptr;
    other.energy_ptr_ = nullptr;
    other.bitarray_ = nullptr;
    other.tts_ptr_ = nullptr;
    other.popcount_ptr_ = nullptr;
  }

  /// @brief ムーブ代入演算子
  ABS3Sol& operator=(ABS3Sol&& other) noexcept {
    if (this != &other) {
      assert(var_count_ptr_ != nullptr);
      assert(size64_ptr_ != nullptr);
      assert(id_ptr_ != nullptr);
      assert(energy_ptr_ != nullptr);
      assert(bitarray_ != nullptr);
      assert(tts_ptr_ != nullptr);
      assert(popcount_ptr_ != nullptr);
      delete var_count_ptr_;
      delete size64_ptr_;
      delete id_ptr_;
      delete energy_ptr_;
      delete[] bitarray_;
      delete tts_ptr_;
      delete popcount_ptr_;
      id_ptr_ = other.id_ptr_;
      energy_ptr_ = other.energy_ptr_;
      bitarray_ = other.bitarray_;
      tts_ptr_ = other.tts_ptr_;
      popcount_ptr_ = other.popcount_ptr_;
      var_count_ptr_ = other.var_count_ptr_;
      size64_ptr_ = other.size64_ptr_;
      other.id_ptr_ = nullptr;
      other.energy_ptr_ = nullptr;
      other.bitarray_ = nullptr;
      other.tts_ptr_ = nullptr;
      other.popcount_ptr_ = nullptr;
      other.var_count_ptr_ = nullptr;
      other.size64_ptr_ = nullptr;
    }
    return *this;
  }

  /// @brief デストラクタ．
  /// @note 全領域を開放する．
  ~ABS3Sol() {
    delete var_count_ptr_;
    delete size64_ptr_;
    delete id_ptr_;
    delete energy_ptr_;
    delete[] bitarray_;
    delete tts_ptr_;
    delete popcount_ptr_;
  }

  /// @brief id_の参照を返す
  uint64_t& id() { return *id_ptr_; }
  /// @brief id_のconst参照を返す
  const uint64_t& id() const { return *id_ptr_; }

  /// @brief energy_の参照を返す
  qbpp::energy_t& energy() { return *energy_ptr_; }
  /// @brief energy_のconst参照を返す
  const qbpp::energy_t& energy() const { return *energy_ptr_; }

  /// @brief bitarray_のポインタを返す
  uint64_t* bitarray() { return bitarray_; }
  /// @brief bitarray_のポインタを返す
  const uint64_t* bitarray() const { return bitarray_; }

  /// @brief bitarray_[i]の参照を返す
  uint64_t& bitarray(size_t i) { return bitarray_[i]; }
  /// @brief bitarray_[i]のconst参照を返す
  const uint64_t& bitarray(size_t i) const { return bitarray_[i]; }

  double& tts() { return *tts_ptr_; }

  const double& tts() const { return *tts_ptr_; }

  qbpp::vindex_t& popcount() { return *popcount_ptr_; }

  const qbpp::vindex_t& popcount() const { return *popcount_ptr_; }

  /// @brief bitarray_のi番目のビットを返す．
  bool get(qbpp::vindex_t index) const {
    assert(index < *var_count_ptr_);
    return (bitarray_[index / 64] & (1ULL << (index % 64))) != 0;
  }

  /// @brief bitarray_のi番目のビットを設定する．
  void set(qbpp::vindex_t index, bool value) {
    assert(index < *var_count_ptr_);
    if (value) {
      bitarray_[index / 64] |= (1ULL << (index % 64));
    } else {
      bitarray_[index / 64] &= ~(1ULL << (index % 64));
    }
  }

  /// @brief bitarray_のi番目のビットを反転する．
  bool flip(qbpp::vindex_t index) {
    assert(index < *var_count_ptr_);
    bitarray_[index / 64] ^= (1ULL << (index % 64));
    return get(index);
  }
};

// ===================================
// dlopen自動ディスパッチ
// ===================================

namespace detail {

/// @brief sizeof(coeff_t) と sizeof(energy_t) から .so ファイル名を決定
inline const char* abs3_lib_name() {
  constexpr size_t cs = sizeof(coeff_t);
  constexpr size_t es = sizeof(energy_t);
  if constexpr (cs == 2 && es == 4) return "libabs3c16e32.so";
  if constexpr (cs == 4 && es == 4) return "libabs3c32e32.so";
  if constexpr (cs == 4 && es == 8) return "libabs3c32e64.so";
  if constexpr (cs == 8 && es == 8) return "libabs3c64e64.so";
  if constexpr (cs == 8 && es == 16) return "libabs3c64e128.so";
  if constexpr (cs == 16 && es == 16) return "libabs3c128e128.so";
  static_assert((cs == 2 && es == 4) || (cs == 4 && es == 4) ||
                    (cs == 4 && es == 8) || (cs == 8 && es == 8) ||
                    (cs == 8 && es == 16) || (cs == 16 && es == 16),
                "No ABS3 variant for this coeff_t/energy_t combination");
  return nullptr;
}

// 関数ポインタ型
using init_fn = int (*)();
using prop_name_fn = const char* (*)(int);
using prop_mp_fn = int (*)(int);
using create_fn = void* (*)(const ABS3Solver*, const FlatHuboModel*, uint32_t);
using destroy_fn = void (*)(void*);
using search_fn = void* (*)(void*, ABS3Sol*, const Params*);
using register_cb_fn = void (*)(void (*)(const ABS3Solver*, const ABS3Sol*));
using list_count_fn = size_t (*)(void*);
using list_get_fn = void (*)(void*, size_t, ABS3Sol*);
using list_destroy_fn = void (*)(void*);

struct ABS3Dispatch {
  void* handle = nullptr;
  init_fn init = nullptr;
  prop_name_fn prop_name = nullptr;
  prop_mp_fn prop_mp = nullptr;
  create_fn create = nullptr;
  destroy_fn destroy = nullptr;
  search_fn search = nullptr;
  register_cb_fn register_cb = nullptr;
  list_count_fn list_count = nullptr;
  list_get_fn list_get = nullptr;
  list_destroy_fn list_destroy = nullptr;
};

/// @brief .soへの関数ポインタを管理するシングルトン
inline ABS3Dispatch& dispatch() {
  static ABS3Dispatch inst = [] {
    ABS3Dispatch d;
    d.handle = dlopen(abs3_lib_name(), RTLD_NOW);
    if (!d.handle) {
      throw std::runtime_error(std::string("ABS3: failed to load ") +
                               abs3_lib_name() + ": " + dlerror());
    }
    auto sym = [&](const char* name) {
      void* s = dlsym(d.handle, name);
      if (!s)
        throw std::runtime_error(std::string("ABS3: symbol not found: ") +
                                 name + ": " + dlerror());
      return s;
    };
    d.init = reinterpret_cast<init_fn>(sym("qbpp_abs3_init"));
    d.prop_name =
        reinterpret_cast<prop_name_fn>(sym("qbpp_abs3_device_prop_name"));
    d.prop_mp = reinterpret_cast<prop_mp_fn>(
        sym("qbpp_abs3_device_prop_multiProcessorCount"));
    d.create = reinterpret_cast<create_fn>(sym("qbpp_abs3_solver_create"));
    d.destroy = reinterpret_cast<destroy_fn>(sym("qbpp_abs3_solver_destroy"));
    d.search = reinterpret_cast<search_fn>(sym("qbpp_abs3_solver_search"));
    d.register_cb =
        reinterpret_cast<register_cb_fn>(sym("qbpp_abs3_register_callback"));
    d.list_count =
        reinterpret_cast<list_count_fn>(sym("qbpp_abs3_sol_list_count"));
    d.list_get = reinterpret_cast<list_get_fn>(sym("qbpp_abs3_sol_list_get"));
    d.list_destroy =
        reinterpret_cast<list_destroy_fn>(sym("qbpp_abs3_sol_list_destroy"));
    return d;
  }();
  return inst;
}

}  // namespace detail

// ===================================
// ABS3Solverのデバイス情報関数
// ===================================

/// @brief GPUの情報取得初期化を行う．
inline int init() { return detail::dispatch().init(); }

/// @brief GPUデバイスのプロパティ名を取得する関数
inline std::string device_prop_name(int device_id = 0) {
  return std::string(detail::dispatch().prop_name(device_id));
}

/// @brief GPUデバイスのプロパティのマルチプロセッサ数を取得する関数
inline int device_prop_multiProcessorCount(int device_id = 0) {
  return detail::dispatch().prop_mp(device_id);
}

// ===================================
// Sol クラス
// ===================================

class Sol : public qbpp::Sol {
 public:
  /// @brief コンストラクタ
  Sol(const qbpp::Model& model, const qbpp::energy_t& energy,
      const uint64_t* bitarray, double tts)
      : qbpp::Sol(model, energy, bitarray, tts) {}
};

// ===================================
// ABS3Sols クラス (Sol + top-k solutions)
// ===================================

/// @brief Solution container with top-k solutions
/// @details Inherits from Sol (the best solution found) and additionally
/// stores a collection of top-k solutions sorted by energy ascending.
class ABS3Sols : public Sol {
  std::vector<qbpp::Sol> best_sols_;

 public:
  ABS3Sols(const qbpp::Model& model, const qbpp::energy_t& energy,
           const uint64_t* bitarray, double tts,
           std::vector<qbpp::Sol> best_sols)
      : Sol(model, energy, bitarray, tts),
        best_sols_(std::move(best_sols)) {}

  /// @brief Number of top-k solutions collected
  [[nodiscard]] size_t size() const noexcept { return best_sols_.size(); }

  /// @brief Access the top-k solutions vector
  const std::vector<qbpp::Sol>& best_sols() const noexcept {
    return best_sols_;
  }

  /// @brief Alias for best_sols()
  const std::vector<qbpp::Sol>& sols() const noexcept { return best_sols_; }

  /// @brief Index access
  const qbpp::Sol& operator[](size_t index) const {
    return best_sols_.at(index);
  }

  // Iterator support
  auto begin() const noexcept { return best_sols_.begin(); }
  auto end() const noexcept { return best_sols_.end(); }
  auto cbegin() const noexcept { return best_sols_.cbegin(); }
  auto cend() const noexcept { return best_sols_.cend(); }
};

// ===================================
// ABS3Solverクラス
// ===================================

/// @brief ABS3ソルバークラス
/// @details ABS3solverが対象とするHuboModelを指定する．
/// @note 前処理でFlatHuboModelを生成し、内部でそれを保持する．
class ABS3Solver {
  qbpp::Model model_;
  /// @brief 対象とするHuboModel
  const qbpp::HuboModel hubo_model_;
  /// @brief フラットなHUBOモデルを指すポインタ
  const qbpp::FlatHuboModel flat_hubo_model_;
  ///  @brief バイナリのソルバーオブジェクトABS3SolverImplを指すポインタ
  void* pimpl_;

  /// @brief デフォルトコンストラクタは禁止
  ABS3Solver() = delete;
  /// @brief コピーコンストラクタと代入演算子は禁止
  ABS3Solver(const ABS3Solver&) = delete;
  /// @brief コピーコンストラクタと代入演算子は禁止
  ABS3Solver& operator=(const ABS3Solver&) = delete;

 public:
  /// @brief コンストラクタ
  /// @details 対象とするHuboModelを引数とする．
  explicit ABS3Solver(const Model& model, uint32_t device_count = 0)
      : model_(model),
        hubo_model_(HuboModel(model)),
        flat_hubo_model_(FlatHuboModel(hubo_model_)),
        pimpl_(nullptr) {
    // コールバック登録（一度だけ）
    static bool cb_registered = false;
    if (!cb_registered) {
      detail::dispatch().register_cb(solver_callback_impl_);
      cb_registered = true;
    }
    pimpl_ = detail::dispatch().create(static_cast<ABS3Solver*>(this),
                                       &flat_hubo_model_, device_count);
  }

  explicit ABS3Solver(const Expr& expr, uint32_t device_count)
      : ABS3Solver(Model(expr), device_count) {}
  /// @brief デストラクタ
  /// @details ソルバーオブジェクトを破棄する．
  virtual ~ABS3Solver() noexcept { detail::dispatch().destroy(pimpl_); }

  ABS3Sols search(const Params& params) {
    ABS3Sol sol(model_.var_count());
    void* topk_list = detail::dispatch().search(pimpl_, &sol, &params);
    std::vector<qbpp::Sol> best_sols;
    if (topk_list) {
      size_t count = detail::dispatch().list_count(topk_list);
      best_sols.reserve(count);
      for (size_t i = 0; i < count; ++i) {
        ABS3Sol asol(model_.var_count());
        detail::dispatch().list_get(topk_list, i, &asol);
        best_sols.emplace_back(
            qbpp::Sol(model_, asol.energy(), asol.bitarray(), asol.tts()));
      }
      detail::dispatch().list_destroy(topk_list);
    }
    return ABS3Sols(model_, sol.energy(), sol.bitarray(), sol.tts(),
                    std::move(best_sols));
  }

  virtual void callback(const ABS3Sol& sol) const {
    std::cout << "TTS = " << std::fixed << std::setprecision(3)
              << std::setfill('0') << sol.tts() << "s Energy = " << sol.energy()
              << std::endl;
  }

 private:
  /// @brief コールバック実装（.soから呼び出される）
  static void solver_callback_impl_(const ABS3Solver* abs3solver,
                                    const ABS3Sol* sol) {
    abs3solver->callback(*sol);
  }
};

}  // namespace abs3

}  // namespace qbpp
