/// @file qbpp_power_solver.hpp
/// @brief Header file for the PowerSolver
/// @details PowerSolver is a high-performance HUBO solver that uses
/// advanced search algorithms with solution pool management.
/// The algorithm is implemented in a shared library (.so) for
/// distribution without exposing the implementation details.
/// @author Koji Nakano
/// @version 2026.03.02

#pragma once

#include <dlfcn.h>

#include "qbpp.hpp"

#ifndef QBPP_POWER_MAXPARAM
#define QBPP_POWER_MAXPARAM 100
#endif

namespace qbpp {
namespace power_solver {

class PowerSolver;

/// @brief Parameter container for PowerSolver
/// @details Stores key-value string pairs for passing parameters across
/// the .so boundary. Uses C strings for ABI safety.
/// Supported parameters:
///   - "time_limit": Search time limit in seconds (default: 10.0)
///   - "thread_count": Number of threads (default: hardware_concurrency)
///   - "target_energy": Stop when energy reaches this value (optional)
///   - "base_time": Base time for restart schedule (default: 0.1)
///   - "verbose": Verbosity level 0/1 (default: 0)
///   - "topk_sols": Top-k solution collection capacity (0 = unlimited)
///   - "best_energy_sols": Best-energy-only solution collection capacity
///                         (0 = unlimited). Only retains solutions with the
///                         best (lowest) energy found.
class Params {
  struct Pair {
    char* key;
    char* value;
  };
  Pair pairs_[QBPP_POWER_MAXPARAM];

  Params(const Params&) = delete;
  Params(Params&&) = delete;
  Params& operator=(const Params&) = delete;
  Params& operator=(Params&&) = delete;

 public:
  Params() {
    for (int i = 0; i < QBPP_POWER_MAXPARAM; i++) {
      pairs_[i].key = nullptr;
      pairs_[i].value = nullptr;
    }
  }

  ~Params() {
    for (int i = 0; i < QBPP_POWER_MAXPARAM; i++) {
      if (pairs_[i].key != nullptr) {
        free(pairs_[i].key);
        pairs_[i].key = nullptr;
      }
      if (pairs_[i].value != nullptr) {
        free(pairs_[i].value);
        pairs_[i].value = nullptr;
      }
    }
  }

  void operator()(const char* key, const std::string& value) {
    add(key, value.c_str());
  }

  void add(const char* key, const std::string& value) {
    add(key, value.c_str());
  }

  void add(const char* key, const char* value) {
    if (pairs_[QBPP_POWER_MAXPARAM - 1].key != nullptr) {
      throw std::runtime_error("Param overflow");
    }
    for (int i = 0; i < QBPP_POWER_MAXPARAM; i++) {
      if (pairs_[i].key == nullptr && pairs_[i].value == nullptr) {
        pairs_[i].key = strdup(key);
        if (pairs_[i].key == nullptr) {
          throw std::runtime_error("strdup failed");
        }
        pairs_[i].value = strdup(value);
        if (pairs_[i].value == nullptr) {
          throw std::runtime_error("strdup failed");
        }
        break;
      }
    }
  }

  const Pair pairs(size_t i) const { return pairs_[i]; }
};

/// @brief ABI-safe solution container for PowerSolver
/// @details All members are pointers for safe passing across .so boundary.
/// Layout is identical to ABS3Sol.
class PowerSol {
  qbpp::vindex_t* var_count_ptr_;
  qbpp::vindex_t* size64_ptr_;
  uint64_t* id_ptr_;
  qbpp::flat_energy_t* energy_ptr_;
  uint64_t* bitarray_;
  double* tts_ptr_;
  qbpp::vindex_t* popcount_ptr_;

 public:
  /// @brief Constructor - allocates all members
  PowerSol(qbpp::vindex_t var_count) {
    var_count_ptr_ = new qbpp::vindex_t;
    size64_ptr_ = new qbpp::vindex_t;
    *var_count_ptr_ = var_count;
    *size64_ptr_ = (var_count + 63) / 64;
    id_ptr_ = new uint64_t;
    energy_ptr_ = new qbpp::flat_energy_t;
    bitarray_ = new uint64_t[*size64_ptr_];
    std::fill(bitarray_, bitarray_ + *size64_ptr_, 0ULL);
    tts_ptr_ = new double;
    popcount_ptr_ = new qbpp::vindex_t;
  }

  /// @brief Copy is disabled
  PowerSol(const PowerSol&) = delete;
  PowerSol& operator=(const PowerSol&) = delete;

  /// @brief Move constructor
  PowerSol(PowerSol&& other) noexcept
      : var_count_ptr_(other.var_count_ptr_),
        size64_ptr_(other.size64_ptr_),
        id_ptr_(other.id_ptr_),
        energy_ptr_(other.energy_ptr_),
        bitarray_(other.bitarray_),
        tts_ptr_(other.tts_ptr_),
        popcount_ptr_(other.popcount_ptr_) {
    other.var_count_ptr_ = nullptr;
    other.size64_ptr_ = nullptr;
    other.id_ptr_ = nullptr;
    other.energy_ptr_ = nullptr;
    other.bitarray_ = nullptr;
    other.tts_ptr_ = nullptr;
    other.popcount_ptr_ = nullptr;
  }

  /// @brief Move assignment
  PowerSol& operator=(PowerSol&& other) noexcept {
    if (this != &other) {
      delete var_count_ptr_;
      delete size64_ptr_;
      delete id_ptr_;
      delete energy_ptr_;
      delete[] bitarray_;
      delete tts_ptr_;
      delete popcount_ptr_;
      var_count_ptr_ = other.var_count_ptr_;
      size64_ptr_ = other.size64_ptr_;
      id_ptr_ = other.id_ptr_;
      energy_ptr_ = other.energy_ptr_;
      bitarray_ = other.bitarray_;
      tts_ptr_ = other.tts_ptr_;
      popcount_ptr_ = other.popcount_ptr_;
      other.var_count_ptr_ = nullptr;
      other.size64_ptr_ = nullptr;
      other.id_ptr_ = nullptr;
      other.energy_ptr_ = nullptr;
      other.bitarray_ = nullptr;
      other.tts_ptr_ = nullptr;
      other.popcount_ptr_ = nullptr;
    }
    return *this;
  }

  ~PowerSol() {
    delete var_count_ptr_;
    delete size64_ptr_;
    delete id_ptr_;
    delete energy_ptr_;
    delete[] bitarray_;
    delete tts_ptr_;
    delete popcount_ptr_;
  }

  uint64_t& id() { return *id_ptr_; }
  const uint64_t& id() const { return *id_ptr_; }

  qbpp::flat_energy_t& energy() { return *energy_ptr_; }
  const qbpp::flat_energy_t& energy() const { return *energy_ptr_; }

  uint64_t* bitarray() { return bitarray_; }
  const uint64_t* bitarray() const { return bitarray_; }

  uint64_t& bitarray(size_t i) { return bitarray_[i]; }
  const uint64_t& bitarray(size_t i) const { return bitarray_[i]; }

  double& tts() { return *tts_ptr_; }
  const double& tts() const { return *tts_ptr_; }

  qbpp::vindex_t& popcount() { return *popcount_ptr_; }
  const qbpp::vindex_t& popcount() const { return *popcount_ptr_; }

  bool get(qbpp::vindex_t index) const {
    assert(index < *var_count_ptr_);
    return (bitarray_[index / 64] & (1ULL << (index % 64))) != 0;
  }

  void set(qbpp::vindex_t index, bool value) {
    assert(index < *var_count_ptr_);
    if (value) {
      bitarray_[index / 64] |= (1ULL << (index % 64));
    } else {
      bitarray_[index / 64] &= ~(1ULL << (index % 64));
    }
  }

  bool flip(qbpp::vindex_t index) {
    assert(index < *var_count_ptr_);
    bitarray_[index / 64] ^= (1ULL << (index % 64));
    return get(index);
  }
};

// ===================================
// dlopen自動ディスパッチ
// ===================================

namespace detail {

/// @brief cpp_int かどうかの判定
constexpr bool is_cpp_int_mode =
    std::is_same_v<coeff_t, qbpp::cpp_int> &&
    std::is_same_v<energy_t, qbpp::cpp_int>;

/// @brief coeff_t/energy_t から .so ファイル名を決定
/// @details cpp_int の場合は型名で判定，それ以外は sizeof で判定
inline const char* power_lib_name() {
  if constexpr (is_cpp_int_mode) return "libqbpp_powercpp_int.so";
  constexpr size_t cs = sizeof(coeff_t);
  constexpr size_t es = sizeof(energy_t);
  if constexpr (cs == 2 && es == 4) return "libqbpp_powerc16e32.so";
  if constexpr (cs == 4 && es == 4) return "libqbpp_powerc32e32.so";
  if constexpr (cs == 4 && es == 8) return "libqbpp_powerc32e64.so";
  if constexpr (cs == 8 && es == 8) return "libqbpp_powerc64e64.so";
  if constexpr (cs == 8 && es == 16) return "libqbpp_powerc64e128.so";
  if constexpr (cs == 16 && es == 16) return "libqbpp_powerc128e128.so";
  static_assert(is_cpp_int_mode ||
                    (cs == 2 && es == 4) || (cs == 4 && es == 4) ||
                    (cs == 4 && es == 8) || (cs == 8 && es == 8) ||
                    (cs == 8 && es == 16) || (cs == 16 && es == 16),
                "No PowerSolver variant for this coeff_t/energy_t combination");
  return nullptr;
}

// 関数ポインタ型
using create_fn = void* (*)(const PowerSolver*, const FlatHuboModel*);
using destroy_fn = void (*)(void*);
using search_fn = void* (*)(void*, PowerSol*, const Params*);
using register_cb_fn = void (*)(void (*)(const PowerSolver*, const PowerSol*));
using list_count_fn = size_t (*)(void*);
using list_get_fn = void (*)(void*, size_t, PowerSol*);
using list_destroy_fn = void (*)(void*);

struct PowerDispatch {
  void* handle = nullptr;
  create_fn create = nullptr;
  destroy_fn destroy = nullptr;
  search_fn search = nullptr;
  register_cb_fn register_cb = nullptr;
  list_count_fn list_count = nullptr;
  list_get_fn list_get = nullptr;
  list_destroy_fn list_destroy = nullptr;
};

/// @brief .soへの関数ポインタを管理するシングルトン
inline PowerDispatch& dispatch() {
  static PowerDispatch inst = [] {
    PowerDispatch d;
    d.handle = dlopen(power_lib_name(), RTLD_NOW);
    if (!d.handle) {
      throw std::runtime_error(std::string("PowerSolver: failed to load ") +
                               power_lib_name() + ": " + dlerror());
    }
    // cpp_int ABI互換性: abi_bigint を介して .so 境界を渡すため
    // Boost バージョンの一致は不要（abi_bigint は malloc/free ベースの固定レイアウト）
    auto sym = [&](const char* name) {
      void* s = dlsym(d.handle, name);
      if (!s)
        throw std::runtime_error(
            std::string("PowerSolver: symbol not found: ") + name + ": " +
            dlerror());
      return s;
    };
    d.create = reinterpret_cast<create_fn>(sym("qbpp_power_solver_create"));
    d.destroy = reinterpret_cast<destroy_fn>(sym("qbpp_power_solver_destroy"));
    d.search = reinterpret_cast<search_fn>(sym("qbpp_power_solver_search"));
    d.register_cb =
        reinterpret_cast<register_cb_fn>(sym("qbpp_power_register_callback"));
    d.list_count =
        reinterpret_cast<list_count_fn>(sym("qbpp_power_sol_list_count"));
    d.list_get =
        reinterpret_cast<list_get_fn>(sym("qbpp_power_sol_list_get"));
    d.list_destroy =
        reinterpret_cast<list_destroy_fn>(sym("qbpp_power_sol_list_destroy"));
    return d;
  }();
  return inst;
}

}  // namespace detail

/// @brief Get the maximum variable count allowed by the current license
inline size_t max_var_count() { return qbpp_max_var_count(); }

// ===================================
// Sol class (wraps qbpp::Sol)
// ===================================

class Sol : public qbpp::Sol {
 public:
  Sol(const qbpp::Model& model, const qbpp::energy_t& energy,
      const uint64_t* bitarray, double tts)
      : qbpp::Sol(model, energy, bitarray, tts) {}
};

// ===================================
// PowerSols class (Sol + top-k solutions)
// ===================================

/// @brief Solution container with top-k solutions
/// @details Inherits from Sol (the best solution found) and additionally
/// stores a collection of top-k solutions sorted by energy ascending.
/// Follows the same pattern as EasySolver::Sols.
class PowerSols : public Sol {
  std::vector<qbpp::Sol> best_sols_;

 public:
  PowerSols(const qbpp::Model& model, const qbpp::energy_t& energy,
            const uint64_t* bitarray, double tts,
            std::vector<qbpp::Sol> best_sols)
      : Sol(model, energy, bitarray, tts),
        best_sols_(std::move(best_sols)) {}

  /// @brief Number of top-k solutions collected
  [[nodiscard]] size_t size() const noexcept { return best_sols_.size(); }

  /// @brief Access the top-k solutions vector
  const std::vector<qbpp::Sol>& best_sols() const noexcept {
    return best_sols_;
  }

  /// @brief Alias for best_sols()
  const std::vector<qbpp::Sol>& sols() const noexcept { return best_sols_; }

  /// @brief Index access
  const qbpp::Sol& operator[](size_t index) const {
    return best_sols_.at(index);
  }

  // Iterator support
  auto begin() const noexcept { return best_sols_.begin(); }
  auto end() const noexcept { return best_sols_.end(); }
  auto cbegin() const noexcept { return best_sols_.cbegin(); }
  auto cend() const noexcept { return best_sols_.cend(); }
};

// ===================================
// PowerSolver class
// ===================================

/// @brief PowerSolver - high-performance HUBO solver
/// @details Uses advanced search algorithms with solution pool management.
/// The algorithm is implemented in a shared library (.so).
class PowerSolver {
  qbpp::Model model_;
  const qbpp::HuboModel hubo_model_;
  const qbpp::FlatHuboModel flat_hubo_model_;
  void* pimpl_;

  PowerSolver() = delete;
  PowerSolver(const PowerSolver&) = delete;
  PowerSolver& operator=(const PowerSolver&) = delete;

 public:
  /// @brief Constructor from Model
  /// @details Checks that the variable count does not exceed the license limit
  /// before creating the solver implementation.
  explicit PowerSolver(const Model& model)
      : model_(model),
        hubo_model_(HuboModel(model)),
        flat_hubo_model_(FlatHuboModel(hubo_model_)),
        pimpl_(nullptr) {
    if (model_.var_count() > qbpp_max_var_count()) {
      std::cerr << "Variable count exceeds the maximum allowed by the license: "
                << model_.var_count() << " > " << qbpp_max_var_count() << "."
                << std::endl;
      exit(EXIT_FAILURE);
    }
    // コールバック登録（一度だけ）
    static bool cb_registered = false;
    if (!cb_registered) {
      detail::dispatch().register_cb(solver_callback_impl_);
      cb_registered = true;
    }
    pimpl_ = detail::dispatch().create(static_cast<PowerSolver*>(this),
                                       &flat_hubo_model_);
  }

  /// @brief Constructor from Expr
  explicit PowerSolver(const Expr& expr) : PowerSolver(Model(expr)) {}

  /// @brief Destructor
  virtual ~PowerSolver() noexcept { detail::dispatch().destroy(pimpl_); }

  /// @brief Execute the search with the given parameters
  /// @return PowerSols containing the best solution and top-k solutions
  PowerSols search(const Params& params) {
    PowerSol sol(model_.var_count());
    void* topk_list = detail::dispatch().search(pimpl_, &sol, &params);
    std::vector<qbpp::Sol> best_sols;
    if (topk_list) {
      size_t count = detail::dispatch().list_count(topk_list);
      best_sols.reserve(count);
      for (size_t i = 0; i < count; ++i) {
        PowerSol psol(model_.var_count());
        detail::dispatch().list_get(topk_list, i, &psol);
        best_sols.emplace_back(qbpp::Sol(
            model_, qbpp::energy_t(psol.energy()), psol.bitarray(), psol.tts()));
      }
      detail::dispatch().list_destroy(topk_list);
    }
    return PowerSols(model_, qbpp::energy_t(sol.energy()), sol.bitarray(),
                     sol.tts(), std::move(best_sols));
  }

  /// @brief Callback function called when a better solution is found
  /// @details Override this method to customize callback behavior.
  virtual void callback(const PowerSol& sol) const {
    std::cout << "TTS = " << std::fixed << std::setprecision(3)
              << std::setfill('0') << sol.tts() << "s Energy = " << sol.energy()
              << std::endl;
  }

 private:
  /// @brief コールバック実装（.soから呼び出される）
  static void solver_callback_impl_(const PowerSolver* solver,
                                    const PowerSol* sol) {
    solver->callback(*sol);
  }
};

}  // namespace power_solver
}  // namespace qbpp
