/// @file qbpp.hpp
/// @brief QUBO++ Library Main Header File
/// @details This toolkit provides classes and functions for generating and
/// manipulating expressions and polynomials involving binary and spin
/// variables. The library is designed to be simple and easy to use.
/// @note A valid license is required.
/// @author Koji Nakano
/// @copyright 2026 Koji Nakano
/// @version 2026.03.05

/// @section structure File Structure
/// This header file is organized into the following sections:
/// - PART 1: INCLUDES AND TYPE DEFINITIONS
/// - PART 2: FORWARD DECLARATIONS
/// - PART 3: UTILITY FUNCTIONS AND TYPE TRAITS
/// - PART 4: CLASS DECLARATIONS
/// - PART 5: CLASS MEMBER IMPLEMENTATIONS (out-of-line)
/// - PART 6: FREE FUNCTIONS AND OPERATORS

#pragma once

// ============================================================================
// PART 1: INCLUDES AND TYPE DEFINITIONS
// ============================================================================

#include <tbb/blocked_range.h>
#include <tbb/combinable.h>
#include <tbb/parallel_for.h>
#include <tbb/parallel_sort.h>

#include <algorithm>
#include <cstring>

#ifndef __CUDACC__
#define BOOST_MP_NO_ET  // Disable expression templates for cpp_int
#include <boost/multiprecision/cpp_int.hpp>
#endif
#include <chrono>
#include <initializer_list>
#include <iostream>
#include <map>
#include <memory>
#include <mutex>
#include <numeric>
#include <optional>
#include <sstream>
#include <string>
#include <thread>
#include <type_traits>
#include <unordered_map>
#include <unordered_set>
#include <utility>
#include <variant>
#include <vector>

#if !defined(MAXDEG) || MAXDEG == 0
#include <boost/container/small_vector.hpp>
#endif

#if defined(MAXDEG) && defined(BASEDEG)
#error "MAXDEG and BASEDEG cannot be defined at the same time."
#endif

#include "qbpp_defs.hpp"

// __int128 I/O support — defined in global namespace for ADL-free use
#if defined(__SIZEOF_INT128__)
#ifndef QBPP_INT128_IO_DEFINED_
#define QBPP_INT128_IO_DEFINED_
#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wpedantic"
namespace qbpp_int128_detail {
inline std::string to_string(__int128 val) {
  if (val == 0) return "0";
  std::string s;
  bool neg = val < 0;
  if (neg) val = -val;
  auto uval = static_cast<unsigned __int128>(val);
  while (uval > 0) {
    s += static_cast<char>('0' + static_cast<int>(uval % 10));
    uval /= 10;
  }
  if (neg) s += '-';
  std::reverse(s.begin(), s.end());
  return s;
}
inline std::string to_string(unsigned __int128 val) {
  if (val == 0) return "0";
  std::string s;
  while (val > 0) {
    s += static_cast<char>('0' + static_cast<int>(val % 10));
    val /= 10;
  }
  std::reverse(s.begin(), s.end());
  return s;
}
}  // namespace qbpp_int128_detail
inline std::ostream& operator<<(std::ostream& os, __int128 val) {
  return os << qbpp_int128_detail::to_string(val);
}
inline std::ostream& operator<<(std::ostream& os, unsigned __int128 val) {
  return os << qbpp_int128_detail::to_string(val);
}
#pragma GCC diagnostic pop
#endif  // QBPP_INT128_IO_DEFINED_
#endif  // __SIZEOF_INT128__

namespace qbpp {

// int128/uint128: use __int128 when available (CUDA ABI compatible)
#if defined(__SIZEOF_INT128__)
#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wpedantic"
using int128_t = __int128;
using uint128_t = unsigned __int128;

/// @brief __int128 の文字列変換
inline std::string str(__int128 val) {
  return qbpp_int128_detail::to_string(val);
}

/// @brief unsigned __int128 の文字列変換
inline std::string str(unsigned __int128 val) {
  return qbpp_int128_detail::to_string(val);
}

/// @brief __int128 の ostream 出力（namespace qbpp 内からも見えるように）
/// @note using ::operator<< はnvccのEDGフロントエンドで曖昧性エラーを起こすため、
///       明示的にオーバーロードを定義する。
inline std::ostream& operator<<(std::ostream& os, __int128 val) {
  return os << qbpp_int128_detail::to_string(val);
}
inline std::ostream& operator<<(std::ostream& os, unsigned __int128 val) {
  return os << qbpp_int128_detail::to_string(val);
}
#pragma GCC diagnostic pop
#elif !defined(__CUDACC__)
using int128_t = boost::multiprecision::int128_t;
using uint128_t = boost::multiprecision::uint128_t;
#endif

#ifndef __CUDACC__
// Use et_off to disable expression templates for cpp_int
using cpp_int =
    boost::multiprecision::number<boost::multiprecision::cpp_int_backend<>,
                                  boost::multiprecision::et_off>;
using int256_t = boost::multiprecision::int256_t;
using uint256_t = boost::multiprecision::uint256_t;
using int512_t = boost::multiprecision::int512_t;
using uint512_t = boost::multiprecision::uint512_t;
using int1024_t = boost::multiprecision::int1024_t;
using uint1024_t = boost::multiprecision::uint1024_t;

/// @brief ABI-stable arbitrary precision integer for .so boundary
/// @details malloc/free で管理する可変長 limb 配列により，Boost バージョンに
///          依存しない固定レイアウトを持つ．cpp_int からの暗黙構築，
///          cpp_int への明示変換を提供する．
///          coeff_t/energy_t が cpp_int の場合に FlatHuboModel/PowerSol で使用し，
///          dlopen 境界の ABI 安全性を保証する．
struct abi_bigint {
  int32_t sign;     ///< -1, 0, +1
  uint32_t size;    ///< number of 64-bit limbs
  uint64_t* limbs;  ///< malloc/free managed, little-endian (limbs[0] = LSB)

  /// @brief Default: zero
  abi_bigint() noexcept : sign(0), size(0), limbs(nullptr) {}

  /// @brief Construct from cpp_int (implicit)
  // NOLINTNEXTLINE(google-explicit-constructor)
  abi_bigint(const cpp_int& x) : sign(0), size(0), limbs(nullptr) {
    if (x == 0) return;
    sign = (x > 0) ? 1 : -1;
    cpp_int abs_x = boost::multiprecision::abs(x);
    auto bit_count =
        static_cast<uint32_t>(boost::multiprecision::msb(abs_x)) + 1;
    size = (bit_count + 63) / 64;
    limbs = static_cast<uint64_t*>(std::malloc(size * sizeof(uint64_t)));
    if (!limbs) throw std::bad_alloc();
    cpp_int mask = (cpp_int(1) << 64) - 1;
    for (uint32_t i = 0; i < size; ++i) {
      limbs[i] = (abs_x & mask).template convert_to<uint64_t>();
      abs_x >>= 64;
    }
  }

  /// @brief Convert to cpp_int (explicit to avoid Boost template conflicts)
  explicit operator cpp_int() const {
    if (sign == 0 || size == 0) return cpp_int(0);
    cpp_int result = 0;
    for (uint32_t i = size; i > 0; --i) {
      result <<= 64;
      result |= limbs[i - 1];
    }
    if (sign < 0) result = -result;
    return result;
  }

  /// @brief Copy constructor
  abi_bigint(const abi_bigint& o) : sign(o.sign), size(o.size), limbs(nullptr) {
    if (size > 0) {
      limbs = static_cast<uint64_t*>(std::malloc(size * sizeof(uint64_t)));
      if (!limbs) throw std::bad_alloc();
      std::memcpy(limbs, o.limbs, size * sizeof(uint64_t));
    }
  }

  /// @brief Move constructor
  abi_bigint(abi_bigint&& o) noexcept
      : sign(o.sign), size(o.size), limbs(o.limbs) {
    o.sign = 0;
    o.size = 0;
    o.limbs = nullptr;
  }

  /// @brief Copy assignment
  abi_bigint& operator=(const abi_bigint& o) {
    if (this != &o) {
      std::free(limbs);
      sign = o.sign;
      size = o.size;
      if (size > 0) {
        limbs = static_cast<uint64_t*>(std::malloc(size * sizeof(uint64_t)));
        if (!limbs) throw std::bad_alloc();
        std::memcpy(limbs, o.limbs, size * sizeof(uint64_t));
      } else {
        limbs = nullptr;
      }
    }
    return *this;
  }

  /// @brief Move assignment
  abi_bigint& operator=(abi_bigint&& o) noexcept {
    if (this != &o) {
      std::free(limbs);
      sign = o.sign;
      size = o.size;
      limbs = o.limbs;
      o.sign = 0;
      o.size = 0;
      o.limbs = nullptr;
    }
    return *this;
  }

  /// @brief Destructor
  ~abi_bigint() { std::free(limbs); }

  /// @brief Stream output
  friend std::ostream& operator<<(std::ostream& os, const abi_bigint& x) {
    os << cpp_int(x);
    return os;
  }
};
#endif

// COEFF_TYPE, ENERGY_TYPE, VINDEX_TYPE はビルド時に -D で定義可能
#ifdef COEFF_TYPE
using coeff_t = COEFF_TYPE;
#else
using coeff_t = int32_t;
#endif

#ifdef ENERGY_TYPE
using energy_t = ENERGY_TYPE;
#else
using energy_t = int64_t;
#endif

/// @brief .so 境界で使うフラット型（cpp_int の場合は abi_bigint に置換）
#ifndef __CUDACC__
using flat_coeff_t =
    std::conditional_t<std::is_same_v<coeff_t, cpp_int>, abi_bigint, coeff_t>;
using flat_energy_t =
    std::conditional_t<std::is_same_v<energy_t, cpp_int>, abi_bigint, energy_t>;
#else
using flat_coeff_t = coeff_t;
using flat_energy_t = energy_t;
#endif

}  // namespace qbpp

// ============================================================================
// PART 2: FORWARD DECLARATIONS AND TYPE TRAITS
// ============================================================================

/// @brief Namespace for HUBO++ library.
namespace qbpp {

/// @brief Type trait to check if T is an integer-like type.
template <typename T, typename = void>
struct is_integer_like : std::is_integral<T> {};

#ifndef __CUDACC__
template <typename T>
struct is_integer_like<
    T, std::void_t<typename boost::multiprecision::number_category<T>::type>>
    : std::bool_constant<boost::multiprecision::number_category<T>::value ==
                         boost::multiprecision::number_kind_integer> {};
#endif

template <typename T>
inline constexpr bool is_integer_like_v = is_integer_like<T>::value;

class Inf;
template <typename T>
class Vector;
class Var;
class Term;
class Terms;
class Expr;
class ExprExpr;
class VarIntCore;
class VarInt;
class Sol;
class Model;
class HuboModel;
template <typename T, typename U>
class SolHolderTemplate;

using QuadModel = HuboModel;

/// @brief Namespace for the internal implementation of the HUBO++ library.
namespace impl {
struct var_hash;
struct vars_hash;
template <size_t N>
class VarArray;
class IVMapper;
class BitVector;
}  // namespace impl

// ============================================================================
// PART 3: UTILITY FUNCTIONS AND TYPE TRAITS
// ============================================================================

/// @brief Returns the string of the file name and line number with the
/// message.
/// @tparam Args Variadic template parameter pack representing the types of
/// the arguments.
/// @param file File name of source code where the debug message is called.
/// @param line Line number in the file where the debug message is called.
/// @param args Debug message arguments to be printed.
template <typename... Args>
std::string file_line(const char* file, int line, Args&&... args) {
  std::ostringstream oss;
  oss << file << "(" << line << ") ";
  using expander = int[];
  (void)expander{0, (void(oss << std::forward<Args>(args)), 0)...};
  return oss.str();
}

/// @brief Macro to print the message when throwing an exception.
#define THROW_MESSAGE(...) file_line(__FILE__, __LINE__, __VA_ARGS__)

/// @brief The size of initial capacity of the vector storing terms in
/// qbpp::Expr.
/// @note A small constant to avoid reallocation of the vector storing small
/// terms.
constexpr size_t TERM_CAPACITY = 4;

// --------------------------------------------------
// Type Definitions
// --------------------------------------------------

/// @brief Type of the variable array.
/// @note When using VarArray, prefer range-based for or iterators over size().

#if defined(MAXDEG) && MAXDEG > 0
using Vars = impl::VarArray<MAXDEG>;
#elif defined(BASEDEG) && BASEDEG > 0
using Vars = boost::container::small_vector<Var, BASEDEG>;
#else
using Vars = boost::container::small_vector<Var, 2>;
#endif

#if !defined(MAXDEG) && !defined(BASEDEG)
/// @brief Advises the user to define MAXDEG or BASEDEG at program exit.
/// @note Only active when neither MAXDEG nor BASEDEG is defined.
/// The message is printed once in the destructor (during static cleanup
/// after main()). Defining MAXDEG=0 or BASEDEG=0 suppresses this message.
namespace impl {
struct MaxDegAdvisor {
  bool active = false;  ///< True if any simplify_as_binary() has been called.
  vindex_t max_deg = 0;  ///< Maximum pre-simplification term degree observed.
  ~MaxDegAdvisor() {
    if (active && max_deg > 0) {
      std::cerr
          << "QUBO++ performance note:\n"
          << "  Max term degree is " << max_deg << ".\n"
          << "  You can improve performance by specifying the term degree"
          << " at compile time.\n"
          << "  Two options are available:\n"
          << "    MAXDEG=N  Fixed-size storage (fastest, but degree is"
          << " limited to N)\n"
          << "    BASEDEG=N Inline buffer of size N with heap fallback"
          << " (no degree limit)\n";
      if (max_deg <= 4) {
        std::cerr
            << "  Recommended:\n"
            << "    1. MAXDEG=" << max_deg
            << "   (all terms are degree " << max_deg
            << " or less, fastest)\n"
            << "    2. BASEDEG=" << max_deg
            << "  (allows higher-degree terms with heap fallback)\n";
      } else {
        std::cerr
            << "  Recommended:\n"
            << "    BASEDEG=4  (max degree is " << max_deg
            << ", so MAXDEG is not suitable)\n";
      }
      std::cerr
          << "  Usage:\n"
          << "    Compile option:  g++ -DMAXDEG=" << max_deg
          << " ...  or  g++ -DBASEDEG=" << max_deg << " ...\n"
          << "    Source code:     #define MAXDEG " << max_deg
          << "  // before #include \"qbpp.hpp\"\n"
          << "  To suppress this message: -DMAXDEG=0 or -DBASEDEG=0\n"
          << "    (=0 is equivalent to BASEDEG=2, the default)\n";
    }
  }
};
inline MaxDegAdvisor& maxdeg_advisor() {
  static MaxDegAdvisor instance;
  return instance;
}
}  // namespace impl
#endif  // !defined(MAXDEG) && !defined(BASEDEG)

/// @brief Type of the set of terms in qbpp::Expr.
// using Terms = std::vector<Term>;

/// @brief Type of the variable value.
/// @note For HUBO models, the variable value is either 0 or 1. bool cannot be
/// used.
using var_val_t = int8_t;

/// @brief MapList is a vector of Var/VarInt and Expr pairs.
using MapList = std::vector<std::pair<std::variant<Var, VarInt>, Expr>>;

/// @brief MapDict is an unordered_map that maps Var to Expr.
using MapDict = std::unordered_map<Var, Expr, impl::var_hash>;

/// @brief VarValMap is an unordered_map that maps Var to var_val_t.
using VarValMap = std::unordered_map<Var, var_val_t, impl::var_hash>;

/// @brief VarExprMap is an unordered_map that maps Var to Expr.
using VarExprMap = std::unordered_map<Var, Expr, impl::var_hash>;

/// @brief VarsCoeffMap is an unordered_map that maps Vars to Val.
using VarsCoeffMap = std::unordered_map<Vars, coeff_t, impl::vars_hash>;

}  // namespace qbpp

namespace qbpp {

namespace impl {

/// @brief struct for the hash function with key Var.
struct var_hash {
  /// @brief Hash function for Var used in unordered_map that maps Var
  /// into size_t
  size_t operator()(const Var var) const;
};

/// @brief struct for the hash function with key Vars.
struct vars_hash {
  /// @brief Hash function for Vars used in unordered_map that maps Vars
  /// into size_t.
  size_t operator()(const Vars& vars) const;
};

}  // namespace impl
}  // namespace qbpp

// --------------------------------------------------
// Global Function Prototypes
// --------------------------------------------------

// Prototype declarations for global functions are placed here if they are
// used before the definition.

namespace qbpp {

Var var(const std::string& name);
Var var();
inline vindex_t all_var_count() { return qbpp_var_set_size(); }
inline vindex_t new_unnamed_var_index() {
  return qbpp_increment_unnamed_var_count();
}

// str functions
std::string str(Var var);
std::string str(const Vars& vars);
std::string str(const Term& term);
std::string str(const Expr& expr);
std::string str(const Expr& expr, const std::string& prefix);
std::string str(const VarInt& var_int);
std::string str(const Model& model);
std::string str(const HuboModel& hubo_model);
std::string str(const Sol& sol);
std::string str(const MapList& map_list);
std::string str_short(const Expr& expr);

// simplify related global functions
void sort_vars_in_place(Vars& vars);
Vars sort_vars(const Vars& vars);
Vars sort_vars_as_binary(const Vars& vars);
Vars sort_vars_as_spin(const Vars& vars);
Expr simplify(const Expr& expr, Vars (*sort_vars_func)(const Vars&));
Expr simplify_as_binary(const Expr& expr);
Expr simplify_as_spin(const Expr& expr);
bool is_binary(const Expr& expr);

energy_t eval(const Expr& expr, const Sol& sol);
energy_t eval(const Expr& expr, const MapList& map_list);
Expr reduce(const Expr& expr);

Expr binary_to_spin(const Expr& expr);
Expr spin_to_binary(const Expr& expr);

template <typename T>
auto binary_to_spin(const Vector<T>& arg);

template <typename T>
auto spin_to_binary(const Vector<T>& arg);

double time();

template <typename T,
          typename std::enable_if<!is_integer_like_v<T>, int>::type = 0>
Expr sum(const Vector<T>& items);

template <typename T>
Vector<Vector<Expr>> transpose(const Vector<Vector<T>>& vec);

Expr operator-(const Expr& expr);
Expr operator-(Expr&& expr);
// for VarOnehot
Expr&& operator-(Expr&& lhs, Expr&& rhs);
// for VarOnehot
Expr sqr(const Expr& expr);

template <typename T>
auto sqr(const Vector<T>& arg);

energy_t toInt(const Expr& expr);
VarValMap list_to_var_val(const MapList& map_list);

// ----------------------------------------------
// Class Terms Global Function Prototypes
// ----------------------------------------------

template <typename T, typename std::enable_if<
                          std::is_convertible<std::decay_t<T>, coeff_t>::value,
                          int>::type = 0>
Term operator*(Var var, T&& val);
template <typename T, typename std::enable_if<
                          std::is_convertible<std::decay_t<T>, coeff_t>::value,
                          int>::type = 0>
Term operator*(T&& val, Var var);

Term operator*(Var var1, Var var2);

template <typename T, typename std::enable_if<
                          std::is_convertible<std::decay_t<T>, coeff_t>::value,
                          int>::type = 0>
Term operator*(const Term& term, T&& val);
template <typename T, typename std::enable_if<
                          std::is_convertible<std::decay_t<T>, coeff_t>::value,
                          int>::type = 0>
Term operator*(T&& val, const Term& term);
template <typename T, typename std::enable_if<
                          std::is_convertible<std::decay_t<T>, coeff_t>::value,
                          int>::type = 0>
Term operator*(Term&& term, T&& val);
template <typename T, typename std::enable_if<
                          std::is_convertible<std::decay_t<T>, coeff_t>::value,
                          int>::type = 0>
Term operator*(T&& val, Term&& term);

Term operator*(const Term& term, Var var);
Term operator*(Var var, const Term& term);
Term operator*(Term&& term, Var var);
Term operator*(Var var, Term&& term);

Term operator*(const Term& term1, const Term& term2);

// ----------------------------------------------
// Class Terms Global Function Prototypes
// ----------------------------------------------

template <typename T>
Terms operator+(const Terms& lhs, T&& rhs);

template <typename T>
Terms operator+(Terms&& lhs, T&& rhs);

template <typename T>
Terms operator-(const Terms& lhs, T&& rhs);

template <typename T>
Terms operator-(Terms&& lhs, T&& rhs);

template <typename T, typename std::enable_if<
                          std::is_convertible<std::decay_t<T>, coeff_t>::value,
                          int>::type = 0>
Terms operator*(const Terms& lhs, T&& rhs);

template <typename T, typename std::enable_if<
                          std::is_convertible<std::decay_t<T>, coeff_t>::value,
                          int>::type = 0>
Terms operator*(Terms&& lhs, T&& rhs);

template <typename T, typename std::enable_if<
                          std::is_convertible<std::decay_t<T>, coeff_t>::value,
                          int>::type = 0>
Terms operator*(T&& rhs, const Terms& lhs);

template <typename T, typename std::enable_if<
                          std::is_convertible<std::decay_t<T>, coeff_t>::value,
                          int>::type = 0>
Terms operator*(T&& rhs, Terms&& lhs);

Terms operator*(const Terms& lhs, const Term& rhs);
Terms operator*(const Term& rhs, const Terms& lhs);
Terms operator*(Terms&& lhs, const Term& rhs);
Terms operator*(const Term& lhs, Terms&& rhs);

Terms operator*(const Terms& lhs, const Terms& rhs);

// ----------------------------------------------
// Class Expr Global Function Prototypes
// ----------------------------------------------

// Note: Scalar operator*(Expr, T) and operator*(T, Expr) are NOT provided.
// Instead, rely on implicit conversion to Expr and operator*(Expr, Expr).
// This avoids ambiguity with Boost multiprecision operators when coeff_t is
// cpp_int.

Expr operator*(const Expr& expr, const Term& term);
Expr operator*(const Term& term, const Expr& expr);
Expr operator*(const Expr& expr, Term&& term);
Expr operator*(Term&& term, const Expr& expr);
Expr&& operator*(Expr&& expr, const Term& term);
Expr&& operator*(const Term& term, Expr&& expr);
Expr&& operator*(Expr&& expr, Term&& rhs);
Expr&& operator*(Term&& rhs, Expr&& expr);

Expr&& operator*(Expr&& lhs, Expr&& rhs);
Expr&& operator*(Expr&& lhs, const Expr& rhs);
Expr&& operator*(const Expr& lhs, Expr&& rhs);
Expr operator*(const Expr& lhs, const Expr& rhs);

Expr&& operator+(Expr&& lhs, Expr&& rhs);
Expr&& operator+(Expr&& lhs, const Expr& rhs);
Expr&& operator+(const Expr& lhs, Expr&& rhs);
Expr operator+(const Expr& lhs, const Expr& rhs);

Expr&& operator-(Expr&& lhs, Expr&& rhs);
Expr&& operator-(Expr&& lhs, const Expr& rhs);
Expr&& operator-(const Expr& lhs, Expr&& rhs);
Expr operator-(const Expr& lhs, const Expr& rhs);

template <typename T, typename std::enable_if<
                          std::is_convertible<std::decay_t<T>, coeff_t>::value,
                          int>::type = 0>
Expr&& operator/(Expr&& expr, T&& val);

template <typename T, typename std::enable_if<
                          std::is_convertible<std::decay_t<T>, coeff_t>::value,
                          int>::type = 0>
Expr operator/(const Expr& expr, T&& val);
Expr operator+(Expr&& expr);
const Expr& operator+(const Expr& expr);

Expr operator-(Expr&& expr);
Expr operator-(const Expr& expr);

template <typename T,
          typename std::enable_if<std::is_integral<T>::value, int>::type = 0>
Expr operator+(const Term& term, T val);

template <typename T,
          typename std::enable_if<std::is_integral<T>::value, int>::type = 0>
Expr operator+(Term&& term, T val);

template <typename T,
          typename std::enable_if<std::is_integral<T>::value, int>::type = 0>
Expr operator+(T val, Term&& term);

/// @brief Operator+ overload for creating Expr with Term and integer.
template <typename T,
          typename std::enable_if<std::is_integral<T>::value, int>::type = 0>
Expr operator+(T val, const Term& term);

template <typename T,
          typename std::enable_if<std::is_integral<T>::value, int>::type = 0>
Expr operator+(Var var, T val);

template <typename T,
          typename std::enable_if<std::is_integral<T>::value, int>::type = 0>
Expr operator+(T val, Var var);

template <typename T,
          typename std::enable_if<std::is_integral<T>::value, int>::type = 0>
Expr operator-(Var var, T val);
template <typename T,
          typename std::enable_if<std::is_integral<T>::value, int>::type = 0>
Expr operator-(T val, Var var);

Expr operator+(Var lhs, Var rhs);

Expr operator+(const Term& lhs, const Term& rhs);
Expr operator+(const Term& lhs, Term&& rhs);
Expr operator+(Term&& lhs, const Term& rhs);
Expr operator+(Term&& lhs, Term&& rhs);

Expr operator-(const Term& lhs, const Term& rhs);
Expr operator-(const Term& lhs, Term&& rhs);
Expr operator-(Term&& lhs, const Term& rhs);
Expr operator-(Term&& lhs, Term&& rhs);

Expr operator+(const Expr& expr, const Term& term);

Expr operator+(Expr&& expr, const Term& term);
Expr operator+(const Expr& expr, Term&& term);

Expr operator+(Expr&& expr, Term&& term);

Expr operator+(const Term& term, const Expr& expr);

Expr operator+(const Term& term, Expr&& expr);
Expr operator+(Term&& term, const Expr& expr);

Expr operator+(Term&& term, Expr&& expr);
Expr operator-(const Term& term, const Expr& expr);
Expr operator-(Term&& term, const Expr& expr);

Expr operator-(const Term& term, Expr&& expr);
Expr operator-(Term&& term, Expr&& expr);
Expr operator-(const Expr& expr, const Term& term);
Expr operator-(Expr&& expr, const Term& term);
Expr operator-(const Expr& expr, Term&& term);
Expr operator-(Expr&& expr, Term&& term);

Expr replace(const Term& term, const MapDict& map_dict);

template <typename T,
          typename std::enable_if<std::is_integral<T>::value, int>::type = 0>
Expr operator-(const Term& term, T val);

template <typename T,
          typename std::enable_if<std::is_integral<T>::value, int>::type = 0>
Expr operator-(Term&& term, T val);

// --------------------------------------------------
// Basic Global Functions
// --------------------------------------------------

inline std::string str(const std::string& param) {
  if (param == "all_vars") {
    std::stringstream ss;
    vindex_t var_set_size = qbpp_var_set_size();
    ss << "{";
    for (vindex_t i = 0; i < var_set_size; i++) {
      ss << "{" << i << "," << qbpp_var_str(i) << "}";
      if (i < var_set_size - 1) {
        ss << ",";
      }
    }
    ss << "}";
    return ss.str();
  } else {
    return qbpp_const_str(param.c_str());
  }
}

/// @brief Converts an int8_t value to a string using std::string.
/// @note This function is defined because std::to_string converts an
/// int8_t value to an ASCII character (char type), which is not the
/// intended behavior.
inline std::string str(int8_t val) {
  return std::to_string(static_cast<int32_t>(val));
}

/// @brief Converts the given value to a string using std::string
template <typename T>
auto str(const T& val) -> decltype(std::to_string(val)) {
  return std::to_string(val);
}

/// @brief Converts the given value to a string using the str() member
/// function.
template <typename T>
auto str(T val) -> decltype(val.str()) {
  return val.str();
}

#ifndef __CUDACC__
/// @brief Converts an abi_bigint to a string via cpp_int conversion
inline std::string str(const abi_bigint& x) { return cpp_int(x).str(); }
#endif

/// @brief Computes the absolute value of the given value.
/// @note Since std::abs do not support boost multi-precision types, this
/// function is used instead.
template <typename T>
T abs(T val) {
  return val < 0 ? static_cast<T>(-val) : val;
}

/// @brief Computes the greatest common divisor of two values.
/// @note Since std::gcd do not support boost multi-precision types, this
/// function is used instead.
inline energy_t gcd(energy_t a, energy_t b) {
  a = abs(a);
  b = abs(b);
  if (a == 0) return b;
  if (b == 0) return a;
  while (b != 0) {
    energy_t r = a % b;
    a = b;
    b = r;
  }
  return a;
}

// --------------------------------------------------
// Stream Output Operator for Types with str() Member Function
// --------------------------------------------------
template <typename, typename = std::void_t<>>
struct has_str : std::false_type {};

template <typename T>
struct has_str<T, std::void_t<decltype(std::declval<const T&>().str())>>
    : std::is_convertible<decltype(std::declval<const T&>().str()),
                          std::string> {};

template <typename T, typename std::enable_if<has_str<T>::value, int>::type = 0>
inline std::ostream& operator<<(std::ostream& os, const T& arg) {
  return os << arg.str();
}

// ==================================================
//            Class Declarations
// ==================================================

// ============================================================================
// PART 4: CLASS DECLARATIONS
// ============================================================================

// --------------------------------------------------
// Class Inf
// --------------------------------------------------

/// @brief Class for representing infinity.
class Inf {
  // True if positive infinity, false if negative infinity.
  bool positive_ = true;

 public:
  Inf() = default;

  /// @brief Returns true if the infinity is positive, false if negative.
  bool is_positive() const { return positive_; }

  /// @brief Returns true if the infinity is negative, false if positive.
  bool is_negative() const { return !positive_; }

  /// @brief Unary operator overloading for positive infinity.
  Inf operator+() const { return *this; }

  /// @brief Unary operator overloading for negative infinity.
  Inf operator-() const {
    Inf inf;
    inf.positive_ = !positive_;
    return inf;
  }
};

/// @brief Global constant for positive infinity.
inline const Inf inf;

// --------------------------------------------------
// Class Vector<T> Declaration
// --------------------------------------------------

/// @brief Custom vector class
/// @note Operator overloading is employed, so the class uses composition
/// with std::vector instead of inheritance.

/// @brief Type trait to convert std::vector types to Vector types recursively.
template <typename T>
struct to_vector_type {
  using type = T;
};

template <typename T, typename A>
struct to_vector_type<std::vector<T, A>> {
  using type = Vector<typename to_vector_type<T>::type>;
};

template <typename T>
using to_vector_type_t = typename to_vector_type<T>::type;

template <typename T>
class Vector {
  /// @brief The vector data.
  std::vector<T> data_;

  /// @brief Generic vector operation function for two vectors in copy.
  /// @param rhs The right-hand side vector.
  /// @param operation The operation to apply to the elements of the vectors.
  /// @return A reference to this object after applying the operation.
  /// @note This function is used for the +=, -=, and *= operators.
  template <typename U, typename Op>
  Vector<T>& vector_operation(const Vector<U>& rhs, Op operation) {
    if (size() != rhs.size()) {
      throw std::out_of_range(
          THROW_MESSAGE("Vector size mismatch: ", size(), " != ", rhs.size()));
    }
    tbb::parallel_for(size_t(0), size(), [&](size_t i) {
      operation((*this)[i], rhs[i]);
      (*this)[i] = static_cast<T>((*this)[i]);
    });
    return *this;
  }

  /// @brief Generic vector operation function for two vectors in move.
  /// @param rhs The right-hand side vector.
  /// @param operation The operation to apply to the elements of the vectors.
  /// @return A reference to this object after applying the operation.
  /// @note This function is used for the +=, -=, and *= operators.
  template <typename U, typename Op>
  Vector<T>& vector_operation(Vector<U>&& rhs, Op operation) {
    if (size() != rhs.size()) {
      throw std::out_of_range(
          THROW_MESSAGE("Vector size mismatch: ", size(), " != ", rhs.size()));
    }
    tbb::parallel_for(size_t(0), size(), [&](size_t i) {
      operation((*this)[i], std::move(rhs[i]));
      (*this)[i] = static_cast<T>((*this)[i]);
    });

    return *this;
  }

  /// @brief Generic vector operation function for a vector and a scalar.
  /// @param rhs The right-hand side scalar.
  /// @param operation The operation to apply to the elements of the vector.
  /// @return A reference to this object after applying the operation.
  /// @note This function is used for the +=, -=, and *= operators.
  template <typename Op>
  Vector<T>& vector_operation(const Expr& rhs, Op operation) {
    tbb::parallel_for(size_t(0), size(),
                      [&](size_t i) { operation((*this)[i], rhs); });
    return *this;
  }

 public:
  // Type aliases for std::vector compatibility
  using value_type = T;
  using size_type = size_t;
  using difference_type = std::ptrdiff_t;
  using reference = T&;
  using const_reference = const T&;
  using pointer = T*;
  using const_pointer = const T*;
  using iterator = typename std::vector<T>::iterator;
  using const_iterator = typename std::vector<T>::const_iterator;
  using reverse_iterator = typename std::vector<T>::reverse_iterator;
  using const_reverse_iterator =
      typename std::vector<T>::const_reverse_iterator;

  /// @brief Default constructor.
  Vector() = default;

  /// @brief Default copy constructor.
  Vector(const Vector<T>&) = default;

  /// @brief Default move constructor.
  Vector(Vector<T>&&) = default;

  /// @brief Constructor to creates a new Vector with an initializer list.
  Vector(std::initializer_list<T> init) : data_(init) {}

  /// @brief Default copy assignment operator.
  Vector& operator=(const Vector<T>&) = default;

  /// @brief Default move assignment operator.
  Vector& operator=(Vector<T>&&) = default;

  /// @brief Constructor to creates a new Vector with a size.
  /// @param size Size of the vector.
  explicit Vector(size_t size) : data_(size) {}

  /// @brief Constructor to creates a new Vector with a size and value.
  template <typename U, typename = typename std::enable_if<
                            std::is_integral<U>::value>::type>
  Vector(U size, const T& value) : data_(static_cast<size_t>(size), value) {}

  /// @brief Constructor to creates a new Vector with begin and end iterators
  /// specifying a range.
  template <typename U, typename = typename std::enable_if<
                            !std::is_integral<U>::value>::type>
  Vector(U begin, U end) : data_(begin, end) {}

  /// @brief Constructor to create a new Vector<T> from a Vector<U>.
  /// @param rhs Vector<U> object to copy.
  /// @note This constructor is intended for implicit conversion from
  ///       Vector<U>.
  template <typename U>
  Vector(const Vector<U>& rhs) {
    data_.resize(rhs.size());
    tbb::parallel_for(size_t(0), rhs.size(),
                      [&](size_t i) { data_[i] = static_cast<T>(rhs[i]); });
  }

  /// @brief Constructor to create a new Vector<T> from a std::vector<T>.
  /// @param rhs std::vector<T> object to copy.
  Vector(const std::vector<T>& rhs) : data_(rhs) {}

  /// @brief Constructor to create a new Vector<T> from a std::vector<T> (move).
  /// @param rhs std::vector<T> object to move.
  Vector(std::vector<T>&& rhs) : data_(std::move(rhs)) {}

  /// @brief Constructor to create a new Vector<T> from a std::vector<U>.
  /// @param rhs std::vector<U> object to convert.
  /// @note This enables conversion from std::vector<std::vector<Expr>> to
  ///       Vector<Vector<Expr>>.
  template <typename U, typename = std::enable_if_t<!std::is_same_v<T, U>>>
  Vector(const std::vector<U>& rhs) {
    data_.reserve(rhs.size());
    for (const auto& elem : rhs) {
      data_.emplace_back(elem);
    }
  }

  /// @brief Returns the const pointer to the underlying data.
  const T* data() const { return data_.data(); }

  /// @brief Returns the pointer to the underlying data.
  T* data() { return data_.data(); }

  /// @brief Resizes the vector to the specified size.
  /// @param size The new size of the vector.
  void resize(size_t size) { data_.resize(size); }

  /// @brief Resizes the vector to the specified size with a default value.
  /// @param size The new size of the vector.
  /// @param value The value to initialize new elements with.
  void resize(size_t size, const T& value) { data_.resize(size, value); }

  /// @brief Clears the vector.
  void clear() { data_.clear(); }

  /// @brief Returns a reference to the first element.
  T& front() { return data_.front(); }

  /// @brief Returns a const reference to the first element.
  const T& front() const { return data_.front(); }

  /// @brief Returns a reference to the last element.
  T& back() { return data_.back(); }

  /// @brief Returns a const reference to the last element.
  const T& back() const { return data_.back(); }

  /// @brief Returns a reference to the element at the specified index with
  /// bounds checking.
  T& at(size_t i) { return data_.at(i); }

  /// @brief Returns a const reference to the element at the specified index
  /// with bounds checking.
  const T& at(size_t i) const { return data_.at(i); }

  /// @brief Removes the last element from the vector.
  void pop_back() { data_.pop_back(); }

  /// @brief push_back function to add an element to the end of the vector.
  void push_back(const T& t) { data_.push_back(t); }

  /// @brief emplace_back function to add an element to the end of the vector.
  template <class... Args>
  void emplace_back(Args&&... args) {
    data_.emplace_back(std::forward<Args>(args)...);
  }

  /// @brief reserve function to reserve memory for the vector.
  void reserve(size_t size) { data_.reserve(size); }

  /// @brief Returns the capacity of the vector.
  size_t capacity() const { return data_.capacity(); }

  /// @brief Shrinks the capacity to fit the size.
  void shrink_to_fit() { data_.shrink_to_fit(); }

  /// @brief Returns the element at the specified index.
  T& operator[](size_t i) { return data_[i]; }

  /// @brief Returns the element at the specified index.
  const T& operator[](size_t i) const { return data_[i]; }

  /// @brief Returns the size of the vector.
  size_t size() const { return data_.size(); }

  /// @brief Returns the begin iterator of the vector.
  auto begin() const { return data_.begin(); }

  /// @brief Returns the end iterator of the vector.
  auto end() const { return data_.end(); }

  /// @brief Returns the begin iterator of the vector.
  auto begin() { return data_.begin(); }

  /// @brief Returns the end iterator of the vector.
  auto end() { return data_.end(); }

  /// @brief Returns the reverse begin iterator of the vector.
  auto rbegin() const { return data_.rbegin(); }

  /// @brief Returns the reverse end iterator of the vector.
  auto rend() const { return data_.rend(); }

  /// @brief Returns the reverse begin iterator of the vector.
  auto rbegin() { return data_.rbegin(); }

  /// @brief Returns the reverse end iterator of the vector.
  auto rend() { return data_.rend(); }

  /// @brief Returns a const iterator to the beginning.
  auto cbegin() const { return data_.cbegin(); }

  /// @brief Returns a const iterator to the end.
  auto cend() const { return data_.cend(); }

  /// @brief Returns a const reverse iterator to the beginning.
  auto crbegin() const { return data_.crbegin(); }

  /// @brief Returns a const reverse iterator to the end.
  auto crend() const { return data_.crend(); }

  /// @brief Returns true if the vector is empty.
  auto empty() const { return data_.empty(); }

  /// @brief Remove a single element at the specified position.
  typename std::vector<T>::iterator erase(
      typename std::vector<T>::iterator pos) {
    return data_.erase(pos);
  }

  /// @brief Remove a range of elements.
  typename std::vector<T>::iterator erase(
      typename std::vector<T>::iterator first,
      typename std::vector<T>::iterator last) {
    return data_.erase(first, last);
  }

  /// @brief Swaps the contents with another vector.
  void swap(Vector& other) { data_.swap(other.data_); }

  /// @brief Inserts an element at the specified position.
  iterator insert(const_iterator pos, const T& value) {
    return data_.insert(pos, value);
  }

  /// @brief Inserts an element at the specified position (move version).
  iterator insert(const_iterator pos, T&& value) {
    return data_.insert(pos, std::move(value));
  }

  /// @brief Inserts count copies of value at the specified position.
  iterator insert(const_iterator pos, size_t count, const T& value) {
    return data_.insert(pos, count, value);
  }

  /// @brief Inserts elements from range [first, last) at the specified
  /// position.
  template <class InputIt>
  iterator insert(const_iterator pos, InputIt first, InputIt last) {
    return data_.insert(pos, first, last);
  }

  /// @brief Inserts elements from initializer list at the specified position.
  iterator insert(const_iterator pos, std::initializer_list<T> ilist) {
    return data_.insert(pos, ilist);
  }

  /// @brief Constructs element in-place at the specified position.
  template <class... Args>
  iterator emplace(const_iterator pos, Args&&... args) {
    return data_.emplace(pos, std::forward<Args>(args)...);
  }

  /// @brief Replaces the contents with count copies of value.
  void assign(size_t count, const T& value) { data_.assign(count, value); }

  /// @brief Replaces the contents with elements from range [first, last).
  template <class InputIt>
  void assign(InputIt first, InputIt last) {
    data_.assign(first, last);
  }

  /// @brief Replaces the contents with elements from initializer list.
  void assign(std::initializer_list<T> ilist) { data_.assign(ilist); }

  /// @brief Store the same qbpp::Expr object in all elements of the vector.
  /// @param rhs qbpp::Expr object to store in all elements of the vector.
  /// @return A reference to this object after storing the qbpp::Expr object.
  Vector<T>& operator=(const Expr& rhs) {
    tbb::parallel_for(size_t(0), size(), [&](size_t i) { (*this)[i] = rhs; });
    return *this;
  }

  /// @brief Store the same integer in all elements of the vector.
  /// @param rhs The integer to store in all elements of the vector.
  /// @return A reference to this object after storing the qbpp::Expr object.
  /// @note This function is necessary for ambiguous overload resolution.
  Vector<T>& operator=(const energy_t& rhs) {
    tbb::parallel_for(size_t(0), size(), [&](size_t i) { (*this)[i] = rhs; });
    return *this;
  }

  /// @brief Overloads the += operator for two multi-dimensional
  /// vectors in copy semantics.
  template <typename U>
  Vector<T>& operator+=(const Vector<U>& rhs) {
    return vector_operation(rhs, [](T& larg, const U& rarg) { larg += rarg; });
  }

  /// @brief Overloads the += operator for two multi-dimensional vectors in
  /// move semantics.
  template <typename U>
  Vector<T>& operator+=(Vector<U>&& rhs) {
    return vector_operation(std::move(rhs),
                            [](T& lhs_elem, U rhs_elem) mutable {
                              lhs_elem += std::move(rhs_elem);
                            });
  }

  /// @brief Overloads the -= operator for two multi-dimensional vectors in
  /// copy semantics.
  template <typename U>
  Vector<T>& operator-=(const Vector<U>& rhs) {
    return vector_operation(rhs, [](T& larg, const U& rarg) { larg -= rarg; });
  }

  /// @brief Overloads the -= operator for two multi-dimensional vectors in
  /// move semantics.
  template <typename U>
  Vector<T>& operator-=(Vector<U>&& rhs) {
    return vector_operation(std::move(rhs),
                            [](T& lhs_elem, U rhs_elem) mutable {
                              lhs_elem -= std::move(rhs_elem);
                            });
  }

  /// @brief Overloads the *= operator for two multi-dimensional vectors in
  /// copy semantics.
  template <typename U>
  Vector<T>& operator*=(const Vector<U>& rhs) {
    return vector_operation(rhs, [](T& larg, const U& rarg) { larg *= rarg; });
  }

  /// @brief Overloads the *= operator for two multi-dimensional vectors in
  /// move semantics.
  template <typename U>
  Vector<T>& operator*=(Vector<U>&& rhs) {
    return vector_operation(std::move(rhs),
                            [](T& lhs_elem, U rhs_elem) mutable {
                              lhs_elem *= std::move(rhs_elem);
                            });
  }

  /// @brief Overloads the += operator for multi-dimensional vector and a
  /// scalar.
  Vector<T>& operator+=(const Expr& expr) {
    return vector_operation(expr,
                            [](T& elem, const Expr& rhs) { elem += rhs; });
  }

  /// @brief Overloads the -= operator for multi-dimensional vector and a
  /// scalar.
  Vector<T>& operator-=(const Expr& expr) {
    return vector_operation(expr,
                            [](T& elem, const Expr& rhs) { elem -= rhs; });
  }

  /// @brief Overloads the *= operator for multi-dimensional vector and a
  /// scalar.
  Vector<T>& operator*=(const Expr& expr) {
    return vector_operation(expr,
                            [](T& elem, const Expr& rhs) { elem *= rhs; });
  }

  /// @brief Overloads the /= operator for multi-dimensional vector and an
  /// integer.
  template <class U, typename std::enable_if<
                         std::is_convertible<U, coeff_t>::value, int>::type = 0>
  Vector<T>& operator/=(U val) {
    tbb::parallel_for(tbb::blocked_range<size_t>(0, size()),
                      [&](const tbb::blocked_range<size_t>& range) {
                        for (size_t i = range.begin(); i < range.end(); ++i) {
                          (*this)[i] /= val;
                        }
                      });
    return *this;
  }

  /// @brief Squares all qbpp::Expr objects in the vector in element-wise.
  /// @return A reference to this object after squaring the vector.
  Vector<T>& sqr() {
    *this *= *this;
    return *this;
  }

  /// @brief Simplifies all qbpp::Expr objects in the vector in element-wise.
  /// @param sort_vars_func A function to sort the variables in the
  /// expression.
  /// @return A reference to this object after simplifying the vector.
  Vector<T>& simplify(Vars (*sort_vars_func)(const Vars&) = sort_vars);

  /// @brief Simplifies the vector of qbpp::Expr objects as binary in
  /// element-wise.
  /// @return A reference to this object after simplifying the vector.
  Vector<T>& simplify_as_binary() {
    *this = simplify(sort_vars_as_binary);
    return *this;
  }

  /// @brief Simplifies the vector of qbpp::Expr objects as spin in
  /// element-wise.
  /// @return A reference to this object after simplifying the vector.
  Vector<T>& simplify_as_spin() {
    *this = simplify(sort_vars_as_spin);
    return *this;
  }

  /// @brief Converts the vector of HUBO qbpp::Expr objects to Ising
  /// qbpp::objects in element-wise.
  /// @return A reference to this object after converting the vector.
  Vector<T>& binary_to_spin() {
    *this = qbpp::binary_to_spin(*this);
    return *this;
  }

  /// @brief Simplifies the vector of Ising qbpp::Expr objects to HUBO
  /// qbpp::objects in element-wise.
  /// @return A reference to this object after converting the vector.
  Vector<T>& spin_to_binary() {
    *this = qbpp::spin_to_binary(*this);
    return *this;
  }

  /// @brief Replace the vector of qbpp::Expr objects.
  /// @param map_list A list of Var and VarInt and Expr pairs.
  Vector<T>& replace(const MapList& map_list);

  /// @brief Replace the vector of qbpp::Expr objects.
  /// @return The replaced vector of qbpp::Expr objects.
  Vector<T>& reduce();

  /// @brief Transposes the two-dimensional vector.
  /// @return A reference to this object after transposing the vector.
  Vector<T>& transpose() {
    *this = transpose(*this);
    return *this;
  }

  auto operator()(const Sol& sol) const { return sol(*this); }

  /// @brief Returns a vector of vars() results from each element.
  /// @return A Vector containing the result of calling vars() on each element.
  /// @note This method is only available when T has a vars() method.
  template <typename U = T>
  auto vars() const -> Vector<decltype(std::declval<U>().vars())> {
    Vector<decltype(std::declval<U>().vars())> result;
    result.reserve(size());
    for (const auto& elem : data_) {
      result.push_back(elem.vars());
    }
    return result;
  }
};

// --------------------------------------------------
// Vector Comparison Operators
// --------------------------------------------------

/// @brief Equality comparison operator for Vector.
template <typename T>
bool operator==(const Vector<T>& lhs, const Vector<T>& rhs) {
  return lhs.size() == rhs.size() &&
         std::equal(lhs.begin(), lhs.end(), rhs.begin());
}

/// @brief Inequality comparison operator for Vector.
template <typename T>
bool operator!=(const Vector<T>& lhs, const Vector<T>& rhs) {
  return !(lhs == rhs);
}

/// @brief Less-than comparison operator for Vector.
template <typename T>
bool operator<(const Vector<T>& lhs, const Vector<T>& rhs) {
  return std::lexicographical_compare(lhs.begin(), lhs.end(), rhs.begin(),
                                      rhs.end());
}

/// @brief Less-than-or-equal comparison operator for Vector.
template <typename T>
bool operator<=(const Vector<T>& lhs, const Vector<T>& rhs) {
  return !(rhs < lhs);
}

/// @brief Greater-than comparison operator for Vector.
template <typename T>
bool operator>(const Vector<T>& lhs, const Vector<T>& rhs) {
  return rhs < lhs;
}

/// @brief Greater-than-or-equal comparison operator for Vector.
template <typename T>
bool operator>=(const Vector<T>& lhs, const Vector<T>& rhs) {
  return !(lhs < rhs);
}

// --------------------------------------------------
// Class Var Declaration
// --------------------------------------------------

/// @brief Class to store a single variable.
/// @note Do not add other members to maximize the performance.
class Var {
  /// @brief Index of the variable. The index starts from 0.
  /// @note Var stores only the index of the variable to maximize performance.
  /// No other information is stored.
  vindex_t index_;

 public:
  /// @brief Default constructor:
  Var() = default;

  /// @brief Constructor: creates a new Var with an index.
  /// @note This constructor is explicit to avoid implicit type conversion
  /// from int to Var.
  explicit constexpr Var(vindex_t index) : index_(index) {}
  /// @brief Gets the index of the qbpp::Var object
  vindex_t index() const { return index_; }

  std::string str() const { return qbpp_var_str(index_); }

  /// @brief Compares this object with another Var for equality.
  /// @param var Var object to compare with.
  /// @return true if the indices of the two Var objects are equal.
  bool operator==(Var var) const { return index_ == var.index_; }

  /// @brief Compares this object with another Var for inequality.
  bool operator!=(Var var) const { return index_ != var.index_; }
  /// @brief Branchless comparison key: maps Var index to a value that
  /// preserves the ordering (base_index first, then negation bit).
  /// x0(0) → 0, ~x0 → 1, x1 → 2, ~x1 → 3, ..., VarVoid → 0xFFFFFFFF
  static vindex_t order_key(vindex_t idx) {
    return ((idx & qbpp::vindex_mask) << 1) | (idx >> 31);
  }

  ///@brief Compares this object with another Var to check if less than.
  ///@param var Var object to compare with.
  ///@return true if this index is less than the index of the other Var.
  bool operator<(Var var) const {
    return order_key(index_) < order_key(var.index_);
  }

  ///@brief Compares this object with another Var to check if greater than.
  ///@param var Var object to compare with.
  ///@return true if this index is greater than the index of the other Var.
  bool operator>(Var var) const {
    return order_key(index_) > order_key(var.index_);
  }

  bool operator<=(Var var) const {
    return order_key(index_) <= order_key(var.index_);
  }

  /// @brief Returns the size of this object.
  /// @return 1, the size of the Var object.
  size_t size() const { return 1; }

  /// @brief Returns the value of the variable in the solution.
  int32_t operator()(const Sol& sol) const;
};  // class Var

namespace impl {
/// @brief A constant Var object representing a non-existing variable.
inline constexpr Var VarVoid{qbpp::vindex_limit};
template <std::size_t N>
class VarArray {
  Var vars_[N];

 public:
  /// @brief Default constructor: Minimal initialization for performance.
  /// @note Does NOT initialize elements to VarVoid. This is intentional to
  /// avoid double initialization when used with resize() followed by immediate
  /// assignment (common in parallel processing with TBB).
  constexpr VarArray() : vars_{} {}

  struct EMPTY {};
  constexpr VarArray(EMPTY) {
    for (std::size_t i = 0; i < N; ++i) vars_[i] = VarVoid;
  }

  constexpr explicit VarArray(Var var) : vars_{} {
    vars_[0] = var;
    for (std::size_t i = 1; i < N; ++i) vars_[i] = VarVoid;
  }

  constexpr explicit VarArray(Var var0, Var var1) : vars_{} {
    vars_[0] = var0;
    vars_[1] = var1;
    for (std::size_t i = 2; i < N; ++i) vars_[i] = VarVoid;
  }

  constexpr VarArray(std::initializer_list<Var> init) : vars_{} {
    std::size_t i = 0;
    for (Var v : init) {
      if (i >= N) break;
      vars_[i++] = v;
    }
    for (; i < N; ++i) vars_[i] = VarVoid;
  }

  void push_back(Var var) {
    assert(var != VarVoid);
    for (std::size_t i = 0; i < N; ++i) {
      if (vars_[i] == VarVoid) {
        vars_[i] = var;
        return;
      }
    }
    throw std::out_of_range("VarArray is full");
  }

  /// @brief Returns the number of valid (non-VarVoid) variables.
  /// @note Branchless implementation using addition of boolean comparisons.
  std::size_t size() const {
    if constexpr (N == 1) {
      return std::size_t(vars_[0] != VarVoid);
    } else if constexpr (N == 2) {
      return std::size_t(vars_[0] != VarVoid) + (vars_[1] != VarVoid);
    } else if constexpr (N == 3) {
      return std::size_t(vars_[0] != VarVoid) + (vars_[1] != VarVoid) +
             (vars_[2] != VarVoid);
    } else if constexpr (N == 4) {
      return std::size_t(vars_[0] != VarVoid) + (vars_[1] != VarVoid) +
             (vars_[2] != VarVoid) + (vars_[3] != VarVoid);
    } else {
      std::size_t count = 0;
      for (std::size_t i = 0; i < N; ++i) count += (vars_[i] != VarVoid);
      return count;
    }
  }

  bool empty() const { return vars_[0] == VarVoid; }

  Var& operator[](std::size_t i) { return vars_[i]; }
  const Var& operator[](std::size_t i) const { return vars_[i]; }

  Var* begin() { return vars_; }
  Var* end() { return vars_ + size(); }
  const Var* begin() const { return vars_; }
  const Var* end() const { return vars_ + size(); }

  void clear() {
    for (std::size_t i = 0; i < N; ++i) vars_[i] = VarVoid;
  }

  Var& back() {
    assert(vars_[0] != VarVoid);
    for (std::size_t i = N; i-- > 0;) {
      if (vars_[i] != VarVoid) return vars_[i];
    }
    return vars_[0];  // fallback
  }

  void pop_back() {
    for (std::size_t i = N; i-- > 0;) {
      if (vars_[i] != VarVoid) {
        vars_[i] = VarVoid;
        return;
      }
    }
  }

  /// @brief Equality comparison using memcmp for optimal codegen.
  /// @note For N=2 (8 bytes), compiles to a single 64-bit comparison.
  /// For N=4 (16 bytes), compiles to two 64-bit comparisons or SSE.
  bool operator==(const VarArray& other) const {
    return std::memcmp(vars_, other.vars_, N * sizeof(Var)) == 0;
  }

  bool operator!=(const VarArray& other) const {
    return std::memcmp(vars_, other.vars_, N * sizeof(Var)) != 0;
  }

  /// @brief Lexicographic less-than using branchless Var::order_key.
  /// @note For N=2, packs two keys into a single uint64_t comparison.
  bool operator<(const VarArray& other) const {
    if constexpr (N <= 2) {
      // Pack keys: [0] in high 32 bits, [1] in low 32 bits
      // → single uint64_t comparison preserves lexicographic order
      auto pack = [](const VarArray& a) -> uint64_t {
        uint64_t k0 = Var::order_key(a.vars_[0].index());
        if constexpr (N == 1) return k0;
        uint64_t k1 = Var::order_key(a.vars_[1].index());
        return (k0 << 32) | k1;
      };
      return pack(*this) < pack(other);
    } else {
      for (std::size_t i = 0; i < N; ++i)
        if (vars_[i] != other.vars_[i]) return vars_[i] < other.vars_[i];
      return false;
    }
  }

  VarArray& operator*=(const VarArray& vars) {
    std::size_t i = 0;
    for (; i < N && vars_[i] != VarVoid; ++i);
    for (std::size_t j = 0; j < N; ++j) {
      if (vars.vars_[j] == VarVoid) break;

      if (i >= N) {
        throw std::out_of_range("VarArray is full");
      }

      vars_[i++] = vars.vars_[j];
    }
    return *this;
  }
};

}  // namespace impl

class IVMapper {
  void* impl_;

 public:
  explicit IVMapper(const Expr& expr);

  ~IVMapper() {
    if (impl_) {
      qbpp_iv_mapper_destroy(impl_);
    }
  }

  vindex_t var_count() const { return qbpp_iv_mapper_var_count(impl_); }

  vindex_t index(Var var) const {
    return qbpp_iv_mapper_index(impl_, var.index() & vindex_mask);
  }

  Var var(vindex_t index) const {
    return Var(qbpp_iv_mapper_var(impl_, index));
  }

  bool has(Var var) const {
    return qbpp_iv_mapper_has(impl_, var.index() & vindex_mask) != 0;
  }
};

// --------------------------------------------------
// Class Term Declaration
// --------------------------------------------------

/// @brief Class to store a term in an expression.
/// @note Represented as coeff * vars[0] * vars[1] * ...
class Term {
  ///@brief Term coefficient
  coeff_t coeff_{1};

  /// @brief A vector of variables (qbpp::Var objects) in the term.
  /// @note The same variables may appear multiple times in the term to
  /// represent their power.
  Vars vars_;

 public:
  /// @brief Default constructor: Creates a space for a Term object.
  /// @note This constructor does not initialize the coefficient or the vars.
  /// This is intentional for performance: resize() followed by immediate
  /// assignment is a common pattern in parallel processing (e.g., TBB).
  /// Avoiding initialization here prevents double initialization overhead.
  Term() = default;

  /// @brief Copy constructor: Creates a new Term object from another Term.
  Term(const Term&) = default;

  /// @brief Move constructor: Creates a new Term object from another Term.
  Term(Term&&) noexcept = default;

/// @brief Constructor: Creates a new Term with a coefficient and no
/// variables.
/// @param coeff Term coefficient.
/// @note This constructor is explicit to avoid implicit conversion from int
/// to Term.
#if defined(MAXDEG) && MAXDEG > 0
  template <
      typename T,
      typename std::enable_if<
          std::is_convertible<std::decay_t<T>, coeff_t>::value, int>::type = 0>
  explicit Term(T&& val)
      : coeff_{static_cast<coeff_t>(std::forward<T>(val))},
        vars_(Vars::EMPTY{}) {}
#else
  template <
      typename T,
      typename std::enable_if<
          std::is_convertible<std::decay_t<T>, coeff_t>::value, int>::type = 0>
  explicit Term(T&& val) : coeff_{static_cast<coeff_t>(std::forward<T>(val))} {}
#endif

  explicit Term(Var var) : vars_({var}) {}
  /// @brief Constructor: Creates a new Term with a coefficient and a single
  /// variable.
  /// @param var Variable in the term.
  /// @param coeff Term coefficient.
  template <
      typename T,
      typename std::enable_if<
          std::is_convertible<std::decay_t<T>, coeff_t>::value, int>::type = 0>
#if defined(MAXDEG) && MAXDEG > 0
  explicit Term(Var var, T&& val)
      : coeff_{static_cast<coeff_t>(std::forward<T>(val))}, vars_(var) {
  }
#else
  explicit Term(Var var, T&& val)
      : coeff_{static_cast<coeff_t>(std::forward<T>(val))}, vars_({var}) {
  }
#endif
#if defined(MAXDEG) && MAXDEG > 0
  explicit Term(Var var1, Var var2) : vars_(var1, var2) {}
#else
  explicit Term(Var var1, Var var2) : vars_({var1, var2}) {}
#endif

  /// @brief Constructor: Creates a new Term with a coefficient and
  /// a vector of variables (copy).
  /// @param vars The vector of variables.
  /// @param coeff The coefficient of the term.
  explicit Term(const Vars& vars) : vars_(vars) {}

  /// @brief Constructor: Creates a new Term with a coefficient and a vector
  /// of variables. (move)
  /// @param vars The vector of variables.
  /// @param coeff The coefficient of the term.
  explicit Term(Vars&& vars) noexcept : vars_(std::move(vars)) {}

  template <
      typename T,
      typename std::enable_if<
          std::is_convertible<std::decay_t<T>, coeff_t>::value, int>::type = 0>
  explicit Term(const Vars& vars, T&& val)
      : coeff_(static_cast<coeff_t>(std::forward<T>(val))), vars_{vars} {}

  template <
      typename T,
      typename std::enable_if<
          std::is_convertible<std::decay_t<T>, coeff_t>::value, int>::type = 0>
  explicit Term(Vars&& vars, T&& val)
      : coeff_(static_cast<coeff_t>(std::forward<T>(val))),
        vars_(std::move(vars)) {}

  std::string str() const { return (qbpp::str(*this)); }

  /// @brief Copy assignment operator to copy Term object.
  /// @return A reference to this object after copying the Term.
  //  Term &operator=(const Term &) = default;
  Term& operator=(const Term& arg) {
    coeff_ = arg.coeff_;
    vars_ = arg.vars_;
    return *this;
  }

  /// @brief Move assignment operator to move Term object.
  /// @return A reference to this object after moving the Term.
  //  Term &operator=(Term &&) noexcept = default;
  Term& operator=(Term&& arg) noexcept {
    coeff_ = arg.coeff_;
    vars_ = std::move(arg.vars_);
    return *this;
  }

  /// @brief Gets the coefficient of the term.
  /// @return The coefficient of the term.
  coeff_t coeff() const { return coeff_; }

  coeff_t& coeff() { return coeff_; }

  /// @brief Gets the vector of variables in the term (non-const).
  Vars& vars() { return vars_; }

  /// @brief Gets the vector of variables in the term (const).
  const Vars& vars() const { return vars_; }

  const Var vars(vindex_t i) const { return vars_[i]; }
  Var& vars(vindex_t i) { return vars_[i]; }

  /// @brief Gets the number of variables in the term.
  /// @return The number of variables in the term.
  vindex_t var_count() const { return static_cast<vindex_t>(vars_.size()); }

  Var var(vindex_t i) const { return vars_[i]; }
  Var& var(vindex_t i) { return vars_[i]; }

  /// @brief Compares this object with another Term object for equality.
  /// @param term The Term object to compare with.
  /// @return true If this term is equal to the other term.
  /// @note This function is used in Expr == Expr. Since C++17 does not
  /// support default operator==, this function is necessary.
  bool operator==(const Term& term) const {
    return (coeff_ == term.coeff_) && (vars_ == term.vars_);
  }

  /// @brief Compares this object with another Term object for inequality.
  /// @param term The Term object to compare with.
  /// @return true If this term is not equal to the other term.
  bool operator!=(const Term& term) const { return !(*this == term); }

  /// @brief Negates the coefficient of the term.
  Term& negate() {
    coeff_ = -coeff_;
    return *this;
  }

  /// @brief Compares this object with another Term object for less than.
  /// @param term The Term object to compare with.
  /// @return true If this term is less than the other term.
  /// @note This function is used to sort terms in an expression.
  bool operator<(const Term& term) const {
    auto vc1 = var_count(), vc2 = term.var_count();
    if (vc1 != vc2) return vc1 < vc2;
    return vars_ < term.vars_;
  }

  bool operator<=(const Term& term) const {
    return *this < term || *this == term;
  }

  /// @brief Multiplies this term by a value.
  /// @param val The value to multiply.
  /// @return A reference to this object after multiplying the term by the
  /// value. This function is used in Expr *= int.
  //  template <typename T,
  //            typename std::enable_if<std::is_integral<T>::value,
  //            int>::type = 0>
  template <
      typename T,
      typename std::enable_if<
          std::is_convertible<std::decay_t<T>, coeff_t>::value, int>::type = 0>
  Term& operator*=(T&& val) {
    coeff_ *= static_cast<coeff_t>(std::forward<T>(val));
    return *this;
  }

  Term& operator*=(Var var) {
    vars_.push_back(var);
    return *this;
  }

  /// @brief Multiplies this term by another Term object.
  /// @param term The term to multiply.
  /// @return A reference to this object after multiplying the terms.
  /// @note This function is used in Expr *= Expr.

  Term& operator*=(const Term& term) {
    coeff_ *= term.coeff_;
#if defined(MAXDEG) && MAXDEG > 0
    vars_ *= term.vars_;
#else
    vars_.reserve(var_count() + term.var_count());
    vars_.insert(vars_.end(), term.vars_.begin(), term.vars_.end());
#endif
    return *this;
  }

  /// @brief Divides this term by a value.
  /// @param val The right-hand side operand.
  /// @return A reference to this object after dividing the term by the
  /// value.
  template <
      typename T,
      typename std::enable_if<
          std::is_convertible<std::decay_t<T>, coeff_t>::value, int>::type = 0>
  Term& operator/=(T&& val) {
    if constexpr (std::is_integral<coeff_t>::value) {
      // coeff % val == 0 is not used because this line is compiled
      // even if coeff and val are float.
      if ((coeff_ / val) * val != coeff_) {
        throw std::runtime_error(
            THROW_MESSAGE("Indivisible division occurred."));
      }
    }
    coeff_ /= std::forward<T>(val);
    return *this;
  }

  /// @brief Returns the negation of the term by modifying its coefficient.
  /// @note This function updates the coefficient of the term directly.
  Term& operator-() && {
    coeff_ = -coeff_;
    return *this;
  }

  /// @brief Returns a negated copy of the term.
  /// @note This function creates a copy and negates the coefficient without
  /// modifying the original term.
  Term operator-() const& {
    Term result = *this;
    result.coeff_ = -result.coeff_;
    return result;
  }

  bool is_simplified_as_binary() const {
    auto v_count = var_count();
    if (v_count == 0 || v_count == 1) {
      return true;
    }
    for (vindex_t i = 1; i < v_count; ++i) {
      if (vars_[i - 1] > vars_[i]) {
        return false;
      }
    }
    return true;
  }
};

// --------------------------------------------------
// Class Terms Declaration
// --------------------------------------------------

/// @brief Class to store a vector of term objects.
class Terms {
  /// @brief A vector of terms.
  std::vector<Term> terms_;

 public:
  Terms() { terms_.reserve(TERM_CAPACITY); };

  explicit Terms(std::initializer_list<Term> init) : Terms() { terms_ = init; }

  explicit Terms(Var var) : Terms() { terms_.push_back(Term(var)); }

  template <
      typename T,
      typename std::enable_if<
          std::is_convertible<std::decay_t<T>, energy_t>::value, int>::type = 0>
  explicit Terms(Var var, T&& val) : Terms() {
    terms_.push_back(Term{var, std::forward<T>(val)});
  }

  explicit Terms(const Term& term) : Terms() { terms_.push_back(term); }

  explicit Terms(Term&& term) : Terms() { terms_.push_back(std::move(term)); }

  explicit Terms(const Term& term1, const Term& term2) : Terms() {
    terms_.push_back(term1);
    terms_.push_back(term2);
  }
  explicit Terms(const Term& term1, Term&& term2) : Terms() {
    terms_.push_back(term1);
    terms_.push_back(std::move(term2));
  }
  explicit Terms(Term&& term1, const Term& term2) : Terms() {
    terms_.push_back(std::move(term1));
    terms_.push_back(term2);
  }
  explicit Terms(Term&& term1, Term&& term2) : Terms() {
    terms_.push_back(std::move(term1));
    terms_.push_back(std::move(term2));
  }

  size_t size() const { return terms_.size(); }

  Term& operator[](size_t i) { return terms_[i]; }
  const Term& operator[](size_t i) const { return terms_[i]; }

  auto begin() { return terms_.begin(); }
  auto end() { return terms_.end(); }
  auto begin() const { return terms_.begin(); }
  auto end() const { return terms_.end(); }
  Term& back() { return terms_.back(); }
  const Term& back() const { return terms_.back(); }

  void push_back(const Term& term) { terms_.push_back(term); }
  void push_back(Term&& term) { terms_.push_back(std::move(term)); }
  void pop_back() { terms_.pop_back(); }
  Term& front() { return terms_.front(); }
  const Term& front() const { return terms_.front(); }

  template <typename... Args>
  Term& emplace_back(Args&&... args) {
    return terms_.emplace_back(std::forward<Args>(args)...);
  }

  std::vector<Term>::iterator erase(std::vector<Term>::iterator pos) {
    return terms_.erase(pos);
  }

  std::vector<Term>::iterator erase(std::vector<Term>::iterator first,
                                    std::vector<Term>::iterator last) {
    return terms_.erase(first, last);
  }

  bool empty() const { return terms_.empty(); }

  void reserve(size_t n) { terms_.reserve(n); }

  void clear() { terms_.clear(); }

  void resize(size_t n) { terms_.resize(n); }

  // resize to n elements with a specified default value
  void resize(size_t n, const Term& value) { terms_.resize(n, value); }

  std::vector<Term>::iterator insert(std::vector<Term>::iterator pos,
                                     const Term& value) {
    return terms_.insert(pos, value);
  }

  std::vector<Term>::iterator insert(std::vector<Term>::iterator pos,
                                     Term&& value) {
    return terms_.insert(pos, std::move(value));
  }

  template <typename InputIt>
  std::vector<Term>::iterator insert(std::vector<Term>::iterator pos,
                                     InputIt first, InputIt last) {
    return terms_.insert(pos, first, last);
  }

  /// @brief Negates all terms in Terms.
  Terms& negate() {
    if (size() < SEQ_THRESHOLD) {
      for (auto& t : terms_) {
        t.negate();
      }
      return *this;
    }
    tbb::parallel_for(size_t(0), size(), [&](size_t i) { terms_[i].negate(); });
    return *this;
  }

  /// @brief Adds a term to this Terms object.
  Terms& operator+=(const Term& term) {
    if (term.coeff() != 0) {
      push_back(term);
    }
    return *this;
  }

  /// @brief Adds a term to this Terms object.
  Terms& operator+=(Term&& term) {
    if (term.coeff() != 0) {
      push_back(std::move(term));
    }
    return *this;
  }

  /// @brief Adds a vector of terms to this Terms object.
  Terms& operator+=(const Terms& terms) {
    if (terms.size() < SEQ_THRESHOLD) {
      terms_.insert(terms_.end(), terms.begin(), terms.end());
      return *this;
    } else {
      size_t old_size = terms_.size();
      terms_.resize(old_size + terms.size());
      tbb::parallel_for(size_t(0), terms.size(),
                        [&](size_t i) { terms_[old_size + i] = terms[i]; });
      return *this;
    }
  }

  /// @brief Adds a vector of terms to this Terms object.
  Terms& operator+=(Terms&& terms) {
    if (terms.size() < SEQ_THRESHOLD) {
      std::move(terms.begin(), terms.end(), std::back_inserter(terms_));
    } else {
      size_t old_size = terms_.size();
      terms_.resize(old_size + terms.size());
      tbb::parallel_for(size_t(0), terms.size(), [&](size_t i) {
        terms_[old_size + i] = std::move(terms[i]);
      });
    }
    return *this;
  }

  Terms& operator-=(const Term& term) {
    push_back(-term);
    return *this;
  }

  Terms& operator*=(const coeff_t& val) {
    if (val == 0) {
      terms_.clear();
      return *this;
    }
    if (val == 1) {
      return *this;
    }
    if (val == -1) {
      for (auto& t : terms_) {
        t.negate();
      }
      return *this;
    }
    for (auto& t : terms_) {
      t *= val;
    }
    return *this;
  }

  Terms& operator*=(const Term& term) {
    if (term.var_count() == 0) {
      *this *= term.coeff();
      return *this;
    }
    for (auto& t : terms_) {
      t *= term;
    }
    return *this;
  }

  template <
      typename T,
      typename std::enable_if<
          std::is_convertible<std::decay_t<T>, coeff_t>::value, int>::type = 0>
  Terms& operator/=(T&& val) {
    if (val == 1) {
      return *this;
    }
    for (auto& t : terms_) {
      t /= val;
    }
    return *this;
  }
};

// --------------------------------------------------
// Class Expr Declaration
// --------------------------------------------------

/// @brief Class to store an expression.
class Expr {
  /// @brief Constant term of the expression
  energy_t constant_{0};

  /// @brief A set of terms in the expression.
  /// @note The terms are stored in a vector.
  Terms terms_;

  /// @brief The constructor for bool is deleted to prevent unintended
  /// creation.
  /// @param b The boolean value used to create an expression.
  /// @note While "Expr == int" is allowed and generates a new Expr object,
  /// "Expr == Expr" returns a bool and does not generate a new Expr object.
  /// Therefore, this constructor is deleted. If "Expr == Expr" is used
  /// with the intention of returning a new Expr object, a compile error
  /// will be triggered.
  explicit Expr(bool b) = delete;

 public:
  /// @brief Default constructor: Construct a new Expr object with a
  /// constant_ of 0 and no terms.
  /// @note TERM_CAPACITY is the initial capacity of the term vector.
  Expr() { terms_.reserve(TERM_CAPACITY); };

  /// @brief Default Copy constructor to create a new Expr object from
  /// another Expr object.
  Expr(const Expr& expr) = default;

  /// @brief Default move constructor to create a new Expr object from
  /// another Expr object.
  Expr(Expr&& expr) noexcept = default;

  /// @brief Constructor to create a new Expr object from a value convertible
  /// to energy_t.
  /// @brief Constructs an Expr from an integer value.
  /// @param value The integer value.
  /// @note Enables implicit conversion from int to Expr (e.g., for MapList).
  Expr(int value) : constant_(value) { terms_.reserve(TERM_CAPACITY); }

  /// @param value The value in the expression.
  /// @note Uses forwarding reference to support both copy and move semantics.
  template <typename T,
            typename std::enable_if<
                std::is_convertible<std::decay_t<T>, energy_t>::value &&
                    !std::is_same<std::decay_t<T>, int>::value,
                int>::type = 0>
  Expr(T&& value) {
    constant_ = static_cast<energy_t>(std::forward<T>(value));
    terms_.reserve(TERM_CAPACITY);
  }

  /// @brief Constructs a new Expr object from a single variable.
  Expr(Var var) : terms_{var} {}

  template <typename T,
            typename std::enable_if<std::is_convertible<T, energy_t>::value,
                                    int>::type = 0>
  Expr(Var var, const T& val) : terms_{var, val} {}

  Expr(Var var, energy_t&& val) : terms_{var, std::move(val)} {}

  Expr(const Term& term) : terms_{term} {}

  Expr(Term&& term) : terms_{std::move(term)} {}

  /// @brief Constructs a new Expr object from a single term and a constant.
  template <typename T,
            typename std::enable_if<std::is_integral<T>::value, int>::type = 0>
  explicit Expr(const Term& term, T constant = 0)
      : constant_{constant}, terms_{term} {}

  /// @brief Constructs a new Expr object from a single term and a constant.
  template <typename T,
            typename std::enable_if<std::is_integral<T>::value, int>::type = 0>
  explicit Expr(Term&& term, T constant = 0)
      : constant_{constant}, terms_{std::move(term)} {}

  /// @brief Constructs a new Expr object from two terms.
  explicit Expr(const Term& term1, const Term& term2) : terms_{term1, term2} {}

  /// @brief Constructs a new Expr object from two terms.
  explicit Expr(const Term& term1, Term&& term2)
      : terms_{term1, std::move(term2)} {}

  /// @brief Constructs a new Expr object from two terms.
  explicit Expr(Term&& term1, const Term& term2)
      : terms_{std::move(term1), term2} {}

  /// @brief Constructs a new Expr object from two terms.
  explicit Expr(Term&& term1, Term&& term2)
      : terms_{std::move(term1), std::move(term2)} {}

  /// @brief Constructs a new Expr object from an lvalue Term object.
  /// @param term The term in the expression.
  /// @param term_capacity The initial capacity of the term vector.
  /// @note This constructor is used for implicit conversion from Term to
  /// Expr.

  /// @brief Constructs a new Expr object from a constant and a set of
  /// terms.
  explicit Expr(const energy_t& constant, Terms&& terms) noexcept
      : constant_(constant), terms_(std::move(terms)) {}

  /// @brief Constructs a new Expr object from a constant and a set of
  /// terms.
  explicit Expr(const energy_t& constant, const Terms& terms) noexcept
      : constant_(constant), terms_(terms) {}

  /// @brief Constructs a new Expr object from an lvalue VarInt object.
  /// @param var_int The integer variable in the expression.
  /// @note This constructor is used for implicit conversion from VarInt to
  /// Expr.
  Expr(const VarInt& var_int);

  /// @brief Constructs a new Expr object from an rvalue VarInt object.
  /// @param var_int The integer variable in the expression.
  /// @note This constructor is used for implicit conversion from VarInt to
  /// Expr.
  Expr(VarInt&& var_int);

  explicit Expr(Var var, const energy_t& constant) noexcept
      : constant_(constant) {
    terms_.emplace_back(Term(var));
  }

  std::string str() const { return qbpp::str(*this); }

  /// @brief Copy assignment operator to copy the Expr object.
  /// @param expr The Expr object to copy.
  /// @return A reference to this object after copying the Expr.
  Expr& operator=(const Expr& expr) {
    if (this != &expr) {
      constant_ = expr.constant_;
      terms_ = expr.terms_;
    }
    return *this;
  }

  ///@brief Move assignment operator to move the Expr object.
  ///@param expr The Expr object to move.
  /// @ return A reference to this object after moving the Expr.
  Expr& operator=(Expr&& expr) noexcept {
    if (this != &expr) {
      constant_ = expr.constant_;
      terms_ = std::move(expr.terms_);
    }
    return *this;
  }

  /// @brief Multiplies this Expr object by a value.
  /// @param val The value to multiply.
  /// @return A reference to this object after the multiplication.
  template <
      typename T,
      typename std::enable_if<
          std::is_convertible<std::decay_t<T>, energy_t>::value, int>::type = 0>
  Expr& operator*=(T&& val) {
    constant_ *= static_cast<energy_t>(std::forward<T>(val));
    terms_ *= static_cast<coeff_t>(std::forward<T>(val));
    return *this;
  }

  /// @brief Multiplies this Expr object by a Term object.
  /// @param term The term to multiply.
  /// @return A reference to this object after the multiplication.
  Expr& operator*=(const Term& term);

  Expr& operator+=(const Terms& terms) {
    terms_ += terms;
    return *this;
  }

  Expr& operator+=(Terms&& terms) {
    terms_ += std::move(terms);
    return *this;
  }

  Expr& operator+=(const Term& term) {
    terms_ += term;
    return *this;
  }

  Expr& operator+=(Term&& term) {
    terms_ += std::move(term);
    return *this;
  }

  Expr& operator-=(const Term& term) {
    terms_ -= term;
    return *this;
  }

  Expr& operator-=(Term&& term) {
    terms_ -= std::move(term);
    return *this;
  }

  /// @brief Multiplies this Expr object by the given Expr.
  /// @param expr The Expr object to multiply by.
  /// @return A reference to this object after multiplication.
  Expr& operator*=(const Expr& expr);

  /// @brief Adds another Expr object to this Expr object.
  /// @param expr The Expr object to add.
  /// @return A reference to this object after addition.
  Expr& operator+=(const Expr& expr) {
    constant_ += expr.constant_;
    auto expr2 = expr;
    terms_.insert(terms_.end(), expr2.terms_.begin(), expr2.terms_.end());
    return *this;
  }

  /// @brief Subtracts another Expr object from this Expr object.
  /// @param expr The Expr object to subtract.
  /// @return A reference to this object after subtraction.
  Expr& operator-=(const Expr& expr) {
    auto expr2 = -expr;
    *this += std::move(expr2);
    return *this;
  }

  /// @brief Divides this Expr object by an integer value.
  /// @param val The integer value to divide.
  /// @return A reference to this object after division
  template <
      typename T,
      typename std::enable_if<
          std::is_convertible<std::decay_t<T>, coeff_t>::value, int>::type = 0>
  Expr& operator/=(T&& val) {
    if (val == 0) {
      throw std::runtime_error(THROW_MESSAGE("Division by zero."));
    }
    tbb::parallel_for(size_t(0), terms_.size(),
                      [&](size_t i) { terms_[i] /= val; });
    // Use compound assignment to avoid ambiguity with Boost operators
    auto divisor = static_cast<coeff_t>(val);
    energy_t temp = constant_;
    temp /= divisor;
    temp *= divisor;
    if (temp != constant_) {
      throw std::runtime_error(THROW_MESSAGE("Indivisible division occurred."));
    }
    constant_ /= static_cast<coeff_t>(std::forward<T>(val));
    return *this;
  }

  template <
      typename T,
      typename std::enable_if<
          std::is_convertible<std::decay_t<T>, energy_t>::value, int>::type = 0>
  Expr& operator+=(T&& val) {
    constant_ += static_cast<energy_t>(std::forward<T>(val));
    return *this;
  }

  template <
      typename T,
      typename std::enable_if<
          std::is_convertible<std::decay_t<T>, energy_t>::value, int>::type = 0>
  Expr& operator-=(T&& val) {
    constant_ -= static_cast<energy_t>(std::forward<T>(val));
    return *this;
  }

  /// @brief sqr() function for Expr objects.
  Expr& sqr() {
    *this *= *this;
    return *this;
  }

  /// @brief Simplifies this Expr object using the specified sorting
  /// function.
  /// @param sort_vars The function used to sort the variables.
  /// @return A reference to this object after simplification.
  /// @note This function modifies this object in place.
  Expr& simplify(Vars (*sort_vars)(const Vars&) = qbpp::sort_vars);

  /// @brief Simplifies this Expr object assuming all variables are
  /// binary.
  /// @return A reference to this object after simplification.
  /// @note This function modifies this object in place.
  Expr& simplify_as_binary();

  /// @brief Simplifies this Expr object assuming all variables are
  /// spin.
  /// @return A reference to this object after simplification.
  /// @note This function modifies this object in place.
  Expr& simplify_as_spin();

  /// @brief Returns the constant part of the Expr object.
  energy_t constant() const { return constant_; }

  /// @brief Returns the reference to the constant part of the Expr object.
  energy_t& constant() { return constant_; }

  /// @brief Gets the const reference to the list of Term objects in the
  /// Expr.
  const Terms& terms() const { return terms_; }

  /// @brief Gets the reference to the list of Term objects in the Expr.
  Terms& terms() { return terms_; }

  Term& term(size_t i) { return terms_[i]; }
  const Term& term(size_t i) const { return terms_[i]; }

  /// @brief Gets the number of terms in the Expr object.
  /// @return The number of terms in the Expr object.
  size_t term_count() const { return terms_.size(); }

  /// @brief Returns the size of the Expr object.
  /// @return The number of terms in the Expr object.
  /// @note This function is used to estimate the size of the Expr
  /// object and determine whether parallelization should be used.
  size_t size() const { return term_count(); }

  Expr& negate() {
    terms_.negate();
    constant_ = -constant_;
    return *this;
  }

  /// @brief Updates the expression by replacing the variables with an
  /// expression.
  /// @param map_list A mapping of variables to their corresponding
  /// expressions.
  Expr& replace(const MapList& map_list);

  energy_t operator()(const MapList& map_list) const {
    return qbpp::eval(*this, map_list);
  }

  energy_t operator()(const Sol& sol) const { return qbpp::eval(*this, sol); }

  /// @brief Reduces the degree of this object to be at most 2.
  /// @return This object after reducing the degree.
  Expr& reduce() { return *this = qbpp::reduce(*this); }

  ///@brief Converts HUBO to Spin.
  ///@return This object after converting HUBO to Spin.
  Expr& binary_to_spin() { return *this = qbpp::binary_to_spin(*this); }

  ///@brief Converts Spin to HUBO.
  ///@return This object after converting Spin to HUBO.
  Expr& spin_to_binary() { return *this = qbpp::spin_to_binary(*this); }

  /// @brief Returns the sum of the positive coefficients in the
  /// expression.
  /// @note The return value provides the upper bound of the value of
  /// the expression.
  energy_t pos_sum() const {
    Expr temp = qbpp::simplify_as_binary(*this);
    energy_t sum = temp.constant_;
    for (const auto& term : temp.terms_) {
      if (term.coeff() > 0) {
        sum += term.coeff();
      }
    }
    return sum;
  }

  /// @brief Returns the sum of the negative coefficients in the
  /// expression.
  /// @note The return value provides the lower bound of the value of
  /// the expression.
  energy_t neg_sum() const {
    Expr temp = qbpp::simplify_as_binary(*this);
    energy_t sum = temp.constant_;
    for (const auto& term : temp.terms_) {
      if (term.coeff() < 0) {
        sum += term.coeff();
      }
    }
    return sum;
  }

  vindex_t var_count() const;

  size_t term_count(vindex_t size) const {
    return static_cast<size_t>(std::count_if(
        terms_.begin(), terms_.end(),
        [size](const Term& term) { return term.var_count() == size; }));
  }
};

// --------------------------------------------------
// Class ExprExpr Declaration
// --------------------------------------------------

/// @brief ExprExpr class to store two expressions.
class ExprExpr : public Expr {
  /// @brief The second expression in the expression.
  Expr body_;

 public:
  /// @brief Constructor to create a new ExprExpr object.
  template <typename T1, typename T2>
  ExprExpr(T1&& expr1, T2&& expr2)
      : Expr(std::forward<T1>(expr1)), body_(std::forward<T2>(expr2)) {}

  ExprExpr() = default;
  ExprExpr(const Expr& expr) : Expr(expr) {}

  /// @brief Returns the body (constrained expression) of the constraint.
  Expr& body() { return body_; }
  /// @brief Returns the body (constrained expression) of the constraint.
  const Expr& body() const { return body_; }

  /// @brief Returns the body expression (for backward compatibility).
  Expr& operator*() { return body_; }
  /// @brief Returns the body expression (for backward compatibility).
  const Expr& operator*() const { return body_; }
  /// @brief Returns a pointer to the body expression (for backward compatibility).
  Expr* operator->() { return &body_; }
  /// @brief Returns a pointer to the body expression (for backward compatibility).
  const Expr* operator->() const { return &body_; }
};

// --------------------------------------------------
// Class VarIntCore Declaration
// --------------------------------------------------

/// @brief Helper class to create VarInt objects.
/// @note This class is introduced to avoid ambiguity for operator <=.
class VarIntCore {
 public:
  /// @brief Constructor to create a new named VarInt object.
  /// @param var_str The name of the variable
  const std::string var_str_;

  /// @brief  Constructor to create a new named VarInt object.
  /// @param var_str The name of the variable
  explicit VarIntCore(const std::string& var_str) : var_str_(var_str) {}

  /// @brief Constructor to create a new unnamed VarInt object.
  //  VarIntCore() : var_str_(std::to_string(new_unnamed_var_index())) {}
  VarIntCore()
      : var_str_("{" + std::to_string(new_unnamed_var_index()) + "}") {}
};

// --------------------------------------------------
// Class VarInt Declaration
// --------------------------------------------------

/// @brief Class to manage an integer variable using multiple HUBO
/// variables.
class VarInt : public Expr {
  /// @brief Private implementation of VarInt

  /// @brief Name of the variable
  std::string var_str_;

  /// @brief Minimum integer value that the variable can take
  energy_t min_val_;
  /// @brief Maximum integer value that the variable can take
  energy_t max_val_;
  /// @brief Coefficients of the variable for an integer variable
  std::shared_ptr<Vector<coeff_t>> coeffs_ptr_;
  /// @brief HUBO variables to represent an integer variable
  Vector<Var> vars_;

 public:
  /// @brief Constructor to create a new VarInt object
  /// @param var_str The name of the variable
  /// @param min_val The minimum integer value that the variable can take
  /// @param max_val The maximum integer value that the variable can take
  /// @param coeffs_ptr The coefficients of the variable for an integer
  /// @note coeffs_ptr must be a shared pointer to a vector of coefficients,
  /// which is computed by comp_coeffs() by caller.
  VarInt(const std::string& var_str, const energy_t& min_val,
         const energy_t& max_val, std::shared_ptr<Vector<coeff_t>> coeffs_ptr)
      : Expr(min_val),
        var_str_(var_str),
        min_val_(min_val),
        max_val_(max_val),
        coeffs_ptr_(coeffs_ptr) {
    if (coeffs_ptr_->size() == 1) {
      vars_.push_back(qbpp::var(var_str_));
    } else {
      for (size_t i = 0; i < coeffs_ptr_->size(); i++) {
        vars_.push_back(qbpp::var(var_str_ + "[" + std::to_string(i) + "]"));
      }
    }
    for (size_t i = 0; i < coeffs_ptr_->size(); i++) {
      *this += Term(vars_[i], (*coeffs_ptr_)[i]);
    }
  }

  /// @brief Copy constructor of VarInt.
  /// @note This function is necessary for copying MapList.
  VarInt(const VarInt&) = default;

  /// @brief Move constructor of VarInt.
  VarInt(VarInt&&) noexcept = default;

  /// @brief Copy assignment operator of VarInt.
  /// @note Implementation is after new_var_int() to support auto-naming.
  VarInt& operator=(const VarInt& other);

  /// @brief Move assignment operator of VarInt.
  /// @note Implementation is after new_var_int() to support auto-naming.
  VarInt& operator=(VarInt&& other) noexcept;

  /// @brief Returns the name of the integer variable
  /// @return The name of the integer variable
  std::string name() const { return var_str_; }

  Vector<Var> vars() const { return vars_; }

  Vector<coeff_t> coeffs() const { return *coeffs_ptr_; }

  /// @brief Returns the number of variables used to represent the integer
  /// variable
  vindex_t var_count() const { return static_cast<vindex_t>(vars_.size()); }

  /// @brief Returns the minimum value of the integer variable
  energy_t min_val() const { return min_val_; }

  /// @brief Returns the maximum value of the integer variable
  energy_t max_val() const { return max_val_; }

  /// @brief Returns the coefficient of the variable
  /// @param i The index of the variable
  /// @return The coefficient of the variable at index i
  coeff_t coeff(vindex_t i) const { return (*coeffs_ptr_)[i]; }

  /// @brief Returns the HUBO variable
  /// @param i The index of the variable
  /// @return The HUBO variable at index i
  Var var(vindex_t i) const { return vars_[i]; }

  /// @brief Returns the HUBO variable
  /// @param i The index of the variable
  /// @return The HUBO variable at index i
  Var operator[](vindex_t i) const { return vars_[i]; }

  /// @brief Returns the qbpp::VarValMap object representing the integer
  /// value
  /// @param val The integer value
  /// @return The VarValMap representing the integer value
  VarValMap val_map(energy_t val) const {
    if (val < min_val_ || val > max_val_) {
      throw std::out_of_range(THROW_MESSAGE("Value (", val, ") out of range."));
    }
    val -= min_val_;
    VarValMap result;
    for (size_t i = var_count(); i >= 1; i--) {
      if (val >= (*coeffs_ptr_)[static_cast<size_t>(i) - 1]) {
        result[vars_[i - 1]] = 1;
        val -= (*coeffs_ptr_)[i - 1];
      } else {
        result[vars_[i - 1]] = 0;
      }
    }
    return result;
  }

  /// @brief Returns the string representation of the VarInt object
  /// @return The string representation of the VarInt object
  std::string str() const { return qbpp::str(*this); }
};

/// --------------------------------------------------
/// Class Model Declaration
/// --------------------------------------------------

/// @brief Exprに対して，バイナリ変数に通し番号を与えたクラス．
class Model {
 protected:
  /// @brief Shared pointer to the fixed expression.
  /// @note Once Model is created with Expr, the Expr is fixed.
  const std::shared_ptr<const Expr> expr_ptr_;

  /// @brief Shared pointer to the index variable.
  /// @note Used to map between all variables and indices in the expression.
  //  const std::shared_ptr<const impl::IndexVarMapper> index_var_ptr_;
  const std::shared_ptr<const IVMapper> index_var_ptr_;

  /// @brief Energy when all base variables are 0.
  /// @details constant + Σ(coeff for terms where ALL vars are negated).
  /// At all-zeros, ~x = 1, so only all-negated terms contribute.
  const energy_t all_zeros_energy_;

  /// @brief Energy when all base variables are 1.
  /// @details constant + Σ(coeff for terms where ALL vars are non-negated).
  /// At all-ones, ~x = 0, so only all-non-negated terms contribute.
  const energy_t all_ones_energy_;

  /// @brief Arguments tuple for delegating constructors.
  using ModelArgs = std::tuple<std::shared_ptr<const Expr>,
                               std::shared_ptr<const IVMapper>,
                               energy_t, energy_t>;

  /// @brief Compute energies at all-zeros and all-ones states.
  static std::pair<energy_t, energy_t> compute_boundary_energies(
      const Expr& expr) {
    energy_t zeros_e = expr.constant();
    energy_t ones_e = expr.constant();
    for (const auto& term : expr.terms()) {
      if (term.var_count() == 0) continue;
      bool all_neg = true;
      bool any_neg = false;
      for (const auto& v : term.vars()) {
        if (v.index() & vindex_neg_bit) {
          any_neg = true;
        } else {
          all_neg = false;
        }
      }
      if (all_neg) zeros_e += term.coeff();
      if (!any_neg) ones_e += term.coeff();
    }
    return {zeros_e, ones_e};
  }

  /// @brief Build ModelArgs from expr shared_ptr and iv_mapper shared_ptr.
  static ModelArgs make_args(std::shared_ptr<const Expr> ep,
                             std::shared_ptr<const IVMapper> ip) {
    auto [z, o] = compute_boundary_energies(*ep);
    return {std::move(ep), std::move(ip), z, o};
  }

  /// @brief Build ModelArgs from expr shared_ptr (creates IVMapper).
  static ModelArgs make_args(std::shared_ptr<const Expr> ep) {
    auto ip = std::make_shared<const IVMapper>(*ep);
    return make_args(std::move(ep), std::move(ip));
  }

  /// @brief Delegating constructor from ModelArgs.
  Model(ModelArgs&& args)
      : expr_ptr_(std::move(std::get<0>(args))),
        index_var_ptr_(std::move(std::get<1>(args))),
        all_zeros_energy_(std::get<2>(args)),
        all_ones_energy_(std::get<3>(args)) {}

  /// @brief Intentionally delete the default constructor.
  Model() = delete;

  /// @brief Intentionally delete the copy assignment operator.
  //  Model &operator=(const Model &) = delete;

  /// @brief Intentionally delete the move assignment operator.
  // Model &operator=(Model &&) = delete;

 public:
  /// @brief Default copy constructor;
  Model(const Model& model)
      : expr_ptr_(model.expr_ptr_),
        index_var_ptr_(model.index_var_ptr_),
        all_zeros_energy_(model.all_zeros_energy_),
        all_ones_energy_(model.all_ones_energy_) {}

  /// @brief Creates a new Model object from a Expr object.
  /// @param expr The expression to create the model object from.
  /// @note The expression is copied to the Model object.
  Model(const Expr& expr)
      : Model(make_args(std::make_shared<const Expr>(expr))) {}

  Model(const Expr& expr, const std::shared_ptr<const IVMapper>& iv_mapper_ptr)
      : Model(make_args(std::make_shared<const Expr>(expr), iv_mapper_ptr)) {}

  /// @brief Default move constructor.
  Model(Model&&) = default;

  /// @brief Constructor to create a new Model object from an rvalue Expr
  /// (move).
  /// @param expr The expression to create the Model object from.
  Model(Expr&& expr) noexcept
      : Model(make_args(
            std::make_shared<const Expr>(std::move(expr)))) {}

  /// @brief Default destructor.
  virtual ~Model() = default;

  /// @brief Gets the number of Var objects in the Model object.
  /// @return The number of Var objects in the Model object.
  vindex_t var_count() const { return index_var_ptr_->var_count(); }

  /// @brief Gets Var object corresponding to an index.
  /// @param index The index to get Var object for.
  /// @return The Var object corresponding to the index.
  /// @note get_var() and index() are inverse functions.
  Var var(vindex_t index) const { return index_var_ptr_->var(index); }

  /// @brief Gets the index of the Var object.
  /// @param var The Var object to get the index for.
  /// @return The index of the Var object.
  /// @note get_var() and index() are inverse functions.
  vindex_t index(Var var) const { return index_var_ptr_->index(var); }

  /// @brief Check if the Var object is in the Model object.
  /// @param var The Var object to check.
  /// @return True if the Var object is in the Model object.
  bool has(Var var) const { return index_var_ptr_->has(var); }

  /// @brief Gets the number of Term objects in the Model object
  /// @return The number of Term objects in the Model object.
  virtual size_t term_count() const { return expr_ptr_->term_count(); }

  virtual size_t term_count(vindex_t size) const {
    return expr_ptr_->term_count(size);
  }
  const IVMapper& iv_mapper() const { return *index_var_ptr_; }

  /// @brief Gets the reference to the Expr object in the Model object.
  /// @return A const reference to the Expr object.
  /// @note The Expr object is const and non-const version is not provided.
  const Expr& expr() const { return *expr_ptr_; }

  /// @brief Gets the reference to the Expr object in the Model object.
  /// @return A const reference to the Expr object.
  /// @note This will provides a implicit conversion to Expr object.
  operator const Expr&() const { return *expr_ptr_; }

  /// @brief Gets the constant of the Expr object in the Model object.
  /// @return The constant of the Expr object.
  energy_t constant() const { return expr_ptr_->constant(); }

  const Terms& terms() const { return expr_ptr_->terms(); }

  /// @brief Energy when all base variables are 0.
  energy_t all_zeros_energy() const { return all_zeros_energy_; }

  /// @brief Energy when all base variables are 1.
  energy_t all_ones_energy() const { return all_ones_energy_; }

  /// @brief Returns the string representation of the Model object
  /// @return The string representation of the Model object
  std::string str() const { return qbpp::str(*this); }
};

// ----------------------------------------
// Struct Incdices declaration
// ----------------------------------------

#ifdef __CUDACC__
#define CUDA_HD __host__ __device__
#else
#define CUDA_HD
#endif

template <size_t N>
struct Indices {
  qbpp::vindex_t indices[N];

  CUDA_HD Indices() {}  // = default; を明示的に書き換え

  CUDA_HD Indices(const qbpp::vindex_t (&in)[N]) {
    for (size_t i = 0; i < N; ++i) {
      indices[i] = in[i];  // std::copy_nを使わない
    }
  }

  CUDA_HD qbpp::vindex_t operator[](size_t i) const { return indices[i]; }
};

// ----------------------------------------
// Struct TermVector declaration
// ----------------------------------------

/// @brief A struct to store a vector of terms with their coefficients.
/// @tparam N The number of indices in the term.
/// @note This struct is used to store terms incuding a partiular variable and
/// this particular variable is not included in the indices.
template <size_t N>
struct TermVector {
  std::vector<Indices<N>> indices_;
  std::vector<qbpp::coeff_t> coeffs_;

  TermVector() = default;

  explicit TermVector(std::vector<Indices<N>>&& indices,
                      std::vector<qbpp::coeff_t>&& coeffs)
      : indices_(std::move(indices)), coeffs_(std::move(coeffs)) {
    if (indices_.size() != coeffs_.size()) {
      throw std::invalid_argument("Size mismatch between indices and coeffs");
    }
  }

  explicit TermVector(const std::vector<Indices<N>>& indices,
                      const std::vector<qbpp::coeff_t>& coeffs)
      : indices_(indices), coeffs_(coeffs) {
    if (indices_.size() != coeffs_.size()) {
      throw std::invalid_argument("Size mismatch between indices and coeffs");
    }
  }

  void push_back(const Indices<N>& indices, const coeff_t& coeff) {
    indices_.push_back(indices);
    coeffs_.push_back(coeff);
  }

  void push_back(Indices<N>&& indices, const coeff_t& coeff) {
    indices_.push_back(std::move(indices));
    coeffs_.push_back(coeff);
  }

  void emplace_back(const qbpp::vindex_t (&in)[N], const coeff_t& coeff) {
    indices_.emplace_back(in);
    coeffs_.push_back(coeff);
  }

  size_t size() const { return indices_.size(); }

  qbpp::coeff_t coeff(size_t i) const {
    if (i >= coeffs_.size()) {
      throw std::out_of_range("Index out of range in TermVector");
    }
    return coeffs_[i];
  }

  const Indices<N>& indices(size_t i) const { return indices_[i]; }
};

// ----------------------------------------
// DynTermVector (dynamic degree, for degree 5+)
// ----------------------------------------

/// @brief Immutable fixed-size term vector for high-order HUBO terms.
/// @details Stores terms in flat arrays (unique_ptr). degree_minus_one() is
/// derived from indices_count_ / count_, so no explicit degree field is stored.
/// Constructed directly from Model (terms are sorted by degree).
struct DynTermVector {
  uint32_t count_ = 0;
  uint32_t indices_count_ = 0;
  std::unique_ptr<qbpp::vindex_t[]> indices_;
  std::unique_ptr<qbpp::coeff_t[]> coeffs_;

  DynTermVector() = default;
  DynTermVector(DynTermVector&&) = default;
  DynTermVector& operator=(DynTermVector&&) = default;

  /// @brief Deep copy constructor.
  DynTermVector(const DynTermVector& other)
      : count_(other.count_),
        indices_count_(other.indices_count_),
        indices_(std::make_unique<qbpp::vindex_t[]>(other.indices_count_)),
        coeffs_(std::make_unique<qbpp::coeff_t[]>(other.count_)) {
    std::copy_n(other.indices_.get(), indices_count_, indices_.get());
    std::copy_n(other.coeffs_.get(), count_, coeffs_.get());
  }

  /// @brief Deep copy assignment.
  DynTermVector& operator=(const DynTermVector& other) {
    if (this != &other) {
      count_ = other.count_;
      indices_count_ = other.indices_count_;
      indices_ = std::make_unique<qbpp::vindex_t[]>(other.indices_count_);
      coeffs_ = std::make_unique<qbpp::coeff_t[]>(other.count_);
      std::copy_n(other.indices_.get(), indices_count_, indices_.get());
      std::copy_n(other.coeffs_.get(), count_, coeffs_.get());
    }
    return *this;
  }

  /// @brief Construct with known sizes (allocates arrays, caller fills data).
  DynTermVector(uint32_t count, uint32_t dm1)
      : count_(count),
        indices_count_(count * dm1),
        indices_(std::make_unique<qbpp::vindex_t[]>(
            static_cast<size_t>(count) * dm1)),
        coeffs_(std::make_unique<qbpp::coeff_t[]>(count)) {}

  size_t size() const { return count_; }
  uint32_t degree_minus_one() const {
    return count_ > 0 ? indices_count_ / count_ : 0;
  }
  qbpp::coeff_t coeff(size_t i) const { return coeffs_[i]; }
  const qbpp::vindex_t* indices_data() const { return indices_.get(); }
  const qbpp::coeff_t* coeffs_data() const { return coeffs_.get(); }
};

class HuboModel : public qbpp::Model {
  const uint32_t max_power_;
  /// @brief The constant term of the model.
  const qbpp::energy_t constant_;
  /// @brief The vector to store the coefficients of the linear terms.
  const std::vector<qbpp::coeff_t> term1_;

  const std::vector<TermVector<1>> term2_;
  const std::vector<TermVector<2>> term3_;
  const std::vector<TermVector<3>> term4_;

  /// @brief Dynamic terms for degree 5+ (per variable).
  const std::vector<std::vector<DynTermVector>> dyn_terms_;

  const qbpp::energy_t all_coeff_sum_;
  const std::vector<qbpp::energy_t> coeff_sum_;

  /// @brief The type of the tuple to store all the terms of the model.
  using all_hubo_terms =
      std::tuple<uint32_t, qbpp::energy_t, std::vector<qbpp::coeff_t>,
                 std::vector<TermVector<1>>, std::vector<TermVector<2>>,
                 std::vector<TermVector<3>>, qbpp::energy_t,
                 std::vector<qbpp::energy_t>,
                 std::vector<std::vector<DynTermVector>>>;

  static all_hubo_terms helper_func(const qbpp::Model& model);

  HuboModel(const qbpp::Model& model, all_hubo_terms&& terms)
      : Model(model),
        max_power_(std::get<0>(terms)),
        constant_(std::get<1>(terms)),
        term1_(std::move(std::get<2>(terms))),
        term2_(std::move(std::get<3>(terms))),
        term3_(std::move(std::get<4>(terms))),
        term4_(std::move(std::get<5>(terms))),
        dyn_terms_(std::move(std::get<8>(terms))),
        all_coeff_sum_(std::get<6>(terms)),
        coeff_sum_(std::move(std::get<7>(terms))) {}

 public:
  HuboModel(const qbpp::Model& model)
      : HuboModel(model, std::move(helper_func(model))) {}

  HuboModel(const qbpp::Expr& expr) : HuboModel(qbpp::Model(expr)) {}

  /// @brief Default copy constructor
  HuboModel(const HuboModel& model) = default;

  /// @brief Default move constructor
  HuboModel(HuboModel&& model) = default;

  const std::vector<qbpp::coeff_t>& term1() const { return term1_; }
  const std::vector<TermVector<1>>& term2() const { return term2_; }
  const std::vector<TermVector<2>>& term3() const { return term3_; }
  const std::vector<TermVector<3>>& term4() const { return term4_; }

  qbpp::coeff_t term1(qbpp::vindex_t i) const { return term1_[i]; }

  const TermVector<1>& term2(qbpp::vindex_t i) const { return term2_[i]; }
  const TermVector<2>& term3(qbpp::vindex_t i) const { return term3_[i]; }
  const TermVector<3>& term4(qbpp::vindex_t i) const { return term4_[i]; }

  const std::vector<DynTermVector>& dyn_terms(qbpp::vindex_t i) const {
    return dyn_terms_[i];
  }
  const std::vector<std::vector<DynTermVector>>& dyn_terms_all() const {
    return dyn_terms_;
  }
  bool has_dyn_terms() const { return max_power_ > 4; }

  qbpp::energy_t all_coeff_sum() const { return all_coeff_sum_; }
  std::vector<qbpp::energy_t> coeff_sum() const { return coeff_sum_; }

  qbpp::energy_t coeff_sum(qbpp::vindex_t i) const { return coeff_sum_[i]; }

  size_t degree(qbpp::vindex_t index) const {
    size_t d = term2_[index].size() + term3_[index].size() +
               term4_[index].size();
    for (const auto& dtv : dyn_terms_[index]) d += dtv.size();
    return d;
  }

  uint32_t max_power() const { return max_power_; }

  std::string str() const;
};

/// @brief QuboModel is an alias for HuboModel for compatibility.
using QuboModel = HuboModel;

template <size_t N>
struct FlatTermVectors {
  const qbpp::vindex_t* const var_count_ptr_;
  const uint64_t* const size_array_;
  const uint64_t* const head_array_;
  const Indices<N>* const indices_array_;
  const qbpp::flat_coeff_t* const coeffs_array_;

  using all_flat_term_vectors =
      std::tuple<const qbpp::vindex_t*, const uint64_t*, const uint64_t*,
                 const Indices<N>*, const qbpp::flat_coeff_t*>;

  static all_flat_term_vectors helper_func(
      const std::vector<TermVector<N>>& term_vector) {
    qbpp::vindex_t* var_count_ptr =
        new qbpp::vindex_t(static_cast<qbpp::vindex_t>(term_vector.size()));
    uint64_t* size_array = new uint64_t[term_vector.size()];
    uint64_t* head_array = new uint64_t[term_vector.size() + 1];
    head_array[0] = 0;
    for (size_t i = 0; i < term_vector.size(); ++i) {
      size_array[i] = term_vector[i].size();
      head_array[i + 1] = head_array[i] + size_array[i];
    }
    size_t total_terms = head_array[term_vector.size()];
    Indices<N>* indices_array = new Indices<N>[total_terms];
    qbpp::flat_coeff_t* coeffs_array = new qbpp::flat_coeff_t[total_terms];
    for (size_t i = 0; i < term_vector.size(); ++i) {
      const auto& tv = term_vector[i];
      for (size_t j = 0; j < tv.size(); ++j) {
        indices_array[head_array[i] + j] = tv.indices(j);
        coeffs_array[head_array[i] + j] = qbpp::flat_coeff_t(tv.coeff(j));
      }
    }

    return std::make_tuple(var_count_ptr, size_array, head_array, indices_array,
                           coeffs_array);
  }

  FlatTermVectors(all_flat_term_vectors&& args)
      : var_count_ptr_(std::get<0>(args)),
        size_array_(std::get<1>(args)),
        head_array_(std::get<2>(args)),
        indices_array_(std::get<3>(args)),
        coeffs_array_(std::get<4>(args)) {}

  // コピー禁止
  FlatTermVectors(const FlatTermVectors&) = delete;
  FlatTermVectors& operator=(const FlatTermVectors&) = delete;

  // ムーブ禁止
  FlatTermVectors(FlatTermVectors&&) = delete;
  FlatTermVectors& operator=(FlatTermVectors&&) = delete;

 public:
  FlatTermVectors(const std::vector<TermVector<N>>& term_vector)
      : FlatTermVectors(std::move(helper_func(term_vector))) {}

  ~FlatTermVectors() {
    delete var_count_ptr_;
    delete[] size_array_;
    delete[] head_array_;
    delete[] indices_array_;
    delete[] coeffs_array_;
  }

  uint64_t size(qbpp::vindex_t i) const { return size_array_[i]; }

  uint64_t head(qbpp::vindex_t i) const { return head_array_[i]; }

  const Indices<N>& indices(qbpp::vindex_t i, uint64_t j) const {
    return indices_array_[head(i) + j];
  }

  qbpp::vindex_t index(qbpp::vindex_t i, uint64_t j, uint8_t k) const {
    return indices_array_[head(i) + j].indices[k];
  }

  qbpp::flat_coeff_t coeff(qbpp::vindex_t i, uint64_t j) const {
    return coeffs_array_[head(i) + j];
  }

  std::string str() const {
    std::string result = "FlatTermVectors<" + qbpp::str(N) + ">\n";
    qbpp::vindex_t var_count = *var_count_ptr_;
    for (qbpp::vindex_t i = 0; i < var_count; ++i) {
      result += "Variable " + qbpp::str(i) + "\n";
      result += "  Size: " + qbpp::str(size(i)) + "\n";
      result += "  Head: " + qbpp::str(head(i)) + "\n";
      for (uint64_t j = 0; j < size(i); ++j) {
        result += "  Term " + qbpp::str(j) + ": ";
        for (uint8_t k = 0; k < N; ++k) {
          result += qbpp::str(index(i, j, k)) + " ";
        }
        result += "Coeff: " + qbpp::str(coeff(i, j)) + "\n";
      }
    }
    return result;
  }
};

/// @brief Flat representation of dynamic (degree > 4) terms for one degree.
/// @details Mirrors the FlatTermVectors<N> layout but with runtime degree.
/// indices_array_ stores dm1 vindex_t values per entry (flat, not Indices<N>).
struct FlatDynTermGroup {
  const uint32_t dm1_;
  const qbpp::vindex_t var_count_;
  const uint64_t* const size_array_;    // [var_count]
  const uint64_t* const head_array_;    // [var_count + 1]
  const qbpp::vindex_t* const indices_array_;  // [total_terms * dm1]
  const qbpp::flat_coeff_t* const coeffs_array_;    // [total_terms]

  // コピー・ムーブ禁止
  FlatDynTermGroup(const FlatDynTermGroup&) = delete;
  FlatDynTermGroup& operator=(const FlatDynTermGroup&) = delete;
  FlatDynTermGroup(FlatDynTermGroup&&) = delete;
  FlatDynTermGroup& operator=(FlatDynTermGroup&&) = delete;

  /// @brief Construct from HuboModel's dyn_terms for a specific degree.
  FlatDynTermGroup(uint32_t dm1, qbpp::vindex_t var_count,
                   const std::vector<std::vector<DynTermVector>>& dyn_terms)
      : dm1_(dm1),
        var_count_(var_count),
        size_array_(new uint64_t[var_count]),
        head_array_(new uint64_t[var_count + 1]),
        indices_array_(nullptr),
        coeffs_array_(nullptr) {
    // Compute size_array and head_array
    auto* sa = const_cast<uint64_t*>(size_array_);
    auto* ha = const_cast<uint64_t*>(head_array_);
    ha[0] = 0;
    for (qbpp::vindex_t i = 0; i < var_count; ++i) {
      uint64_t cnt = 0;
      for (const auto& dtv : dyn_terms[i]) {
        if (dtv.degree_minus_one() == dm1) {
          cnt = dtv.size();
          break;
        }
      }
      sa[i] = cnt;
      ha[i + 1] = ha[i] + cnt;
    }
    uint64_t total = ha[var_count];
    // Allocate and fill indices and coeffs
    auto* ia =
        new qbpp::vindex_t[std::max(static_cast<uint64_t>(1), total * dm1)];
    auto* ca =
        new qbpp::flat_coeff_t[std::max(static_cast<uint64_t>(1), total)];
    for (qbpp::vindex_t i = 0; i < var_count; ++i) {
      for (const auto& dtv : dyn_terms[i]) {
        if (dtv.degree_minus_one() == dm1) {
          const auto* src_idx = dtv.indices_data();
          const auto* src_coeff = dtv.coeffs_data();
          uint64_t base = ha[i];
          for (uint64_t j = 0; j < dtv.size(); ++j) {
            ca[base + j] = qbpp::flat_coeff_t(src_coeff[j]);
            for (uint32_t k = 0; k < dm1; ++k) {
              ia[(base + j) * dm1 + k] = src_idx[j * dm1 + k];
            }
          }
          break;
        }
      }
    }
    const_cast<const qbpp::vindex_t*&>(indices_array_) = ia;
    const_cast<const qbpp::flat_coeff_t*&>(coeffs_array_) = ca;
  }

  ~FlatDynTermGroup() {
    delete[] size_array_;
    delete[] head_array_;
    delete[] indices_array_;
    delete[] coeffs_array_;
  }

  uint64_t size(qbpp::vindex_t i) const { return size_array_[i]; }
  uint64_t head(qbpp::vindex_t i) const { return head_array_[i]; }
};

/// @brief HuboModelをフラット化したもの．
/// @note
/// ABI互換を保ち，バイナリでソルバーにわたすことを想定し，すべてポインタを使っている．
class FlatHuboModel {
 protected:
  const uint32_t* max_power_ptr_;
  /// @brief 変数の個数
  const qbpp::vindex_t* const var_count_ptr_;
  /// @brief 定数項
  const qbpp::flat_energy_t* const constant_ptr_;
  /// @brief 一次項の係数配列
  const qbpp::flat_coeff_t* const term1_array_;
  /// @brief 二次項の係数配列
  const FlatTermVectors<1>* const term2_array_;
  /// @brief 三次項の係数配列
  const FlatTermVectors<2>* const term3_array_;
  /// @brief 四次項の係数配列
  const FlatTermVectors<3>* const term4_array_;

  /// @brief すべての係数の和
  const qbpp::flat_energy_t* const all_coeff_sum_ptr_;
  /// @brief 各変数の係数の和を格納する配列
  const qbpp::flat_energy_t* const coeff_sum_array_;

  /// @brief 5次以上の動的項グループの数
  const uint32_t dyn_group_count_;
  /// @brief 5次以上の動的項グループの配列（dyn_group_count_個）
  FlatDynTermGroup* const* const dyn_groups_;

  /// @brief all-zeros 状態のエネルギー（~x対応）
  const qbpp::flat_energy_t* const all_zeros_energy_ptr_;

 private:
  using all_flat_hubo_model =
      std::tuple<const uint32_t*, const qbpp::vindex_t*,
                 const qbpp::flat_energy_t*,
                 const qbpp::flat_coeff_t*, const FlatTermVectors<1>*,
                 const FlatTermVectors<2>*, const FlatTermVectors<3>*,
                 const qbpp::flat_energy_t*, const qbpp::flat_energy_t*,
                 uint32_t, FlatDynTermGroup* const*,
                 const qbpp::flat_energy_t*>;

  all_flat_hubo_model helper_func(const qbpp::HuboModel& hubo_model) {
    const uint32_t* max_power_ptr = new uint32_t(hubo_model.max_power());
    const qbpp::vindex_t* var_count_ptr =
        new qbpp::vindex_t(hubo_model.var_count());
    auto* constant_ptr =
        new qbpp::flat_energy_t(hubo_model.constant());
    auto* term1_array =
        new qbpp::flat_coeff_t[hubo_model.term1().size()];
    for (size_t i = 0; i < hubo_model.term1().size(); ++i) {
      term1_array[i] = qbpp::flat_coeff_t(hubo_model.term1().data()[i]);
    }
    const FlatTermVectors<1>* term2_array =
        new FlatTermVectors<1>(hubo_model.term2());
    const FlatTermVectors<2>* term3_array =
        new FlatTermVectors<2>(hubo_model.term3());
    const FlatTermVectors<3>* term4_array =
        new FlatTermVectors<3>(hubo_model.term4());
    auto* all_coeff_sum_ptr =
        new qbpp::flat_energy_t(hubo_model.all_coeff_sum());
    auto* coeff_sum_array =
        new qbpp::flat_energy_t[hubo_model.var_count()];
    for (qbpp::vindex_t i = 0; i < hubo_model.var_count(); ++i) {
      coeff_sum_array[i] = qbpp::flat_energy_t(hubo_model.coeff_sum(i));
    }
    // Build dyn_groups for degree > 4
    uint32_t dyn_group_count = 0;
    FlatDynTermGroup** dyn_groups = nullptr;
    if (hubo_model.has_dyn_terms()) {
      // Collect distinct degrees
      std::vector<uint32_t> degrees;
      for (qbpp::vindex_t i = 0; i < hubo_model.var_count(); ++i) {
        for (const auto& dtv : hubo_model.dyn_terms(i)) {
          uint32_t dm1 = dtv.degree_minus_one();
          if (std::find(degrees.begin(), degrees.end(), dm1) == degrees.end())
            degrees.push_back(dm1);
        }
      }
      std::sort(degrees.begin(), degrees.end());
      dyn_group_count = static_cast<uint32_t>(degrees.size());
      dyn_groups = new FlatDynTermGroup*[dyn_group_count];
      for (uint32_t g = 0; g < dyn_group_count; ++g) {
        dyn_groups[g] = new FlatDynTermGroup(
            degrees[g], hubo_model.var_count(), hubo_model.dyn_terms_all());
      }
    }
    auto* all_zeros_energy_ptr =
        new qbpp::flat_energy_t(hubo_model.all_zeros_energy());
    return std::make_tuple(
        max_power_ptr, var_count_ptr, constant_ptr, term1_array, term2_array,
        term3_array, term4_array,
        all_coeff_sum_ptr, coeff_sum_array, dyn_group_count, dyn_groups,
        all_zeros_energy_ptr);
  }

  FlatHuboModel(all_flat_hubo_model&& args)
      : max_power_ptr_(std::get<0>(args)),
        var_count_ptr_(std::get<1>(args)),
        constant_ptr_(std::get<2>(args)),
        term1_array_(std::get<3>(args)),
        term2_array_(std::get<4>(args)),
        term3_array_(std::get<5>(args)),
        term4_array_(std::get<6>(args)),
        all_coeff_sum_ptr_(std::get<7>(args)),
        coeff_sum_array_(std::get<8>(args)),
        dyn_group_count_(std::get<9>(args)),
        dyn_groups_(std::get<10>(args)),
        all_zeros_energy_ptr_(std::get<11>(args)) {}

  // コピー禁止
  FlatHuboModel(const FlatHuboModel&) = delete;
  FlatHuboModel& operator=(const FlatHuboModel&) = delete;

 public:
  explicit FlatHuboModel(const HuboModel& model)
      : FlatHuboModel(std::move(helper_func(model))) {}

  ~FlatHuboModel() {
    delete var_count_ptr_;
    delete constant_ptr_;
    delete[] term1_array_;
    delete term2_array_;
    delete term3_array_;
    delete term4_array_;
    delete all_coeff_sum_ptr_;
    delete[] coeff_sum_array_;
    delete all_zeros_energy_ptr_;
    if (dyn_groups_ != nullptr) {
      for (uint32_t g = 0; g < dyn_group_count_; ++g) delete dyn_groups_[g];
      delete[] dyn_groups_;
    }
  }

  qbpp::vindex_t var_count() const { return *var_count_ptr_; }
  qbpp::vindex_t size64() const { return (var_count() + 63) / 64; }
  qbpp::flat_energy_t constant() const { return *constant_ptr_; }
  const qbpp::flat_coeff_t* term1_array() const { return term1_array_; }
  const FlatTermVectors<1>& term2_array() const { return *term2_array_; }
  const FlatTermVectors<2>& term3_array() const { return *term3_array_; }
  const FlatTermVectors<3>& term4_array() const { return *term4_array_; }
  uint32_t max_power() const { return *max_power_ptr_; }
  uint32_t dyn_group_count() const { return dyn_group_count_; }
  const FlatDynTermGroup& dyn_group(uint32_t g) const { return *dyn_groups_[g]; }
  qbpp::flat_energy_t all_coeff_sum() const { return *all_coeff_sum_ptr_; }
  const qbpp::flat_energy_t& coeff_sum_array() const {
    return *coeff_sum_array_;
  }
  qbpp::flat_energy_t all_zeros_energy() const {
    return *all_zeros_energy_ptr_;
  }

  std::string str() const {
    std::string result = "FlatHuboModel\n";
    result += "Variable Count: " + qbpp::str(*var_count_ptr_) + "\n";
    result += "Constant: " + qbpp::str(*constant_ptr_) + "\n";
    result += "Term1 Coefficients:\n";
    for (qbpp::vindex_t i = 0; i < *var_count_ptr_; ++i) {
      result += "  Variable " + qbpp::str(i) + ": " +
                qbpp::str(term1_array_[i]) + "\n";
    }
    result += "Term2:\n" + term2_array_->str();
    result += "Term3:\n" + term3_array_->str();
    result += "Term4:\n" + term4_array_->str();
    result += "All Coefficients Sum: " + qbpp::str(*all_coeff_sum_ptr_) + "\n";
    result += "Coefficient Sums:\n";
    for (qbpp::vindex_t i = 0; i < *var_count_ptr_; ++i) {
      result += "  Variable " + qbpp::str(i) + ": " +
                qbpp::str(coeff_sum_array_[i]) + "\n";
    }
    return result;
  }
};

/// @brief A class to represent a bit vector.
class BitVector {
  // @brief Pointer to the implementation of the bit vector.
  void* impl_;

 public:
  // コンストラクタ（生成）
  explicit BitVector(vindex_t bit_count)
      : impl_(qbpp_bitvector_create(bit_count)) {}

  explicit BitVector(vindex_t bit_count, const uint64_t* bit_array)
      : impl_(qbpp_bitvector_create_from_array(bit_count, bit_array)) {}

  // コピーコンストラクタ
  BitVector(const BitVector& other) : impl_(qbpp_bitvector_copy(other.impl_)) {}

  // ムーブコンストラクタ
  BitVector(BitVector&& other) noexcept : impl_(other.impl_) {
    other.impl_ = nullptr;
  }

  // コピー代入
  BitVector& operator=(const BitVector& other) {
    if (this != &other) {
      qbpp_bitvector_destroy(impl_);
      impl_ = qbpp_bitvector_copy(other.impl_);
    }
    return *this;
  }

  // ムーブ代入
  BitVector& operator=(BitVector&& other) noexcept {
    if (this != &other) {
      qbpp_bitvector_destroy(impl_);
      impl_ = other.impl_;
      other.impl_ = nullptr;
    }
    return *this;
  }

  // デストラクタ
  ~BitVector() { qbpp_bitvector_destroy(impl_); }
  void set(vindex_t index, bool value) {
    qbpp_bitvector_set(impl_, index, value);
  }

  /// @brief index番目のビットを取得する。
  bool get(vindex_t index) const { return qbpp_bitvector_get(impl_, index); }

  /// @brief index番目のビットを反転する。
  void flip(vindex_t index) { qbpp_bitvector_flip(impl_, index); }

  /// @brief ビット数を取得する．
  vindex_t size() const { return qbpp_bitvector_size(impl_); }

  /// @brief ビットを格納する64ビット整数の配列のサイズを取得する。
  vindex_t size64() const { return qbpp_bitvector_size64(impl_); }

  /// @brief ビットを格納する64ビット整数の配列のポインタを取得する。
  const uint64_t* bits_ptr() const { return qbpp_bitvector_bits_ptr(impl_); }

  /// @brief index番目の64ビット整数を取得する。
  uint64_t get64(vindex_t index64) const {
    return qbpp_bitvector_get64(impl_, index64);
  }

  /// @brief index番目の64ビット整数を設定する。
  void set64(vindex_t index64, uint64_t value) {
    qbpp_bitvector_set64(impl_, index64, value);
  }

  /// @brief 全ビットをクリアする．
  void clear() { qbpp_bitvector_clear(impl_); }

  /// @brief ビットベクトルのポップカウントを取得する。
  vindex_t popcount() const { return qbpp_bitvector_popcount(impl_); }

  /// @brief ２つのビットベクトルが等しいかどうかを比較する。
  bool operator==(const BitVector& other) const {
    return qbpp_bitvector_equal(impl_, other.impl_);
  }

  /// @brief ２つのビットベクトルの大小比較
  bool operator<(const BitVector& other) const {
    return qbpp_bitvector_less_than(impl_, other.impl_);
  }

  /// @brief ビットベクトルのポインタを取得する。
  void* impl() const { return impl_; }

  /// @brief ビットベクトルの文字列表現を取得する。
  std::string str() const {
    std::string result;
    vindex_t size = this->size();
    for (vindex_t i = 0; i < size; ++i) {
      result += (get(i) ? '1' : '0');
    }
    return result;
  }
};

// 1. 型変換ルール
template <typename T>
struct eval_type;  // プライマリ（中身は定義しない）

// added to avoid error for sol(transpose(x))
template <>
struct eval_type<Expr> {
  using type = qbpp::energy_t;
};

// Var は var_val_t に写す
template <>
struct eval_type<Var> {
  //  using type = var_val_t;
  using type = int32_t;
};

// Vector<T> は Vector< eval_type<T> > に写す（再帰）
template <typename T>
struct eval_type<qbpp::Vector<T>> {
  using type = qbpp::Vector<typename eval_type<T>::type>;
};

template <typename T>
using eval_type_t = typename eval_type<T>::type;

/// @brief 解のクラス
class Sol {
 protected:
  /// @brief 解の対象となるモデル
  const Model model_;

  /// @brief 解の対象となる式
  const Expr& expr_ = model_.expr();

  /// @brief モデルのiv_mapper
  const IVMapper& iv_mapper_ = model_.iv_mapper();

  /// @brief モデルの定数項
  const energy_t constant_ = model_.constant();

  /// @brief ビットベクトル
  BitVector bit_vector_;

  /// @brief 解のエネルギー
  /// @note　遅延評価のため、std::optionalを使用．未定の場合は値が設定されない．
  std::optional<energy_t> energy_ = std::nullopt;

  /// @brief 解を得た時間
  /// @note -1.0は未設定を表す
  double tts_ = -1.0;

  /// @brief Gets MapList object representing the solution.
  /// @return The MapList object representing the solution.
  MapList map_list() const;

  /// @brief デフォルトコンストラクタは削除
  Sol() = delete;

 public:
  /// @brief Constructor to create a new Sol object using copy semantics.
  /// @param sol The existing Sol object to copy.
  Sol(const Sol& sol) = default;

  /// @brief Constructor to create a new Sol object using move semantics.
  /// @param sol The existing Sol object to move.
  Sol(Sol&& other) = default;

  explicit Sol(const Model& model)
      : model_(model),
        bit_vector_(model.var_count()),
        energy_(model.all_zeros_energy()) {}

  explicit Sol(const Model& model, const BitVector& bit_vector)
      : model_(model), bit_vector_(bit_vector) {}

  explicit Sol(const Model& model, const energy_t& energy,
               const uint64_t* bit_array, double tts = -1.0)
      : model_(model),
        bit_vector_(model.var_count(), bit_array),
        energy_(energy),
        tts_(tts) {}

  /// @brief Destructor to destroy the Sol object.
  virtual ~Sol() = default;

  /// @brief Copy assignment operator to copy the Sol object.
  /// @param sol The existing solution to copy.
  /// @return A reference to this object after copying the solution.
  Sol& operator=(const Sol& sol) {
    if (this != &sol) {
      bit_vector_ = sol.bit_vector_;
      energy_ = sol.energy_;
      tts_ = sol.tts_;
    }
    return *this;
  }

  /// @brief Compares this object with another Sol object for equality.
  /// @param sol The Sol object to compare with.
  /// @return true If the bit_vectors of the solutions are equal.
  bool operator==(const Sol& sol) const {
    if (energy() != sol.energy()) return false;
    return bit_vector_ == sol.bit_vector_;
  }
  /// @brief Compares this object with another Sol object for inequality.
  /// @param sol The Sol object to compare with.
  /// @return true if the energy of this object is less than the energy of
  /// the sol object.
  bool operator<(const Sol& sol) const {
    if (energy() < sol.energy()) return true;
    if (energy() == sol.energy())
      return bit_vector_ < sol.bit_vector_;
    else
      return false;
  }

  /// @brief Gets the value of the bit at the specified index.
  /// @param index The index of the bit.
  /// @return The value of the bit.
  int32_t get(vindex_t index) const { return bit_vector_.get(index); }

  /// @brief Gets the value of the bit of the variable.
  /// @param var The variable to get the value for.
  /// @return The value of the bit. For negated variables (~x), returns 1 -
  /// get(x).
  int32_t get(Var var) const {
    bool negated = (var.index() & vindex_neg_bit) != 0;
    Var base_var(var.index() & vindex_mask);
    auto index = iv_mapper_.index(base_var);
    if (index == vindex_limit) {
      std::cerr << "Error: Cannot find variable (" << var.str() << ").\n";
      exit(EXIT_FAILURE);
    }
    return negated ? 1 - get(index) : get(index);
  }

  /// @brief Gets the value of the expression for the solution.
  energy_t get(const Expr& expr) const { return qbpp::eval(expr, *this); }

  energy_t operator()(const Expr& expr) const { return get(expr); }

  energy_t operator()(vindex_t index) const { return get(index); }

  /// @brief Check if the variable is in the solution.
  bool has(Var var) const { return iv_mapper_.has(var); }

  /// @brief Clears the solution to all zeros.
  void clear() {
    bit_vector_.clear();
    energy_ = constant_;
  }

  /// @brief Nullifies the energy value of the solution.
  void nullify() { energy_ = std::nullopt; }

  bool is_null() const { return !energy_.has_value(); }

  /// @brief Gets the values of Vector/nested Vector of objects
  /// @param vec The Vector/nested Vector of objects to get the energy
  /// for.
  /// @return The values of the Vector/nested Vector of objects.
  template <typename T>
  auto get(const Vector<T>& vec) const {
    Vector<std::decay_t<decltype(get(std::declval<T>()))>> result;
    result.reserve(vec.size());
    for (const auto& elem : vec) {
      result.push_back(get(elem));
    }
    return result;
  }

  /// @brief Sets the value of the bit at the specified index.
  /// @param index The index of the bit.
  /// @param value The value to set.
  void set(vindex_t index, bool value) {
    energy_.reset();
    bit_vector_.set(index, value);
  }

  /// @brief Sets the value of the bit of the variable.
  /// @param var The variable to set the value for.
  /// @param value The value to set.
  /// @note For negated variables (~x), the value is inverted and applied to
  /// the base variable.
  void set(Var var, bool value) {
    energy_.reset();
    bool negated = (var.index() & vindex_neg_bit) != 0;
    set(iv_mapper_.index(var), negated ? !value : value);
  }

  void set64(vindex_t index64, uint64_t value) {
    energy_.reset();
    bit_vector_.set64(index64, value);
  }

  /// @brief Flips the value of the bit at the specified index.
  /// @note The energy is not updated by this function.
  void bit_vector_flip(vindex_t index) { bit_vector_.flip(index); }

  /// @brief Flips the value of the bit of the variable.
  /// @param index The index of the variable to be flipped.
  /// @note The energy is not updated by this function. energy_ is reselt
  /// because the energy is not updated.
  virtual void flip(vindex_t index) {
    energy_.reset();
    bit_vector_.flip(index);
  }

  void flip(Var var) { flip(iv_mapper_.index(var)); }

  /// @brief Flips the value of the bit of the variable and adds the delta
  /// to the energy.
  /// @note delta must be the energy change of the variable.
  virtual void flip_bit_add_delta(vindex_t index, const energy_t& delta) {
    energy_ = energy_.value() + delta;
    bit_vector_.flip(index);
  }

  /// @brief Returns popcount of the bit vector.
  /// @return The number of bits set to 1.
  vindex_t popcount() const { return bit_vector_.popcount(); }

  /// @brief Gets the energy of the solution.
  /// @return The energy of the solution.
  /// @note Energy is computed if energy is empty.
  energy_t energy() const {
    if (!energy_) {
      throw std::runtime_error(THROW_MESSAGE("Energy is not set."));
    }
    return *energy_;
  }

  energy_t comp_energy() {
    return energy_ ? *energy_ : *(energy_ = expr_(*this));
  }

  /// @brief Forces the energy value to be set.
  /// @param energy The energy value to set.
  void energy(const energy_t& energy) { energy_ = energy; }

  void energy(const Expr& expr) { energy_ = expr(*this); }

  /// @brief Check if the energy value is set.
  bool energy_has_value() const { return energy_.has_value(); }

  /// @brief Adds the energy value to the solution.
  energy_t add_energy(const energy_t& energy) { return *energy_ += energy; }

  /// @brief Return bit vector of the solution.
  /// @return BitVector object representing the solution.
  const BitVector& bit_vector() const { return bit_vector_; }

  /// @brief Return bit vector of the solution.
  /// @return BitVector object representing the solution.
  BitVector& bit_vector() { return bit_vector_; }

  /// @brief Gets the number of variables in the model.
  /// @return The number of variables in the model.
  vindex_t var_count() const { return iv_mapper_.var_count(); }

  /// @brief Gets the constant of the model.
  /// @return The constant of the model.
  energy_t constant() const { return constant_; }

  /// @brief Gets the variable object from the index.
  /// @param index The index of the variable.
  /// @return The variable with the specified index.
  /// @note The index must be less than var_count(), the number of
  /// variables in the model.
  Var var(vindex_t index) const { return iv_mapper_.var(index); }

  /// @brief Gets the index of the variable.
  /// @param var The variable to get the index for.
  /// @return The index of the variable.
  vindex_t index(Var var) const { return iv_mapper_.index(var); }

  /// @brief Casts the solution to a MapList object.
  operator MapList() const { return map_list(); }

  /// @brief Sets ths solution to this sol object.
  /// @param sol The Sol object to copy.
  /// @return This Sol object.
  /// @note Usually, sol is a subset of this solution.
  Sol& set(const Sol& sol) {
    for (vindex_t i = 0; i < sol.var_count(); ++i) {
      set(sol.var(i), sol.get(i));
    }
    return *this;
  }

  /// @brief Sets the solution represented by the MapList object.
  /// @param map_list The MapList object representing the solution.
  /// @return This Sol object.
  Sol& set(const MapList& map_list) {
    VarValMap var_val_map = list_to_var_val(map_list);
    for (const auto& [var, val] : var_val_map) {
      set(var, val);
    }
    if (!energy_) energy_ = comp_energy();
    return *this;
  }

  /// @brief Sets the solution from both Sol and MapList objects.
  /// @param sol The Sol object to copy.
  /// @param map_list The MapList object representing the solution.
  /// @return This Sol object.
  /// @note The expressions in map_list are evaluated using sol.
  /// @note If the same variable exists in both with different values,
  ///       throws an error.
  Sol& set(const Sol& sol, const MapList& map_list);

  void tts(double tts) { tts_ = tts; }

  double tts() const { return tts_; }

  /// @brief Functor to evaluate variables and vectors of variables.
  int32_t operator()(const qbpp::Var& var) const { return get(var); }

  /// @brief Functor to evaluate nested vectors of variables.
  template <typename T>
  qbpp::Vector<eval_type_t<T>> operator()(const qbpp::Vector<T>& vec) const {
    qbpp::Vector<eval_type_t<T>> result;
    result.reserve(vec.size());
    for (const auto& e : vec) {
      result.push_back((*this)(e));  // e の型は T
    }
    return result;
  }

  /// @brief Returns the string representation of the Sol object
  /// @return The string representation of the Sol object
  std::string str() const { return qbpp::str(*this); }
};

/// @brief Class to maintain the best solution of a HUBO model.
/// @tparam T The type of the solution. Usually it is Sol.
/// @tparam U The type of the energy. Usually it is energy_t.
/// @note When the SolHolder object is created, the zero-initialized
/// solution is stored as a trivial solution.
template <typename T, typename U>
class SolHolderTemplate {
 protected:
  /// @brief The best solution.
  T sol_;
  /// @brief The best energy bound.
  std::optional<energy_t> bound_ = std::nullopt;
  /// @brief The best energy bound.
  double startx_ = time();
  /// @brief Time to Solution.
  double tts_{-1.0f};
  /// @brief The name of the solver.
  std::string solver_ = "N/A";
  /// @brief The mutex to lock the best solution for thread safety.
  mutable std::mutex mtx_;

 public:
  explicit SolHolderTemplate(const Model& model) : sol_(model) {}

  explicit SolHolderTemplate(const Expr& expr) : sol_(Model(expr)) {}

  explicit SolHolderTemplate(const T& sol) : sol_(sol) {}

  /// @brief Copy constructor to create a new SolHolderTemplate object.
  SolHolderTemplate(const SolHolderTemplate<T, U>& other) = delete;

  /// @brief Default Destructor.
  virtual ~SolHolderTemplate() = default;

  /// @brief Casts the SolHolderTemplate object to the Sol object.
  /// @note This function is used to implicitly convert the SolHolder
  /// object to the Sol object.
  operator Sol() const {
    std::lock_guard<std::mutex> lock(mtx_);
    return sol_;
  }

  /// @brief Sets the best solution if the energy is better than the
  /// current best solution.
  /// @param new_sol  The new solution to compare with the best solution
  /// in the SolHolderTemplate.
  /// @param solver The name of the solver that obtained the new solution.
  /// @return std::optional<double> The duration to obtain
  /// the new solution if it is better than the current best solution.
  /// Returns std::nullopt if the new solution is not better.
  virtual std::optional<double> set_if_better(const T& new_sol,
                                              const std::string& solver = "") {
    if (new_sol.energy() >= sol_.energy()) {
      return std::nullopt;
    }
    std::lock_guard<std::mutex> lock(mtx_);
    if (new_sol.energy() < sol_.energy()) {
      tts_ = time() - startx_;
      sol_ = new_sol;
      sol_.tts(tts_);
      solver_ = solver;
      return std::make_optional(tts_);
    } else {
      return std::nullopt;
    }
  }

  virtual std::optional<double> set_if_better(T&& new_sol,
                                              const std::string& solver = "") {
    if (new_sol.energy() >= sol_.energy()) {
      return std::nullopt;
    }
    std::lock_guard<std::mutex> lock(mtx_);
    if (new_sol.energy() < sol_.energy()) {
      tts_ = time() - startx_;
      sol_ = std::move(new_sol);
      sol_.tts(tts_);
      solver_ = solver;
      return std::make_optional(tts_);
    } else {
      return std::nullopt;
    }
  }

  /// @brief Returns the best solution in the SolHolderTemplate if its
  /// energy is better than the given energy.
  /// @param my_energy The energy to compare with the best solution in the
  /// SolHolderTemplate.
  /// @return std::optional<T> The best solution in the SolHolderTemplate
  /// if it is better; otherwise, returns std::nullopt. This avoids
  /// overhead of copying unnecessary solution.
  virtual std::optional<T> get_if_better(U my_energy) {
    if (sol_.energy() >= my_energy) return std::nullopt;
    std::lock_guard<std::mutex> lock(mtx_);
    if (sol_.energy() < my_energy) {
      return sol_;
    } else {
      return std::nullopt;
    }
  }

  /// @brief Returns the best solution in the SolHolderTemplate if it is
  /// better than the given solution.
  /// @param my_sol The solution to compare with the best solution in the
  /// SolHolderTemplate.
  /// @return std::optional<qbpp::Sol> The best solution in the
  /// SolHolderTemplate if it is better; otherwise, returns std::nullopt.
  /// This avoids overhead of copying unnecessary solution.
  std::optional<T> get_if_better(const T& my_sol) {
    return get_if_better(my_sol.energy());
  }

  /// @brief Gets the solution, TTS, and solver at the same time.
  /// @return std::tuple<Sol, double, std::string> The best
  /// solution, TTS, and solver.
  /// @note This function is thread-safe.
  std::tuple<T, double, std::string> get_sol_tts_solver() const {
    std::lock_guard<std::mutex> lock(mtx_);
    return std::make_tuple(sol_, tts_, solver_);
  }

  /// @brief Gets the number of variables in the model.
  /// @return The number of variables in the model.
  vindex_t var_count() const { return sol_.var_count(); }

  /// @brief Gets the energy of the best solution.
  /// @return Val The energy of the best solution.
  const U energy() const { return sol_.energy(); }

  /// @brief Gets the best solution.
  /// @return Sol The best solution.
  const T& sol() const { return sol_; }

  const T& sol(const T& sol) {
    std::lock_guard<std::mutex> lock(mtx_);
    sol_ = sol;
    return sol_;
  }

  /// @brief Gets the best solution by copy for thread safety.
  /// @return Sol The best solution.
  T copy_sol() const {
    std::lock_guard<std::mutex> lock(mtx_);
    return sol_;
  }

  void clear() {
    std::lock_guard<std::mutex> lock(mtx_);
    sol_.clear();
    tts_ = 0;
    solver_ = "N/A";
  }

  /// @brief Gets the TTS to obtain the best solution.
  /// @return double The TTS to obtain the best solution.
  double tts() const { return tts_; }

  /// @brief Gets the name of the solver that obtained the best solution.
  /// @return std::string The name of the solver.
  const std::string& solver() const { return solver_; }

  /// @brief Set the energy bound of the HUBO model.
  /// @param bound The energy bound of the HUBO model.
  /// @note The energy bound is the lower bound of energy value of the
  /// HUBO model, which can be expected to be obtained by an Integer
  /// Linear Programming Solver.
  void bound(U bound) { bound_ = bound; }

  /// @brief gets the energy bound of the HUBO model.
  /// @return std::optional<energy_t> The energy bound of the HUBO model.
  /// @note std::nullopt if no bound is set.
  std::optional<U> bound() const { return bound_; }
};

using SolHolder = SolHolderTemplate<Sol, energy_t>;

// =============================
// str/ostream global functions
// =============================

/// @brief String conversion function for the Var object.
/// @param vars The Vars object to convert to a string.
/// @param str The string conversion function for the Var object.
/// @return std::string The string representation of the Vars object.
/// @note This function is called by str(const Term &term).
inline std::string str_impl(const Vars& vars,
                            std::function<std::string(Var)> str) {
  std::string result;
  for (const auto& var : vars) {
    if (!result.empty()) {
      result += "*";
    }
    result += str(var);
  }
  return result;
}

/// @brief String conversion function for the Term object.
/// @param term The Term object to convert to a string.
/// @param str The string conversion function for the Var object.
/// @return std::string The string representation of the Term object.
inline std::string str_impl(const Term& term,
                            std::function<std::string(Var)> str) {
  std::string result;
  if (term.var_count() == 0) return qbpp::str(term.coeff());
  if (term.coeff() == -1)
    result += "-";
  else if (term.coeff() != 1)
    result += qbpp::str(term.coeff()) + "*";
  result += str_impl(term.vars(), str);
  return result;
}

inline std::string str_impl(const Terms& terms,
                            std::function<std::string(Var)> str) {
  bool first = true;  // flag to check if the first iterm.
  std::string result;
  for (const auto& term : terms) {
    if (first) {
      result += str_impl(term, str);
      first = false;
    } else {
      if (term.coeff() < 0)
        result += " " + str_impl(term, str);
      else
        result += " +" + str_impl(term, str);
    }
  }
  return result;
}

/// @brief  String conversion function for the Expr object.
/// @param expr The Expr object to convert to a string.
/// @param str The string conversion function for the Var object.
/// @return std::string The string representation of the Expr object.
inline std::string str_impl(const Expr& expr,
                            std::function<std::string(Var)> str) {
  bool first = true;  // flag to check if the first iterm.
  std::string result;
  if (expr.constant() != 0) {
    result += qbpp::str(expr.constant());
    first = false;
  } else if (expr.term_count() == 0)
    return "0";
  for (const auto& term : expr.terms()) {
    if (first) {
      result += str_impl(term, str);
      first = false;
    } else {
      if (term.coeff() < 0)
        result += " " + str_impl(term, str);
      else
        result += " +" + str_impl(term, str);
    }
  }
  return result;
}

/// @brief Returns the string representation of the Vars object
/// @param vars The Vars object to get the string representation.
/// @return std::string The string representation of the Vars object.
/// @note This function is called by str(const Term &term).
inline std::string str(const Vars& vars) {
  return str_impl(vars, static_cast<std::string (*)(Var)>(str));
}

/// @brief Returns the string representation of BitVector.
/// @param bit_vector The BitVector object to get the string
/// representation.
/// @return std::string The string representation of BitVector.
inline std::string str(const BitVector& bit_vector) {
  std::string result;
  for (vindex_t i = 0; i < bit_vector.size(); i++) {
    result += bit_vector.get(i) ? "1" : "0";
  }
  return result;
}

/// @brief Returns the string representation of Term object
/// @param term The Term object to get the string representation.
/// @return std::string The string representation of the Term object.
/// @note This function is called by str(const Expr &expr).
inline std::string str(const Term& term) {
  return str_impl(term, static_cast<std::string (*)(Var)>(str));
}

/// @brief Returns the string representation of Expr object
/// @param expr The Expr object to get the string representation.
/// @return std::string The string representation of the Expr object.
inline std::string str(const Expr& expr) {
  return str_impl(expr, static_cast<std::string (*)(Var)>(str));
}

inline std::string str(const Terms& terms) {
  return str_impl(terms, static_cast<std::string (*)(Var)>(str));
}

/// @brief Returns the string representation of Expr object
/// @param expr The Expr object to get the string representation.
/// @param prefix The prefix string to add to the string representation.
/// @param separator The separator string to add to the string
/// @return std::string The string representation of the Expr object.
/// @note prefix is used to represent std::vector<Expr>.
inline std::string str(const Expr& expr, const std::string& prefix,
                       const std::string& separator [[maybe_unused]] = ",") {
  if (prefix == "") {
    return "{" + str_impl(expr, static_cast<std::string (*)(Var)>(str)) + "}";
  } else {
    return "{" + prefix + "," +
           str_impl(expr, static_cast<std::string (*)(Var)>(str)) + "}";
  }
}

/// @brief Returns the string representation of VarInt object
/// @param var_int The VarInt object to get the string representation.
/// @return std::string The string representation of the VarInt object.
inline std::string str(const VarInt& var_int) {
  return str(static_cast<const Expr&>(var_int));
}

/// @brief モデルの文字列表現を返す関数
inline std::string str(const Model& model) {
  auto to_str = [&model](Var var) -> std::string {
    vindex_t index = model.index(var);  // 型明示しておくと安心
    std::string var_string = std::to_string(index & qbpp::vindex_mask);
    return "<" + var_string + ">";
  };
  return str_impl(model.expr(), to_str);
}

/// @brief Returns the string representation of HuboModel object
/// @param hubo_model The HuboModel object to get the string representation.
/// @return std::string The string representation of the HuboModel object.
inline std::string str(const HuboModel& hubo_model) {
  return str(static_cast<const Model&>(hubo_model));
}

/// @brief Returns the string representation of MapList object
/// @param map_list The MapList object to get the string representation.
/// @return std::string The string representation of the MapList object.
inline std::string str(const MapList& map_list) {
  std::ostringstream oss;
  oss << "{";
  bool first = true;

  for (const auto& [key, val] : map_list) {
    if (!first) {
      oss << ",";
    }
    first = false;

    auto str_val = str(val);
    std::visit(
        [&](const auto& arg) {
          using T = std::decay_t<decltype(arg)>;
          oss << "{";
          if constexpr (std::is_same_v<T, VarInt>) {
            oss << arg.name();
          } else {
            oss << str(arg);
          }
          oss << "," << str_val << "}";
        },
        key);
  }

  oss << "}";
  return oss.str();
}

/// @brief Output operator for MapList.
/// @param os The output stream.
/// @param map_list The MapList object to output.
/// @return The output stream.
inline std::ostream& operator<<(std::ostream& os, const MapList& map_list) {
  return os << str(map_list);
}

/// @brief Returns the string representation of the solution.
/// @param sol The solution to get the string representation.
/// @return std::string The string representation of the solution.
inline std::string str(const Sol& sol) {
  if (sol.tts() >= 0.0) {
    return std::to_string(sol.tts()) + ":" + str(sol.energy()) + ":" +
           str(static_cast<MapList>(sol));
  }
  return str(sol.energy()) + ":" + str(static_cast<MapList>(sol));
}

/// @brief Returns the string representation of the Vector object.
/// @param vec The Vector object to get the string representation.
/// @param prefix The prefix string to add to the string representation.
/// @param separator The separator string to add to the string
/// representation.
/// @return std::string The string representation of the Vector object.
/// @note this function will be removed.
template <typename T>
std::string str(const Vector<T>& vec, const std::string& prefix,
                const std::string& separator = ",") {
  std::string result;
  for (size_t i = 0; i < vec.size(); i++) {
    result += str(vec[i], prefix + "[" + qbpp::str(i) + "]", separator);
    if (i < vec.size() - 1) result += separator;
  }
  return result;
}

/// @brief Returns the string representation of the Vector object.
template <typename T>
std::string str(const Vector<T>& vec) {
  std::string result;
  for (size_t i = 0; i < vec.size(); i++) {
    result += str(vec[i]);
    if (i < vec.size() - 1) result += ",";
  }
  return "{" + result + "}";
}

/// @brief Stream output operator for Vector<T> object.
/// @param os The output stream.
/// @param vec The vector to output.
/// @return std::ostream& The output stream.
template <typename T>
std::ostream& operator<<(std::ostream& os, const Vector<T>& vec) {
  os << str(vec);
  return os;
}

/// @brief Stream output operator for Vector<T> object.
/// @param os The output stream.
/// @param vec The vector to output.
/// @return std::ostream& The output stream.
template <typename T>
std::ostream& operator<<(std::ostream& os,
                         const std::pair<std::string, Vector<T>>& vec) {
  os << str(vec.second, vec.first);
  return os;
}

}  // namespace qbpp

namespace qbpp::impl {}  // namespace qbpp::impl

namespace qbpp {

/// @brief Converts Expr to a short string.
/// @param expr The expression to convert.
/// @return std::string The short string representation of the expression.
/// @note If the expression has more than 5 terms, terms excluding the first
/// 2 terms and the last 2 terms are converted to a string.
inline std::string str_short(const Expr& expr) {
  if (expr.term_count() <= 5) return str(expr);
  std::string result;
  if (expr.constant() != 0) result += qbpp::str(expr.constant()) + " + ";
  auto it = expr.terms().begin();
  result += str(*it) + " + ";
  ++it;
  result += str(*it) + " + ... + ";
  it = expr.terms().end();
  --it;
  --it;
  result += str(*it) + " + ";
  ++it;
  result += str(*it);
  result += " (" + qbpp::str(expr.term_count()) + " terms)";
  return result;
}

// ============================================
// Hash functions for qbpp::Var and qbpp::Vars
// ============================================
namespace impl {
inline size_t var_hash::operator()(const Var var) const {
  std::hash<vindex_t> hasher;
  return hasher(var.index());
}

inline size_t vars_hash::operator()(const Vars& vars) const {
#if defined(MAXDEG) && MAXDEG > 0
  // VarArray has fixed-size storage: hash raw bytes directly.
  // N=2 (8 bytes) → single std::hash<uint64_t>, no loop/serial dependency.
  // N=3,4 (12-16 bytes) → two uint64_t hash combines.
  constexpr size_t n_vals =
      (sizeof(Vars) + sizeof(uint64_t) - 1) / sizeof(uint64_t);
  uint64_t vals[n_vals] = {};
  std::memcpy(vals, &vars, sizeof(Vars));
  size_t h = std::hash<uint64_t>{}(vals[0]);
  for (size_t i = 1; i < n_vals; ++i) {
    h ^= std::hash<uint64_t>{}(vals[i]) + 0x9e3779b9 + (h << 6) + (h >> 2);
  }
  return h;
#else
  std::hash<vindex_t> hasher;
  size_t seed = 0;
  for (const auto& item : vars) {
    seed ^= hasher(item.index()) + 0x9e3779b9 + (seed << 6) + (seed >> 2);
  }
  return seed;
#endif
}
}  // namespace impl

// ===============================================
// Global functions for equality check for Vectors
// ===============================================

namespace impl {
/// @brief Returns an expression that checks if two objects are equal.
/// @tparam T The type of the object to compare.
/// @param lhs The left-hand side object.
/// @param rhs The right-hand side object.
/// @return qbpp::Expr The expression that takes the minimum value 0 if
/// the two objects are equal.
template <typename T>
Expr equal(const T& lhs, const T& rhs) {
  return lhs - rhs == 0;
}

/// @brief Returns an expression that checks if two vectors are equal.
/// @tparam T The type of the vector elements.
/// @param lhs The left-hand side vector.
/// @param rhs The right-hand side vector.
/// @return qbpp::Expr The expression that takes the minimum value 0 if
/// the two vectors are equal.
template <typename T>
Expr equal(const std::vector<T>& lhs, const std::vector<T>& rhs) {
  if (lhs.size() != rhs.size()) {
    throw std::runtime_error(THROW_MESSAGE("Vector dimension mismatch"));
  }
  Expr result = 0;
  for (size_t i = 0; i < lhs.size(); i++) {
    result += equal(lhs[i], rhs[i]);
  }
  return result;
}

}  // namespace impl

// --------------------------------------------------
// Eval/Replace Related Functions
// --------------------------------------------------

/// @brief Converts MapList to VarValMap.
/// @param map_list The list of mappings.
/// @return VarValMap The integer assignment of variables.
inline VarValMap list_to_var_val(const MapList& map_list) {
  VarValMap var_int_map;
  for (const auto& [key, val] : map_list) {
    if (val.term_count() >= 1) {
      throw std::runtime_error(THROW_MESSAGE("Value must be an integer."));
    }
    auto constant = val.constant();
    std::visit(
        [&](auto&& arg) {
          using T = std::decay_t<decltype(arg)>;
          if constexpr (std::is_same_v<T, VarInt>) {
            for (const auto& [var, bin_val] :
                 arg.val_map(static_cast<coeff_t>(constant))) {
              var_int_map[var] = bin_val;
            }
          } else {
            if (arg.index() & vindex_neg_bit) {
              throw std::runtime_error(THROW_MESSAGE(
                  "Negated variable (~",
                  qbpp::str(Var(arg.index() & vindex_mask)),
                  ") cannot be used as a key for evaluation. "
                  "Use the base variable instead."));
            }
            var_int_map[arg] = static_cast<var_val_t>(constant);
          }
        },
        key);
  }
  return var_int_map;
}

/// @brief Converts MapList to MapDict.
/// @param map_list The list of mappings.
/// @return MapDict The dictionary of mappings.
inline MapDict list_to_dict(const MapList& map_list) {
  MapDict map_dict;
  for (const auto& [key, val] : map_list) {
    auto val_local = val;
    std::visit(
        [&](auto&& arg) {
          using T = std::decay_t<decltype(arg)>;
          if constexpr (std::is_same_v<T, VarInt>) {
            if (val_local.term_count() >= 1) {
              throw std::runtime_error(
                  THROW_MESSAGE("VarInt must have a constant."));
            }
            for (const auto& [var, bin_val] :
                 arg.val_map(static_cast<coeff_t>(val_local.constant()))) {
              map_dict[var] = bin_val;
            }
          } else {
            map_dict[arg] = val_local;
          }
        },
        key);
  }
  return map_dict;
}

// --------------------------------------------------
// Eval/Replace Global Functions
// --------------------------------------------------

/// @brief Evaluates the term with var_val_map.
/// @param term The term to evaluate.
/// @param var_val_map The integer assignment of variables.
/// @return Val The value of the term with var_val_map.
inline energy_t eval(const Term& term, const VarValMap& var_val_map) {
  energy_t result = term.coeff();
  for (const auto& item : term.vars()) {
    bool negated = (item.index() & vindex_neg_bit) != 0;
    Var base_var(item.index() & vindex_mask);
    try {
      energy_t val = var_val_map.at(base_var);
      result *= negated ? 1 - val : val;
    } catch (const std::out_of_range& e) {
      throw std::runtime_error(THROW_MESSAGE("Variable ", qbpp::str(item),
                                             " is not found in the map."));
    }
  }
  return result;
}

/// @brief Evaluates the term with the solution.
/// @param term The term to evaluate.
/// @param sol The solution to evaluate.
/// @return The value of the term with the solution.
inline energy_t eval(const Term& term, const Sol& sol) {
  energy_t result = term.coeff();
  for (const auto& item : term.vars()) {
    result *= sol.get(item);
  }
  return result;
}

/// @brief Returns a new Expr object with each variable replaced by either
/// an integer value or another Expr object.
/// @param expr The Expr object in which variables will be replaced.
/// @param map_list The MapList containing mappings of Var objects to
/// integer values or Expr objects.
/// @return A new Expr object with the variables replaced.
inline Expr replace(const Expr& expr, const MapList& map_list) {
  auto result = expr;
  return result.replace(map_list);
}

/// @brief Evaluates the given Expr object using the specified VarValMap
/// object.
/// @param expr The Expr object to be evaluated.
/// @param var_val_map The VarValMap object containing mappings of Var
/// objects to integer values for evaluation.
/// @return The result of the evaluated expression.
inline energy_t eval_var_val_map(const Expr& expr,
                                 const VarValMap& var_val_map) {
  energy_t result = expr.constant();

  tbb::combinable<energy_t> local_results(
      [] { return static_cast<energy_t>(0); });

  tbb::parallel_for(size_t(0), expr.terms().size(), [&](size_t i) {
    local_results.local() += eval(expr.terms()[i], var_val_map);
  });

  result += local_results.combine(
      [](const energy_t& a, const energy_t& b) { return a + b; });

  return result;
}

/// @brief Evaluates the given Expr object using the specified MapList
/// object.
/// @param expr The Expr object to be evaluated.
/// @param map_list The MapList object containing mappings of Var objects to
/// integer values for evaluation.
/// @return The result of the evaluated expression.
/// @note The MapList must provide integer values for all variables used in
/// the expression.
inline energy_t eval(const Expr& expr, const MapList& map_list) {
  VarValMap var_val_map = list_to_var_val(map_list);
  return eval_var_val_map(expr, var_val_map);
}

/// @brief Evaluates the given Expr object using the specified Sol object.
/// @param expr The Expr object to be evaluated.
/// @param sol The Sol object.
/// @return The result of the evaluated energy value.
inline energy_t eval(const Expr& expr, const Sol& sol) {
  tbb::combinable<energy_t> local_results(
      [] { return static_cast<energy_t>(0); });

  tbb::parallel_for(tbb::blocked_range<size_t>(0, expr.terms().size()),
                    [&](const tbb::blocked_range<size_t>& range) {
                      auto& local = local_results.local();
                      for (size_t i = range.begin(); i < range.end(); ++i) {
                        local += eval(expr.terms()[i], sol);
                      }
                    });

  energy_t result = expr.constant();
  result += local_results.combine(
      [](const energy_t& a, const energy_t& b) { return a + b; });
  return result;
}

// --------------------------------------------------
// Var Related Global Functions
// --------------------------------------------------

inline Var var(const std::string& name) {
  vindex_t index = qbpp_new_var(name.c_str());
  if (index == qbpp::vindex_limit) {
    throw std::runtime_error(
        THROW_MESSAGE("License check failed: trial period expired or no valid "
                      "license found."));
  }
  return Var(index);
}

inline Var var() {
  std::string unused_name = "{" + std::to_string(new_unnamed_var_index()) + "}";
  return Var(qbpp_new_var(unused_name.c_str()));
}

inline std::string str(Var var) {
  return std::string(qbpp_var_str(var.index()));
}

/// @brief Creates a multi-dimensional array of new variables with the
/// specified name.
/// @param var_str The name of the variable.
/// @param size The first dimension of the array.
/// @param args The remaining dimensions of the array.
/// @return The multi-dimensional array of new variables.
template <typename T, typename... Args,
          typename = typename std::enable_if<std::is_integral<T>::value>::type>
auto var(const std::string& var_str, T size, Args... args) {
  if constexpr (sizeof...(Args) == 0) {
    Vector<Var> vars;
    if (size == 1) {
      vars.emplace_back(var(var_str));
    } else {
      for (vindex_t i = 0; i < static_cast<size_t>(size); ++i) {
        vars.emplace_back(var(var_str + "[" + qbpp::str(i) + "]"));
      }
    }
    return vars;
  } else {
    Vector<std::decay_t<decltype(var(var_str, args...))>> vars;
    vars.reserve(static_cast<size_t>(size));
    for (size_t i = 0; i < static_cast<size_t>(size); ++i) {
      vars.emplace_back(var(var_str + "[" + qbpp::str(i) + "]",
                            static_cast<size_t>(args)...));
    }
    return vars;
  }
}

/// @brief Creates a multi-dimensional array of new variables with no name.
template <typename T, typename... Args,
          typename = typename std::enable_if<std::is_integral<T>::value>::type>
auto var(T size, Args... args) {
  return var("{" + std::to_string(new_unnamed_var_index()) + "}", size,
             args...);
}

// --------------------------------------------------
// VarInt Related Global Functions
// --------------------------------------------------

/// @brief Create a new VarIntCore object with the specified name.
/// @param var_str The name of the VarIntCore object.
/// @return The new VarIntCore object.
inline VarIntCore var_int(const std::string& var_str) {
  return VarIntCore(var_str);
}

/// @brief Create a new VarInt object with no name.
/// @return The new VarInt object.
inline VarIntCore var_int() {
  return var_int("{" + std::to_string(new_unnamed_var_index()) + "}");
}

/// @brief Create a new array of VarInt objects with the specified name and
/// dimensions.
/// @param var_str The name of the VarInt object.
/// @param size The first dimension of the array.
/// @param args The remaining dimensions of the array.
/// @return The new array of VarInt objects.

template <typename T, typename... Args>
auto var_int(const std::string& var_str, T size, Args... args) {
  if constexpr (sizeof...(args) == 0) {
    Vector<VarIntCore> vars;
    vars.reserve(static_cast<size_t>(size));
    for (size_t i = 0; i < static_cast<size_t>(size); ++i) {
      vars.emplace_back(VarIntCore(var_str + "[" + qbpp::str(i) + "]"));
    }
    return vars;
  } else {
    Vector<std::decay_t<decltype(var_int(var_str, args...))>> vars;
    vars.reserve(static_cast<size_t>(size));
    for (size_t i = 0; i < static_cast<size_t>(size); ++i) {
      vars.emplace_back(var_int(var_str + "[" + qbpp::str(i) + "]",
                                static_cast<size_t>(args)...));
    }
    return vars;
  }
}

/// @brief Creates an array of VarIntCore objects with auto-generated name.
/// @param size The first dimension of the array.
/// @param args The remaining dimensions of the array.
/// @return The new array of VarInt objects.
template <typename T, typename... Args,
          typename = std::enable_if_t<is_integer_like_v<T>>>
auto var_int(T size, Args... args) {
  return var_int("{" + std::to_string(new_unnamed_var_index()) + "}", size,
                 args...);
}

/// @brief Helper function to compute the coefficients for the VarInt
/// object.
/// @param min_val The minimum value.
/// @param max_val The maximum value.
/// @param base_coeff The base coefficient. 1 or 2.
/// @return The vector of coefficients.
inline Vector<coeff_t> comp_coeffs(const energy_t& min_val,
                                   const energy_t& max_val,
                                   const energy_t& base_coeff = 1) {
  Vector<coeff_t> coeffs;
  coeff_t val = static_cast<coeff_t>(max_val - min_val);
  if (val < 0) {
    throw std::invalid_argument(THROW_MESSAGE(
        "max_val(", max_val, ") must be no less than min_val(", min_val, ")"));
  }
  coeff_t current_coeff = static_cast<coeff_t>(base_coeff);
  while (val > 0) {
    if (current_coeff < val) {
      coeffs.push_back(current_coeff);
    } else {
      coeffs.push_back(val);
    }
    val -= current_coeff;
    current_coeff *= 2;
  }
  return coeffs;
}

/// @brief Create a new VarInt object with the specified name and domain.
/// @param var_str The name of the VarInt object.
/// @param min_val The minimum value.
/// @param max_val The maximum value.
/// @param base_coeff The base coefficient. 1 or 2.
inline VarInt new_var_int(const std::string& var_str, const energy_t& min_val,
                          const energy_t& max_val,
                          const energy_t& base_coeff = 1) {
  std::shared_ptr<Vector<coeff_t>> coeffs_ptr =
      std::make_shared<Vector<coeff_t>>(
          comp_coeffs(min_val, max_val, base_coeff));
  return VarInt(var_str, min_val, max_val, coeffs_ptr);
}

/// @brief Create a new VarInt object with the specified name and domain.
/// @param var_int_core The VarIntCore object.
/// @param min_val The minimum value.
/// @param max_val The maximum value.
/// @param base_coeff The base coefficient. 1 or 2.
inline VarInt new_var_int(const VarIntCore& var_int_core,
                          const energy_t& min_val, const energy_t& max_val,
                          const energy_t& base_coeff = 1) {
  return new_var_int(var_int_core.var_str_, min_val, max_val, base_coeff);
}

/// @brief Copy assignment operator of VarInt.
inline VarInt& VarInt::operator=(const VarInt& other) {
  if (this != &other) {
    // If RHS is unnamed (starts with '{'), use LHS's name
    if (!other.var_str_.empty() && other.var_str_[0] == '{') {
      *this = new_var_int(var_str_, other.min_val_, other.max_val_);
    } else {
      Expr::operator=(other);
      var_str_ = other.var_str_;
      min_val_ = other.min_val_;
      max_val_ = other.max_val_;
      coeffs_ptr_ = other.coeffs_ptr_;
      vars_ = other.vars_;
    }
  }
  return *this;
}

/// @brief Move assignment operator of VarInt.
inline VarInt& VarInt::operator=(VarInt&& other) noexcept {
  if (this != &other) {
    // If RHS is unnamed (starts with '{'), use LHS's name
    if (!other.var_str_.empty() && other.var_str_[0] == '{') {
      *this = new_var_int(var_str_, other.min_val_, other.max_val_);
    } else {
      Expr::operator=(std::move(other));
      var_str_ = std::move(other.var_str_);
      min_val_ = other.min_val_;
      max_val_ = other.max_val_;
      coeffs_ptr_ = std::move(other.coeffs_ptr_);
      vars_ = std::move(other.vars_);
    }
  }
  return *this;
}

/// @brief Sets the minimum value of a VarInt object
/// @param lhs The minimum value.
/// @param rhs The VarInt object or nested vector of VarInt objects.
/// @return The pair of the minimum value and the VarInt object.
/// @note This function is used to implement the left-hand side <= of the
/// expression int <= var_int() <= int.
template <typename T, typename = std::enable_if_t<is_integer_like_v<T>>>
auto operator<=(T lhs, VarIntCore&& rhs) {
  return std::make_pair(static_cast<energy_t>(lhs), std::move(rhs));
}

/// @brief Sets the minimum value of a VarInt object or a nested vector of
/// VarInt objects.
/// @param lhs The minimum value.
/// @param rhs A VarInt object or a nested vector of VarInt objects.
/// @return The VarInt object or nested vector of VarInt objects with the
/// specified minimum value.
/// @note This function is used to implement the left-hand side <= of the
/// expression int <= var_int() <= int.
template <typename T, typename U,
          typename = std::enable_if_t<is_integer_like_v<T>>>
auto operator<=(T lhs, Vector<U>&& rhs) {
  return std::make_pair(static_cast<energy_t>(lhs),
                        std::forward<Vector<U>>(rhs));
}

/// @brief The lefthand side operator <= for defining element-wise bounds with
/// vectors.
/// @param lhs The vector of minimum values.
/// @param rhs The vector of VarInt objects.
/// @return A pair of the lower bound vector and the VarInt vector.
template <typename T1, typename T2>
auto operator<=(const Vector<T1>& lhs, Vector<T2>&& rhs) {
  return std::make_pair(lhs, std::forward<Vector<T2>>(rhs));
}

/// @brief The lefthand side operator <= for defining element-wise bounds with
/// vectors (lvalue version).
template <typename T1, typename T2>
auto operator<=(const Vector<T1>& lhs, const Vector<T2>& rhs) {
  return std::make_pair(lhs, rhs);
}

/// @brief The righthand side operator <= for defining element-wise bounds with
/// vectors.
/// @param lhs The pair of lower bound vector and VarInt vector.
/// @param rhs The vector of maximum values.
/// @return The constrained expressions.
template <typename T1, typename T2, typename T3>
auto operator<=(std::pair<Vector<T1>, Vector<T2>> lhs, const Vector<T3>& rhs) {
  if (lhs.first.size() != lhs.second.size() ||
      lhs.second.size() != rhs.size()) {
    throw std::invalid_argument(
        "Vector sizes must match for element-wise bounds");
  }
  using ResultType =
      decltype(lhs.first[0] <= std::move(lhs.second[0]) <= rhs[0]);
  Vector<ResultType> result;
  result.reserve(lhs.second.size());
  for (size_t i = 0; i < lhs.second.size(); ++i) {
    result.push_back(lhs.first[i] <= std::move(lhs.second[i]) <= rhs[i]);
  }
  return result;
}

/// @brief The righthand side operator <= for scalar lower bound and vector
/// upper bound.
/// @param lhs The pair of scalar lower bound and VarInt vector.
/// @param rhs The vector of maximum values.
/// @return The constrained expressions.
template <typename T1, typename T2>
auto operator<=(std::pair<energy_t, Vector<T1>> lhs, const Vector<T2>& rhs) {
  if (lhs.second.size() != rhs.size()) {
    throw std::invalid_argument(
        "Vector sizes must match for element-wise bounds");
  }
  using ResultType = decltype(lhs.first <= std::move(lhs.second[0]) <= rhs[0]);
  Vector<ResultType> result;
  result.reserve(lhs.second.size());
  for (size_t i = 0; i < lhs.second.size(); ++i) {
    result.push_back(lhs.first <= std::move(lhs.second[i]) <= rhs[i]);
  }
  return result;
}

/// @brief The righthand side operator <= for vector lower bound and scalar
/// upper bound.
/// @param lhs The pair of vector lower bound and VarInt vector.
/// @param rhs The scalar maximum value.
/// @return The constrained expressions.
template <typename T1, typename T2, typename T3,
          typename = std::enable_if_t<is_integer_like_v<T3>>>
auto operator<=(std::pair<Vector<T1>, Vector<T2>> lhs, T3 rhs) {
  if (lhs.first.size() != lhs.second.size()) {
    throw std::invalid_argument(
        "Vector sizes must match for element-wise bounds");
  }
  using ResultType = decltype(lhs.first[0] <= std::move(lhs.second[0]) <= rhs);
  Vector<ResultType> result;
  result.reserve(lhs.second.size());
  for (size_t i = 0; i < lhs.second.size(); ++i) {
    result.push_back(lhs.first[i] <= std::move(lhs.second[i]) <= rhs);
  }
  return result;
}

/// @brief Sets the maximum value of a VarInt object or a nested vector of
/// VarInt objects.
/// @param lhs The pair of T and the minimum value.
/// @param rhs The maximum value.
/// @return The VarInt object or nested vector of VarInt objects with the
/// minimum and maximum values.
/// @note This function is used to implement the right-hand side <= of the
/// expression int <= var_int() <= int.

template <typename T, typename = std::enable_if_t<is_integer_like_v<T>>>
auto operator<=(const std::pair<energy_t, VarIntCore> lhs, T rhs) {
  return new_var_int(lhs.second.var_str_, lhs.first,
                     static_cast<energy_t>(rhs));
}

/// @brief The lefthand size operator <= for defining the Vector of VarInt
/// objects.
template <typename T, typename = std::enable_if_t<is_integer_like_v<T>>>
std::pair<energy_t, Vector<VarIntCore>> operator<=(
    T lhs, const Vector<VarIntCore>& rhs) {
  return std::make_pair(static_cast<energy_t>(lhs), rhs);
}

/// @brief The righthand size operator <= for defining the Vector of VarInt
/// objects.
template <typename T, typename = std::enable_if_t<is_integer_like_v<T>>>
auto operator<=(const std::pair<energy_t, Vector<VarIntCore>> lhs, T rhs) {
  Vector<VarInt> result;
  result.reserve(lhs.second.size());
  for (const auto& item : lhs.second) {
    result.push_back(new_var_int(item, lhs.first, static_cast<energy_t>(rhs)));
  }
  return result;
}

/// @brief Creates a VarInt with min_val = max_val = val (constant).
/// @param lhs The VarIntCore object.
/// @param rhs The constant value.
/// @return The VarInt object with min_val = max_val = rhs.
/// @note Useful for creating placeholder VarInt arrays to be reassigned later.
template <typename T, typename = std::enable_if_t<is_integer_like_v<T>>>
VarInt operator==(VarIntCore&& lhs, T rhs) {
  return new_var_int(lhs.var_str_, static_cast<energy_t>(rhs),
                     static_cast<energy_t>(rhs));
}

/// @brief Creates a Vector of VarInt with min_val = max_val = val (constant).
/// @param lhs The Vector of VarIntCore objects.
/// @param rhs The constant value.
/// @return The Vector of VarInt objects.
template <typename T, typename U,
          typename = std::enable_if_t<is_integer_like_v<U>>>
auto operator==(Vector<T>&& lhs, U rhs) {
  Vector<std::decay_t<decltype(std::move(lhs[0]) == rhs)>> result;
  result.reserve(lhs.size());
  for (auto& item : lhs) {
    result.push_back(std::move(item) == rhs);
  }
  return result;
}

/// @brief Intentionally deleted to cause a compilation error when
/// operator<= is used for Var objects, because it is misusage hard to be
/// recognized.
void operator<=(energy_t /**/, Var /**/) = delete;

/// @brief Intentionally deleted to cause a compilation error when
/// operator<= is used for Var objects, because it is misusage hard to be
/// recognized.
void operator<=(Var /**/, energy_t /**/) = delete;

/// @brief Creates a new single zero-initialized qbpp::Expr object.
/// @return The new single Expr object.
inline Expr expr() { return Expr(); }

/// @brief Creates a new multi-dimensional array of zero-initialized
/// qbpp::Expr objects.
/// @param size The first dimension of the array.
/// @param args The remaining dimensions of the array.
/// @return The multi-dimensional array of new Expr objects.
template <typename T, typename... Args>
auto expr(T size, Args... args) {
  if constexpr (sizeof...(Args) == 0) {
    if (size <= 0) {
      throw std::invalid_argument(
          THROW_MESSAGE("The argument of expr() must be greater than 0."));
    }
    return Vector<Expr>(static_cast<size_t>(size));
  } else {
    Vector<std::decay_t<decltype(expr(args...))>> result(
        static_cast<size_t>(size));
    for (size_t i = 0; i < static_cast<size_t>(size); ++i)
      result[i] = expr(static_cast<size_t>(args)...);
    return result;
  }
}

/// @brief Creates a new single zero-initialized energy_t value.
/// @return The zero value.
inline energy_t integer() { return 0; }

/// @brief Creates a new multi-dimensional array of zero-initialized
/// energy_t values.
/// @param size The first dimension of the array.
/// @param args The remaining dimensions of the array.
/// @return The multi-dimensional array of zero-initialized energy_t values.
/// @example
///   auto a = qbpp::integer(2, 3, 4);  // Vector<Vector<Vector<energy_t>>>
template <typename T, typename... Args>
auto integer(T size, Args... args) {
  if constexpr (sizeof...(Args) == 0) {
    if (size <= 0) {
      throw std::invalid_argument(
          THROW_MESSAGE("The argument of integer() must be greater than 0."));
    }
    return Vector<energy_t>(static_cast<size_t>(size), 0);
  } else {
    Vector<std::decay_t<decltype(integer(args...))>> result(
        static_cast<size_t>(size));
    for (size_t i = 0; i < static_cast<size_t>(size); ++i)
      result[i] = integer(static_cast<size_t>(args)...);
    return result;
  }
}

/// @brief Creates a 1D array of energy_t values from an initializer list.
/// @param list The initializer list of values.
/// @return The 1D array of energy_t values.
/// @example
///   auto a = qbpp::integer({1, 2, 3});  // Vector<energy_t>
inline Vector<energy_t> integer(std::initializer_list<energy_t> list) {
  return Vector<energy_t>(list);
}

/// @brief Creates a 2D array of energy_t values from a nested initializer list.
/// @param list The nested initializer list of values.
/// @return The 2D array of energy_t values.
/// @example
///   auto a = qbpp::integer({{1, 2}, {3, 4}});  // Vector<Vector<energy_t>>
inline Vector<Vector<energy_t>> integer(
    std::initializer_list<std::initializer_list<energy_t>> list) {
  Vector<Vector<energy_t>> result;
  result.reserve(list.size());
  for (const auto& inner : list) {
    result.push_back(Vector<energy_t>(inner));
  }
  return result;
}

/// @brief Creates a 3D array of energy_t values from a nested initializer list.
/// @param list The nested initializer list of values.
/// @return The 3D array of energy_t values.
/// @example
///   auto a = qbpp::integer({{{1, 2}, {3, 4}}, {{5, 6}, {7, 8}}});
inline Vector<Vector<Vector<energy_t>>> integer(
    std::initializer_list<
        std::initializer_list<std::initializer_list<energy_t>>>
        list) {
  Vector<Vector<Vector<energy_t>>> result;
  result.reserve(list.size());
  for (const auto& inner : list) {
    result.push_back(integer(inner));
  }
  return result;
}

/// @brief Creates a 4D array of energy_t values from a nested initializer list.
/// @param list The nested initializer list of values.
/// @return The 4D array of energy_t values.
inline Vector<Vector<Vector<Vector<energy_t>>>> integer(
    std::initializer_list<std::initializer_list<
        std::initializer_list<std::initializer_list<energy_t>>>>
        list) {
  Vector<Vector<Vector<Vector<energy_t>>>> result;
  result.reserve(list.size());
  for (const auto& inner : list) {
    result.push_back(integer(inner));
  }
  return result;
}

/// @brief Creates a 1D array of Expr values from an initializer list.
/// @param list The initializer list of values convertible to Expr.
/// @return The 1D array of Expr values.
/// @example
///   auto f = qbpp::expr({a+b, a+1, 2*a});  // Vector<Expr>
inline Vector<Expr> expr(std::initializer_list<Expr> list) {
  return Vector<Expr>(list);
}

/// @brief Creates a 2D array of Expr values from a nested initializer list.
/// @param list The nested initializer list of values convertible to Expr.
/// @return The 2D array of Expr values.
/// @example
///   auto f = qbpp::expr({{a+b, a+1}, {2*a, b}});  // Vector<Vector<Expr>>
inline Vector<Vector<Expr>> expr(
    std::initializer_list<std::initializer_list<Expr>> list) {
  Vector<Vector<Expr>> result;
  result.reserve(list.size());
  for (const auto& inner : list) {
    result.push_back(expr(inner));
  }
  return result;
}

/// @brief Creates a 3D array of Expr values from a nested initializer list.
/// @param list The nested initializer list of values convertible to Expr.
/// @return The 3D array of Expr values.
inline Vector<Vector<Vector<Expr>>> expr(
    std::initializer_list<std::initializer_list<std::initializer_list<Expr>>>
        list) {
  Vector<Vector<Vector<Expr>>> result;
  result.reserve(list.size());
  for (const auto& inner : list) {
    result.push_back(expr(inner));
  }
  return result;
}

/// @brief Creates a 4D array of Expr values from a nested initializer list.
/// @param list The nested initializer list of values convertible to Expr.
/// @return The 4D array of Expr values.
inline Vector<Vector<Vector<Vector<Expr>>>>
expr(std::initializer_list<
     std::initializer_list<std::initializer_list<std::initializer_list<Expr>>>>
         list) {
  Vector<Vector<Vector<Vector<Expr>>>> result;
  result.reserve(list.size());
  for (const auto& inner : list) {
    result.push_back(expr(inner));
  }
  return result;
}

/// @brief Converts an Expr object to an Expr object (copy or move).
/// @note This function is used when conversion is not required.
template <typename T,
          typename std::enable_if<std::is_same<std::decay_t<T>, Expr>::value,
                                  int>::type = 0>
Expr toExpr(T&& arg) {
  return std::forward<T>(arg);
}

/// @brief Converts any object to an Expr object.
/// @param arg The object to be converted to an Expr object.
/// @return The resulting Expr object after conversion.
template <typename T,
          typename std::enable_if<!std::is_same<std::decay_t<T>, Expr>::value,
                                  int>::type = 0>
Expr toExpr(T&& arg) {
  return Expr(std::forward<T>(arg));
}

/// @brief Converts a vector of Expr objects to a vector of Expr objects (copy
/// or move).
/// @note This function is used when conversion is not required.
template <typename T, typename std::enable_if<
                          std::is_same<std::decay_t<T>, Vector<Expr>>::value,
                          int>::type = 0>
Vector<Expr> toExpr(T&& arg) {
  return std::forward<T>(arg);
}

/// @brief Converts a nested vector of objects to a nested vector of Expr.
/// @param arg The nested vector of objects to be converted to a nested
/// vector.
/// @return The resulting nested vector of Expr objects after conversion.
/// @note A nested vector of objects is defined using qbpp::Vector.
template <typename T,
          typename std::enable_if<!std::is_same<T, Expr>::value, int>::type = 0>
auto toExpr(const Vector<T>& arg) {
  Vector<std::decay_t<decltype(toExpr(arg[0]))>> result;
  result.reserve(arg.size());
  for (const auto& item : arg) {
    result.push_back(toExpr(item));
  }
  return result;
}

/// @brief Converts a nested vector of objects to a nested vector of Expr.
/// @param arg The nested vector of objects to be converted to a nested
/// vector.
/// @return The resulting nested vector of Expr objects after conversion.
/// @note A nested vector of objects is defined using std::vector
template <typename T>
auto toExpr(const std::vector<T>& arg) {
  Vector<std::decay_t<decltype(toExpr(arg[0]))>> result;
  result.reserve(arg.size());
  for (const auto& item : arg) {
    result.push_back(toExpr(item));
  }
  return result;
}

/// @brief Retuns the vector of Expr objects created from the initializer
/// list.
/// @param list The initializer list of objects.
/// @return The vector of Expr objects created from the initializer list.
inline Vector<Expr> toExpr(const std::initializer_list<Expr>& list) {
  return Vector<Expr>(list);
}

template <typename T,
          typename std::enable_if<!std::is_same<T, Expr>::value, int>::type = 0>
auto toExpr(const std::initializer_list<T>& list) {
  Vector<std::decay_t<decltype(toExpr(std::declval<T>()))>> result;
  result.reserve(list.size());
  for (const auto& item : list) {
    result.push_back(toExpr(item));
  }
  return result;
}

/// @brief Returns the vector of vector of Expr objects created from the
/// nested initializer list.
/// @param list The nested initializer list of objects.
/// @return The vector of vector of Expr objects created from the nested
/// list.
inline Vector<Vector<Expr>> toExpr(
    const std::initializer_list<std::initializer_list<Expr>>& list) {
  Vector<Vector<Expr>> result;
  result.reserve(list.size());
  for (const auto& item : list) {
    result.push_back(toExpr(item));
  }
  return result;
}

/// @brief Returns a vector of vector of vector of Expr objects created from
/// the given initializer list.
/// @param list The nested initializer list of objects.
/// @return A vector of vector of vector of Expr objects created from the
/// nested initializer list.
inline Vector<Vector<Vector<Expr>>> toExpr(
    const std::initializer_list<
        std::initializer_list<std::initializer_list<Expr>>>& list) {
  Vector<Vector<Vector<Expr>>> result;
  result.reserve(list.size());
  for (const auto& item : list) {
    result.push_back(toExpr(item));
  }
  return result;
}

/// @brief Returns a vector of vector of vector of vector of Expr objects
/// created from the given initializer list.
/// @param list The nested initializer list of objects.
/// @return A vector of vector of vector of vector of Expr objects created
/// from the nested initializer list.
/// @note Up to four levels of nesting are supported. For more than four
/// levels, an extended version of this function is required. Unlimited
/// nesting is not supported since type deduction is not possible.
inline Vector<Vector<Vector<Vector<Expr>>>> toExpr(
    const std::initializer_list<std::initializer_list<
        std::initializer_list<std::initializer_list<Expr>>>>& list) {
  Vector<Vector<Vector<Vector<Expr>>>> result;
  result.reserve(list.size());
  for (const auto& item : list) {
    result.push_back(toExpr(item));
  }
  return result;
}

/// @brief Operator == overload for the Expr object and integer value.
/// @param expr The expression.
/// @param val The integer value.
/// @return The expression that takes the minimum value 0 if expr ==
/// val.
inline ExprExpr operator==(const Expr& expr, const energy_t& val) {
  return ExprExpr(sqr(expr - val), expr);
}

///@brief Create a constraint: minimum <= expr <= maximum.
///@param expr The expression to constrain.
///@param minimum The minimum value.
///@param maximum The maximum value.
///@return The expression that takes the minimum value 0 if minimum <= expr
///<=
/// maximum.
///@note log_2(maximum-minimum) unnamed slack variables may be created.
inline ExprExpr between(const Expr& expr, const energy_t& minimum,
                        const energy_t& maximum) {
  energy_t val = maximum - minimum;
  if (val < 0) {
    throw std::runtime_error(THROW_MESSAGE("RHS (", maximum,
                                           ") must be greater than LHS (",
                                           minimum, ") in operator <=."));
  } else if (val == 0) {
    return ExprExpr((expr - minimum) == 0, expr);
  } else if (val == 1) {
    return ExprExpr((expr - minimum) * (expr - maximum), expr);
  } else {
    VarInt slack_var =
        new_var_int("{" + std::to_string(new_unnamed_var_index()) + "}",
                    minimum, maximum - 1, 2);
    return ExprExpr((expr - slack_var) * (expr - (slack_var + 1)), expr);
  }
}

/// @brief Operator <= overload for integer value and Expr object.
/// @param min_val The minimum value.
/// @param expr The expression to compare.
/// @return The pair of min_val and expr.
template <typename T, typename = std::enable_if_t<is_integer_like_v<T>>>
std::pair<energy_t, Expr> operator<=(T min_val, const Expr& expr) {
  return std::make_pair(static_cast<energy_t>(min_val), expr);
}

/// @brief Operator overload for <= for the pair and integer value.
/// @param pair The pair of min_val and expr.
/// @param max_val The maximum value.
/// @return The expression that takes the minimum value 0 if min_val <= expr
/// <= max_val.
template <typename T, typename = std::enable_if_t<is_integer_like_v<T>>>
ExprExpr operator<=(const std::pair<energy_t, Expr>& pair, T max_val) {
  energy_t min_val = pair.first;
  const Expr& result = pair.second;
  return between(result, min_val, static_cast<energy_t>(max_val));
}

/// @brief Operator <= overload for the pair and Inf object.
inline ExprExpr operator<=(const std::pair<energy_t, Expr>& pair, Inf val) {
  energy_t min_val = pair.first;
  const Expr& result = pair.second;
  if (val.is_negative()) {
    throw std::runtime_error(
        THROW_MESSAGE("RHS of operator <= must not be -inf."));
  }
  return between(result, min_val, result.pos_sum());
}

/// @brief Operator <= overload for Inf object and Expr object.
inline std::pair<energy_t, Expr> operator<=(Inf val, const Expr& expr) {
  if (val.is_positive()) {
    throw std::runtime_error(
        THROW_MESSAGE("LHS of operator <= must not be inf."));
  }
  return std::make_pair(expr.neg_sum(), expr);
}

// --------------------------------------------------
// Simplification Global Functions
// --------------------------------------------------

inline bool is_pos_neg(Var a, Var b) {
  return (a.index() ^ b.index()) == qbpp::vindex_neg_bit;
}

/// @brief Sorts variables in place.
/// @param vars Input variables to be sorted.
/// @note Modifies the input `vars`.
inline void sort_vars_in_place(Vars& vars) {
#if defined(MAXDEG) && MAXDEG == 2
  if (vars[0] > vars[1]) {
    std::swap(vars[0], vars[1]);
    return;
  }
#else
  std::size_t size = vars.size();
  switch (size) {
    case 0:
    case 1:
      break;
    case 2:
      if (vars[0] > vars[1]) std::swap(vars[0], vars[1]);
      //      if (is_pos_neg(vars[0], vars[1])) {
      //        vars.clear();
      //      }
      break;
    case 3:
      if (vars[0] > vars[1]) std::swap(vars[0], vars[1]);
      if (vars[1] > vars[2]) std::swap(vars[1], vars[2]);
      if (vars[0] > vars[1]) std::swap(vars[0], vars[1]);
      break;
    case 4:
      if (vars[0] > vars[1]) std::swap(vars[0], vars[1]);
      if (vars[2] > vars[3]) std::swap(vars[2], vars[3]);
      if (vars[0] > vars[2]) std::swap(vars[0], vars[2]);
      if (vars[1] > vars[3]) std::swap(vars[1], vars[3]);
      if (vars[1] > vars[2]) std::swap(vars[1], vars[2]);
      break;
    default:
      for (size_t i = 1; i < size; ++i) {
        Var key = vars[i];
        size_t j = i;
        while (j > 0 && key < vars[j - 1]) {
          vars[j] = vars[j - 1];
          --j;
        }
        vars[j] = key;
      }
  }
#endif
}

inline void compare_swap_binary_vars(Var& a, Var& b) {
  if (a == b) {
    b = qbpp::impl::VarVoid;
  } else if (a > b) {
    std::swap(a, b);
  }
}

inline void compare_swap(Var& a, Var& b) {
  if (a > b) {
    std::swap(a, b);
  }
}

inline void unique_vars(size_t size, const Vars& src, Vars& dest) {
  auto prev = qbpp::impl::VarVoid;
  size_t j = 0;
  for (size_t i = 0; i < size; ++i) {
    if (src[i] != prev) {
      dest[j++] = src[i];
      prev = src[i];
    }
  }
  for (; j < size; ++j) {
    dest[j] = qbpp::impl::VarVoid;
  }
}

inline void erase_two_vars(size_t size, const Vars& src, Vars& dest) {
  auto prev = qbpp::impl::VarVoid;
  size_t j = 0;
  for (size_t i = 0; i < size; ++i) {
    if (src[i] != prev) {
      dest[j++] = src[i];
      prev = src[i];
    } else {
      if (j > 0) --j;
      prev = qbpp::impl::VarVoid;
    }
  }
  for (; j < size; ++j) {
    dest[j] = qbpp::impl::VarVoid;
  }
}

inline void sort_binary_vars_in_place(Vars& vars) {
#if defined(MAXDEG) && MAXDEG == 2
  compare_swap_binary_vars(vars[0], vars[1]);
#else
  size_t size = vars.size();
  if (size == 0 || size == 1) {
    return;
  }
  if (size == 2) {
    compare_swap_binary_vars(vars[0], vars[1]);
    return;
  }
  if (size == 3) {
    compare_swap_binary_vars(vars[0], vars[1]);
    compare_swap_binary_vars(vars[1], vars[2]);
    compare_swap_binary_vars(vars[0], vars[1]);
    compare_swap_binary_vars(vars[1], vars[2]);
    return;
  }
  Vars temp = vars;
  if (size == 4) {
    compare_swap(temp[0], temp[1]);
    compare_swap(temp[2], temp[3]);
    compare_swap(temp[0], temp[2]);
    compare_swap(temp[1], temp[3]);
    compare_swap(temp[1], temp[2]);
    unique_vars(size, temp, vars);
    return;
  }
  for (size_t i = 1; i < size; ++i) {
    for (size_t j = i; j > 0; --j) {
      compare_swap(temp[j - 1], temp[j]);
    }
  }
  unique_vars(size, temp, vars);
#endif
}

inline void sort_spin_vars_in_place(Vars& vars) {
  Vars temp = vars;
  size_t size = vars.size();
  for (size_t i = 1; i < size; ++i) {
    for (size_t j = i; j > 0; --j) {
      compare_swap(temp[j - 1], temp[j]);
    }
  }
  erase_two_vars(size, temp, vars);
}

/// @brief Returns a sorted copy of variables.
/// @param vars Input variables to be sorted.
/// @return Sorted copy of `vars`.
/// @note Does not modify the input `vars`.
inline Vars sort_vars(const Vars& vars) {
  auto result = vars;
  sort_vars_in_place(result);
  return result;
}

/// @brief Sorts variables treating them as binary variables.
/// @param vars Variables to be sorted as binary.
/// @return Sorted variables treated as binary.
/// @note Does not modify the input `vars`.
inline Vars sort_vars_as_binary(const Vars& vars) {
#if defined(MAXDEG) && MAXDEG == 2
  if (vars[0] != qbpp::impl::VarVoid) {
    if (vars[1] != qbpp::impl::VarVoid) {
      if (vars[0] == vars[1]) {
        return Vars(vars[0]);
      }
      // Check x * ~x = 0
      if ((vars[0].index() ^ vars[1].index()) == vindex_neg_bit) {
        return Vars(impl::VarArray<MAXDEG>::EMPTY{});
      }
      if (vars[0] < vars[1]) {
        return vars;
      } else {
        return Vars(vars[1], vars[0]);
      }
    }
  }
  return vars;
#elif defined(MAXDEG) && MAXDEG > 0
  Vars result = vars;
  sort_binary_vars_in_place(result);
  // Check for x * ~x conflict in sorted result (adjacent pairs)
  for (std::size_t i = 0; i + 1 < result.size(); ++i) {
    if ((result[i].index() ^ result[i + 1].index()) == vindex_neg_bit) {
      result.clear();
      return result;
    }
  }
  return result;
#else
  Vars result = vars;
  sort_vars_in_place(result);
  if (result.size() >= 2) {
    // Check for x * ~x conflict before dedup
    for (std::size_t i = 0; i + 1 < result.size(); ++i) {
      if ((result[i].index() ^ result[i + 1].index()) == vindex_neg_bit) {
        result.clear();
        return result;
      }
    }
    result.erase(std::unique(result.begin(), result.end()), result.end());
  }
  return result;
#endif
}

/// @brief Sorts variables treating them as spin variables.
/// @param vars Variables to be sorted as spin.
/// @return Sorted variables treated as spin.
/// @note Does not modify the input `vars`.
inline Vars sort_vars_as_spin(const Vars& vars) {
#if defined(MAXDEG) && MAXDEG == 2
  if (vars[0] != qbpp::impl::VarVoid) {
    if (vars[1] != qbpp::impl::VarVoid) {
      if (vars[0] < vars[1]) {
        return vars;
      } else if (vars[0] == vars[1]) {
        return Vars(qbpp::impl::VarArray<MAXDEG>::EMPTY{});
      } else {
        return Vars(vars[1], vars[0]);
      }
    }
  }
  return vars;
#elif defined(MAXDEG) && MAXDEG > 0
  auto result = vars;
  sort_binary_vars_in_place(result);
  return result;
#else
  auto result = vars;
  sort_vars_in_place(result);
  if (result.size() >= 2) {
    for (auto it = result.begin();
         it != result.end() && it + 1 != result.end();) {
      if (*it == *(it + 1)) {
        it = result.erase(it, it + 2);
      } else {
        ++it;
      }
    }
  }
  return result;
#endif
}

/// @brief Simplifies Expr objects using the specified sorting function by
/// sequentially processing terms.
inline Expr simplify_seq(const Expr& expr,
                         Vars (*sort_vars_func)(const Vars&) = sort_vars) {
  VarsCoeffMap vars_val_map;
  Expr result = expr.constant();
  for (const auto& term : expr.terms()) {
    auto new_vars = (*sort_vars_func)(term.vars());
    if (new_vars.size() != 0) {
      vars_val_map[new_vars] += term.coeff();
    } else {  // 変数の数が0の場合は0とする．
      result += term.coeff();
    }
  }
  for (const auto& [vars, val] : vars_val_map) {
    if (val != 0) {
      result += Term{vars, val};
    }
  }
  std::sort(result.terms().begin(), result.terms().end());
  return result;
}

/// @brief Simplifies Expr objects using the specified sorting function.
/// @param expr The Expr object to be simplified.
/// @param sort_vars_func Function to sort variables, defaults to
/// `sort_vars`.
/// @return The simplified Expr object.
inline Expr simplify(const Expr& expr,
                     Vars (*sort_vars_func)(const Vars&) = sort_vars) {
  if (expr.size() < SEQ_THRESHOLD) return simplify_seq(expr, sort_vars_func);

  Terms simplified_terms;
  simplified_terms.resize(expr.terms().size());

  // Simplify every term in parallel
  tbb::parallel_for(size_t(0), expr.terms().size(), [&](size_t i) {
    simplified_terms[i] =
        Term(sort_vars_func(expr.terms()[i].vars()), expr.terms()[i].coeff());
  });

  // Sort all simplified terms
  tbb::parallel_sort(simplified_terms.begin(), simplified_terms.end());

  const size_t size = simplified_terms.size();
  constexpr size_t min_chunk_size = 32;
  size_t max_chunk_count = std::thread::hardware_concurrency();
  // chunk_count and chunk_size are calculated to maximize chunk_count,
  // subject to the following constraints:
  // 1. chunk_size >= 1
  // 2. chunk_size * chunk_count >= size
  // 3. chunk_count <= max_chunk_count
  size_t chunk_count =
      std::min((size + min_chunk_size - 1) / min_chunk_size, max_chunk_count);
  size_t chunk_size = (size + chunk_count - 1) / chunk_count;

  std::vector<Terms> chunk(chunk_count);
  std::vector<energy_t> constant(chunk_count, 0);
  std::vector<size_t> indices(chunk_count);

  tbb::parallel_for(
      tbb::blocked_range<size_t>(0, chunk_count),
      [&](const tbb::blocked_range<size_t>& range) {
        for (size_t i = range.begin(); i < range.end(); ++i) {
          size_t start = i * chunk_size;
          size_t end = std::min(start + chunk_size, size);

          for (size_t j = start; j < end; ++j) {
            if (simplified_terms[j].coeff() == 0) {
              continue;
            }
            if (simplified_terms[j].var_count() == 0) {
              constant[i] += simplified_terms[j].coeff();
              continue;
            }
            if (chunk[i].empty()) {
              chunk[i].push_back(std::move(simplified_terms[j]));
              continue;
            }
            if (chunk[i].back().vars() == simplified_terms[j].vars()) {
              chunk[i].back().coeff() += simplified_terms[j].coeff();
              if (chunk[i].back().coeff() == 0) {
                chunk[i].pop_back();
              }
              continue;
            }
            chunk[i].emplace_back(std::move(simplified_terms[j]));
          }
        }
      });

  // Merge duplicated terms in adjacent chunks (sequential as it involves
  // dependency). Since O(chunk_count) is small, it is acceptable.
  for (size_t i = 1; i < chunk_count; ++i) {
    if (!chunk[i - 1].empty()) {
      if (chunk[i].empty()) {
        chunk[i].push_back(std::move(chunk[i - 1].back()));
        chunk[i - 1].pop_back();
        continue;
      }
      if (chunk[i - 1].back().vars() == chunk[i].front().vars()) {
        chunk[i].front().coeff() += chunk[i - 1].back().coeff();
        chunk[i - 1].pop_back();
        if (chunk[i].front().coeff() == 0) {
          chunk[i].erase(chunk[i].begin());
        }
      }
    }
  }

  // Compute prefix sum and result constant
  std::vector<size_t> prefix(chunk_count + 1, 0);
  energy_t result_constant = expr.constant();
  for (size_t i = 0; i < chunk_count; ++i) {
    prefix[i + 1] = prefix[i] + chunk[i].size();
    result_constant += constant[i];
  }

  // Write the result
  Terms result_terms;
  result_terms.resize(prefix.back());
  tbb::parallel_for(size_t(0), size_t(chunk_count), [&](size_t i) {
    std::copy(chunk[i].begin(), chunk[i].end(),
              result_terms.begin() + static_cast<std::ptrdiff_t>(prefix[i]));
  });

  return Expr(result_constant, std::move(result_terms));
}

/// @brief Simplifies a nested vector of Expr objects.
/// @param vec The nested vector of Expr objects to be simplified.
/// @param sort_vars_func Function to sort variables, defaults to
/// `sort_vars`.
/// @return The simplified nested vector of Expr objects.
template <typename T>
Vector<T> simplify(const Vector<T>& vec,
                   Vars (*sort_vars_func)(const Vars&) = sort_vars) {
  Vector<T> result(vec.size());
  tbb::parallel_for(size_t(0), vec.size(), [&](size_t i) {
    result[i] = simplify(vec[i], sort_vars_func);
  });
  return result;
}

/// @brief Simplifies an expression assuming variables are binary.
/// @param expr The Expr object to be simplified.
/// @return The simplified Expr object.
/// @details
/// 1. Sorts each term's variables via sort_vars_as_binary (which detects
///    x * ~x = 0 and returns empty Vars, effectively setting coefficient to 0).
/// 2. Merges duplicate terms.
/// 3. Expands linear negated terms: c*~x → c (constant) + (-c)*x.
inline Expr simplify_as_binary(const Expr& expr) {
  // Sort each term and merge duplicates (x*~x returns empty → coeff dropped)
  VarsCoeffMap vars_val_map;
  energy_t new_constant = expr.constant();
#if !defined(MAXDEG) && !defined(BASEDEG)
  vindex_t max_deg = 0;
#endif

  for (const auto& term : expr.terms()) {
#if !defined(MAXDEG) && !defined(BASEDEG)
    // Track pre-simplification degree: this is the size that VarArray<N>
    // must accommodate during expression building (before simplification).
    auto vc = term.var_count();
    if (vc > max_deg) max_deg = vc;
#endif
    auto new_vars = sort_vars_as_binary(term.vars());
    if (new_vars.size() == 0) {
      // x*~x conflict returns empty Vars → coefficient is 0 (dropped).
      // Original constant terms (var_count == 0) also have empty Vars.
      if (term.var_count() == 0) {
        new_constant += term.coeff();
      }
      continue;
    }
    vars_val_map[new_vars] += term.coeff();
  }

  // Build terms from merged map, expanding ~x in linear and quadratic terms
  std::map<vindex_t, coeff_t> linear_map;
  Terms higher_terms;

  // Expand quadratic negated literals: c*~xi*xj → c*xj - c*xi*xj etc.
  // Collect generated non-negated quadratic terms separately to avoid
  // modifying vars_val_map during iteration.
  VarsCoeffMap quad_expanded;
  for (auto& [vars, coeff] : vars_val_map) {
    if (coeff == 0) continue;
    if (vars.size() != 2) continue;
    vindex_t i0 = vars[0].index();
    vindex_t i1 = vars[1].index();
    bool neg0 = (i0 & vindex_neg_bit) != 0;
    bool neg1 = (i1 & vindex_neg_bit) != 0;
    if (!neg0 && !neg1) continue;  // no negation → keep as-is
    vindex_t b0 = i0 & vindex_mask;
    vindex_t b1 = i1 & vindex_mask;
    // c * lit0 * lit1 where lit = (1-x) if negated, x otherwise
    // Expand all negated literals:
    //   neg0 && neg1: c*(1-x0)*(1-x1) = c - c*x0 - c*x1 + c*x0*x1
    //   neg0 only:    c*(1-x0)*x1     =     c*x1 - c*x0*x1
    //   neg1 only:    c*x0*(1-x1)     = c*x0     - c*x0*x1
    if (neg0 && neg1) {
      new_constant += coeff;
      linear_map[b0] -= coeff;
      linear_map[b1] -= coeff;
      // +c*x0*x1
      Vars qvars({Var(b0), Var(b1)});
      quad_expanded[qvars] += coeff;
    } else if (neg0) {
      linear_map[b1] += coeff;
      // -c*x0*x1
      Vars qvars({Var(b0), Var(b1)});
      quad_expanded[qvars] -= coeff;
    } else {
      // neg1 only
      linear_map[b0] += coeff;
      // -c*x0*x1
      Vars qvars({Var(b0), Var(b1)});
      quad_expanded[qvars] -= coeff;
    }
    // Mark original entry as consumed
    coeff = 0;
  }

  // Merge expanded quadratic terms back
  for (auto& [vars, coeff] : quad_expanded) {
    if (coeff != 0) {
      vars_val_map[vars] += coeff;
    }
  }

  for (auto& [vars, coeff] : vars_val_map) {
    if (coeff == 0) continue;
    if (vars.size() == 1) {
      vindex_t idx = vars[0].index();
      if (idx & vindex_neg_bit) {
        // c*~x → c (constant) + (-c)*x
        new_constant += coeff;
        linear_map[idx & vindex_mask] -= coeff;
      } else {
        linear_map[idx] += coeff;
      }
    } else {
      higher_terms.emplace_back(Term(vars, coeff));
    }
  }

  // Build final terms
  Terms new_terms;
  new_terms.reserve(linear_map.size() + higher_terms.size());
  for (const auto& [idx, coeff] : linear_map) {
    if (coeff != 0) {
      new_terms.emplace_back(Term(Var(idx), coeff));
    }
  }
  for (auto& t : higher_terms) {
    new_terms.push_back(std::move(t));
  }
  std::sort(new_terms.begin(), new_terms.end());

#if !defined(MAXDEG) && !defined(BASEDEG)
  // Track max degree across all simplify_as_binary() calls.
  auto& advisor = impl::maxdeg_advisor();
  advisor.active = true;
  if (max_deg > advisor.max_deg) {
    advisor.max_deg = max_deg;
  }
#endif

  return Expr(new_constant, std::move(new_terms));
}

/// @brief Simplifies a vector of expressions assuming variables are binary.
/// @param arg The vector of Expr objects to be simplified.
/// @return The simplified vector of Expr objects.
//  @note This fuction accepts nested vectors of Expr objects.
template <typename T>
auto simplify_as_binary(const Vector<T>& arg) {
  return simplify(arg, sort_vars_as_binary);
}

/// @brief Simplifies an expression assuming variables are spin.
/// @param expr The Expr object to be simplified.
/// @return The simplified Expr object.
inline Expr simplify_as_spin(const Expr& expr) {
  return simplify(expr, sort_vars_as_spin);
}

/// @brief Simplifies a vector of expressions assuming variables are spin.
/// @param arg The vector of Expr objects to be simplified.
/// @return The simplified vector of Expr objects.
///  @note This fuction accepts nested vectors of Expr objects.
template <typename T>
auto simplify_as_spin(const Vector<T>& arg) {
  return simplify(arg, sort_vars_as_spin);
}

/// @brief Checks whether this simplified Expr object is binary
/// @param expr The Expr object to be checked.
/// @return true if the object satisfies the binary conditions.
inline bool is_binary(const Expr& expr) {
  for (const auto& term : expr.terms()) {
    if (term.var_count() > 2) {
      return false;
    }
    if (term.var_count() == 2 && term.vars()[0] == term.vars()[1]) {
      return false;
    }
  }
  return true;
}

// --------------------------------------------------
// Class Sol Member Functions
// --------------------------------------------------

inline MapList Sol::map_list() const {
  MapList result;
  //  for (Var var : iv_mapper_.index_var()) {
  //    result.push_back({var, static_cast<var_val_t>(get(var))});
  //  }
  for (vindex_t i = 0; i < iv_mapper_.var_count(); ++i) {
    result.push_back({var(i), static_cast<var_val_t>(get(i))});
  }

  return result;
}

inline Sol& Sol::set(const Sol& sol, const MapList& map_list) {
  set(sol);
  for (const auto& [key, expr] : map_list) {
    auto val = sol(expr);
    std::visit(
        [&](auto&& arg) {
          using T = std::decay_t<decltype(arg)>;
          if constexpr (std::is_same_v<T, VarInt>) {
            for (const auto& [var, bin_val] :
                 arg.val_map(static_cast<coeff_t>(val))) {
              if (sol.has(var) && sol.get(var) != bin_val) {
                throw std::runtime_error(
                    THROW_MESSAGE("Conflicting values for " + var.str()));
              }
              set(var, bin_val);
            }
          } else {
            if (sol.has(arg) && sol.get(arg) != val) {
              throw std::runtime_error(
                  THROW_MESSAGE("Conflicting values for " + arg.str()));
            }
            set(arg, static_cast<var_val_t>(val));
          }
        },
        key);
  }
  if (!energy_) energy_ = comp_energy();
  return *this;
}

// --------------------------------------------------
// Reduction Global Functions
// --------------------------------------------------

/// @brief Reduces the degree of the Term object to at most degree 2 using
/// the sum of variables.
/// @param term The Term object to be reduced.
/// @return The reduced Term object.
/// @f$x_0x_1\cdots x_{n-1}@f$ equals @f$+1@f$ if the sum is @f$n@f$, and 0
/// if the sum is less than @f$n@f$.
/// @note This function is only for internal use to implement reduce().
inline Expr reduce_sum(const Term& term) {
  coeff_t num_var = static_cast<coeff_t>(term.var_count());
  if (num_var <= 2) {  // term is quadratic or linear
    return Expr{term};
  }
  Expr sum_vars =
      std::accumulate(term.vars().begin(), term.vars().end(), Expr(0));
  if (term.coeff() < 0) {  // Negative term
    return term.coeff() * qbpp::var() * (sum_vars - (num_var - 1));
  }
  // Positive term
  VarInt aux_var = new_var_int(
      "{" + std::to_string(new_unnamed_var_index()) + "}", 0, num_var - 2, 2);
  Expr result =
      term.coeff() * (sum_vars - aux_var) * (sum_vars - (aux_var + 1));
  return simplify_as_binary(result) / 2;
}

/// @brief Reduces the degree of the Term object to at most degree 2 using
/// the cascade of logic AND operations.
/// @param term The Term object to be reduced.
/// @return The reduced Term object.
/// @note This function is only for internal use to implement reduce().
inline Expr reduce_cascade(const Term& term) {
  coeff_t var_count = static_cast<coeff_t>(term.var_count());
  if (var_count <= 2) {  // term is quadratic or linear
    return Expr{term};
  }
  Term temp = term;
  auto aux_var = qbpp::var();
  auto tail1 = temp.vars().back();
  temp.vars().pop_back();
  auto tail0 = temp.vars().back();
  temp.vars().pop_back();
  temp.vars().push_back(aux_var);
  return reduce_cascade(temp) +
         abs(term.coeff()) *
             (tail0 * tail1 - 2 * (tail0 + tail1) * aux_var + 3 * aux_var);
}

/// @brief Reduces the degree of the Expr object to at most degree 2.
/// @param expr The Expr object to be reduced.
/// @return The reduced Expr object.
inline Expr reduce(const Expr& expr) {
  Expr result = expr.constant();
  for (const auto& term : expr.terms()) {
    if (term.coeff() < 0 || term.var_count() <= 4) {
      result += reduce_sum(term);
    } else
      result += reduce_cascade(term);
  }
  return result;
}

// --------------------------------------------------
// HUBO/Ising Expression Conversion Functions
// --------------------------------------------------

/// @brief Convert HUBO to Ising.
/// @param expr The Expr object representing a HUBO model.
/// @return The Expr object representing the equivalent Ising model.
/// @note The resulting Expr object will have values 4 times larger than the
/// original due to the conversion between and@f$-1/+1@f$ to @f$0/1@f$

inline vindex_t max_degree(const Expr& expr) {
  vindex_t max_degree = 0;
  for (const auto& term : expr.terms()) {
    if (term.var_count() > max_degree) {
      max_degree = term.var_count();
    }
  }
  return max_degree;
}

inline Expr binary_to_spin(const Expr& expr) {
  vindex_t max_deg = max_degree(expr);
  coeff_t factor = 1 << max_deg;
  Expr result = expr.constant() * factor;
  for (const auto& term : expr.terms()) {
    const auto& vars = term.vars();
    Expr binary_expr = factor;
    for (const auto& v : vars) {
      binary_expr *= (v + 1);
      binary_expr /= 2;
    }
    result += term.coeff() * binary_expr;
  }

  return result.simplify_as_spin();
}

/// @brief Converts a HUBO model to an Ising model.
/// @param expr The Expr object representing a HUBO model.
/// @return The Expr object representing the equivalent Ising model.
/// @note The resulting Expr object will have the same value due to the
/// conversion from @f$0/1@f$ to @f$-1/+1@f$.
inline Expr spin_to_binary(const Expr& expr) {
  Expr result = expr.constant();
  for (const auto& term : expr.terms()) {
    const auto& vars = term.vars();
    Expr spin_expr = 1;
    for (const auto& v : vars) {
      spin_expr *= (2 * v - 1);
    }
    result += term.coeff() * spin_expr;
  }
  return result.simplify_as_binary();
}

// --------------------------------------------------
// Vector Operator Overloads
// --------------------------------------------------

/// @brief  Operator + for two vectors (preserves element type when possible).
template <typename T, typename U>
auto operator+(const Vector<T>& lhs, const Vector<U>& rhs) {
  using ResultType = std::decay_t<decltype(lhs[0] + rhs[0])>;
  Vector<ResultType> result;
  result.reserve(lhs.size());
  for (size_t i = 0; i < lhs.size(); ++i) {
    result.push_back(lhs[i] + rhs[i]);
  }
  return result;
}

/// @brief  Operator + for two nested vectors
template <typename T, typename U>
auto operator+(const Vector<Vector<T>>& lhs, const Vector<Vector<U>>& rhs) {
  using ResultType = std::decay_t<decltype(lhs[0] + rhs[0])>;
  Vector<ResultType> result = lhs;
  result += rhs;
  return result;
}

/// @brief Operator + for Vector and scalar (preserves element type when
/// possible).
template <typename T, typename U>
auto operator+(const Vector<T>& lhs, const U& rhs) {
  using ResultType = std::decay_t<decltype(lhs[0] + rhs)>;
  Vector<ResultType> result;
  result.reserve(lhs.size());
  for (const auto& elem : lhs) {
    result.push_back(elem + rhs);
  }
  return result;
}

/// @brief Operator + for scalar and Vector (preserves element type when
/// possible).
template <typename T, typename U>
auto operator+(const U& lhs, const Vector<T>& rhs) {
  return rhs + lhs;
}

/// @brief Operator + for Scalar and Vector in copy semantics.
template <typename T>
auto operator+(const Expr& lhs, Vector<T>&& rhs) {
  rhs += lhs;
  return std::move(rhs);
}

/// @brief Operator + for Vector and std::vector.
template <typename T, typename U>
auto operator+(const Vector<T>& lhs, const std::vector<U>& rhs) {
  return lhs + to_vector_type_t<std::vector<U>>(rhs);
}

/// @brief Operator + for std::vector and Vector.
template <typename T, typename U>
auto operator+(const std::vector<T>& lhs, const Vector<U>& rhs) {
  return to_vector_type_t<std::vector<T>>(lhs) + rhs;
}

/// @brief  Operator * for two vectors
/// @brief Operator * for two vectors (preserves element type when possible).
template <typename T, typename U>
auto operator*(const Vector<T>& lhs, const Vector<U>& rhs) {
  using ResultType = std::decay_t<decltype(lhs[0] * rhs[0])>;
  Vector<ResultType> result;
  result.reserve(lhs.size());
  for (size_t i = 0; i < lhs.size(); ++i) {
    result.push_back(lhs[i] * rhs[i]);
  }
  return result;
}

/// @brief  Operator * for two nested vectors
template <typename T, typename U>
auto operator*(const Vector<Vector<T>>& lhs, const Vector<Vector<U>>& rhs) {
  using ResultType = std::decay_t<decltype(lhs[0] * rhs[0])>;
  Vector<ResultType> result = lhs;
  result *= rhs;
  return result;
}

/// @brief Operator * for Vector and scalar (preserves element type when
/// possible).
template <typename T, typename U>
auto operator*(const Vector<T>& lhs, const U& rhs) {
  using ResultType = std::decay_t<decltype(lhs[0] * rhs)>;
  Vector<ResultType> result;
  result.reserve(lhs.size());
  for (const auto& elem : lhs) {
    result.push_back(elem * rhs);
  }
  return result;
}

/// @brief Operator * for scalar and Vector (preserves element type when
/// possible).
template <typename T, typename U>
auto operator*(const U& lhs, const Vector<T>& rhs) {
  return rhs * lhs;
}

/// @brief Operator * for Vector and std::vector.
template <typename T, typename U>
auto operator*(const Vector<T>& lhs, const std::vector<U>& rhs) {
  return lhs * to_vector_type_t<std::vector<U>>(rhs);
}

/// @brief Operator * for std::vector and Vector.
template <typename T, typename U>
auto operator*(const std::vector<T>& lhs, const Vector<U>& rhs) {
  return to_vector_type_t<std::vector<T>>(lhs) * rhs;
}

/// @brief  Operator - for two vectors (preserves element type when possible).
template <typename T, typename U>
auto operator-(const Vector<T>& lhs, const Vector<U>& rhs) {
  using ResultType = std::decay_t<decltype(lhs[0] - rhs[0])>;
  Vector<ResultType> result;
  result.reserve(lhs.size());
  for (size_t i = 0; i < lhs.size(); ++i) {
    result.push_back(lhs[i] - rhs[i]);
  }
  return result;
}

/// @brief  Operator - for two nested vectors
template <typename T, typename U>
auto operator-(const Vector<Vector<T>>& lhs, const Vector<Vector<U>>& rhs) {
  using ResultType = std::decay_t<decltype(lhs[0] - rhs[0])>;
  Vector<ResultType> result = lhs;
  result -= rhs;
  return result;
}

/// @brief Operator - for Vector and scalar (preserves element type when
/// possible).
template <typename T, typename U>
auto operator-(const Vector<T>& lhs, const U& rhs) {
  using ResultType = std::decay_t<decltype(lhs[0] - rhs)>;
  Vector<ResultType> result;
  result.reserve(lhs.size());
  for (const auto& elem : lhs) {
    result.push_back(elem - rhs);
  }
  return result;
}

/// @brief Operator - for scalar and Vector (preserves element type when
/// possible).
template <typename T, typename U>
auto operator-(const U& lhs, const Vector<T>& rhs) {
  using ResultType = std::decay_t<decltype(lhs - rhs[0])>;
  Vector<ResultType> result;
  result.reserve(rhs.size());
  for (const auto& elem : rhs) {
    result.push_back(lhs - elem);
  }
  return result;
}

/// @brief Operator - for Vector and std::vector.
template <typename T, typename U>
auto operator-(const Vector<T>& lhs, const std::vector<U>& rhs) {
  return lhs - to_vector_type_t<std::vector<U>>(rhs);
}

/// @brief Operator - for std::vector and Vector.
template <typename T, typename U>
auto operator-(const std::vector<T>& lhs, const Vector<U>& rhs) {
  return to_vector_type_t<std::vector<T>>(lhs) - rhs;
}

template <typename T, class U,
          typename std::enable_if<std::is_convertible<U, coeff_t>::value,
                                  int>::type = 0>
auto operator/(const Vector<T>& lhs, U rhs) {
  Vector<std::decay_t<decltype(lhs[0] / rhs)>> result = lhs;
  result /= rhs;
  return result;
}

/// @brief  Unary +
template <typename T>
auto operator+(const Vector<T>& lhs) {
  return qbpp::toExpr(lhs);
}

/// @brief Unary -
template <typename T>
auto operator-(const Vector<T>& lhs) {
  return lhs * (-1);
}

template <typename T, typename U,
          typename = std::enable_if_t<is_integer_like_v<U>>>
auto operator==(const Vector<T>& lhs, U rhs) {
  Vector<std::decay_t<decltype(lhs[0] == rhs)>> result = qbpp::sqr(lhs - rhs);
  return result;
}

/// @brief Vector == Vector element-wise comparison.
/// @param lhs The left-hand side Vector.
/// @param rhs The right-hand side Vector.
/// @return A Vector where each element is the result of lhs[i] == rhs[i].
/// @note This overload is enabled when element comparison returns non-bool
/// (e.g., Expr). Works with multi-dimensional Vectors recursively.
template <
    typename T, typename U,
    typename R = std::decay_t<decltype(std::declval<T>() == std::declval<U>())>,
    typename = std::enable_if_t<!std::is_same_v<R, bool>>>
auto operator==(const Vector<T>& lhs, const Vector<U>& rhs) {
  if (lhs.size() != rhs.size()) {
    throw std::runtime_error(
        THROW_MESSAGE("Vector sizes must match for element-wise comparison"));
  }
  Vector<R> result;
  result.reserve(lhs.size());
  for (size_t i = 0; i < lhs.size(); ++i) {
    result.push_back(lhs[i] == rhs[i]);
  }
  return result;
}

/// @brief Integer <= Vector
/// @note This function is used to double inequalities for two integers
template <typename T, typename U,
          typename = std::enable_if_t<is_integer_like_v<U>>>
auto operator<=(U lhs, const Vector<T>& rhs) {
  return std::make_pair(static_cast<energy_t>(lhs), rhs);
}

template <typename T>
auto operator<=(Inf lhs, const Vector<T>& rhs) {
  return std::make_pair(lhs, rhs);
}

/// @brief  Pair<Integer,Vector> <= Integer
/// @note This function is used to double inequalities for two integers
template <typename T, typename U,
          typename = std::enable_if_t<is_integer_like_v<U>>>
auto operator<=(const std::pair<energy_t, Vector<T>>& lhs, U rhs) {
  Vector<ExprExpr> result;
  result.resize(lhs.second.size());
  tbb::parallel_for(size_t(0), lhs.second.size(), [&](size_t i) {
    result[i] = (lhs.first <= lhs.second[i] <= rhs);
  });
  return result;
}

template <typename T>
auto operator<=(const std::pair<energy_t, Vector<T>>& lhs, Inf rhs) {
  Vector<ExprExpr> result;
  result.resize(lhs.second.size());
  tbb::parallel_for(size_t(0), lhs.second.size(), [&](size_t i) {
    result[i] = (lhs.first <= lhs.second[i] <= rhs);
  });
  return result;
}

template <typename T, typename U,
          typename = std::enable_if_t<is_integer_like_v<U>>>
auto operator<=(const std::pair<Inf, Vector<T>>& lhs, U rhs) {
  Vector<ExprExpr> result;
  result.resize(lhs.second.size());
  tbb::parallel_for(size_t(0), lhs.second.size(), [&](size_t i) {
    result[i] = (lhs.first <= lhs.second[i] <= rhs);
  });
  return result;
}

/// @brief  Integer <= Array
/// @note This function is used to double inequalities for two integers
template <typename T, typename U,
          typename = std::enable_if_t<is_integer_like_v<U>>>
auto operator<=(U lhs, const Vector<Vector<T>>& rhs) {
  return std::make_pair(static_cast<energy_t>(lhs), rhs);
}

/// @brief  Pair<Integer,Array> <= Integer
/// @note This function is used to double inequalities for two integers
template <typename T, typename U,
          typename = std::enable_if_t<is_integer_like_v<U>>>
auto operator<=(const std::pair<energy_t, Vector<Vector<T>>>& lhs, U rhs) {
  Vector<std::decay_t<decltype(lhs.first <= lhs.second[0] <= rhs)>> result;
  result.resize(lhs.second.size());
  tbb::parallel_for(size_t(0), lhs.second.size(), [&](size_t i) {
    result[i] = (lhs.first <= lhs.second[i] <= rhs);
  });
  return result;
}

template <typename T>
auto operator<=(const std::pair<energy_t, Vector<Vector<T>>>& lhs, Inf rhs) {
  Vector<Vector<T>> result;
  result.resize(lhs.second.size());
  tbb::parallel_for(size_t(0), lhs.second.size(), [&](size_t i) {
    result[i] = (lhs.first <= lhs.second[i] <= rhs);
  });
  return result;
}

template <typename T, typename U,
          typename = std::enable_if_t<is_integer_like_v<U>>>
auto operator<=(const std::pair<Inf, Vector<Vector<T>>>& lhs, U rhs) {
  Vector<std::decay_t<decltype(lhs.second[0] <= rhs)>> result;
  result.resize(lhs.second.size());
  tbb::parallel_for(size_t(0), lhs.second.size(), [&](size_t i) {
    result[i] = (lhs.first <= lhs.second[i] <= rhs);
  });
  return result;
}

/// @brief Meta function to get the number of dimensions of a type.
/// @note Returns 0 for scalar types, 1 for Vector<T>, 2 for Vector<Vector<T>>,
/// etc.
template <typename T>
struct dim_of {
  static constexpr int value = 0;
};

template <typename T>
struct dim_of<Vector<T>> {
  static constexpr int value = 1 + dim_of<T>::value;
};

template <typename T>
inline constexpr int dim_of_v = dim_of<T>::value;

/// @brief Normalizes axis value (handles negative indices like Python/NumPy).
/// @param axis The axis value (can be negative).
/// @param ndim The number of dimensions.
/// @return The normalized axis value (0 <= result < ndim).
/// @throws std::out_of_range if axis is out of range.
inline int normalize_axis(int axis, int ndim) {
  if (axis < 0) axis += ndim;
  if (axis < 0 || axis >= ndim) {
    throw std::out_of_range(THROW_MESSAGE("axis ", axis,
                                          " is out of range for array with ",
                                          ndim, " dimensions"));
  }
  return axis;
}

/// @brief Returns the sum of a 1-d Vector of integer-like values.
template <typename T,
          typename std::enable_if<is_integer_like_v<T>, int>::type = 0>
T sum(const Vector<T>& items) {
  T result = 0;
  for (const auto& item : items) {
    result += item;
  }
  return result;
}

/// @brief Returns the sum of a multi-dimensional Vector of integer-like values.
template <typename T,
          typename std::enable_if<is_integer_like_v<std::decay_t<decltype(sum(
                                      std::declval<Vector<T>>()))>>,
                                  int>::type = 0>
auto sum(const Vector<Vector<T>>& items) -> decltype(sum(items[0])) {
  decltype(sum(items[0])) result = 0;
  for (const auto& item : items) {
    result += sum(item);
  }
  return result;
}

template <typename T>
Expr sum(const T& arg) {
  return toExpr(arg);
}

inline Expr sum(const Vector<Var>& vars) {
  Expr result;
  if (vars.size() < SEQ_THRESHOLD) {
    for (const auto& var : vars) {
      result += var;
    }
  } else {
    auto& terms = result.terms();
    terms.resize(vars.size());
    tbb::parallel_for(size_t(0), vars.size(),
                      [&](size_t i) { terms[i] = Term(vars[i]); });
  }
  return result;
}

/// @brief Returns the sum of a 1-d Vector of Expr objects.
inline Expr sum(const Vector<Expr>& expr) {
  Expr result;
  size_t n = expr.size();
  std::vector<size_t> indices(n + 1, 0);

  for (size_t i = 0; i < n; ++i) {
    indices[i + 1] = indices[i] + expr[i].term_count();
    result.constant() += expr[i].constant();
  }

  size_t total_terms = indices.back();
  result.terms().resize(total_terms);

  tbb::parallel_for(size_t(0), n, [&](size_t i) {
    auto& dst = result.terms();
    auto& src = expr[i].terms();
    std::copy(src.begin(), src.end(),
              dst.begin() + static_cast<std::ptrdiff_t>(indices[i]));
  });

  return result;
}

/// @brief Returns the sum of a Vector of T objects (parallelized).
template <typename T, typename std::enable_if<!is_integer_like_v<T>, int>::type>
Expr sum(const Vector<T>& items) {
  std::vector<Expr> result;
  result.resize(items.size());
  tbb::parallel_for(size_t(0), items.size(),
                    [&](size_t i) { result[i] = sum(items[i]); });
  std::vector<size_t> indices(result.size() + 1);
  energy_t constant = 0;
  for (size_t i = 0; i < result.size(); ++i) {
    indices[i + 1] = indices[i] + result[i].term_count();
    constant += result[i].constant();
  }
  Terms terms;
  terms.resize(indices.back());
  tbb::parallel_for(size_t(0), result.size(), [&](size_t i) {
    std::copy(result[i].terms().begin(), result[i].terms().end(),
              terms.begin() + static_cast<std::ptrdiff_t>(indices[i]));
  });
  return Expr(constant, std::move(terms));
}

/// @brief Alias for sum() for backward compatibility.
/// @note total_sum() is now equivalent to sum().
template <typename T>
Expr total_sum(const T& items) {
  return sum(items);
}

/// @brief Sum along specified axis for 2D vectors.
/// @param items 2D vector to sum.
/// @param axis Axis to sum along (0 or 1, already normalized).
/// @return Vector with one less dimension, preserving element type.
template <typename T>
auto vector_sum(const Vector<Vector<T>>& items, int axis) {
  using ResultType = std::conditional_t<
      is_integer_like_v<T>, T,
      std::decay_t<decltype(std::declval<T>() + std::declval<T>())>>;
  constexpr int ndim = dim_of<Vector<Vector<T>>>::value;
  int norm_axis = normalize_axis(axis, ndim);

  if (norm_axis == 0) {
    // Sum along axis 0: sum columns (parallelized by column)
    if (items.empty()) {
      throw std::runtime_error("qbpp::vector_sum: empty vector");
    }
    size_t ncols = items[0].size();
    Vector<ResultType> result(ncols);
    if (ncols < SEQ_THRESHOLD) {
      for (size_t j = 0; j < ncols; ++j) {
        ResultType col_sum = items[0][j];
        for (size_t i = 1; i < items.size(); ++i) {
          col_sum = col_sum + items[i][j];
        }
        result[j] = std::move(col_sum);
      }
    } else {
      tbb::parallel_for(size_t(0), ncols, [&](size_t j) {
        ResultType col_sum = items[0][j];
        for (size_t i = 1; i < items.size(); ++i) {
          col_sum = col_sum + items[i][j];
        }
        result[j] = std::move(col_sum);
      });
    }
    return result;
  } else {
    // Sum along axis 1: sum rows (parallelized by row)
    Vector<ResultType> result(items.size());
    if (items.size() < SEQ_THRESHOLD) {
      for (size_t i = 0; i < items.size(); ++i) {
        ResultType row_sum = items[i][0];
        for (size_t j = 1; j < items[i].size(); ++j) {
          row_sum = row_sum + items[i][j];
        }
        result[i] = std::move(row_sum);
      }
    } else {
      tbb::parallel_for(size_t(0), items.size(), [&](size_t i) {
        ResultType row_sum = items[i][0];
        for (size_t j = 1; j < items[i].size(); ++j) {
          row_sum = row_sum + items[i][j];
        }
        result[i] = std::move(row_sum);
      });
    }
    return result;
  }
}

// Forward declaration for 3D+
template <typename T>
auto vector_sum(const Vector<Vector<Vector<T>>>& items, int axis);

/// @brief Sum along specified axis for 3D+ nested vectors.
template <typename T>
auto vector_sum(const Vector<Vector<Vector<T>>>& items, int axis) {
  constexpr int ndim = dim_of<Vector<Vector<Vector<T>>>>::value;
  int norm_axis = normalize_axis(axis, ndim);

  if (norm_axis == 0) {
    // Sum along outermost axis (parallelized by second dimension)
    if (items.empty()) {
      throw std::runtime_error("qbpp::vector_sum: empty vector");
    }
    using ResultElemType = decltype(items[0][0] + items[0][0]);
    size_t ncols = items[0].size();
    Vector<ResultElemType> result(ncols);
    if (ncols < SEQ_THRESHOLD) {
      for (size_t j = 0; j < ncols; ++j) {
        ResultElemType col_sum = items[0][j];
        for (size_t i = 1; i < items.size(); ++i) {
          col_sum = col_sum + items[i][j];
        }
        result[j] = std::move(col_sum);
      }
    } else {
      tbb::parallel_for(size_t(0), ncols, [&](size_t j) {
        ResultElemType col_sum = items[0][j];
        for (size_t i = 1; i < items.size(); ++i) {
          col_sum = col_sum + items[i][j];
        }
        result[j] = std::move(col_sum);
      });
    }
    return result;
  } else {
    // Recursively sum along inner axis (parallelized)
    using SubResultType = decltype(vector_sum(items[0], norm_axis - 1));
    Vector<SubResultType> result(items.size());
    if (items.size() < SEQ_THRESHOLD) {
      for (size_t i = 0; i < items.size(); ++i) {
        result[i] = vector_sum(items[i], norm_axis - 1);
      }
    } else {
      tbb::parallel_for(size_t(0), items.size(), [&](size_t i) {
        result[i] = vector_sum(items[i], norm_axis - 1);
      });
    }
    return result;
  }
}

/// @brief Returns the sum along the innermost axis (axis=-1) of a nested
/// vector.
/// @param items The nested vector (2-d or higher).
/// @return A vector with one less dimension than the input.
template <typename T>
auto vector_sum(const Vector<Vector<T>>& items) {
  return vector_sum(items, -1);
}

/// @brief Returns the expression for the consecutive ones.
/// @param items Vector of T objects.
template <typename T>
Expr diff(const Vector<T>& items, energy_t head = 0, energy_t tail = 0) {
  if (items.empty()) {
    return 0;
  }
  Expr result = sqr(head - items[0]);
  for (size_t i = 0; i < items.size() - 1; ++i) {
    result += sqr(items[i] - items[i + 1]);
  }
  result += sqr(items[items.size() - 1] - tail);
  return result;
}

/// @brief Returns the consecutive ones for the nested vector of Var
/// objects.
template <typename T>
auto diff(const Vector<Vector<T>>& items, energy_t head = 0,
          energy_t tail = 0) {
  using SubResultType = decltype(diff(std::declval<Vector<T>>()));
  Vector<SubResultType> result(items.size());
  tbb::parallel_for(size_t(0), items.size(),
                    [&](size_t i) { result[i] = diff(items[i], head, tail); });
  return result;
}

/// @brief Convert an Expr object to an integer values.
/// @param expr The Expr object.
/// @return The constant value of the Expr object.
/// @throw std::runtime_error if the expression has terms.
/// @note This is the base case for Vectors.
inline energy_t toInt(const Expr& expr) {
  if (expr.term_count() == 0) {
    return static_cast<energy_t>(expr.constant());
  } else
    throw std::runtime_error(
        THROW_MESSAGE("The expression is not a constant."));
}

/// @brief Convert a Vector of Expr objects to the Vector of
/// integer values.
/// @param arg The Vector of Expr objects.
/// @return The Vector of integer values.
/// @note This function calls the base case and std::runtime_error is thrown
/// if at least one of the Expr objects is not a constant.
template <typename T>
auto toInt(const Vector<T>& arg) {
  using ResultType = decltype(toInt(arg[0]));
  Vector<ResultType> result(arg.size());

  tbb::parallel_for(tbb::blocked_range<size_t>(0, arg.size()),
                    [&](const tbb::blocked_range<size_t>& range) {
                      for (size_t i = range.begin(); i < range.end(); ++i) {
                        result[i] = toInt(arg[i]);
                      }
                    });

  return result;
}

/// @brief Evaluates all Expr objects in a vector using the VarValMap
/// object.
/// @param arg The vector of Expr objects.
/// @param var_val_map The VarValMap object.
/// @return The vector of energy values after evaluating the Expr objects.
template <typename T>
Vector<energy_t> eval_var_val_map(const Vector<T>& arg,
                                  const VarValMap& var_val_map) {
  Vector<energy_t> result(arg.size());

  tbb::parallel_for(tbb::blocked_range<size_t>(0, arg.size()),
                    [&](const tbb::blocked_range<size_t>& range) {
                      for (size_t i = range.begin(); i < range.end(); ++i) {
                        result[i] = eval_var_val_map(arg[i], var_val_map);
                      }
                    });

  return result;
}

/// @brief Evaluates a vector of Expr objects.
/// @param arg The vector of Expr objects.
/// @param map_list The MapList object.
/// @return The vector of integer values after evaluating the Expr objects
/// using the MapList object.
/// @note This function is the base case for Vectors.
template <typename T>
Vector<energy_t> eval(const Vector<T>& arg, const MapList& map_list) {
  VarValMap var_val_map = list_to_var_val(map_list);
  return eval_var_val_map(arg, var_val_map);
}

template <typename T>
auto eval_var_val_map(const Vector<Vector<T>>& arg,
                      const VarValMap& var_val_map) {
  using ResultType = decltype(eval_var_val_map(arg[0], var_val_map));
  Vector<ResultType> result(arg.size());

  tbb::parallel_for(tbb::blocked_range<size_t>(0, arg.size()),
                    [&](const tbb::blocked_range<size_t>& range) {
                      for (size_t i = range.begin(); i < range.end(); ++i) {
                        result[i] = eval_var_val_map(arg[i], var_val_map);
                      }
                    });

  return result;
}

/// @brief Evaluates a nested vector of Expr objects.
/// @param arg The nested vector of Expr objects.
/// @param map_list The MapList object.
/// @return The nested vector of integer values after evaluating the Expr
/// objects using the MapList object.
/// @note This function accepts multi-level nested vectors of Expr objects
/// by recursion.
template <typename T>
auto eval(const Vector<Vector<T>>& arg, const MapList& map_list) {
  VarValMap var_val_map = list_to_var_val(map_list);
  return eval_var_val_map(arg, var_val_map);
}

/// @brief Replace variables in a vector of Expr objects.
/// @param arg The vector of Expr objects.
/// @param map_list The MapList object.
/// @return The vector of Expr objects after replacing the variables using
/// the MapList object.
template <typename T>
Vector<Expr> replace(const Vector<T>& arg, const MapList& map_list) {
  Vector<Expr> result(arg.size());

  tbb::parallel_for(tbb::blocked_range<size_t>(0, arg.size()),
                    [&](const tbb::blocked_range<size_t>& range) {
                      for (size_t i = range.begin(); i < range.end(); ++i) {
                        result[i] = replace(arg[i], map_list);
                      }
                    });

  return result;
}

/// @brief Replace variables in a nested vector of Expr objects.
/// @param arg The nested vector of Expr objects.
/// @param map_list The MapList object.
/// @return The nested vector of Expr objects after replacing the variables
/// using the MapList object.
/// @note This function accepts multi-level nested vectors of Expr objects
/// by recursion.
template <typename T>
auto replace(const Vector<Vector<T>>& arg, const MapList& map_list) {
  using ResultType = decltype(replace(arg[0], map_list));
  Vector<ResultType> result(arg.size());

  tbb::parallel_for(tbb::blocked_range<size_t>(0, arg.size()),
                    [&](const tbb::blocked_range<size_t>& range) {
                      for (size_t i = range.begin(); i < range.end(); ++i) {
                        result[i] = replace(arg[i], map_list);
                      }
                    });

  return result;
}

/// @brief Generic element-wise function for a vector/nested vector of Expr
/// objects.
/// @param arg The vector/nested vector of Expr objects.
/// @param func The function to be applied to each Expr objects.
/// @return The vector/nested Vector of Expr objects after applying the
/// function.
template <typename T, typename F>
auto element_wise(const Vector<T>& arg, F func) {
  Vector<std::decay_t<decltype(func(arg[0]))>> result(arg.size());

  tbb::parallel_for(tbb::blocked_range<size_t>(0, arg.size()),
                    [&](const tbb::blocked_range<size_t>& range) {
                      for (size_t i = range.begin(); i < range.end(); ++i) {
                        result[i] = func(arg[i]);
                      }
                    });

  return result;
}

/// @brief Returns the square of the Expr object.
inline Expr sqr(const Expr& expr) { return expr * expr; }

/// @brief Returns the square of the Term object as an Expr.
inline Expr sqr(const Term& term) { return qbpp::toExpr(term * term); }

/// @brief Returns a vector of squared objects (preserves element type).
/// @param arg The vector of objects.
/// @return The squared vector (preserves element type when possible).
/// @note This function handles the base case for Vectors.
template <typename T>
auto sqr(const Vector<T>& arg) {
  using ResultType =
      std::decay_t<decltype(std::declval<T>() * std::declval<T>())>;
  Vector<ResultType> result;
  result.reserve(arg.size());
  for (const auto& item : arg) {
    result.push_back(item *
                     item);  // Use direct multiplication to preserve type
  }
  return result;
}

/// @brief Returns a vector of reduced Expr objects.
/// @param arg The vector of Expr objects.
/// @return The vector of reduced Expr objects.
/// @note This function handles multi-level nested vectors by recursion.
template <typename T>
auto reduce(const Vector<T>& arg) {
  using ResultType = std::decay_t<decltype(reduce(arg[0]))>;
  Vector<ResultType> result;
  result.reserve(arg.size());
  for (const auto& item : arg) {
    result.push_back(reduce(item));
  }
  return result;
}

/// @brief Converts a vector of Expr objects using binary_to_spin.
/// @param arg The vector of Expr objects.
/// @return The vector of Expr objects after applying binary_to_spin.
/// @note This function handles multi-level nested vectors by recursion.
template <typename T>
auto binary_to_spin(const Vector<T>& arg) {
  using ResultType = std::decay_t<decltype(binary_to_spin(arg[0]))>;
  Vector<ResultType> result;
  result.reserve(arg.size());
  for (const auto& item : arg) {
    result.push_back(binary_to_spin(item));
  }
  return result;
}

/// @brief Converts a vector of Expr objects using spin_to_binary.
/// @param arg The vector of Expr objects.
/// @return The vector of Expr objects after applying spin_to_binary.
/// @note This function handles multi-level nested vectors by recursion.
template <typename T>
auto spin_to_binary(const Vector<T>& arg) {
  using ResultType = std::decay_t<decltype(spin_to_binary(arg[0]))>;
  Vector<ResultType> result;
  result.reserve(arg.size());
  for (const auto& item : arg) {
    result.push_back(spin_to_binary(item));
  }
  return result;
}

/// @brief Returns the greatest common divisor (GCD) of the constant term
/// and all coefficients in the expression.
/// @param expr The Expr object.
/// @return The GCD of all coefficients and the constant term.
/// @note Dividing the expression by its GCD (expr /= gcd(expr)) reduces
/// coefficient magnitudes without changing optimal solutions.
inline energy_t gcd(const Expr& expr) {
  energy_t result = abs(expr.constant());
  for (const auto& term : expr.terms()) {
    result = gcd(result, static_cast<energy_t>(abs(term.coeff())));
  }
  return result;
}

/// @brief Transposes the two-dimensional nested vector of Expr objects.
/// @param vec The nested vector of Expr objects.
/// @return The transposed nested vector of Expr objects.
template <typename T>
Vector<Vector<Expr>> transpose(const Vector<Vector<T>>& vec) {
  const size_t rows = vec.size();
  const size_t cols = vec[0].size();

  Vector<Vector<Expr>> result(cols, Vector<Expr>(rows));  // 事前確保

  tbb::parallel_for(size_t(0), rows, [&](size_t i) {
    for (size_t j = 0; j < cols; ++j) {
      result[j][i] = vec[i][j];
    }
  });

  return result;
}

/// @brief Convert a vector of one-hot encoded values to an integer.
/// @param vec The vector of one-hot encoded values.
/// @return The integer value of the one-hot encoded vector. If the vector
/// is not one-hot encoded, the function returns -1.
inline int32_t onehot_to_int(const Vector<var_val_t>& vec) {
  int32_t total = 0;
  int32_t result = -1;
  for (vindex_t i = 0; i < vec.size(); i++) {
    if (vec[i] == 1) {
      result = static_cast<int32_t>(i);
    }
    total += vec[i];
  }
  if (total == 1) {
    return result;
  } else {
    return -1;
  }
}

inline uint64_t bin_to_int(const Vector<var_val_t>& vec) {
  uint64_t total = 0;
  for (vindex_t i = 0; i < vec.size(); i++) {
    total += static_cast<uint64_t>(vec[i]) << i;
  }
  return total;
}

/// @brief Convert a nested vector of one-hot encoded values to a vector of
/// integers (reduces innermost axis).
/// @param vec The nested vector of one-hot encoded values.
/// @return The vector of integers of the one-hot encoded vector.
/// @note This function handles multi-level nested vectors by recursion.
template <typename T>
auto onehot_to_int(const Vector<Vector<T>>& vec) {
  using ResultType = std::decay_t<decltype(onehot_to_int(vec[0]))>;
  Vector<ResultType> result(vec.size());
  tbb::parallel_for(size_t(0), vec.size(),
                    [&](size_t i) { result[i] = onehot_to_int(vec[i]); });
  return result;
}

// Forward declaration for 3D+ version with axis
template <typename T>
auto onehot_to_int(const Vector<Vector<Vector<T>>>& vec, int axis);

/// @brief Convert a 2D vector of one-hot encoded values along specified axis.
/// @param vec The 2D nested vector of one-hot encoded values.
/// @param axis The axis along which to apply onehot_to_int (supports negative).
/// @return The vector of integers.
inline Vector<int32_t> onehot_to_int(const Vector<Vector<var_val_t>>& vec,
                                     int axis) {
  constexpr int ndim = 2;
  int norm_axis = normalize_axis(axis, ndim);

  if (norm_axis == 1) {
    // Innermost axis - current behavior
    return onehot_to_int(vec);
  } else {
    // axis == 0: gather along first dimension
    if (vec.empty()) return Vector<int32_t>();
    Vector<int32_t> result(vec[0].size());
    for (size_t j = 0; j < vec[0].size(); ++j) {
      Vector<var_val_t> gathered(vec.size());
      for (size_t i = 0; i < vec.size(); ++i) {
        gathered[i] = vec[i][j];
      }
      result[j] = onehot_to_int(gathered);
    }
    return result;
  }
}

/// @brief Convert a 3D+ vector of one-hot encoded values along specified axis.
/// @param vec The 3D+ nested vector of one-hot encoded values.
/// @param axis The axis along which to apply onehot_to_int (supports negative).
/// @return The nested vector of integers with one less dimension along axis.
template <typename T>
auto onehot_to_int(const Vector<Vector<Vector<T>>>& vec, int axis) {
  constexpr int ndim = dim_of<Vector<Vector<Vector<T>>>>::value;
  int norm_axis = normalize_axis(axis, ndim);

  if (norm_axis == 0) {
    // Gather along outermost axis and continue reducing along axis 0
    if (vec.empty() || vec[0].empty()) {
      using InnerResultType = std::decay_t<decltype(onehot_to_int(vec[0], 0))>;
      return Vector<InnerResultType>{};
    }
    using InnerResultType = std::decay_t<decltype(onehot_to_int(
        std::declval<Vector<Vector<T>>>(), 0))>;
    using ResultType = Vector<InnerResultType>;
    ResultType result(vec[0].size());
    for (size_t j = 0; j < vec[0].size(); ++j) {
      Vector<Vector<T>> gathered(vec.size());
      for (size_t i = 0; i < vec.size(); ++i) {
        gathered[i] = vec[i][j];
      }
      result[j] = onehot_to_int(gathered, 0);
    }
    return result;
  } else {
    // Recursively apply with axis-1
    using InnerResultType =
        std::decay_t<decltype(onehot_to_int(vec[0], norm_axis - 1))>;
    using ResultType = Vector<InnerResultType>;
    if (vec.empty()) return ResultType{};
    ResultType result(vec.size());
    if (vec.size() < SEQ_THRESHOLD) {
      for (size_t i = 0; i < vec.size(); ++i) {
        result[i] = onehot_to_int(vec[i], norm_axis - 1);
      }
    } else {
      tbb::parallel_for(size_t(0), vec.size(), [&](size_t i) {
        result[i] = onehot_to_int(vec[i], norm_axis - 1);
      });
    }
    return result;
  }
}

/// @brief Convert a nested vector of binary values to a vector of integers
/// (reduces innermost axis).
/// @param vec The nested vector of binary values.
/// @return The vector of integers.
/// @note This function handles multi-level nested vectors by recursion.
template <typename T>
auto bin_to_int(const Vector<Vector<T>>& vec) {
  using ResultType = std::decay_t<decltype(bin_to_int(vec[0]))>;
  Vector<ResultType> result(vec.size());
  tbb::parallel_for(size_t(0), vec.size(),
                    [&](size_t i) { result[i] = bin_to_int(vec[i]); });
  return result;
}

// Forward declaration for 3D+ version with axis
template <typename T>
auto bin_to_int(const Vector<Vector<Vector<T>>>& vec, int axis);

/// @brief Convert a 2D vector of binary values along specified axis.
/// @param vec The 2D nested vector of binary values.
/// @param axis The axis along which to apply bin_to_int (supports negative).
/// @return The vector of integers.
inline Vector<uint64_t> bin_to_int(const Vector<Vector<var_val_t>>& vec,
                                   int axis) {
  constexpr int ndim = 2;
  int norm_axis = normalize_axis(axis, ndim);

  if (norm_axis == 1) {
    // Innermost axis - current behavior
    return bin_to_int(vec);
  } else {
    // axis == 0: gather along first dimension
    if (vec.empty()) return Vector<uint64_t>();
    Vector<uint64_t> result(vec[0].size());
    for (size_t j = 0; j < vec[0].size(); ++j) {
      Vector<var_val_t> gathered(vec.size());
      for (size_t i = 0; i < vec.size(); ++i) {
        gathered[i] = vec[i][j];
      }
      result[j] = bin_to_int(gathered);
    }
    return result;
  }
}

/// @brief Convert a 3D+ vector of binary values along specified axis.
/// @param vec The 3D+ nested vector of binary values.
/// @param axis The axis along which to apply bin_to_int (supports negative).
/// @return The nested vector of integers with one less dimension along axis.
template <typename T>
auto bin_to_int(const Vector<Vector<Vector<T>>>& vec, int axis) {
  constexpr int ndim = dim_of<Vector<Vector<Vector<T>>>>::value;
  int norm_axis = normalize_axis(axis, ndim);

  if (norm_axis == 0) {
    // Gather along outermost axis and continue reducing along axis 0
    if (vec.empty() || vec[0].empty()) {
      using InnerResultType = std::decay_t<decltype(bin_to_int(vec[0], 0))>;
      return Vector<InnerResultType>{};
    }
    using InnerResultType = std::decay_t<decltype(bin_to_int(
        std::declval<Vector<Vector<T>>>(), 0))>;
    using ResultType = Vector<InnerResultType>;
    ResultType result(vec[0].size());
    for (size_t j = 0; j < vec[0].size(); ++j) {
      Vector<Vector<T>> gathered(vec.size());
      for (size_t i = 0; i < vec.size(); ++i) {
        gathered[i] = vec[i][j];
      }
      result[j] = bin_to_int(gathered, 0);
    }
    return result;
  } else {
    // Recursively apply with axis-1
    using InnerResultType =
        std::decay_t<decltype(bin_to_int(vec[0], norm_axis - 1))>;
    using ResultType = Vector<InnerResultType>;
    if (vec.empty()) return ResultType{};
    ResultType result(vec.size());
    if (vec.size() < SEQ_THRESHOLD) {
      for (size_t i = 0; i < vec.size(); ++i) {
        result[i] = bin_to_int(vec[i], norm_axis - 1);
      }
    } else {
      tbb::parallel_for(size_t(0), vec.size(), [&](size_t i) {
        result[i] = bin_to_int(vec[i], norm_axis - 1);
      });
    }
    return result;
  }
}

// ============================================================================
// PART 5: CLASS MEMBER IMPLEMENTATIONS (out-of-line)
// ============================================================================

// --------------------------------------------------
// Class Vector<T> Member Functions
// --------------------------------------------------

template <typename T>
Vector<T>& Vector<T>::simplify(Vars (*sort_vars_func)(const Vars&)) {
  *this = qbpp::simplify(*this, sort_vars_func);
  return *this;
}

template <typename T>
Vector<T>& Vector<T>::replace(const MapList& map_list) {
  *this = qbpp::replace(*this, map_list);
  return *this;
}

template <typename T>
Vector<T>& Vector<T>::reduce() {
  *this = qbpp::reduce(*this);
  return *this;
}

// --------------------------------------------------
// Class Var Member Functions
// --------------------------------------------------

inline int32_t Var::operator()(const Sol& sol) const { return sol.get(*this); }

// --------------------------------------------------
// Class IVMapper Helper Functions
// --------------------------------------------------

inline IVMapper::IVMapper(const Expr& expr) {
  std::vector<uint8_t> var_flags(all_var_count(), 0);
  if (expr.term_count() == 0) {
    throw std::runtime_error(THROW_MESSAGE("Error: Empty expressoin."));
  };

  tbb::parallel_for(size_t(0), expr.terms().size(), [&](size_t i) {
    const auto& term = expr.terms()[i];
    for (const auto& var : term.vars()) {
      var_flags[var.index() & qbpp::vindex_mask] = 1;
    }
    if (!term.is_simplified_as_binary()) {
      throw std::runtime_error(
          THROW_MESSAGE("Error: The expression is not simplified as binary (" +
                        term.str() + ")."));
    }
    if ((i > 0) && !(expr.terms()[i - 1] < term)) {
      throw std::runtime_error(
          THROW_MESSAGE("Error: The expression is not simplified as binary (" +
                        expr.terms()[i - 1].str() + " >" + term.str() + ")."));
    }
  });

  impl_ = qbpp_iv_mapper_create(all_var_count(), var_flags.data());
}

// --------------------------------------------------
// Class Expr member functions
// --------------------------------------------------

inline Expr& Expr::operator*=(const Expr& expr) {
  // when expr is a constant and has no terms
  if (expr.term_count() == 0) {
    return *this *= expr.constant_;
  }

  if (expr.term_count() == 1) {
    terms_ = terms_ * expr.terms_[0] + terms_ * expr.constant_ +
             // Should not be expr.terms_[0] * static_cast<coeff_t>(constant_);
             expr.terms_ * constant_;
    constant_ *= expr.constant_;
    return *this;
  }

  Expr result{constant_ * expr.constant_};
  result += terms_ * expr.terms_;
  result += terms_ * static_cast<coeff_t>(expr.constant_);
  result += expr.terms_ * static_cast<coeff_t>(constant_);

  *this = std::move(result);
  return *this;
}

inline Expr& Expr::operator*=(const Term& term) {
  if (terms_.size() < SEQ_THRESHOLD) {
    for (auto& t : terms_) {
      t *= term;
    }
  } else {
    tbb::parallel_for(size_t(0), terms_.size(),
                      [&](size_t i) { terms_[i] *= term; });
  }
  if (constant_ != 0) {
    *this += term * static_cast<coeff_t>(constant_);
    constant_ = 0;
  }
  return *this;
}

inline Expr& Expr::simplify(Vars (*sort_vars_func)(const Vars&)) {
  return *this = qbpp::simplify(*this, sort_vars_func);
}

inline Expr& Expr::simplify_as_binary() {
  return *this = qbpp::simplify_as_binary(*this);
}

inline Expr& Expr::simplify_as_spin() {
  return *this = qbpp::simplify_as_spin(*this);
}

inline Expr::Expr(const VarInt& var_int)
    : constant_(var_int.constant()), terms_(var_int.terms()) {
  if (var_int.max_val() == 0) {
    throw std::runtime_error(
        THROW_MESSAGE("Wrong VarInt object. Max value is not specified."));
  }
}

inline Expr::Expr(VarInt&& var_int)
    : constant_(var_int.constant()), terms_(std::move(var_int.terms())) {
  if (var_int.max_val() == 0) {
    throw std::runtime_error(
        THROW_MESSAGE("Wrong VarInt object. Max value is not specified."));
  }
}

inline Expr& Expr::replace(const MapList& map_list) {
  MapDict map_dict = list_to_dict(map_list);
  Vector<Expr> exprs;
  exprs.resize(terms_.size());
  tbb::parallel_for(size_t(0), terms_.size(), [&](size_t i) {
    exprs[i] = qbpp::replace(terms_[i], map_dict);
  });
  Expr result = qbpp::sum(exprs);
  result += constant_;
  *this = std::move(result);
  return *this;
}

inline vindex_t Expr::var_count() const {
  qbpp::BitVector bits(all_var_count());
  for (const auto& term : terms_) {
    for (const auto& var : term.vars()) {
      bits.set(var.index() & vindex_mask, 1);
    }
  }
  return bits.popcount();
}

// ============================================================================
// PART 6: FREE FUNCTIONS AND OPERATORS
// ============================================================================

// --------------------------------------------------
// Term Operators
// --------------------------------------------------

template <typename T,
          typename std::enable_if<
              std::is_convertible<std::decay_t<T>, coeff_t>::value, int>::type>
Term operator*(Var var, T&& val) {
  return Term(var, std::forward<T>(val));
}

template <typename T,
          typename std::enable_if<
              std::is_convertible<std::decay_t<T>, coeff_t>::value, int>::type>
Term operator*(T&& val, Var var) {
  return Term(var, std::forward<T>(val));
}

template <typename T,
          typename std::enable_if<
              std::is_convertible<std::decay_t<T>, coeff_t>::value, int>::type>
Term operator*(const Term& term, T&& val) {
  Term result = term;
  result *= std::forward<T>(val);
  return result;
}

template <typename T,
          typename std::enable_if<
              std::is_convertible<std::decay_t<T>, coeff_t>::value, int>::type>
Term operator*(T&& val, const Term& term) {
  Term result = term;
  result *= std::forward<T>(val);
  return result;
}
template <typename T,
          typename std::enable_if<
              std::is_convertible<std::decay_t<T>, coeff_t>::value, int>::type>
Term operator*(Term&& term, T&& val) {
  term *= std::forward<T>(val);
  return std::move(term);
}

template <typename T,
          typename std::enable_if<
              std::is_convertible<std::decay_t<T>, coeff_t>::value, int>::type>
Term operator*(T&& val, Term&& term) {
  term *= std::forward<T>(val);
  return std::move(term);
}

inline Term operator*(Var var1, Var var2) { return Term(var1, var2); }

inline Term operator*(const Term& term, Var var) {
  Term result = term;
  result *= var;
  return result;
}

inline Term operator*(Term&& term, Var var) {
  term *= var;
  return std::move(term);
}

inline Term operator*(Var var, const Term& term) { return term * var; }

inline Term operator*(Var var, Term&& term) { return std::move(term) * var; }

inline Term operator*(const Term& term1, const Term& term2) {
  Term result = term1;
  result.coeff() *= term2.coeff();
#if defined(MAXDEG) && MAXDEG > 0
  result.vars() *= term2.vars();
#else
  result.vars().insert(result.vars().end(), term2.vars().begin(),
                       term2.vars().end());
#endif
  return result;
}

inline Term operator*(Term&& term1, const Term& term2) {
  term1.coeff() *= term2.coeff();
#if defined(MAXDEG) && MAXDEG > 0
  term1.vars() *= term2.vars();
#else
  term1.vars().insert(term1.vars().end(), term2.vars().begin(),
                      term2.vars().end());
#endif
  return term1;
}

inline Term operator*(const Term& term1, Term&& term2) {
  return std::move(term2) * term1;
}

inline Term operator*(Term&& term1, Term&& term2) {
  return std::move(term1) * term2;
}

// --------------------------------------------------
// Terms Global Functions
// --------------------------------------------------

template <typename T>
Terms operator+(const Terms& lhs, T&& rhs) {
  Terms result = lhs;
  result += std::forward<T>(rhs);
  return result;
}

template <typename T>
Terms operator+(Terms&& lhs, T&& rhs) {
  lhs += std::forward<T>(rhs);
  return std::move(lhs);
}

template <typename T>
Terms operator-(const Terms& lhs, T&& rhs) {
  Terms result = lhs;
  result -= std::forward<T>(rhs);
  return result;
}

template <typename T>
Terms operator-(Terms&& lhs, T&& rhs) {
  lhs -= std::forward<T>(rhs);
  return std::move(lhs);
}

template <typename T,
          typename std::enable_if<
              std::is_convertible<std::decay_t<T>, coeff_t>::value, int>::type>
Terms operator*(const Terms& lhs, T&& rhs) {
  Terms result;
  if (rhs == 0) {
    return result;
  }
  const size_t n = lhs.size();
  if (n < SEQ_THRESHOLD) {
    result.reserve(n);
    for (const auto& term : lhs) {
      result += term * rhs;
    }
  } else {
    result.resize(n);
    tbb::parallel_for(size_t(0), n,
                      [&](size_t i) { result[i] = lhs[i] * rhs; });
  }
  return result;
}

template <typename T,
          typename std::enable_if<
              std::is_convertible<std::decay_t<T>, coeff_t>::value, int>::type>
Terms operator*(Terms&& lhs, T&& rhs) {
  if (rhs == 0) {
    return Terms{};
  } else {
    lhs *= std::forward<T>(rhs);
  }
  return std::move(lhs);
}

template <typename T,
          typename std::enable_if<
              std::is_convertible<std::decay_t<T>, coeff_t>::value, int>::type>
inline Terms operator*(T&& rhs, const Terms& lhs) {
  return lhs * std::forward<T>(rhs);
}

template <typename T,
          typename std::enable_if<
              std::is_convertible<std::decay_t<T>, coeff_t>::value, int>::type>
inline Terms operator*(T&& rhs, Terms&& lhs) {
  return std::move(lhs) * std::forward<T>(rhs);
}

inline Terms operator*(const Terms& lhs, const Term& rhs) {
  Terms result;
  const size_t n = lhs.size();
  if (n < SEQ_THRESHOLD) {
    result.reserve(n);
    for (const auto& term : lhs) {
      result += term * rhs;
    }
  } else {
    result.resize(n);
    tbb::parallel_for(size_t(0), n,
                      [&](size_t i) { result[i] = lhs[i] * rhs; });
  }
  return result;
}

inline Terms operator*(const Term& lhs, const Terms& rhs) { return lhs * rhs; }

inline Terms operator*(Terms&& lhs, const Term& rhs) {
  lhs *= rhs;
  return std::move(lhs);
}

inline Terms operator*(const Term& lhs, Terms&& rhs) {
  rhs *= lhs;
  return std::move(rhs);
}

inline Terms operator*(const Terms& lhs, const Terms& rhs) {
  Terms result;
  const size_t n = lhs.size(), m = rhs.size();

  if (n * m < SEQ_THRESHOLD) {
    result.reserve(n * m);
    for (const auto& term : rhs) {
      result += lhs * term;
    }
  } else {
    result.resize(n * m);

    const Terms& small_term = (n <= m) ? lhs : rhs;
    const Terms& large_term = (n > m) ? lhs : rhs;

    tbb::parallel_for(size_t(0), large_term.size(), [&](size_t i) {
      for (size_t j = 0; j < small_term.size(); ++j) {
        result[i * small_term.size() + j] = large_term[i] * small_term[j];
      }
    });
  }
  return result;
}

// ---------------------------------------------------
// Class Expr global functions
// ---------------------------------------------------

// Note: Scalar operator*(Expr, T) and operator*(T, Expr) are NOT provided.
// Instead, rely on implicit conversion to Expr and operator*(Expr, Expr).
// This avoids ambiguity with Boost multiprecision operators when coeff_t is
// cpp_int.

inline Expr operator*(const Expr& expr, const Term& term) {
  Expr result = expr;
  result *= term;
  return result;
}

inline Expr operator*(const Term& term, const Expr& expr) {
  Expr result = expr;
  result *= term;
  return result;
}
inline Expr operator*(const Expr& expr, Term&& term) {
  Expr result = expr;
  result *= std::move(term);
  return result;
}
inline Expr operator*(Term&& term, const Expr& expr) {
  Expr result = expr;
  result *= std::move(term);
  return result;
}

inline Expr&& operator*(Expr&& expr, const Term& term) {
  expr *= term;
  return std::move(expr);
}
inline Expr&& operator*(const Term& term, Expr&& expr) {
  expr *= term;
  return std::move(expr);
}
inline Expr&& operator*(Expr&& expr, Term&& rhs) {
  expr *= std::move(rhs);
  return std::move(expr);
}

inline Expr&& operator*(Term&& rhs, Expr&& expr) {
  expr *= std::move(rhs);
  return std::move(expr);
}

/// @brief Multiplies two Expr objects using move semantics.
inline Expr&& operator*(Expr&& lhs, Expr&& rhs) {
  if (lhs.term_count() >= rhs.term_count()) {
    lhs *= rhs;
    return std::move(lhs);
  } else {
    rhs *= lhs;
    return std::move(rhs);
  }
}

/// @brief Multiplies two Expr objects using move semantics.
inline Expr&& operator*(Expr&& lhs, const Expr& rhs) {
  lhs *= rhs;
  return std::move(lhs);
}

/// @brief Multiplies two Expr objects using move semantics.
inline Expr&& operator*(const Expr& lhs, Expr&& rhs) {
  rhs *= lhs;
  return std::move(rhs);
}

/// @brief Multiplies two Expr objects using copy semantics.
inline Expr operator*(const Expr& lhs, const Expr& rhs) {
  auto result = lhs;
  result *= rhs;
  return result;
}

/// @brief Adds two Expr objects using move semantics.
inline Expr&& operator+(Expr&& lhs, Expr&& rhs) {
  if (lhs.term_count() >= rhs.term_count()) {
    lhs += rhs;
    return std::move(lhs);
  } else {
    rhs += lhs;
    return std::move(rhs);
  }
}

/// @brief Adds two Expr objects using move semantics.
inline Expr&& operator+(Expr&& lhs, const Expr& rhs) {
  lhs += rhs;
  return std::move(lhs);
}

/// @brief Adds two Expr objects using move semantics.
inline Expr&& operator+(const Expr& lhs, Expr&& rhs) {
  rhs += lhs;
  return std::move(rhs);
}

/// @brief Adds two Expr objects using copy semantics.
inline Expr operator+(const Expr& lhs, const Expr& rhs) {
  auto result = lhs;
  return result += rhs;
}

/// @brief Subtracts two Expr objects using move semantics.
inline Expr&& operator-(Expr&& lhs, Expr&& rhs) {
  lhs -= rhs;
  return std::move(lhs);
}

/// @brief Subtracts two Expr objects using move semantics.
inline Expr&& operator-(Expr&& lhs, const Expr& rhs) {
  lhs -= rhs;
  return std::move(lhs);
}

/// @brief Subtracts two Expr objects using move semantics.
inline Expr&& operator-(const Expr& lhs, Expr&& rhs) {
  rhs *= -1;
  rhs += lhs;
  return std::move(rhs);
}

/// @brief Subtracts two Expr objects using copy semantics.
inline Expr operator-(const Expr& lhs, const Expr& rhs) {
  auto result = lhs;
  return result -= rhs;
}

/// @brief Divides the Expr object by an integer value using move semantics.
template <typename T,
          typename std::enable_if<
              std::is_convertible<std::decay_t<T>, coeff_t>::value, int>::type>
inline Expr&& operator/(Expr&& expr, T&& val) {
  expr /= std::forward<T>(val);
  return std::move(expr);
}

/// @brief Divides the Expr object by an integer value using copy semantics.
/// @param expr The Expr object to divide, passed as a const lvalue
/// reference.
/// @param val The integer value to divide by.
/// @return Expr The result of the division, returned by value.
template <typename T,
          typename std::enable_if<
              std::is_convertible<std::decay_t<T>, coeff_t>::value, int>::type>
inline Expr operator/(const Expr& expr, T&& val) {
  auto temp = expr;
  return temp /= std::forward<T>(val);
}

/// @brief Unary operator+ overload for the Expr object using move
/// semantics.
inline Expr operator+(Expr&& expr) { return std::move(expr); }

/// @brief Unary operator+ overload for the Expr object using copy
/// semantics.
inline const Expr& operator+(const Expr& expr) { return expr; }

/// @brief Negates the Expr object using move semantics.
/// @param expr The Expr object to be negated, passed as an rvalue
/// reference.
/// @return Expr The negated Expr object, returned by moving.
inline Expr operator-(Expr&& expr) {
  expr.constant() = -expr.constant();
  if (expr.term_count() < SEQ_THRESHOLD) {
    for (auto& term : expr.terms()) {
      term.negate();
    }
  } else {
    tbb::parallel_for(size_t(0), expr.size(),
                      [&](size_t i) { expr.term(i).negate(); });
  }
  return std::move(expr);
}

/// @brief Creates a new Expr object as the negated copy of the input.
inline Expr operator-(const Expr& expr) {
  Expr result{-expr.constant()};
  const size_t n = expr.size();
  if (n < SEQ_THRESHOLD) {
    result.terms().reserve(n);
    for (const auto& term : expr.terms()) {
      result.terms().emplace_back(-term);
    }
  } else {
    result.terms().resize(n);
    tbb::parallel_for(size_t(0), n,
                      [&](size_t i) { result.term(i) = -expr.term(i); });
  }
  return result;
}

// ===== Overload+ for Term and Integer =====
/// @brief Operator+ overload for creating Expr with Term and integer.

template <typename T,
          typename std::enable_if<std::is_integral<T>::value, int>::type>
Expr operator+(const Term& term, T val) {
  return Expr{term, val};
}

/// @brief Operator+ overload for creating Expr with Term and integer.
template <typename T,
          typename std::enable_if<std::is_integral<T>::value, int>::type>
Expr operator+(Term&& term, T val) {
  return Expr{std::move(term), val};
}

/// @brief Operator+ overload for creating Expr with Term and integer.
template <typename T,
          typename std::enable_if<std::is_integral<T>::value, int>::type>
Expr operator+(T val, Term&& term) {
  return Expr{std::move(term), val};
}

/// @brief Operator+ overload for creating Expr with Term and integer.
template <typename T,
          typename std::enable_if<std::is_integral<T>::value, int>::type>
Expr operator+(T val, const Term& term) {
  return Expr{term, val};
}

// ===== Overload+ for Term and Term =====
/// @brief Operator+ overload for creating Expr with two terms.
inline Expr operator+(const Term& lhs, const Term& rhs) {
  return Expr{lhs, rhs};
}

/// @brief Operator+ overload for creating Expr with two terms.
inline Expr operator+(const Term& lhs, Term&& rhs) {
  return Expr{lhs, std::move(rhs)};
}

/// @brief Operator+ overload for creating Expr with two terms.
inline Expr operator+(Term&& lhs, const Term& rhs) {
  return Expr{std::move(lhs), rhs};
}

/// @brief Operator+ overload for creating Expr with two terms.
inline Expr operator+(Term&& lhs, Term&& rhs) {
  return Expr(std::move(lhs), std::move(rhs));
}

inline Expr operator-(const Term& lhs, const Term& rhs) {
  Expr result{lhs};
  result -= rhs;
  return result;
}

inline Expr operator-(const Term& lhs, Term&& rhs) {
  Expr result{lhs};
  result -= std::move(rhs);
  return result;
}
inline Expr operator-(Term&& lhs, const Term& rhs) {
  Expr result{std::move(lhs)};
  result -= rhs;
  return result;
}
inline Expr operator-(Term&& lhs, Term&& rhs) {
  Expr result{std::move(lhs)};
  result -= std::move(rhs);
  return result;
}

/// @brief Operator* overload for creating Expr using Var and Var.
// Expr operator*(Var lhs, Var rhs) { return Expr{Term{lhs, rhs}}; }

/// @brief Operator+ overload for creating Expr using Var and integer.
template <typename T,
          typename std::enable_if<std::is_integral<T>::value, int>::type>
Expr operator+(Var var, T val) {
  return Expr(var, static_cast<energy_t>(val));
}

/// @brief Operator+ overload for creating Expr using Var and integer.
template <typename T,
          typename std::enable_if<std::is_integral<T>::value, int>::type>
Expr operator+(T val, Var var) {
  return var + val;
}

template <typename T,
          typename std::enable_if<std::is_integral<T>::value, int>::type>
Expr operator-(Var var, T val) {
  return Expr(var, static_cast<energy_t>(-val));
}

template <typename T,
          typename std::enable_if<std::is_integral<T>::value, int>::type>
Expr operator-(T val, Var var) {
  return Expr{Term(var, static_cast<coeff_t>(-1)) + val};
}

inline Expr operator+(Var lhs, Var rhs) { return Term(lhs) + Term(rhs); }

inline Expr operator+(const Expr& expr, const Term& term) {
  Expr result = expr;
  return result += term;
}

inline Expr operator+(Expr&& expr, const Term& term) { return expr += term; }

inline Expr operator+(const Expr& expr, Term&& term) {
  Expr result = expr;
  return result += std::move(term);
}

inline Expr operator+(Expr&& expr, Term&& term) {
  return expr += std::move(term);
}

inline Expr operator+(const Term& term, const Expr& expr) {
  Expr result = expr;
  return result += term;
}

inline Expr operator+(const Term& term, Expr&& expr) { return expr += term; }

inline Expr operator+(Term&& term, const Expr& expr) {
  Expr result = expr;
  return result += std::move(term);
}

inline Expr operator+(Term&& term, Expr&& expr) {
  return expr += std::move(term);
}

inline Expr operator-(const Term& term, const Expr& expr) {
  return Expr(term) - expr;
}
inline Expr operator-(Term&& term, const Expr& expr) {
  return Expr(std::move(term)) - expr;
}

inline Expr operator-(const Term& term, Expr&& expr) {
  expr.negate();
  return expr += term;
}
inline Expr operator-(Term&& term, Expr&& expr) {
  expr.negate();
  return expr += std::move(term);
}

inline Expr operator-(const Expr& expr, const Term& term) {
  Expr result = expr;
  return result -= term;
}
inline Expr operator-(Expr&& expr, const Term& term) {
  expr -= term;
  return std::move(expr);
}
inline Expr operator-(const Expr& expr, Term&& term) {
  Expr result = expr;
  return result -= std::move(term);
}
inline Expr operator-(Expr&& expr, Term&& term) {
  expr -= std::move(term);
  return std::move(expr);
}

template <typename T,
          typename std::enable_if<std::is_integral<T>::value, int>::type>
Expr operator-(const Term& term, T val) {
  Expr result(term);
  result -= val;
  return result;
}

template <typename T,
          typename std::enable_if<std::is_integral<T>::value, int>::type>
Expr operator-(Term&& term, T val) {
  Expr result(std::move(term));
  result -= val;
  return result;
}

/// @brief Generates a new expression from the term by replacement defined
/// in MapDict.
/// @param term The term to replace.
/// @param map_dict The dictionary of mappings.
/// @return Expr The new expression generated by replacement.
inline Expr replace(const Term& term, const MapDict& map_dict) {
  Expr result{term.coeff()};
  for (auto item : term.vars()) {
    auto it = map_dict.find(item);
    if (it == map_dict.end()) {
      result *= item;
    } else {
      result *= it->second;
    }
  }
  return result;
}

// --------------------------------------------------
// QuadModel Helper Functions
// --------------------------------------------------

inline std::tuple<bool, size_t, size_t, coeff_t, coeff_t>
check_if_simplified_as_binary(const Expr& expr) {
  if (expr.term_count() == 0) {
    return {false, 0, 0, 0, 0};
  }
  const auto& terms = expr.terms();
  bool error = false;
  size_t linear_count = 0;
  coeff_t min_coeff = terms[0].coeff();
  coeff_t max_coeff = terms[0].coeff();
  std::mutex mtx;

  tbb::parallel_for(
      tbb::blocked_range<size_t>(0, terms.size()),
      [&](const tbb::blocked_range<size_t>& range) {
        coeff_t local_min = min_coeff;
        coeff_t local_max = max_coeff;
        for (size_t i = range.begin(); i < range.end(); ++i) {
          const auto& term = terms[i];

          if (local_min > term.coeff()) local_min = term.coeff();
          if (local_max < term.coeff()) local_max = term.coeff();

          if (term.var_count() == 0 || term.var_count() >= 3) {
            error = true;
            return;
          }
          if (term.var_count() == 2 && term.vars()[1] <= term.vars()[0]) {
            error = true;
            return;
          }

          if (i > 0) {
            if (term <= terms[i - 1]) {
              error = true;
              return;
            }
            if (terms[i - 1].var_count() == 1 && term.var_count() == 2) {
              linear_count = i;
            }
          }
        }

        std::lock_guard<std::mutex> lock(mtx);
        if (local_min < min_coeff) min_coeff = local_min;
        if (local_max > max_coeff) max_coeff = local_max;
      });

  if (terms.back().var_count() == 1) {
    linear_count = terms.size();
  }
  return {error, linear_count, terms.size() - linear_count, min_coeff,
          max_coeff};
}

// -------------------------------------------------
// Class HuboModel member functions
// -------------------------------------------------

template <size_t K, class Model, class Term, class Buckets>
inline void add_term_rotations(const Model& model, const Term& term,
                               Buckets& buckets) {
  static_assert(K >= 2, "K must be >= 2");
  for (vindex_t i = 0; i < K; ++i) {
    // If primary variable is negated, negate the coefficient
    coeff_t coeff = term.coeff();
    if (term.var(i).index() & qbpp::vindex_neg_bit) {
      coeff = -coeff;
    }
    vindex_t idx[K - 1];
    for (vindex_t j = 0; j < K - 1; ++j) {
      vindex_t var_pos = (i + 1 + j) % K;
      vindex_t dense_idx = model.index(term.var(var_pos));
      // If secondary variable is negated, set MSB of stored index
      if (term.var(var_pos).index() & qbpp::vindex_neg_bit) {
        dense_idx |= qbpp::vindex_neg_bit;
      }
      idx[j] = dense_idx;
    }
    buckets[model.index(term.var(i))].emplace_back(idx, coeff);
  }
}

inline HuboModel::all_hubo_terms HuboModel::helper_func(
    const qbpp::Model& model) {
  uint32_t max_power = 0;
  std::vector<qbpp::coeff_t> term1(model.var_count(), 0);
  std::vector<TermVector<1>> term2(model.var_count());
  std::vector<TermVector<2>> term3(model.var_count());
  std::vector<TermVector<3>> term4(model.var_count());

  for (const auto& term : model.expr().terms()) {
    if (term.var_count() > max_power) {
      max_power = term.var_count();
    }
    switch (term.var_count()) {
      case 0:
        break;
      case 1:
        if (term.coeff() != 0) {
          if (term.var(0).index() & qbpp::vindex_neg_bit) {
            term1[model.index(Var(term.var(0).index() & qbpp::vindex_mask))] -=
                term.coeff();
          } else {
            term1[model.index(term.var(0))] += term.coeff();
          }
        }
        break;
      case 2:
        add_term_rotations<2>(model, term, term2);
        break;
      case 3:
        add_term_rotations<3>(model, term, term3);
        break;
      case 4:
        add_term_rotations<4>(model, term, term4);
        break;
      default:
        break;
    }
  }

  // Build DynTermVectors directly for degree > 4.
  // Terms are sorted by var_count (simplify_as_binary), so same-degree terms
  // are contiguous. Two-pass: count entries per variable, then fill.
  std::vector<std::vector<DynTermVector>> dyn_terms(model.var_count());
  if (max_power > 4) {
    const auto& expr_terms = model.expr().terms();
    size_t t = 0;
    while (t < expr_terms.size() && expr_terms[t].var_count() <= 4) ++t;
    while (t < expr_terms.size()) {
      const uint32_t K = expr_terms[t].var_count();
      const uint32_t dm1 = K - 1;
      const size_t group_start = t;
      while (t < expr_terms.size() && expr_terms[t].var_count() == K) ++t;
      const size_t group_end = t;

      // Pass 1: count entries per variable
      std::vector<uint32_t> entry_count(model.var_count(), 0);
      for (size_t j = group_start; j < group_end; ++j)
        for (vindex_t v = 0; v < K; ++v)
          entry_count[model.index(expr_terms[j].var(v))]++;

      // Allocate DynTermVectors with exact sizes
      std::vector<DynTermVector*> dtv_ptr(model.var_count(), nullptr);
      std::vector<uint32_t> cursor(model.var_count(), 0);
      for (vindex_t i = 0; i < model.var_count(); ++i) {
        if (entry_count[i] > 0) {
          dyn_terms[i].emplace_back(entry_count[i], dm1);
          dtv_ptr[i] = &dyn_terms[i].back();
        }
      }

      // Pass 2: fill data (rotation: each variable stores the other K-1 indices)
      for (size_t j = group_start; j < group_end; ++j) {
        const auto& et = expr_terms[j];
        for (vindex_t vi = 0; vi < K; ++vi) {
          vindex_t var_idx = model.index(et.var(vi));
          uint32_t pos = cursor[var_idx]++;
          // If primary variable is negated, negate the coefficient
          coeff_t coeff = et.coeff();
          if (et.var(vi).index() & qbpp::vindex_neg_bit) {
            coeff = -coeff;
          }
          dtv_ptr[var_idx]->coeffs_[pos] = coeff;
          vindex_t* dest =
              dtv_ptr[var_idx]->indices_.get() + static_cast<size_t>(pos) * dm1;
          for (uint32_t jj = 0; jj < dm1; ++jj) {
            vindex_t var_pos = (vi + 1 + jj) % K;
            vindex_t dense_idx = model.index(et.var(var_pos));
            // If secondary variable is negated, set MSB
            if (et.var(var_pos).index() & qbpp::vindex_neg_bit) {
              dense_idx |= qbpp::vindex_neg_bit;
            }
            dest[jj] = dense_idx;
          }
        }
      }
    }
  }

  // coeff_sum[i] = sum of stored coefficients for bucket i where all secondary
  // indices are non-negated (MSB=0). This represents the delta at all-ones
  // state: delta_[i] = -coeff_sum[i].
  // At all-ones, negated secondaries have effective value 0 → term contributes 0.
  std::vector<energy_t> coeff_sum(model.var_count(), 0);
  for (vindex_t i = 0; i < model.var_count(); ++i) {
    coeff_sum[i] = term1[i];
    for (size_t j = 0; j < term2[i].size(); ++j) {
      if (!(term2[i].indices(j)[0] & qbpp::vindex_neg_bit))
        coeff_sum[i] += term2[i].coeff(j);
    }
    for (size_t j = 0; j < term3[i].size(); ++j) {
      const auto& inds = term3[i].indices(j);
      if (!(inds[0] & qbpp::vindex_neg_bit) && !(inds[1] & qbpp::vindex_neg_bit))
        coeff_sum[i] += term3[i].coeff(j);
    }
    for (size_t j = 0; j < term4[i].size(); ++j) {
      const auto& inds = term4[i].indices(j);
      if (!(inds[0] & qbpp::vindex_neg_bit) &&
          !(inds[1] & qbpp::vindex_neg_bit) &&
          !(inds[2] & qbpp::vindex_neg_bit))
        coeff_sum[i] += term4[i].coeff(j);
    }
    for (const auto& dtv : dyn_terms[i]) {
      const uint32_t nm1 = dtv.degree_minus_one();
      const vindex_t* dbase = dtv.indices_data();
      for (uint32_t j = 0; j < dtv.count_; ++j) {
        const vindex_t* idx = dbase + static_cast<size_t>(j) * nm1;
        bool all_non_neg = true;
        for (uint32_t k = 0; k < nm1; ++k) {
          if (idx[k] & qbpp::vindex_neg_bit) { all_non_neg = false; break; }
        }
        if (all_non_neg) coeff_sum[i] += dtv.coeffs_[j];
      }
    }
  }

  // all_coeff_sum = energy at all-ones state.
  // Only terms with ALL non-negated variables contribute (negated vars are 0).
  energy_t all_coeff_sum = model.constant();
  for (const auto& term : model.expr().terms()) {
    bool any_neg = false;
    for (const auto& var : term.vars()) {
      if (var.index() & qbpp::vindex_neg_bit) { any_neg = true; break; }
    }
    if (!any_neg) all_coeff_sum += term.coeff();
  }

  return std::make_tuple(
      max_power, model.constant(), std::move(term1), std::move(term2),
      std::move(term3), std::move(term4), all_coeff_sum,
      std::move(coeff_sum), std::move(dyn_terms));
}

inline std::string HuboModel::str() const {
  std::ostringstream oss;
  bool is_first = true;
  oss << "(constant) " << constant() << "\n";
  for (vindex_t i = 0; i < term1_.size(); ++i) {
    if (term1_[i] != 0) {
      if (is_first) {
        oss << "(degree 1)\n";
        is_first = false;
      }
      oss << var(i) << "*" << term1_[i] << "\n";
    }
  }
  is_first = true;
  for (vindex_t i = 0; i < term2_.size(); ++i) {
    auto& t2 = term2_[i];
    for (size_t j = 0; j < t2.size(); ++j) {
      if (is_first) {
        oss << "(degree 2)\n";
        is_first = false;
      }
      oss << var(i) << "*" << var(t2.indices(j)[0]) << "*" << t2.coeff(j)
          << "\n";
    }
  }
  is_first = true;
  for (vindex_t i = 0; i < term3_.size(); ++i) {
    auto& t3 = term3_[i];
    for (size_t j = 0; j < t3.size(); ++j) {
      if (is_first) {
        oss << "(degree 3)\n";
        is_first = false;
      }
      oss << var(i) << "*" << var(t3.indices(j)[0]) << "*"
          << var(t3.indices(j)[1]) << "*" << t3.coeff(j) << "\n";
    }
  }
  return oss.str();
}

// -------------------------------------------------
// Not functions
// -------------------------------------------------

inline Var operator~(const Var& var) {
  return Var(var.index() ^ qbpp::vindex_neg_bit);
}

// -------------------------------------------------
// Other global function
// -------------------------------------------------

/// @brief Returns the time in seconds since the first call to this
/// function.
/// @return Elapsed time in seconds since the first call.
inline double time() {
  static const auto start_ = std::chrono::high_resolution_clock::now();
  auto elapsed = std::chrono::high_resolution_clock::now() - start_;
  return std::chrono::duration<double>(elapsed).count();
}

/// @brief Returns a Vector of Expr objects from a Vector of ExprExpr object
/// using the operator*.
/// @note This function handles multi-level nested vectors by recursion.
template <typename T>
auto operator*(const Vector<T>& arg) {
  using ResultType = std::decay_t<decltype(*arg[0])>;
  Vector<ResultType> result(arg.size());
  tbb::parallel_for(size_t(0), arg.size(),
                    [&](size_t i) { result[i] = *arg[i]; });
  return result;
}

/// @brief The operator* overload for the Vector of two Var objects
/// @note This function is used to access the operator* for the Var objects
inline Vector<Expr> operator*(const Vector<Var>& lhs, const Vector<Var>& rhs) {
  Vector<Expr> result;
  result.resize(lhs.size());
  for (size_t i = 0; i < lhs.size(); ++i) {
    result.push_back(qbpp::Expr(qbpp::Term(lhs[i], rhs[i])));
  }
  return result;
}

// QueueSet related functions
inline void queueset_capacity(uint32_t capacity) {
  qbpp_queueset_capacity(capacity);
}

inline size_t queueset_size() { return qbpp_queueset_size(); }

inline bool queueset_has(const BitVector& bv) {
  return qbpp_queueset_has(static_cast<const void*>(bv.impl())) == 1;
}

inline bool queueset_insert(const BitVector& bv) {
  return qbpp_queueset_insert(static_cast<const void*>(bv.impl())) == 1;
}

}  // namespace qbpp
