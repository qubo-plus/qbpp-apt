/// @file qbpp_misc.hpp
/// @author Koji Nakano
/// @brief A miscellaneous library used for sample programs of the QUBO++
/// library.
/// @details This library includes miscellaneous classes and functions used for
/// sample programs of the QUBO++ library. The classes include random number
/// generators and graph drawing functions.
/// @copyright 2026, Koji Nakano
/// @version 2026.02.06

#pragma once

#include <algorithm>
#include <cassert>
#include <boost/random/taus88.hpp>
#include <boost/random/uniform_int_distribution.hpp>
#include <boost/random/uniform_real_distribution.hpp>
#include <cmath>
#include <iostream>
#include <numeric>
#include <random>
#include <set>
#include <sstream>
#include <vector>

#include "qbpp.hpp"

extern "C" {
void* qbpp_tabu_create(qbpp::vindex_t var_count, qbpp::vindex_t tabu_capacity);
void qbpp_tabu_destroy(void* tabu);
qbpp::vindex_t qbpp_tabu_capacity(const void* tabu);
uint8_t qbpp_tabu_has(const void* tabu, qbpp::vindex_t index);
uint8_t qbpp_tabu_insert(void* tabu, qbpp::vindex_t index, bool must_be_new);
qbpp::vindex_t qbpp_non_tabu_random(const void* tabu);
}

namespace qbpp {
/// @brief Namespace for miscellaneous classes and functions used for QUBO++
/// library
namespace misc {

struct PcloseDeleter {
  void operator()(FILE* file) const {
    if (file) pclose(file);
  }
};

// @brief Class to manipulate a set from which an variable index can be
/// randomly selected with equal probability.
/// @details This set is a subset of variable indices from 0 to size-1. It
/// has member functions:
/// - insert() : inserts an variable index in O(1) time complexity.
/// - erase() : erases an variable index in O(1) time complexity.
/// - has() : checks if the variable index is in the set in O(1) time
/// complexity.
/// - select_at_random() : gets a random variable index with uniform
/// probability in O(1) time complexity.
///
///  This class is used in RandomMinSet.

class RandomSet {
  /// @brief A vector storing the positions of variables_ in the set.
  /// @details position_[i] holds the position_ of the variable with index i
  /// in the std::vector `variables_`. If a variable is not present in
  /// `variables_`, its position_[i] is set to `vindex_limit`. In other words,
  /// `variables_[position_[i]] == i` if `position_[i] != vindex_limit`.
  std::vector<vindex_t> position_;

  /// @brief A vector of variables_ in the set.
  /// @details variables_[i] stores the index of the variable.
  std::vector<vindex_t> variables_;

 public:
  /// @brief Constructor to create a RandomSet object with the specified size.
  /// @param size The size of the set.
  explicit RandomSet(vindex_t size) : position_(size, vindex_limit) {
    variables_.reserve(size);
  }

  /// @brief Gets the number of variables_ in the set.
  /// @return int The number of variables_ in the set.
  vindex_t var_count() const {
    return static_cast<vindex_t>(variables_.size());
  }

  /// @brief Inserts an variable into the set.
  /// @param index The variable index to be inserted.
  /// @throw std::runtime_error if the variable is already in the set.
  void insert(vindex_t index) {
    if (position_[index] != vindex_limit) {
      throw std::runtime_error(THROW_MESSAGE("RandomSet: Insert variable (",
                                             index, ") already in set"));
    }
    variables_.push_back(index);
    position_[index] = static_cast<vindex_t>(variables_.size() - 1);
  }

  /// @brief Swaps two variables_ in the set.
  /// @param pos1 The position of the first variable.
  /// @param pos2 The position of the second variable.
  /// @note variables_ are swapped and positions are updated accordingly.
  void swap(vindex_t pos1, vindex_t pos2) {
    if (pos1 == pos2) return;
    std::swap(variables_[pos1], variables_[pos2]);
    position_[variables_[pos1]] = pos1;
    position_[variables_[pos2]] = pos2;
  }

  /// @brief Erases an variable from the set.
  /// @param index The variable index to be erased.
  /// @throw std::runtime_error if the variable is not in the set.
  void erase(vindex_t index) {
    if (position_[index] == vindex_limit) {
      throw std::runtime_error(
          THROW_MESSAGE("RandomSet: Erase variable (", index, ") not in set"));
    }
    swap(position_[index], var_count() - 1);
    variables_.pop_back();
    position_[index] = vindex_limit;
  }

  /// @brief Checks if an variable is in the set.
  /// @param index The variable to be checked.
  /// @return bool True if the variable is in the set; false otherwise.
  bool has(vindex_t index) const { return position_[index] != vindex_limit; }

  /// @brief Selects a random variable from the set.
  /// @return vindex_t The randomly selected variable.
  vindex_t select_at_random() const {
    assert(!variables_.empty());
    return variables_[qbpp::random_gen(var_count())];
  }

  /// @brief Prints the set. Debug purpose.
  /// @param prefix The prefix string to be printed before the variables_.
  void print(const std::string& prefix = "") const {
    std::cout << prefix << " Size = " << var_count() << " : ";
    for (vindex_t i = 0; i < var_count(); ++i) {
      std::cout << " " << variables_[i];
    }
    std::cout << std::endl;
  }
};

/// @brief Class to store a set of variable indices ordered by their delta
/// values.
/// @details The set stores pairs of delta values and variable indices.
/// It is ordered by (delta value, variable index). Thus, if multiple variable
/// indices have the same delta value, the one with the smallest index is
/// considered first.
///
/// This class provides the following member functions:
/// - insert() : Inserts a variable index with O(log n) time complexity.
/// - erase() : Erases a variable index with O(log n) time complexity.
/// - first() : Retrieves the first variable index with the minimum delta
/// value with O(1) time complexity.
///
/// This class is used in RandomMinSet.
template <typename T = energy_t>
class MinSet {
  /// @brief A std::set to store a pair of a delta value and a variable index.
  /// @details Since the set is ordered by the delta value, the minimum delta
  /// value can be obtained by the begin() function efficiently.
  //  using ValIndexMap = std::set<std::pair<energy_t, vindex_t>>;

  using ValIndexMap = std::set<std::pair<T, vindex_t>>;

  /// @brief A set to store a pair of a delta value and a variable index.
  ValIndexMap set_;

 public:
  /// @brief Default constructor to create an empty MinSet object.
  MinSet() = default;

  /// @brief Returns the number of variables in the set_.
  vindex_t var_count() const { return static_cast<vindex_t>(set_.size()); }

  /// @brief Inserts a variable index into the set_.
  /// @param index The variable index to be inserted.
  /// @param delta The delta value of the variable.
  /// @throw std::runtime_error if the variable is already in the set.
  void insert(vindex_t index, T delta) {
    auto tuple_val = std::make_pair(delta, index);
    auto result = set_.insert(tuple_val);
    if (!result.second) {
      throw std::runtime_error(THROW_MESSAGE("MinSet: Insert variable (", index,
                                             ") already in set"));
    }
  }

  /// @brief Erases an variable from the set_.
  /// @param index The variable to be erased.
  /// @param delta The delta value of the variable.
  /// @throw std::runtime_error if the variable is not in the set_.
  void erase(vindex_t index, T delta) {
    auto pair_val = std::make_pair(delta, index);
    auto result = set_.erase(pair_val);
    if (result == 0) {
      throw std::runtime_error(
          THROW_MESSAGE("MinSet: Erase variable (", index, ") not in set"));
    }
  }

  /// @brief Retuns the variable index with the minimum delta value.
  /// @return The variable index with the minimum delta value. If multiple
  /// variable take the same delta value, the minimum index of them is
  /// returned.
  vindex_t first() const {
    if (set_.empty()) {
      throw std::runtime_error(THROW_MESSAGE("MinSet: Empty set"));
    }
    return (*set_.begin()).second;
  }

  std::pair<T, vindex_t> min() const {
    if (set_.empty()) {
      throw std::runtime_error(THROW_MESSAGE("MinSet: Empty set"));
    }
    return *set_.begin();
  }

  bool empty() const { return set_.empty(); }

  /// @brief prints the set_. Debug purpose.
  void print(const std::string& prefix) const {
    std::cout << prefix;
    for (auto& [val, i] : set_) {
      if constexpr (std::is_same_v<T, energy_t>) {
        std::cout << "(" << i << "," << val << ")";
      } else {
        std::cout << "(" << i << "," << val.constraint_delta() << ","
                  << val.objective_delta() << ")";
      }
    }
    std::cout << std::endl;
  }
};

/// @brief Class to store a set of variable indices ordered by their delta
/// values.
/// @details The set stores pairs of delta values and variable indices.
/// This class supports the following member functions:
/// - insert() : Inserts a variable index with O(log n) time complexity.
/// - erase() : Erases a variable index with O(log n) time complexity.
/// - first() : Retrieves the first variable index with the minimum delta
/// value with O(1) time complexity.
template <typename T = energy_t>
class MinHeap {
  /// @brief The heap to store the deltas of variables.
  std::vector<std::pair<T, vindex_t>> heap_;
  /// @brief The index of variables in the heap.
  std::vector<vindex_t> index_;

  /// @brief Inserts a variable index with delta into the heap.
  void emplace_back(vindex_t index, T delta) {
    heap_.emplace_back(std::make_pair(delta, index));
    index_[index] = heap_size() - 1;
  }

  /// @brief Swaps the variables at the specified indices in the heap.
  void swap_heap(vindex_t i, vindex_t j) {
    std::swap(heap_[i], heap_[j]);
    index_[heap_[i].second] = i;
    index_[heap_[j].second] = j;
  }

  /// @brief Bubbles up the variable at the specified index.
  void bubble_up(vindex_t i) {
    while (i > 0) {
      vindex_t parent = (i - 1) / 2;
      if (heap_[i] < heap_[parent]) {
        swap_heap(i, parent);
        i = parent;
      } else {
        break;
      }
    }
  }

  /// @brief Bubbles down the variable at the specified index.
  void bubble_down(vindex_t i) {
    while (true) {
      vindex_t left = 2 * i + 1;
      vindex_t right = 2 * i + 2;
      vindex_t smallest = i;

      if (left < heap_size() && heap_[left] < heap_[smallest]) {
        smallest = left;
      }
      if (right < heap_size() && heap_[right] < heap_[smallest]) {
        smallest = right;
      }
      if (smallest != i) {
        swap_heap(i, smallest);
        // To ensure that first() returns the smallest index the following
        // line is necessary.
        i = smallest;
      } else {
        break;
      }
    }
  }

 public:
  /// @brief Constructs a MinHeap object with the specified size.
  /// @param size The variable size.
  MinHeap(size_t size) : index_(size, vindex_limit) {}

  /// @brief Returns the number of variables in the heap.
  vindex_t heap_size() const { return static_cast<vindex_t>(heap_.size()); }

  const std::vector<std::pair<T, vindex_t>>& heap() const { return heap_; }

  void clear() {
    heap_.clear();
    std::fill(index_.begin(), index_.end(), vindex_limit);
  }

  std::pair<T, vindex_t> min() const {
    if (heap_.empty()) {
      throw std::runtime_error(THROW_MESSAGE("MinHeap: Empty heap"));
    }
    return heap_[0];
  }

  /// @brief Returns the variable index with the minimum delta value.
  vindex_t first() const {
    if (heap_.empty()) {
      throw std::runtime_error(THROW_MESSAGE("MinHeap: Empty heap"));
    }
    return heap_[0].second;
  }

  vindex_t pop_first() {
    if (heap_.empty()) {
      throw std::runtime_error(THROW_MESSAGE("MinHeap: Empty heap"));
    }
    vindex_t index = heap_[0].second;
    erase(index);
    return index;
  }

  bool has(vindex_t index) const { return index_[index] != vindex_limit; }

  bool empty() const { return heap_.empty(); }

  vindex_t select_at_random() const {
    assert(!heap_.empty());
    return heap_[qbpp::random_gen(heap_size())].second;
  }

  /// @brief Inserts a variable index with delta into the heap.
  void insert(vindex_t index, T delta) {
    if (index_[index] != vindex_limit) {
      throw std::runtime_error(THROW_MESSAGE("MinHeap: Insert variable (",
                                             index,
                                             ") already in "
                                             "heap"));
    }
    emplace_back(index, delta);
    bubble_up(heap_size() - 1);
  }

  /// @brief Erases a variable from the heap.
  void erase(vindex_t index) {
    vindex_t i = index_[index];
    if (i == vindex_limit) {
      throw std::runtime_error(THROW_MESSAGE("MinHeap: Erase variable (", index,
                                             ") not in "
                                             "heap"));
    }
    swap_heap(i, heap_size() - 1);
    heap_.pop_back();
    index_[index] = vindex_limit;
    if (i < heap_size()) {
      bubble_up(i);
      bubble_down(i);
    }
  }

  /// @brief Prints the heap. Debug purpose.
  void print(const std::string& prefix) const {
    std::cout << prefix;
    for (auto& [delta, i] : heap_) {
      std::cout << "(" << i << "," << delta << ")";
    }
    std::cout << std::endl;
  }
};

/// @brief Class to store a set_ of variables_ ordered by delta values and
/// randomly returns a variable index.
/// @details This class combines the RandomSet and MinSet classes. Hence, in
/// addition to the member functions of MinSet, it also provides the following
/// member functions:
/// - select_at_random() : Returns a variable index randomly with uniform at
/// random.
///
/// Since MinSet is used, if multiple variables_ take the same minimum delta,
/// the minimum variable index is selected.
/// @see RandomSet, MinSet
template <typename T = energy_t>
class RandomMinSet {
  /// @brief A set_ of variables_ to pick the minimum delta value.
  MinSet<T> min_set_;
  /// @brief A set_ of variables_ to pick a variable at random.
  RandomSet random_set_;

 public:
  /// @brief Constructs a RandomMinSet object with the specified size.
  /// @param size The size of the set_.
  /// @details The size is passed to the RandomSet.
  RandomMinSet(vindex_t size) : random_set_(size) {};

  /// @brief Returns the number of variables_ in the set_.
  /// @return int The number of variables_ in the set_.
  vindex_t var_count() const {
    return static_cast<vindex_t>(min_set_.var_count());
  }

  /// @brief Inserts a variable into the set_.
  /// @param index The variable index to be inserted.
  /// @param delta The delta value of the variable.
  void insert(vindex_t index, T delta) {
    min_set_.insert(index, delta);
    random_set_.insert(index);
  }

  /// @brief Erases a variable from the set_.
  /// @param index The variable index to be erased.
  /// @param delta The delta val  ue of the variable.
  void erase(vindex_t index, T delta) {
    min_set_.erase(index, delta);
    random_set_.erase(index);
  }

  /// @brief Checks if a variable is in the set_.
  /// @param index The variable index to be checked.
  /// @return bool True if the variable is in the set_; false otherwise.
  bool has(vindex_t index) const { return random_set_.has(index); }

  /// @brief Returns a variable index in the set_ uniformly at random.
  /// @return vindex_t The randomly selected variable index.
  vindex_t select_at_random() const { return random_set_.select_at_random(); }

  /// @brief Returns the variable index with the minimum delta value.
  /// @return vindex_t The variable index with the minimum delta value.
  vindex_t first() const { return min_set_.first(); }

  std::pair<T, vindex_t> min() const { return min_set_.min(); }

  bool empty() const { return min_set_.empty(); }

  /// @brief Prints the set_. Debug purpose.
  /// @param prefix The prefix string to be printed before the variables_.
  void print(const std::string& prefix) const {
    min_set_.print(prefix + " MIN:");
    random_set_.print(prefix + "RANDOM:");
  }
};

/// @brief Class to manage a tabu list for variable indices.
/// @details This class provides member functions to create and manage a tabu
/// listclass
class Tabu {
  void* impl_;

  // Disallow copy and move operations
  Tabu(const Tabu&) = delete;
  Tabu& operator=(const Tabu&) = delete;
  Tabu(Tabu&&) = delete;
  Tabu& operator=(Tabu&&) = delete;

 public:
  explicit Tabu(vindex_t var_count, vindex_t tabu_capacity) {
    impl_ = qbpp_tabu_create(var_count, tabu_capacity);
  }

  ~Tabu() { qbpp_tabu_destroy(impl_); }

  vindex_t capacity() const { return qbpp_tabu_capacity(impl_); }

  bool has(vindex_t index) const { return qbpp_tabu_has(impl_, index) == 1; }

  bool insert(vindex_t index, bool must_be_new) {
    return qbpp_tabu_insert(impl_, index, must_be_new) == 1;
  }

  bool insert(vindex_t index) { return qbpp_tabu_insert(impl_, index, false); }

  vindex_t non_tabu_random() const { return qbpp_non_tabu_random(impl_); }
};

inline std::string to_text(const HuboModel& arg, bool with_header = false) {
  std::ostringstream oss;

  if (with_header) {
    oss << "# 1st line: number of variables\n"
        << "# Remaining lines: each line represents a term as\n"
        << "#   coefficient [var_index ...]\n"
        << "# A line with only a coefficient denotes a constant term.\n";
  }

  oss << arg.var_count() << "\n";

  if (arg.constant() != 0) {
    oss << arg.constant() << "\n";
  }

  for (const auto& term : arg.terms()) {
    oss << term.coeff();
    for (vindex_t j = 0; j < term.var_count(); ++j) {
      oss << " " << arg.index(term.var(j));
    }
    oss << "\n";
  }

  return oss.str();
}

}  // namespace misc
}  // namespace qbpp
