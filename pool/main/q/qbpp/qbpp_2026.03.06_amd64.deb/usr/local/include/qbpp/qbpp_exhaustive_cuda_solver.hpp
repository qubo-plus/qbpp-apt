/// @file qbpp_exhaustive_cuda_solver.hpp
/// @brief Header file for the ExhaustiveCudaSolver
/// @details GPU-accelerated exhaustive search for HUBO/QUBO problems.
///          Uses Gray code traversal with delta-based energy updates on CUDA.
///          Binary distribution via dlopen, same pattern as ABS3/PowerSolver.
/// @author Koji Nakano
/// @version 2026.03.01

#pragma once

#include <dlfcn.h>

#include "qbpp.hpp"

#ifndef QBPP_EXCUDA_MAXPARAM
#define QBPP_EXCUDA_MAXPARAM 100
#endif

namespace qbpp {
namespace exhaustive_cuda {

class ExhaustiveCudaSolver;

/// @brief Parameter container for ExhaustiveCudaSolver
/// @details Stores key-value string pairs for passing parameters across
/// the .so boundary. Uses C strings for ABI safety.
/// Supported parameters:
///   - "target_energy": Stop when energy reaches this value (optional)
///   - "verbose": Verbosity level 0/1 (default: 0)
///   - "block_count": Override block count (default: auto)
///   - "thread_count": Override thread count per block (default: 128)
///   - "parallel_param": Number of top variables to split across blocks
///                       (default: auto based on SM count)
///   - "search_optimal": "true" to collect all optimal solutions (2-pass)
///   - "enable_callback": "true" to enable callback on best solution found
class Params {
  struct Pair {
    char* key;
    char* value;
  };
  Pair pairs_[QBPP_EXCUDA_MAXPARAM];

  Params(const Params&) = delete;
  Params(Params&&) = delete;
  Params& operator=(const Params&) = delete;
  Params& operator=(Params&&) = delete;

 public:
  Params() {
    for (int i = 0; i < QBPP_EXCUDA_MAXPARAM; i++) {
      pairs_[i].key = nullptr;
      pairs_[i].value = nullptr;
    }
  }

  ~Params() {
    for (int i = 0; i < QBPP_EXCUDA_MAXPARAM; i++) {
      if (pairs_[i].key != nullptr) {
        free(pairs_[i].key);
        pairs_[i].key = nullptr;
      }
      if (pairs_[i].value != nullptr) {
        free(pairs_[i].value);
        pairs_[i].value = nullptr;
      }
    }
  }

  void operator()(const char* key, const std::string& value) {
    add(key, value.c_str());
  }

  void add(const char* key, const std::string& value) {
    add(key, value.c_str());
  }

  void add(const char* key, const char* value) {
    if (pairs_[QBPP_EXCUDA_MAXPARAM - 1].key != nullptr) {
      throw std::runtime_error("Param overflow");
    }
    for (int i = 0; i < QBPP_EXCUDA_MAXPARAM; i++) {
      if (pairs_[i].key == nullptr && pairs_[i].value == nullptr) {
        pairs_[i].key = strdup(key);
        if (pairs_[i].key == nullptr) {
          throw std::runtime_error("strdup failed");
        }
        pairs_[i].value = strdup(value);
        if (pairs_[i].value == nullptr) {
          throw std::runtime_error("strdup failed");
        }
        break;
      }
    }
  }

  const Pair pairs(size_t i) const { return pairs_[i]; }
};

/// @brief ABI-safe solution container for ExhaustiveCudaSolver
/// @details All members are pointers for safe passing across .so boundary.
class ExhaustiveCudaSol {
  qbpp::vindex_t* var_count_ptr_;
  qbpp::vindex_t* size64_ptr_;
  uint64_t* id_ptr_;
  qbpp::energy_t* energy_ptr_;
  uint64_t* bitarray_;
  double* tts_ptr_;
  qbpp::vindex_t* popcount_ptr_;

 public:
  ExhaustiveCudaSol(qbpp::vindex_t var_count) {
    var_count_ptr_ = new qbpp::vindex_t;
    size64_ptr_ = new qbpp::vindex_t;
    *var_count_ptr_ = var_count;
    *size64_ptr_ = (var_count + 63) / 64;
    id_ptr_ = new uint64_t;
    energy_ptr_ = new qbpp::energy_t;
    bitarray_ = new uint64_t[*size64_ptr_];
    std::fill(bitarray_, bitarray_ + *size64_ptr_, 0ULL);
    tts_ptr_ = new double;
    popcount_ptr_ = new qbpp::vindex_t;
  }

  ExhaustiveCudaSol(const ExhaustiveCudaSol&) = delete;
  ExhaustiveCudaSol& operator=(const ExhaustiveCudaSol&) = delete;

  ExhaustiveCudaSol(ExhaustiveCudaSol&& other) noexcept
      : var_count_ptr_(other.var_count_ptr_),
        size64_ptr_(other.size64_ptr_),
        id_ptr_(other.id_ptr_),
        energy_ptr_(other.energy_ptr_),
        bitarray_(other.bitarray_),
        tts_ptr_(other.tts_ptr_),
        popcount_ptr_(other.popcount_ptr_) {
    other.var_count_ptr_ = nullptr;
    other.size64_ptr_ = nullptr;
    other.id_ptr_ = nullptr;
    other.energy_ptr_ = nullptr;
    other.bitarray_ = nullptr;
    other.tts_ptr_ = nullptr;
    other.popcount_ptr_ = nullptr;
  }

  ExhaustiveCudaSol& operator=(ExhaustiveCudaSol&& other) noexcept {
    if (this != &other) {
      delete var_count_ptr_;
      delete size64_ptr_;
      delete id_ptr_;
      delete energy_ptr_;
      delete[] bitarray_;
      delete tts_ptr_;
      delete popcount_ptr_;
      var_count_ptr_ = other.var_count_ptr_;
      size64_ptr_ = other.size64_ptr_;
      id_ptr_ = other.id_ptr_;
      energy_ptr_ = other.energy_ptr_;
      bitarray_ = other.bitarray_;
      tts_ptr_ = other.tts_ptr_;
      popcount_ptr_ = other.popcount_ptr_;
      other.var_count_ptr_ = nullptr;
      other.size64_ptr_ = nullptr;
      other.id_ptr_ = nullptr;
      other.energy_ptr_ = nullptr;
      other.bitarray_ = nullptr;
      other.tts_ptr_ = nullptr;
      other.popcount_ptr_ = nullptr;
    }
    return *this;
  }

  ~ExhaustiveCudaSol() {
    delete var_count_ptr_;
    delete size64_ptr_;
    delete id_ptr_;
    delete energy_ptr_;
    delete[] bitarray_;
    delete tts_ptr_;
    delete popcount_ptr_;
  }

  uint64_t& id() { return *id_ptr_; }
  const uint64_t& id() const { return *id_ptr_; }

  qbpp::energy_t& energy() { return *energy_ptr_; }
  const qbpp::energy_t& energy() const { return *energy_ptr_; }

  uint64_t* bitarray() { return bitarray_; }
  const uint64_t* bitarray() const { return bitarray_; }

  uint64_t& bitarray(size_t i) { return bitarray_[i]; }
  const uint64_t& bitarray(size_t i) const { return bitarray_[i]; }

  double& tts() { return *tts_ptr_; }
  const double& tts() const { return *tts_ptr_; }

  qbpp::vindex_t& popcount() { return *popcount_ptr_; }
  const qbpp::vindex_t& popcount() const { return *popcount_ptr_; }

  bool get(qbpp::vindex_t index) const {
    assert(index < *var_count_ptr_);
    return (bitarray_[index / 64] & (1ULL << (index % 64))) != 0;
  }

  void set(qbpp::vindex_t index, bool value) {
    assert(index < *var_count_ptr_);
    if (value) {
      bitarray_[index / 64] |= (1ULL << (index % 64));
    } else {
      bitarray_[index / 64] &= ~(1ULL << (index % 64));
    }
  }

  bool flip(qbpp::vindex_t index) {
    assert(index < *var_count_ptr_);
    bitarray_[index / 64] ^= (1ULL << (index % 64));
    return get(index);
  }
};

// ===================================
// dlopen自動ディスパッチ
// ===================================

namespace detail {

/// @brief sizeof(coeff_t) と sizeof(energy_t) から .so ファイル名を決定
inline const char* lib_name() {
  constexpr size_t cs = sizeof(coeff_t);
  constexpr size_t es = sizeof(energy_t);
  if constexpr (cs == 2 && es == 4) return "libexhaustive_cudac16e32.so";
  if constexpr (cs == 4 && es == 4) return "libexhaustive_cudac32e32.so";
  if constexpr (cs == 4 && es == 8) return "libexhaustive_cudac32e64.so";
  if constexpr (cs == 8 && es == 8) return "libexhaustive_cudac64e64.so";
  if constexpr (cs == 8 && es == 16) return "libexhaustive_cudac64e128.so";
  if constexpr (cs == 16 && es == 16) return "libexhaustive_cudac128e128.so";
  static_assert(
      (cs == 2 && es == 4) || (cs == 4 && es == 4) || (cs == 4 && es == 8) ||
          (cs == 8 && es == 8) || (cs == 8 && es == 16) ||
          (cs == 16 && es == 16),
      "No ExhaustiveCudaSolver variant for this coeff_t/energy_t combination");
  return nullptr;
}

// 関数ポインタ型
using create_fn = void* (*)(const ExhaustiveCudaSolver*, const FlatHuboModel*);
using destroy_fn = void (*)(void*);
using search_fn = void* (*)(void*, ExhaustiveCudaSol*, const Params*);
using register_cb_fn =
    void (*)(void (*)(const ExhaustiveCudaSolver*, const ExhaustiveCudaSol*));
using list_count_fn = size_t (*)(void*);
using list_get_fn = void (*)(void*, size_t, ExhaustiveCudaSol*);
using list_destroy_fn = void (*)(void*);

struct ExhaustiveCudaDispatch {
  void* handle = nullptr;
  create_fn create = nullptr;
  destroy_fn destroy = nullptr;
  search_fn search = nullptr;
  register_cb_fn register_cb = nullptr;
  list_count_fn list_count = nullptr;
  list_get_fn list_get = nullptr;
  list_destroy_fn list_destroy = nullptr;
};

/// @brief .soへの関数ポインタを管理するシングルトン
inline ExhaustiveCudaDispatch& dispatch() {
  static ExhaustiveCudaDispatch inst = [] {
    ExhaustiveCudaDispatch d;
    d.handle = dlopen(lib_name(), RTLD_NOW);
    if (!d.handle) {
      throw std::runtime_error(
          std::string("ExhaustiveCudaSolver: failed to load ") + lib_name() +
          ": " + dlerror());
    }
    auto sym = [&](const char* name) {
      void* s = dlsym(d.handle, name);
      if (!s)
        throw std::runtime_error(
            std::string("ExhaustiveCudaSolver: symbol not found: ") + name +
            ": " + dlerror());
      return s;
    };
    d.create =
        reinterpret_cast<create_fn>(sym("qbpp_exhaustive_cuda_solver_create"));
    d.destroy =
        reinterpret_cast<destroy_fn>(sym("qbpp_exhaustive_cuda_solver_destroy"));
    d.search =
        reinterpret_cast<search_fn>(sym("qbpp_exhaustive_cuda_solver_search"));
    d.register_cb = reinterpret_cast<register_cb_fn>(
        sym("qbpp_exhaustive_cuda_register_callback"));
    d.list_count = reinterpret_cast<list_count_fn>(
        sym("qbpp_exhaustive_cuda_sol_list_count"));
    d.list_get = reinterpret_cast<list_get_fn>(
        sym("qbpp_exhaustive_cuda_sol_list_get"));
    d.list_destroy = reinterpret_cast<list_destroy_fn>(
        sym("qbpp_exhaustive_cuda_sol_list_destroy"));
    return d;
  }();
  return inst;
}

}  // namespace detail

// ===================================
// Sol class (wraps qbpp::Sol)
// ===================================

class Sol : public qbpp::Sol {
 public:
  Sol(const qbpp::Model& model, const qbpp::energy_t& energy,
      const uint64_t* bitarray, double tts)
      : qbpp::Sol(model, energy, bitarray, tts) {}
};

// ===================================
// ExhaustiveCudaSols class (Sol + optimal solutions)
// ===================================

/// @brief Solution container with all optimal solutions
/// @details Inherits from Sol (the best solution found) and additionally
/// stores all solutions with the optimal energy value.
class ExhaustiveCudaSols : public Sol {
  std::vector<qbpp::Sol> optimal_sols_;

 public:
  ExhaustiveCudaSols(const qbpp::Model& model, const qbpp::energy_t& energy,
                     const uint64_t* bitarray, double tts,
                     std::vector<qbpp::Sol> optimal_sols)
      : Sol(model, energy, bitarray, tts),
        optimal_sols_(std::move(optimal_sols)) {}

  /// @brief Number of optimal solutions found
  [[nodiscard]] size_t size() const noexcept { return optimal_sols_.size(); }

  /// @brief Access the optimal solutions vector
  const std::vector<qbpp::Sol>& optimal_sols() const noexcept {
    return optimal_sols_;
  }

  /// @brief Alias for optimal_sols()
  const std::vector<qbpp::Sol>& sols() const noexcept { return optimal_sols_; }

  /// @brief Index access
  const qbpp::Sol& operator[](size_t index) const {
    return optimal_sols_.at(index);
  }

  // Iterator support
  auto begin() const noexcept { return optimal_sols_.begin(); }
  auto end() const noexcept { return optimal_sols_.end(); }
  auto cbegin() const noexcept { return optimal_sols_.cbegin(); }
  auto cend() const noexcept { return optimal_sols_.cend(); }
};

// ===================================
// ExhaustiveCudaSolver class
// ===================================

/// @brief GPU-accelerated exhaustive HUBO/QUBO solver
/// @details Performs deterministic exhaustive search using Gray code traversal
/// on CUDA GPU. Each CUDA block handles a branch of the search tree, with
/// all threads in a block cooperating on delta updates per flip.
/// Supports up to 50 variables (practical limit ~35-40).
class ExhaustiveCudaSolver {
  qbpp::Model model_;
  const qbpp::HuboModel hubo_model_;
  const qbpp::FlatHuboModel flat_hubo_model_;
  void* pimpl_;

  ExhaustiveCudaSolver() = delete;
  ExhaustiveCudaSolver(const ExhaustiveCudaSolver&) = delete;
  ExhaustiveCudaSolver& operator=(const ExhaustiveCudaSolver&) = delete;

 public:
  /// @brief Constructor from Model
  explicit ExhaustiveCudaSolver(const Model& model)
      : model_(model),
        hubo_model_(HuboModel(model)),
        flat_hubo_model_(FlatHuboModel(hubo_model_)),
        pimpl_(nullptr) {
    if (model_.var_count() > 50) {
      throw std::invalid_argument(
          "ExhaustiveCudaSolver: variable count must be <= 50, got " +
          std::to_string(model_.var_count()));
    }
    // コールバック登録（一度だけ）
    static bool cb_registered = false;
    if (!cb_registered) {
      detail::dispatch().register_cb(solver_callback_impl_);
      cb_registered = true;
    }
    pimpl_ = detail::dispatch().create(
        static_cast<ExhaustiveCudaSolver*>(this), &flat_hubo_model_);
  }

  /// @brief Constructor from Expr
  explicit ExhaustiveCudaSolver(const Expr& expr)
      : ExhaustiveCudaSolver(Model(expr)) {}

  /// @brief Destructor
  virtual ~ExhaustiveCudaSolver() noexcept {
    detail::dispatch().destroy(pimpl_);
  }

  /// @brief Find one optimal solution by exhaustive search
  Sol search(const Params& params) {
    ExhaustiveCudaSol sol(model_.var_count());
    void* list = detail::dispatch().search(pimpl_, &sol, &params);
    if (list) {
      detail::dispatch().list_destroy(list);
    }
    return Sol(model_, sol.energy(), sol.bitarray(), sol.tts());
  }

  /// @brief Find all optimal solutions by exhaustive search (2-pass)
  ExhaustiveCudaSols search_optimal_solutions(const Params& params) {
    // Create a modified params with search_optimal=true
    Params opt_params;
    // Copy existing params
    for (size_t i = 0; params.pairs(i).key != nullptr; ++i) {
      opt_params.add(params.pairs(i).key, params.pairs(i).value);
    }
    opt_params.add("search_optimal", "true");

    ExhaustiveCudaSol sol(model_.var_count());
    void* list = detail::dispatch().search(pimpl_, &sol, &opt_params);

    std::vector<qbpp::Sol> optimal_sols;
    if (list) {
      size_t count = detail::dispatch().list_count(list);
      optimal_sols.reserve(count);
      for (size_t i = 0; i < count; ++i) {
        ExhaustiveCudaSol s(model_.var_count());
        detail::dispatch().list_get(list, i, &s);
        optimal_sols.emplace_back(
            qbpp::Sol(model_, s.energy(), s.bitarray(), s.tts()));
      }
      detail::dispatch().list_destroy(list);
    }

    return ExhaustiveCudaSols(model_, sol.energy(), sol.bitarray(), sol.tts(),
                              std::move(optimal_sols));
  }

  /// @brief Callback function called when a better solution is found
  virtual void callback(const ExhaustiveCudaSol& sol) const {
    std::cout << "TTS = " << std::fixed << std::setprecision(3)
              << std::setfill('0') << sol.tts() << "s Energy = " << sol.energy()
              << std::endl;
  }

 private:
  static void solver_callback_impl_(const ExhaustiveCudaSolver* solver,
                                    const ExhaustiveCudaSol* sol) {
    solver->callback(*sol);
  }
};

}  // namespace exhaustive_cuda
}  // namespace qbpp
