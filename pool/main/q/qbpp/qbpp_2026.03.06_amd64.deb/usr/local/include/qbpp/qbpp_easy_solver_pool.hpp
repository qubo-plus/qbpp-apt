/// @file qbpp_easy_solver.hpp
/// @author Koji Nakano
/// @brief HUBO Solver for solving HUBO problems
/// @details High Order Unconstrained Binary Optimization (HUBO) solver up to
/// degree 8. This is a native solver that does not reduce the degree.
/// @version 2026.02.07

#pragma once

#include <string_view>
#include <unordered_set>

#include "qbpp.hpp"
#include "qbpp_defs.hpp"
#include "qbpp_misc.hpp"

namespace qbpp {

namespace easy_solver {

constexpr double kDefaultTimeLimit = 10.0;  // seconds

//=====================================
//  Class Prototypes
//=====================================

class BestSols;
class EasySolver;
class SolDelta;

/// @brief Class to compute xxhash for Sol object.
/// @details This class is used to compute the hash value of a Sol object to
/// check the equality of the Sol objects.
struct SolHash {
  /// @brief Computes the 64-bit hash value of a Sol object.
  uint64_t operator()(const qbpp::Sol& sol) const noexcept {
    return static_cast<uint64_t>(
        qbpp_hash(sol.bit_vector().size64(), sol.bit_vector().bits_ptr()));
  }
};

enum class SavePolicy {
  BestSolsOnly,        // Save only the best solutions found so far.
  All,                 // Save any solution, regardless of local optimality.
  WeakLocalMinimum,    // Save only solutions not worse than any neighbor (≤).
  StrictLocalMinimum,  // Save only solutions strictly better than all neighbors
                       // (<).
};

/// @brief Per-thread solution pool for diversity-driven search
/// @details Maintains diverse solutions using min-heap structure.
/// Independent from BestSols (which stores final results).
class SolPool {
 private:
  struct Element {
    qbpp::Sol sol_;
    explicit Element(const qbpp::Sol& sol) : sol_(sol) {}
  };

  std::vector<Element> elements_;
  size_t capacity_;
  const HuboModel& hubo_model_;

  void sift_up(size_t index) {
    while (index > 0) {
      size_t parent = (index - 1) / 2;
      if (elements_[index].sol_.energy() < elements_[parent].sol_.energy()) {
        std::swap(elements_[index], elements_[parent]);
        index = parent;
      } else {
        break;
      }
    }
  }

  void sift_down(size_t index) {
    size_t size = elements_.size();
    while (true) {
      size_t left = 2 * index + 1;
      size_t right = 2 * index + 2;
      size_t smallest = index;

      if (left < size &&
          elements_[left].sol_.energy() < elements_[smallest].sol_.energy()) {
        smallest = left;
      }
      if (right < size &&
          elements_[right].sol_.energy() < elements_[smallest].sol_.energy()) {
        smallest = right;
      }

      if (smallest != index) {
        std::swap(elements_[index], elements_[smallest]);
        index = smallest;
      } else {
        break;
      }
    }
  }

 public:
  explicit SolPool(const HuboModel& hubo_model, size_t capacity = 0)
      : capacity_(capacity == 0 ? std::max(hubo_model.var_count() / 10, 10u)
                                : capacity),
        hubo_model_(hubo_model) {
    elements_.reserve(capacity_);
  }

  size_t size() const { return elements_.size(); }
  size_t capacity() const { return capacity_; }
  bool empty() const { return elements_.empty(); }

  qbpp::Sol get_random() const {
    if (elements_.empty()) {
      throw std::runtime_error("SolPool::get_random() called on empty pool");
    }
    size_t index = qbpp::random_gen(static_cast<uint32_t>(elements_.size()));
    return elements_[index].sol_;
  }

  qbpp::Sol get_best() const {
    if (elements_.empty()) {
      throw std::runtime_error("SolPool::get_best() called on empty pool");
    }
    return elements_[0].sol_;
  }

  void insert(const qbpp::Sol& sol) {
    if (elements_.size() < capacity_) {
      elements_.emplace_back(sol);
      sift_up(elements_.size() - 1);
    } else if (sol.energy() < elements_[0].sol_.energy()) {
      // Replace worst (root of min-heap) and sift down
      elements_[0].sol_ = sol;
      sift_down(0);
    }
  }

  void init_random(size_t count) {
    elements_.clear();
    for (size_t i = 0; i < std::min(count, capacity_); ++i) {
      qbpp::Sol sol(hubo_model_);
      // Randomly flip about half the bits
      vindex_t var_count = hubo_model_.var_count();
      for (vindex_t j = 0; j < var_count; ++j) {
        if (qbpp::random_gen(2u) == 0) {
          sol.set(j, true);
        }
      }
      // Compute energy
      sol.energy(hubo_model_.expr());
      elements_.emplace_back(sol);
    }
    // Build heap
    if (!elements_.empty()) {
      for (size_t i = (elements_.size() / 2); i > 0; --i) {
        sift_down(i - 1);
      }
      if (elements_.size() > 1) {
        sift_down(0);
      }
    }
  }
};

/// @brief Class to store the best solutions.
/// @details This class is used to store the best solutions found so far.
/// @note The class uses SolHash to compute the hash value of a Sol object.
class BestSols {
  /// @brief The maximum number of best solutions to store.
  const size_t capacity_;

  SavePolicy save_policy_;

  /// @brief The vector to store the best solutions.
  std::vector<qbpp::Sol> sol_vector_;

  /// @brief The set to store the hash values of the best solutions.
  /// @note The set is used to check if the solution is already stored.
  std::unordered_set<qbpp::Sol, SolHash> sol_set_;

  /// @brief The worst energy of the best solutions.
  std::optional<energy_t> worst_energy_;

  /// @brief The mutex to protect the sol_vector_ and sol_set_.
  std::mutex mutex_;

 public:
  /// @brief Constructor to initialize the BestSols object.
  /// @param capacity The maximum number of best solutions to store.
  explicit BestSols(size_t capacity = 0,
                    SavePolicy save_policy = SavePolicy::All)
      : capacity_(capacity), save_policy_(save_policy) {}

  /// @brief Inserts the solution into the best solutions if it is local minimum
  /// and better than the worst solution in the set.
  void insert_if_better(const qbpp::Sol& sol,
                        const misc::MinHeap<energy_t>& neg_set,
                        const misc::MinHeap<energy_t>& pos_set) {
    if (save_policy_ != SavePolicy::BestSolsOnly && capacity_ == 0) return;
    if (save_policy_ == SavePolicy::WeakLocalMinimum && !neg_set.empty())
      return;
    if (save_policy_ == SavePolicy::StrictLocalMinimum &&
        pos_set.heap_size() < sol.var_count())
      return;
    std::lock_guard<std::mutex> lock(mutex_);
    if (worst_energy_ && *worst_energy_ < sol.energy()) return;
    if (sol_set_.count(sol)) return;  // Already exists
    if (save_policy_ == SavePolicy::BestSolsOnly && worst_energy_ &&
        sol.energy() < *worst_energy_) {
      sol_vector_.clear();
      sol_set_.clear();
    }

    if (sol_vector_.size() < capacity_ || capacity_ == 0) {
      sol_vector_.push_back(sol);
      sol_set_.insert(sol);
    } else {
      if (sol.energy() >= sol_vector_.back().energy()) return;
      const auto& removed = sol_vector_.back();
      sol_set_.erase(removed);
      sol_vector_.back() = sol;
      sol_set_.insert(sol);
    }

    for (size_t i = sol_vector_.size() - 1; i > 0; --i) {
      if (sol_vector_[i].energy() < sol_vector_[i - 1].energy()) {
        std::swap(sol_vector_[i], sol_vector_[i - 1]);
      } else {
        break;
      }
    }

    worst_energy_ = sol_vector_.back().energy();
  }

  const std::vector<qbpp::Sol>& sol_vector() const { return sol_vector_; }

  std::vector<qbpp::Sol>& sol_vector() { return sol_vector_; }
};

/// @brief Class to store the solution with delta vector, neg_set, and
/// pos_set.
class SolDelta : public Sol {
 protected:
  /// @brief A reference to the EasySolver object calling this class.
  const EasySolver& easy_solver_;

  /// @brief A reference to the HuboModel object for this class.
  const HuboModel& hubo_model_;

  /// @brief The vector to store the delta of each variable in the model.
  std::vector<energy_t> delta_;

  /// @brief The MinHeap object to store the variables with negative deltas.
  misc::MinHeap<energy_t> neg_set_;

  /// @brief The MinHeap object to store the variables with positive deltas.
  misc::MinHeap<energy_t> pos_set_;

  /// @brief Reusable buffer for delta updates during flip operations.
  std::vector<energy_t> delta_delta_;

  /// @brief Reusable buffer to track indices modified in delta_delta_.
  std::vector<vindex_t> dirty_list_;

  /// @brief The Tabu object to store the tabu list.
  misc::Tabu tabu_;

  uint32_t fail_count_ = 0;

  /// @brief The BestSols object to store the best solutions.
  const std::shared_ptr<qbpp::SolHolder> all_best_sol_ptr_;

  std::shared_ptr<qbpp::SolHolder> time_limited_best_sol_ptr_;

  uint64_t flip_count_ = 0;

  /// @brief Per-thread solution pool (only used when pool search is enabled)
  std::unique_ptr<SolPool> pool_ptr_;

 public:
  /// @brief Constructor to create a new SolDelta object for the specified
  /// EasySolver object.
  SolDelta(const EasySolver& easy_solver, size_t thread_id,
           size_t thread_count);

  SolDelta& set_all_one() {
    neg_set_.clear();
    pos_set_.clear();
    for (vindex_t i = 0; i < var_count(); ++i) {
      Sol::set(i, true);
      delta_[i] = -hubo_model_.coeff_sum(i);
      if (delta_[i] < 0) {
        neg_set_.insert(i, delta_[i]);
      } else if (delta_[i] > 0) {
        pos_set_.insert(i, delta_[i]);
      }
    }
    energy_ = hubo_model_.all_coeff_sum();
    return *this;
  }

  bool reach_time_limit() const;

  bool reach_target_energy() const;

  bool reach_end_time() const;

  bool should_stop() const {
    return reach_target_energy() || reach_time_limit() || reach_end_time();
  }

  double remaining_time() const;

  void set_if_better(std::string_view info);

  void set_if_better_neighbor(std::string_view info);

  void flip(vindex_t index) { flip_with_updated_vars(index, false); }

  uint64_t flip_count() const { return flip_count_; }

  SolPool* pool() { return pool_ptr_.get(); }
  const SolPool* pool() const { return pool_ptr_.get(); }

  template <size_t N>
  inline void update_delta_delta(
      const TermVector<N - 1>& terms,  // termN(index) の戻り（size(),
                                       // indices(i)[j], coeff(i) が使える）
      std::vector<energy_t>& delta_delta,
      int32_t flip_bit_sign)  // +1 or -1 only
  {
    static_assert(N >= 3, "N must be >= 3");

    for (size_t i = 0; i < terms.size(); ++i) {
      std::array<vindex_t, N - 1> idx{};
      std::array<uint8_t, N - 1> val{};
      uint8_t sum = 0;

      const auto inds = terms.indices(i);  // N-1 要素へのアクセスを想定

      for (size_t j = 0; j < N - 1; ++j) {
        idx[j] = inds[j];
        val[j] = static_cast<uint8_t>(get(idx[j]));
        sum = static_cast<uint8_t>(sum + val[j]);
      }

      const energy_t factor = terms.coeff(i) * flip_bit_sign;

      // 規則: sum <= (N-3) は何もしない
      if (sum <= static_cast<uint8_t>(N - 3)) continue;

      // 全員1: sum == (N - 1) → 全員に -factor
      if (sum == static_cast<uint8_t>(N - 1)) {
        for (size_t j = 0; j < N - 1; ++j) {
          if (delta_delta[idx[j]] == 0) dirty_list_.push_back(idx[j]);
          delta_delta[idx[j]] -= factor;
        }
        continue;
      }

      // sum == (N - 2): 最初に 0 の位置へ +factor
      for (uint8_t target = 0; target < N - 1; ++target) {
        if (val[target] == 0) {
          if (delta_delta[idx[target]] == 0) dirty_list_.push_back(idx[target]);
          delta_delta[idx[target]] += factor;
          break;
        }
      }
    }
  }

  std::vector<vindex_t> flip_with_updated_vars(
      vindex_t index, bool track_updated_vars = false) {
    assert(index < var_count());
    std::vector<vindex_t> updated_vars;
    updated_vars.reserve(16);

    int32_t flip_bit_sign = 1 - 2 * get(index);

    auto& delta_delta = delta_delta_;
    dirty_list_.clear();

    const auto& t2 = hubo_model_.term2(index);
    for (size_t i = 0; i < t2.size(); ++i) {
      vindex_t j = t2.indices(i)[0];
      coeff_t coeff = t2.coeff(i);
      if (delta_delta[j] == 0) dirty_list_.push_back(j);
      delta_delta[j] += coeff * flip_bit_sign * (1 - 2 * get(j));
    }

    auto mp = hubo_model_.max_power();
    if (mp > 2)
      update_delta_delta<3>(hubo_model_.term3(index), delta_delta,
                            flip_bit_sign);
    if (mp > 3)
      update_delta_delta<4>(hubo_model_.term4(index), delta_delta,
                            flip_bit_sign);
    if (mp > 4)
      update_delta_delta<5>(hubo_model_.term5(index), delta_delta,
                            flip_bit_sign);
    if (mp > 5)
      update_delta_delta<6>(hubo_model_.term6(index), delta_delta,
                            flip_bit_sign);
    if (mp > 6)
      update_delta_delta<7>(hubo_model_.term7(index), delta_delta,
                            flip_bit_sign);
    if (mp > 7)
      update_delta_delta<8>(hubo_model_.term8(index), delta_delta,
                            flip_bit_sign);
    if (mp > 8)
      update_delta_delta<9>(hubo_model_.term9(index), delta_delta,
                            flip_bit_sign);
    if (mp > 9)
      update_delta_delta<10>(hubo_model_.term10(index), delta_delta,
                             flip_bit_sign);
    if (mp > 10)
      update_delta_delta<11>(hubo_model_.term11(index), delta_delta,
                             flip_bit_sign);
    if (mp > 11)
      update_delta_delta<12>(hubo_model_.term12(index), delta_delta,
                             flip_bit_sign);
    if (mp > 12)
      update_delta_delta<13>(hubo_model_.term13(index), delta_delta,
                             flip_bit_sign);
    if (mp > 13)
      update_delta_delta<14>(hubo_model_.term14(index), delta_delta,
                             flip_bit_sign);
    if (mp > 14)
      update_delta_delta<15>(hubo_model_.term15(index), delta_delta,
                             flip_bit_sign);
    if (mp > 15)
      update_delta_delta<16>(hubo_model_.term16(index), delta_delta,
                             flip_bit_sign);

    Sol::flip_bit_add_delta(index, delta_[index]);
    for (vindex_t i : dirty_list_) {
      if (delta_delta[i] == 0) continue;
      assert(i != index);
      if (track_updated_vars) {
        updated_vars.emplace_back(i);
      }
      if (delta_[i] < 0) {
        neg_set_.erase(i);
      } else if (delta_[i] > 0) {
        pos_set_.erase(i);
      }
      delta_[i] += delta_delta[i];
      delta_delta[i] = 0;
      if (delta_[i] < 0) {
        neg_set_.insert(i, delta_[i]);
      } else if (delta_[i] > 0) {
        pos_set_.insert(i, delta_[i]);
      }
    }

    if (delta_[index] < 0) {
      neg_set_.erase(index);
    } else if (delta_[index] > 0) {
      pos_set_.erase(index);
    }
    delta_[index] = -delta_[index];
    if (delta_[index] < 0) {
      neg_set_.insert(index, delta_[index]);
    } else if (delta_[index] > 0) {
      pos_set_.insert(index, delta_[index]);
    }

    tabu_.insert(index);
    ++flip_count_;
    return updated_vars;
  }

  /// @brief Greedy algorithm to flip the variables with negative deltas.
  uint32_t greedy() {
    // 0=always first, 1=always random, 2=per-flip coin toss
    uint32_t strategy = qbpp::random_gen(3u);
    uint32_t count = 0;
    while (!neg_set_.empty()) {
      if (should_stop()) {
        break;
      }
      bool use_first =
          (strategy == 0) || (strategy == 2 && qbpp::random_gen(2) == 0);
      vindex_t min_index;
      if (use_first) {
        min_index = neg_set_.first();
      } else {
        min_index = neg_set_.select_at_random();
      }
      flip(min_index);
      set_if_better(use_first ? "Greedy(first)" : "Greedy(random)");
      ++count;
    }
    {
      static std::mutex queueset_mutex;
      std::lock_guard<std::mutex> lock(queueset_mutex);
      if (qbpp::queueset_insert(bit_vector())) {
        fail_count_ = 0;
      } else {
        ++fail_count_;
      }
    }
    return count + fail_count_;
  }

  /// @brief Returns the SolHolder object storing the best solutions.
  qbpp::SolHolder& sol_holder() { return *all_best_sol_ptr_; }

  void pos_min(size_t iteration) {
    for (size_t i = 0; i < iteration; ++i) {
      if (should_stop()) {
        break;
      }
      std::optional<vindex_t> flip_index = std::nullopt;
      for (size_t j = 0; j < tabu_.capacity() * 2; ++j) {
        vindex_t candidate = vindex_limit;
        if (pos_set_.empty() || neg_set_.empty()) {
          candidate = qbpp::random_gen(var_count());
        } else if (qbpp::random_gen(neg_set_.heap_size() + 1) == 0) {
          candidate = pos_set_.first();
        } else {
          candidate = neg_set_.select_at_random();
        }
        if (candidate == vindex_limit) {
          throw std::runtime_error(THROW_MESSAGE("Unexpected error."));
        }
        if (!tabu_.has(candidate)) {
          flip_index = candidate;
          break;
        }
      }
      if (!flip_index.has_value()) {
        flip_index = tabu_.non_tabu_random();
      }
      flip(flip_index.value());
      set_if_better("PosMin");
      if (neg_set_.empty()) {
        if (qbpp::queueset_insert(bit_vector())) {
          fail_count_ = 0;
        } else {
          ++fail_count_;
        }
      }
    }
  }

  /// @brief Moves the solution toward the given destination.
  void move_to(const qbpp::Sol& destination);
  /// @brief Randomly flips the solution for the given number of iterations.
  void random_flip(size_t iteration);

  void random_flip();

  /// @brief Get the delta value of the given index.
  /// @note This function is used for debugging to verify the delta
  /// value.
  energy_t comp_delta(vindex_t index) const {
    energy_t current_energy = get(hubo_model_.expr());
    Sol flipped_sol = *this;
    flipped_sol.flip(index);
    energy_t flipped_energy = flipped_sol.get(hubo_model_.expr());
    return flipped_energy - current_energy;
  }

  /// @brief Gets the delta values as a string.
  std::string str_delta() const {
    std::ostringstream oss;
    oss << "delta: ";
    for (vindex_t i = 0; i < delta_.size(); ++i) {
      oss << "(" << var(i) << ", " << delta_[i] << ") ";
    }
    return oss.str();
  }

  /// @brief Get the delta value of the given index.
  std::string debug_str() const {
    std::ostringstream oss;
    oss << "delta debug: ";
    for (vindex_t i = 0; i < delta_.size(); ++i) {
      oss << "" << var(i) << ": Computed Delta = " << comp_delta(i)
          << ", Delta = " << delta_[i] << std::endl;
    }
    return oss.str();
  }

  void check_sets() {
    for (const auto& [val, index] : neg_set_.heap()) {
      if (delta_[index] >= 0) {
        throw std::runtime_error(THROW_MESSAGE("Unexpected error."));
      }
      if (delta_[index] != val) {
        std::cout << "neg_set: index = " << index
                  << " delta = " << delta_[index] << " val = " << val
                  << std::endl;
        throw std::runtime_error(THROW_MESSAGE("Unexpected error."));
      }
    }
    for (const auto& [val, index] : pos_set_.heap()) {
      if (delta_[index] <= 0) {
        throw std::runtime_error(THROW_MESSAGE("Unexpected error."));
      }
      if (delta_[index] != val) {
        std::cout << "pos_set: index = " << index
                  << " delta = " << delta_[index] << " val = " << val
                  << std::endl;
        throw std::runtime_error(THROW_MESSAGE("Unexpected error."));
      }
    }
  }
};

class Sols : public qbpp::Sol {
  const std::vector<qbpp::Sol> best_sols_;

 public:
  explicit Sols(const qbpp::SolHolder& sol_holder,
                std::vector<qbpp::Sol> best_sols)
      : qbpp::Sol(sol_holder.sol()), best_sols_(best_sols) {}

  [[nodiscard]] size_t size() const noexcept { return best_sols_.size(); }

  const std::vector<qbpp::Sol>& best_sols() const noexcept {
    return best_sols_;
  }

  const std::vector<qbpp::Sol>& sols() const noexcept { return best_sols_; }

  const qbpp::Sol& operator[](size_t index) const {
    return best_sols_.at(index);
  }

  // iterator support
  auto begin() const noexcept { return best_sols_.begin(); }

  auto end() const noexcept { return best_sols_.end(); }

  auto cbegin() const noexcept { return best_sols_.cbegin(); }

  auto cend() const noexcept { return best_sols_.cend(); }
};

class EasySolver {
  const qbpp::HuboModel hubo_model_;

  double time_limit_ = kDefaultTimeLimit;

  std::optional<energy_t> target_energy_;

  std::shared_ptr<qbpp::SolHolder> all_best_sol_ptr_;

  size_t thread_count_{std::thread::hardware_concurrency() < 4
                           ? 4
                           : std::thread::hardware_concurrency()};

  bool enable_default_callback_{false};

  bool use_pool_search_{false};

  double start_time_;

  double base_time_{0.1};

  std::shared_ptr<BestSols> best_sols_ptr_ = std::make_shared<BestSols>(0);

  uint64_t flip_count_{0};

  mutable std::mutex flip_count_mutex_;

  double end_time_;

  void single_search(size_t thread_id);

  std::shared_ptr<qbpp::SolHolder> time_limited_best_sol_ptr_;

  void time_limited_search(double time_limit, bool use_best_sol);

  void add_flip_count(uint64_t flip_count) {
    std::lock_guard<std::mutex> lock(flip_count_mutex_);
    flip_count_ += flip_count;
  }

  std::unique_ptr<qbpp::Sol> hint_sol_ptr_;

  mutable std::mutex cb_mutex_;
  mutable std::optional<energy_t> cb_prev_energy_;
  mutable std::mutex hint_sol_mutex_;

 public:
  explicit EasySolver(const qbpp::Model& model)
      : hubo_model_(model),
        all_best_sol_ptr_(std::make_shared<qbpp::SolHolder>(hubo_model_)),
        best_sols_ptr_(std::make_shared<BestSols>(0)) {
    if (hubo_model_.term_count() == 0) {
      throw std::runtime_error(
          "The HUBO model has no terms. Please check the model.");
    }
  }

  const qbpp::HuboModel& hubo_model() const { return hubo_model_; }

  const std::shared_ptr<qbpp::SolHolder>& sol_holder_ptr() const {
    return all_best_sol_ptr_;
  }

  const qbpp::SolHolder& sol_holder() const { return *all_best_sol_ptr_; }

  const std::shared_ptr<qbpp::SolHolder>& time_limited_best_sol_ptr() const {
    return time_limited_best_sol_ptr_;
  }

  virtual ~EasySolver() = default;

  vindex_t var_count() const { return hubo_model_.var_count(); }

  void time_limit(double limit) { time_limit_ = limit; }

  void target_energy(energy_t energy) { target_energy_ = energy; }

  void base_time(double time = 0.0) { base_time_ = time; }

  bool reach_target_energy() const {
    if (!target_energy_.has_value()) {
      return false;
    }
    return all_best_sol_ptr_->energy() <= target_energy_.value();
  }

  bool reach_time_limit() const {
    if (time_limit_ == 0.0) {
      return false;
    }
    return qbpp::time() > start_time_ + time_limit_;
  }

  bool reach_end_time() const {
    if (base_time_ == 0.0) {
      return false;
    }
    return qbpp::time() >= end_time_;
  }

  bool should_stop() const {
    return reach_target_energy() || reach_time_limit() || reach_end_time();
  }

  double remaining_time() const {
    if (time_limit_ == 0.0) {
      return std::numeric_limits<double>::max();
    }
    return start_time_ + time_limit_ - qbpp::time();
  }

  const std::optional<energy_t>& target_energy() const {
    return target_energy_;
  }

  double time_limit() const { return time_limit_; }

  void thread_count(size_t count) { thread_count_ = count; }

  /// @brief Enables the default callback function.
  void enable_default_callback() { enable_default_callback_ = true; }

  /// @brief Enables pool-based search algorithm.
  /// @param enable If true, use pool-based search; if false, use original algorithm.
  void enable_pool_search(bool enable = true) { use_pool_search_ = enable; }

  /// @brief Check if pool-based search is enabled.
  bool is_pool_search_enabled() const { return use_pool_search_; }

  uint64_t flip_count() const {
    std::lock_guard<std::mutex> lock(flip_count_mutex_);
    return flip_count_;
  }

  double tts() const { return all_best_sol_ptr_->tts(); }

  /// @brief Callback function called when the best solution is updated.
  /// @param sol The best solution.
  /// @param tts The time to solution.
  virtual void callback(const qbpp::Sol& sol, double tts,
                        std::string_view info) const {
    std::lock_guard<std::mutex> lock(cb_mutex_);
    if (enable_default_callback_) {
      if (!cb_prev_energy_.has_value() ||
          sol.energy() < cb_prev_energy_.value()) {
        std::cout << "TTS = " << std::fixed << std::setprecision(3)
                  << std::setfill('0') << tts << "s Energy = " << sol.energy()
                  << " thread = "
                  << tbb::this_task_arena::current_thread_index() << " " << info
                  << std::endl;
        cb_prev_energy_ = sol.energy();
      }
    }
  }

  void enable_best_energy_sols(size_t capacity = 0) {
    best_sols_ptr_ = std::make_shared<BestSols>(capacity, SavePolicy::BestSolsOnly);
  }

  void enable_topk_sols(size_t capacity) {
    best_sols_ptr_ = std::make_shared<BestSols>(capacity, SavePolicy::All);
  }

  std::shared_ptr<BestSols>& best_sols_ptr() { return best_sols_ptr_; }
  const std::shared_ptr<BestSols>& best_sols_ptr() const {
    return best_sols_ptr_;
  }

  const std::vector<qbpp::Sol>& best_sols() const {
    return best_sols_ptr_->sol_vector();
  }

  /// @brief Executes the PositiveMin search algorithm.
  /// @return The best solution found.
  Sols search(bool has_initial_sol = false);

  /// @brief Executes the PositiveMin search algorithm with the specified
  /// initial solution
  /// @param initial_sol Initial solution to be written in the best
  /// solution.
  qbpp::Sol search(const qbpp::Sol& initial_sol) {
    all_best_sol_ptr_->sol(initial_sol);
    return search(true);
  }

  void set_hint_sol(const qbpp::Sol& hint_sol) {
    std::lock_guard<std::mutex> lock(hint_sol_mutex_);
    hint_sol_ptr_ = std::make_unique<qbpp::Sol>(hint_sol);
  }

  const std::unique_ptr<qbpp::Sol>& hint_sol_ptr() const {
    return hint_sol_ptr_;
  }
};

//=====================================
// Class EasySolver member functions
//=====================================

inline void EasySolver::single_search(size_t thread_id) {
  const size_t min_flip_count = 100;
  size_t max_flip_count = (var_count() / 2);
  SolDelta sol_delta(*this, thread_id, thread_count_);
  if (thread_count_ > 1) {
    // if multiple threads are used, the max_flip_count is varied from
    // min_flip_count to var_count/2 in an exponential manner.
    double k = std::pow(static_cast<double>(max_flip_count) / min_flip_count,
                        1.0 / static_cast<double>(thread_count_ - 1));
    max_flip_count =
        static_cast<size_t>(min_flip_count * std::pow(k, thread_id));
    if (max_flip_count < min_flip_count) max_flip_count = min_flip_count;
  }

  if (use_pool_search_) {
    // ========== Pool-based search algorithm ==========
    size_t mutation_count = std::max(var_count() / 20, 5u);

    // Initialize solution based on thread_id (like original algorithm)
    if (thread_id % 2) {
      sol_delta.set_all_one();
      sol_delta.greedy();
    } else {
      // Start from all-zero, do initial greedy
      sol_delta.greedy();
    }

    while (!should_stop()) {
      if (sol_delta.pool() && !sol_delta.pool()->empty()) {
        // Get random solution from pool and move to it
        qbpp::Sol pool_sol = sol_delta.pool()->get_random();
        sol_delta.move_to(pool_sol);
        sol_delta.greedy();
      }

      // Mutation: multiple random flips
      sol_delta.random_flip(mutation_count);
      sol_delta.greedy();

      // Main search
      sol_delta.pos_min(max_flip_count);
      sol_delta.greedy();

      // Insert result into pool
      if (sol_delta.pool()) {
        sol_delta.pool()->insert(sol_delta);
      }
    }
  } else {
    // ========== Original search algorithm ==========
    energy_t prev_energy = time_limited_best_sol_ptr_->energy();
    size_t random_flip_count = 1;

    if (thread_id % 2) {
      sol_delta.set_all_one();
    }

    while (!should_stop()) {
      sol_delta.random_flip(random_flip_count);
      sol_delta.greedy();
      sol_delta.move_to(*time_limited_best_sol_ptr_);
      sol_delta.greedy();
      sol_delta.random_flip(random_flip_count);
      sol_delta.greedy();
      sol_delta.pos_min(max_flip_count);
      sol_delta.greedy();
      sol_delta.random_flip(random_flip_count);
      sol_delta.greedy();

      if (prev_energy == time_limited_best_sol_ptr_->energy()) {
        // if the energy is not updated, the random_flip_count is increased
        random_flip_count = (random_flip_count + 1) % (max_flip_count / 2);
        if (random_flip_count == 0) random_flip_count = 1;
      } else {
        random_flip_count = 1;
      }
      prev_energy = time_limited_best_sol_ptr_->energy();
    }
  }

  add_flip_count(sol_delta.flip_count());
}

inline void EasySolver::time_limited_search(double duration,
                                            bool use_best_sol) {
  end_time_ = qbpp::time() + duration;
  if (should_stop()) {
    return;
  }
  if (use_best_sol) {
    time_limited_best_sol_ptr_ =
        std::make_shared<qbpp::SolHolder>(all_best_sol_ptr_->sol());
  } else {
    time_limited_best_sol_ptr_ = std::make_shared<qbpp::SolHolder>(hubo_model_);
  }
  tbb::parallel_for(size_t(0), static_cast<size_t>(thread_count_),
                    [&](size_t thread_id) { single_search(thread_id); });
}

inline double compute_duration(size_t index, double base) {
  uint32_t k = static_cast<uint32_t>(
      std::ceil((std::sqrt(1 + 8.0 * static_cast<double>(index + 1)) - 1) / 2));

  uint32_t position = static_cast<uint32_t>(index) - k * (k - 1) / 2;

  return base * static_cast<double>(1ull << std::min(position, uint32_t(63)));
}

inline Sols EasySolver::search(bool has_initial_sol) {
  if (!has_initial_sol) {
    all_best_sol_ptr_ = std::make_shared<qbpp::SolHolder>(hubo_model_);
  }
  cb_prev_energy_ = std::nullopt;
  start_time_ = qbpp::time();
  queueset_capacity(1000000);

  for (size_t i = 0;; ++i) {
    if (reach_time_limit() || reach_target_energy()) break;
    double duration = compute_duration(i, base_time_);
    time_limited_search(duration, false);
    time_limited_search(duration, true);
  }
  return Sols(*all_best_sol_ptr_, best_sols_ptr_->sol_vector());
}

//=====================================
// Class SolDelta member functions
//=====================================

inline SolDelta::SolDelta(const EasySolver& easy_solver, size_t /*thread_id*/,
                          size_t /*thread_count*/)
    : Sol(easy_solver.hubo_model()),
      easy_solver_(easy_solver),
      hubo_model_(easy_solver_.hubo_model()),
      delta_(var_count()),
      neg_set_(var_count()),
      pos_set_(var_count()),
      delta_delta_(var_count(), 0),
      tabu_(var_count(),
            std::min(static_cast<vindex_t>(std::sqrt(var_count())),
                     var_count() / 2)),
      all_best_sol_ptr_(easy_solver_.sol_holder_ptr()),
      time_limited_best_sol_ptr_(easy_solver_.time_limited_best_sol_ptr()) {
  for (vindex_t i = 0; i < var_count(); ++i) {
    delta_[i] = hubo_model_.term1(i);
    if (delta_[i] < 0) {
      neg_set_.insert(i, delta_[i]);
    } else if (delta_[i] > 0) {
      pos_set_.insert(i, delta_[i]);
    }
  }

  // Initialize pool if pool search is enabled (but keep it empty initially)
  if (easy_solver_.is_pool_search_enabled()) {
    pool_ptr_ = std::make_unique<SolPool>(hubo_model_);
    // Pool starts empty - will be filled with good solutions during search
  }
}

inline void SolDelta::move_to(const Sol& destination) {
  misc::MinHeap to_be_flipped(var_count());
  for (vindex_t i = 0; i < var_count(); ++i) {
    if (should_stop()) {
      break;
    }
    if (get(i) != destination.get(i)) {
      to_be_flipped.insert(i, delta_[i]);
    }
  }
  while (!to_be_flipped.empty()) {
    if (should_stop()) {
      break;
    }
    vindex_t min_index = to_be_flipped.pop_first();
    std::vector<vindex_t> updated_vars =
        flip_with_updated_vars(min_index, true);
    set_if_better("MoveTo");
    for (const auto& index : updated_vars) {
      if (to_be_flipped.has(index)) {
        to_be_flipped.erase(index);
        to_be_flipped.insert(index, delta_[index]);
      }
    }
  }
}

inline void SolDelta::random_flip(size_t iteration) {
  for (vindex_t i = 0; i < iteration; ++i) {
    if (should_stop()) {
      break;
    }
    vindex_t flip_index = qbpp::random_gen(var_count());
    flip(flip_index);
    set_if_better("Random");
  }
}

inline void SolDelta::random_flip() {
  size_t iteration = (1u << (fail_count_ % 30)) % (var_count() / 2 + 2);
  for (size_t i = 0; i < iteration; ++i) {
    if (should_stop()) {
      break;
    }
    vindex_t flip_index = qbpp::random_gen(var_count());
    flip(flip_index);
    set_if_better("Random");
  }
}

inline void SolDelta::set_if_better(std::string_view info) {
  if (time_limited_best_sol_ptr_->set_if_better(*this, std::string(info))) {
    std::optional<double> tts =
        all_best_sol_ptr_->set_if_better(*this, std::string(info));
    if (tts.has_value()) {
      easy_solver_.callback(*this, tts.value(), info);
    }
    set_if_better_neighbor(info);
    if (easy_solver_.best_sols_ptr() != nullptr) {
      easy_solver_.best_sols_ptr()->insert_if_better(*this, neg_set_, pos_set_);
    }
  }
}

inline void SolDelta::set_if_better_neighbor(std::string_view info) {
  if (neg_set_.empty()) {
    return;
  }
  const auto& [min_delta, min_index] = neg_set_.min();
  if (energy() + min_delta < all_best_sol_ptr_->energy()) {
    Sol temp_sol = *this;
    temp_sol.flip_bit_add_delta(min_index, min_delta);
    std::string neighbor_info = std::string(info) + "(neighbor)";
    std::optional<double> tts =
        all_best_sol_ptr_->set_if_better(temp_sol, neighbor_info);
    if (tts.has_value()) {
      easy_solver_.callback(temp_sol, tts.value(), neighbor_info);
    }
  }
}

inline bool SolDelta::reach_time_limit() const {
  return easy_solver_.reach_time_limit();
}

inline double SolDelta::remaining_time() const {
  return easy_solver_.remaining_time();
}

inline bool SolDelta::reach_target_energy() const {
  return easy_solver_.reach_target_energy();
}

inline bool SolDelta::reach_end_time() const {
  return easy_solver_.reach_end_time();
}

}  // namespace easy_solver

}  // namespace qbpp
