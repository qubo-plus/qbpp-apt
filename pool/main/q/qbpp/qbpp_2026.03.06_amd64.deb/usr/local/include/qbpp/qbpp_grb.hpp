/// @file  qbpp_grb.hpp
/// @brief QUBO++ interface to call Gurobi Optimizer
/// @details This file provides interfaces to call Gurobi Optimizer from QUBO++
/// @author Koji Nakano
/// @version 2025.12.26

#pragma once

#include <cmath>

#include "gurobi_c++.h"
#include "qbpp.hpp"

#define GRB_SAFE_CALL(func)                                               \
  try {                                                                   \
    func;                                                                 \
  } catch (const GRBException& e) {                                       \
    std::cerr << e.getErrorCode() << ": " << e.getMessage() << std::endl; \
    exit(1);                                                              \
  }

/// @brief Namespace to use Gurobi optimizer from QUBO++ library
namespace qbpp {
namespace grb {

//===========================
// Class forward declarations
//===========================
class HuboModel;
class Sol;
class Callback;

//===================
// Class declarations
//===================

/// @brief Class to store a QUBO model using Gurobi Optimizer through QUBO++
/// library
/// @details This class is used to store a QUBO model and solve it using
/// Gurobi Optimizer through QUBO++ library.
class HuboModel : public qbpp::HuboModel {
 protected:
  /// @brief Gurobi environment
  GRBEnv grb_env;
  /// @brief Gurobi model
  std::shared_ptr<GRBModel> grb_model_ptr;
  /// @brief Pointer to Gurobi variables
  GRBVar* grb_x;

 public:
  /// @defgroup qbpp_grb QUBO++ API for Gurobi Optimizer
  /// @brief API to call Gurobi Optimizer from QUBO++ Library
  /// @details API to provide a way to call Gurobi Optimizer from QUBO++
  /// Library.
  /// @{

  /// @brief Constructor to create a model from HuboModel object
  /// @param hubo_model QUBO model of QUBO++ library
  /// @param verbose true if Gurobi optimizer outputs are shown on the screen
  HuboModel(const qbpp::HuboModel& hubo_model, bool verbose = false);

  /// @brief Copy constructor to create a model from another model
  /// @param grb_model Gurobi model
  HuboModel(const HuboModel& grb_model) = default;

  /// @brief Sets a parameter to the Gurobi environment
  /// @param key parameter name
  /// @param val parameter value
  void set(const std::string& key, const std::string& val) {
    grb_model_ptr->getEnv().set(key, val);
  };

  /// @brief Sets time limit to the Gurobi model
  /// @param time_limit Time limit in seconds
  void time_limit(double time_limit) {
    set("TimeLimit", std::to_string(time_limit));
  }

  /// @brief Set a callback function to the Gurobi model
  /// @param cb Pointer to the class object that includes user-defined
  /// callback function
  /// @details The callback function in the class object *cb is called during
  /// the optimization process of Gurobi Optimizer.
  void set(Callback& cb);

  /// @}

  /// @brief Get the Gurobi variable from the index
  /// @param index index of the variable from 0 to size()-1
  /// @return Gurobi variable
  GRBVar grb_var(qbpp::vindex_t index) const { return grb_x[index]; };

  /// @brief Get the Gurobi model
  /// @return Gurobi model
  GRBModel& grb_model() { return *grb_model_ptr; }

  /// @brief Get the Gurobi model
  /// @return Gurobi model
  const GRBModel& grb_model() const { return *grb_model_ptr; }

  ///@{
  /// @brief Optimize the QUBO model
  /// @return Solution of the QUBO model
  Sol optimize();
  ///@}

  /// @brief Write the model to a file
  /// @param filename File name
  /// @details The model is written in the LP format. The format type is
  /// determined by the file extension such as .lp and .mps.
  void write(std::string filename) {
    GRB_SAFE_CALL(grb_model_ptr->write(filename));
  }
};

/// @brief Class to store a solution of a QUBO model using Gurobi Optimizer
/// @details This class is used to store a solution of a QUBO model obtained
/// by Gurobi Optimizer through QUBO++ library.
class Sol : public qbpp::Sol {
  /// @brief Energy Bound obtained by of the Grobi Optimizer
  qbpp::energy_t bound_;

 public:
  /// @defgroup qbpp_grb
  /// @{

  /// @brief Creates a solution object from a model
  /// @param hubo_model QUBO model of QUBO++ library
  Sol(const qbpp::HuboModel& hubo_model) : qbpp::Sol(hubo_model) {}

  /// @}

  /// @brief Gets the energy bound of the solution
  /// @return Energy bound
  qbpp::energy_t bound() const { return bound_; }

  /// @brief Sets the energy bound of the solution
  /// @return Energy bound
  qbpp::energy_t bound(qbpp::energy_t eval) {
    bound_ = eval;
    return bound_;
  }
};

/// @brief Class to manage a callback function called by Gurobi Optimizer
/// @details This class is used to manage a callback function for Gurobi
/// Optimizer through QUBO++ library.
class Callback : public GRBCallback {
 protected:
  /// @brief QUBO model
  const HuboModel hubo_model_;

  /// @brief Shortcut to the GRBModel in HuboModel.
  const GRBModel& grb_model_;

  /// @brief Target energy to stop the Gurobi optimizer.
  std::optional<qbpp::energy_t> target_energy_ = std::nullopt;

  /// @brief Mutex to lock the critical section in get_sol()
  mutable std::mutex mtx_;

  /// @brief Abort the optimization process if the target energy is achieved
  /// @param energy Energy of the current solution
  /// @details This function is intended to be called in callback() function.
  void abort_if_target_energy(qbpp::energy_t energy) {
    if (target_energy_.has_value() && energy <= target_energy_.value()) {
      abort();
    }
  }

 public:
  /// @brief Constructor: a new Callback object
  /// @param hubo_model QUBO model of QUBO++ library
  Callback(const HuboModel& hubo_model)
      : hubo_model_(hubo_model), grb_model_(hubo_model.grb_model()) {
    qbpp::time();
  };

  virtual ~Callback() = default;

  /// @brief Get the solution obtained by Gurobi Optimizer
  /// @return Solution by Gurobi Optimizer
  Sol sol();

  /// @brief Default callback function for Gurobi Optimizer
  /// @details This function is called during the optimization process of
  /// Gurobi Optimizer. The function can be customized by overriding it.
  virtual void callback() override {
    if (where == GRB_CB_MIPSOL) {
      qbpp::energy_t energy = sol().energy();
      std::cout << "TTS = " << std::fixed << std::setprecision(3)
                << std::setfill('0') << qbpp::time() << "s Energy = " << energy
                << std::endl;
      abort_if_target_energy(energy);
    }
  }

  /// @brief Set the target energy for Gurobi Optimizer
  void target_energy(qbpp::energy_t target_energy) {
    target_energy_ = target_energy;
  }

  /// @brief Calls GetDoubleInfo() of GRBCallback
  /// @param what what to get
  /// @return double value
  double getDoubleInfoPublic(int what) { return getDoubleInfo(what); }

  /// @brief Calls getSolution() of GRBCallback
  /// @param v Gurobi variable
  /// @return double value
  double getSolutionPublic(GRBVar v) { return getSolution(v); }
};

//=============================
// Class HuboModel member functions
//=============================

inline HuboModel::HuboModel(const qbpp::HuboModel& hubo_model, bool verbose)
    : qbpp::HuboModel(hubo_model), grb_env(true) {
  // Suppress Gurobi outputs to the screen.
  GRB_SAFE_CALL(grb_env.set(GRB_IntParam_OutputFlag, 0));

  if (verbose) {
    GRB_SAFE_CALL(grb_env.set("OutputFlag", "1"));
  }
  GRB_SAFE_CALL(grb_env.start());

  if (hubo_model.max_power() > 2) {
    std::cerr << "HuboModel has a term with maximum power of "
              << hubo_model.max_power()
              << ". Gurobi supports only quadratic models." << std::endl;
  }

  grb_model_ptr = std::make_unique<GRBModel>(grb_env);

  //  Objective is minimization.
  GRB_SAFE_CALL(grb_model_ptr->set(GRB_IntAttr_ModelSense, GRB_MINIMIZE));

  // Add binary variables to the Gurobi model.
  grb_x = grb_model_ptr->addVars(static_cast<int>(var_count()), GRB_BINARY);
  // Compute objective function of QUBO problem.
  GRBQuadExpr obj;
  obj += static_cast<double>(hubo_model.constant());
  for (qbpp::vindex_t i = 0; i < var_count(); ++i) {
    if (hubo_model.term1()[i] != 0)
      obj += static_cast<double>(hubo_model.term1()[i]) * grb_x[i];
  }
  for (qbpp::vindex_t i = 0; i < var_count(); ++i) {
    qbpp::vindex_t degree =
        static_cast<qbpp::vindex_t>(hubo_model.term2(i).size());
    for (qbpp::vindex_t j = 0; j < degree; ++j) {
      // Get the indices and coefficients of the term.
      auto k = hubo_model.term2(i).indices(j)[0];
      auto coeff = hubo_model.term2(i).coeff(j);
      if (i < k) obj += static_cast<double>(coeff) * grb_x[i] * grb_x[k];
    }
  }
  // Set the objective function to the Gurobi model.
  GRB_SAFE_CALL(grb_model_ptr->setObjective(obj));
}

inline void HuboModel::set(Callback& cb) { grb_model_ptr->setCallback(&cb); }

inline Sol HuboModel::optimize() {
  Sol sol(*this);
  GRB_SAFE_CALL(grb_model_ptr->optimize());
  for (qbpp::vindex_t i = 0; i < var_count(); ++i)
    sol.set(i, int(grb_x[i].get(GRB_DoubleAttr_X)));
  sol.energy(static_cast<qbpp::energy_t>(
      std::round(grb_model_ptr->get(GRB_DoubleAttr_ObjVal))));
  sol.bound(static_cast<qbpp::energy_t>(
      std::round(grb_model_ptr->get(GRB_DoubleAttr_ObjBound))));
  return sol;
}

//================================
// Class Callback member functions
//================================

inline Sol Callback::sol() {
  Sol sol(hubo_model_);
  std::lock_guard<std::mutex> lock(mtx_);
  // Intentionally commented out because the solution obtained by getSolution
  // may provide corrupted values when Gurobi finds an optimal solution.
  // sol.set_energy(std::round(getDoubleInfoPublic(GRB_CB_MIPSOL_OBJ)));
  sol.bound(static_cast<qbpp::energy_t>(
      std::round(getDoubleInfoPublic(GRB_CB_MIPSOL_OBJBND))));
  // Get the solution from Gurobi Optimizer.
  for (qbpp::vindex_t i = 0; i < hubo_model_.var_count(); ++i) {
    sol.set(i, int(getSolutionPublic(hubo_model_.grb_var(i))));
  }
  // eval is used to compute the energy of the solution instead of MIPSOL_OBJ.
  sol.energy(eval(hubo_model_, sol));
  return sol;
}

using QuboModel = HuboModel;
}  // namespace grb
namespace qbpp_grb = grb;
}  // namespace qbpp
