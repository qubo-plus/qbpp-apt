/// @file gurobi.hpp
/// @brief GurobiSolver — header-only wrapper calling Gurobi Optimizer
/// @version 2026.04.22

#pragma once

#include <chrono>
#include <cmath>
#include <cstdlib>
#include <memory>
#include <mutex>
#include <optional>
#include <string>
#include <vector>

#include "gurobi_c++.h"
#include "qbpp.hpp"

namespace qbpp {
namespace gurobi {

using GurobiSol = SolverSol;

namespace detail {

inline std::string gurobi_status_name(int s) {
  switch (s) {
    case GRB_LOADED:          return "LOADED";
    case GRB_OPTIMAL:         return "OPTIMAL";
    case GRB_INFEASIBLE:      return "INFEASIBLE";
    case GRB_INF_OR_UNBD:     return "INF_OR_UNBD";
    case GRB_UNBOUNDED:       return "UNBOUNDED";
    case GRB_CUTOFF:          return "CUTOFF";
    case GRB_ITERATION_LIMIT: return "ITERATION_LIMIT";
    case GRB_NODE_LIMIT:      return "NODE_LIMIT";
    case GRB_TIME_LIMIT:      return "TIME_LIMIT";
    case GRB_SOLUTION_LIMIT:  return "SOLUTION_LIMIT";
    case GRB_INTERRUPTED:     return "INTERRUPTED";
    case GRB_NUMERIC:         return "NUMERIC";
    case GRB_SUBOPTIMAL:      return "SUBOPTIMAL";
    case GRB_INPROGRESS:      return "INPROGRESS";
    case GRB_USER_OBJ_LIMIT:  return "USER_OBJ_LIMIT";
    default:                  return "STATUS_" + std::to_string(s);
  }
}

inline std::string gurobi_version_str() {
  int major = 0, minor = 0, technical = 0;
  GRBversion(&major, &minor, &technical);
  return std::to_string(major) + "." + std::to_string(minor) + "." +
         std::to_string(technical);
}

/// Convert any qbpp integer type to double. cpp_int and __int128 go via
/// string to avoid compile errors / precision surprises on direct cast.
template <typename T>
inline double to_double(const T& v) {
  if constexpr (std::is_same_v<T, cpp_int>) {
    return std::stod(_to_string(v));
#ifdef __SIZEOF_INT128__
  } else if constexpr (std::is_same_v<T, __int128>) {
    return std::stod(_to_string(v));
#endif
  } else {
    return static_cast<double>(v);
  }
}

/// Keys recognised by apply_param(); anything else is forwarded verbatim to
/// GRBEnv::set(key, val).
inline bool is_qbpp_param(const char* key) {
  return std::strcmp(key, "time_limit") == 0 ||
         std::strcmp(key, "target_energy") == 0 ||
         std::strcmp(key, "thread_count") == 0 ||
         std::strcmp(key, "topk_sols") == 0 ||
         std::strcmp(key, "best_energy_sols") == 0 ||
         std::strcmp(key, "license_file") == 0;
}

}  // namespace detail

/// Internal callback — fires on each new incumbent, records tts and
/// aborts early when target_energy is reached.
class GurobiCallback : public GRBCallback {
 public:
  std::optional<energy_t> target_energy;
  std::chrono::steady_clock::time_point t_start =
      std::chrono::steady_clock::now();
  double best_tts = 0.0;
  bool has_best = false;
  energy_t best_energy = 0;
  std::mutex mtx;

  void callback() override {
    if (where != GRB_CB_MIPSOL) return;
    std::lock_guard<std::mutex> lk(mtx);
    double obj = getDoubleInfo(GRB_CB_MIPSOL_OBJ);
    energy_t e = static_cast<energy_t>(std::llround(obj));
    if (!has_best || e < best_energy) {
      best_energy = e;
      has_best = true;
      best_tts = std::chrono::duration<double>(
                     std::chrono::steady_clock::now() - t_start)
                     .count();
    }
    if (target_energy.has_value() && e <= *target_energy) abort();
  }
};

class GurobiSolver {
  Model model_;
  // Build env_ in the body so we can set OutputFlag *before* start().
  // grb_model_ must be constructed AFTER env_.start(), so use unique_ptr.
  GRBEnv env_;
  std::unique_ptr<GRBModel> grb_model_ptr_;
  std::vector<GRBVar> grb_vars_;

  GRBModel& grb_model_() { return *grb_model_ptr_; }
  const GRBModel& grb_model_() const { return *grb_model_ptr_; }

  GurobiSolver(const GurobiSolver&) = delete;
  GurobiSolver& operator=(const GurobiSolver&) = delete;

  static GRBEnv make_env_() {
    GRBEnv e(true);
    e.set(GRB_IntParam_OutputFlag, 0);
    e.start();
    return e;
  }

  void build_gurobi_model_() {
    if (model_.max_degree() > 2) {
      throw std::runtime_error(
          "GurobiSolver: max_degree=" +
          std::to_string(model_.max_degree()) +
          " is not supported. Gurobi handles QUBO (degree<=2); "
          "reduce the HUBO to QUBO first.");
    }

    grb_model_().set(GRB_IntAttr_ModelSense, GRB_MINIMIZE);

    const vindex_t vc = model_.var_count();
    grb_vars_.reserve(vc);
    for (vindex_t i = 0; i < vc; ++i) {
      std::string nm = model_.var(i)._str();
      grb_vars_.push_back(grb_model_().addVar(0.0, 1.0, 0.0, GRB_BINARY, nm));
    }
    grb_model_().update();

    GRBQuadExpr obj;
    obj += detail::to_double(model_.constant());

    // Degree 1 terms
    if (model_.max_degree() >= 1) {
      uint32_t n = model_.term_count(1);
      const vindex_t* tv = model_.term_vars(1);
      const flat_coeff_t* ca = model_.coeff_array(1);
      for (uint32_t t = 0; t < n; ++t) {
        vindex_t raw = tv[t];
        double c = detail::to_double(_from_flat_c(ca[t]));
        vindex_t idx = raw & vindex_mask;
        if (raw & vindex_neg_bit) {
          // ~x = 1 - x
          obj += c;
          obj += -c * grb_vars_[idx];
        } else {
          obj += c * grb_vars_[idx];
        }
      }
    }

    // Degree 2 terms
    if (model_.max_degree() >= 2) {
      uint32_t n = model_.term_count(2);
      const vindex_t* tv = model_.term_vars(2);
      const flat_coeff_t* ca = model_.coeff_array(2);
      for (uint32_t t = 0; t < n; ++t) {
        vindex_t a = tv[2 * t];
        vindex_t b = tv[2 * t + 1];
        double c = detail::to_double(_from_flat_c(ca[t]));
        bool neg_a = (a & vindex_neg_bit) != 0;
        bool neg_b = (b & vindex_neg_bit) != 0;
        vindex_t ia = a & vindex_mask;
        vindex_t ib = b & vindex_mask;
        GRBVar& xa = grb_vars_[ia];
        GRBVar& xb = grb_vars_[ib];

        // Expand (~x = 1 - x):
        // (1) plain xa * xb
        // (2) ~xa * xb      = xb - xa * xb
        // (3) xa  * ~xb     = xa - xa * xb
        // (4) ~xa * ~xb     = 1 - xa - xb + xa * xb
        if (!neg_a && !neg_b) {
          obj += c * xa * xb;
        } else if (neg_a && !neg_b) {
          obj += c * xb;
          obj += -c * xa * xb;
        } else if (!neg_a && neg_b) {
          obj += c * xa;
          obj += -c * xa * xb;
        } else {
          obj += c;
          obj += -c * xa;
          obj += -c * xb;
          obj += c * xa * xb;
        }
      }
    }

    grb_model_().setObjective(obj);
    // Default: silent unless user opts in via output_flag.
    grb_model_().set(GRB_IntParam_OutputFlag, 0);
  }

  void apply_params_(const Params& p, GurobiCallback& cb) {
    for (size_t i = 0; i < p.size(); ++i) {
      const char* k = p.data()[i].key;
      const char* v = p.data()[i].value;
      try {
        if (std::strcmp(k, "time_limit") == 0) {
          grb_model_().set(GRB_DoubleParam_TimeLimit, std::atof(v));
        } else if (std::strcmp(k, "target_energy") == 0) {
          cb.target_energy = static_cast<energy_t>(std::atoll(v));
        } else if (std::strcmp(k, "thread_count") == 0) {
          grb_model_().set(GRB_IntParam_Threads, std::atoi(v));
        } else if (std::strcmp(k, "topk_sols") == 0 ||
                   std::strcmp(k, "best_energy_sols") == 0) {
          int kk = std::atoi(v);
          if (kk > 0) {
            grb_model_().set(GRB_IntParam_PoolSearchMode, 2);
            grb_model_().set(GRB_IntParam_PoolSolutions, kk);
          }
        } else if (std::strcmp(k, "license_file") == 0) {
          setenv("GRB_LICENSE_FILE", v, 1);
        } else {
          // Unknown: forward to Gurobi environment verbatim.
          grb_model_().set(k, v);
        }
      } catch (const GRBException& e) {
        throw std::runtime_error(std::string("GurobiSolver: parameter '") +
                                 k + "'=" + v + " rejected: " + e.getMessage());
      }
    }
  }

 public:
  explicit GurobiSolver(Model&& model)
      : model_(std::move(model)), env_(make_env_()) {
    if (model_.var_count() == 0)
      throw std::runtime_error("GurobiSolver: expression has no variables");
    try {
      grb_model_ptr_ = std::make_unique<GRBModel>(env_);
      build_gurobi_model_();
    } catch (const GRBException& e) {
      throw std::runtime_error(std::string("GurobiSolver: ") + e.getMessage());
    }
  }

  explicit GurobiSolver(const Expr& expr) : GurobiSolver(Model(expr)) {}

  template <size_t Dim, typename T>
  explicit GurobiSolver(const Array<Dim, T>& arr) : GurobiSolver(sum(arr)) {}

  vindex_t var_count() const { return model_.var_count(); }
  const Model& model() const { return model_; }
  GRBModel& grb_model() { return *grb_model_ptr_; }
  const GRBModel& grb_model() const { return *grb_model_ptr_; }
  GRBVar grb_var(vindex_t i) const { return grb_vars_[i]; }

  /// Write the model to a file (.lp, .mps, etc. — Gurobi picks by extension).
  void write(const std::string& filename) { grb_model_().write(filename); }

  GurobiSol search() {
    Params p;
    return search(p);
  }
  GurobiSol search(Params&& p) { return search(p); }

  GurobiSol search(Params& params) {
    if (params.has_hint())
      throw std::runtime_error("GurobiSolver does not support hint");

    GurobiCallback cb;
    apply_params_(params, cb);
    grb_model_().setCallback(&cb);

    auto t0 = std::chrono::steady_clock::now();
    try {
      grb_model_().optimize();
    } catch (const GRBException& e) {
      throw std::runtime_error(std::string("GurobiSolver: optimize failed: ") +
                               e.getMessage());
    }
    auto t1 = std::chrono::steady_clock::now();
    double run_time = std::chrono::duration<double>(t1 - t0).count();

    int status = grb_model_().get(GRB_IntAttr_Status);
    int sol_count = grb_model_().get(GRB_IntAttr_SolCount);

    GurobiSol result(qbpp_sol_create(model_.impl()));

    if (sol_count > 0) {
      const vindex_t vc = model_.var_count();
      // Primary solution: index 0 == incumbent
      for (vindex_t i = 0; i < vc; ++i) {
        double xv = grb_vars_[i].get(GRB_DoubleAttr_X);
        result.set(model_.var(i), xv > 0.5);
      }
      result.energy(static_cast<energy_t>(
          std::llround(grb_model_().get(GRB_DoubleAttr_ObjVal))));
      result.tts(cb.best_tts > 0.0 ? cb.best_tts : run_time);

      // Solution pool → result.sols (skip index 0, that's the incumbent)
      for (int k = 1; k < sol_count; ++k) {
        grb_model_().set(GRB_IntParam_SolutionNumber, k);
        Sol s(qbpp_sol_create(model_.impl()));
        for (vindex_t i = 0; i < vc; ++i) {
          double xv = grb_vars_[i].get(GRB_DoubleAttr_Xn);
          s.set(model_.var(i), xv > 0.5);
        }
        s.energy(static_cast<energy_t>(
            std::llround(grb_model_().get(GRB_DoubleAttr_PoolObjVal))));
        s.tts(run_time);
        result.sols.push_back(std::move(s));
      }
    } else {
      // No feasible solution found — leave all-zero sol with energy from model
      result.tts(run_time);
    }

    // --- Info ---
    result.info_.set("os",       qbpp_const_str("os"));
    result.info_.set("cpu",      qbpp_const_str("cpu_info"));
    result.info_.set("gpu",      qbpp_const_str("gpu"));
    result.info_.set("ram",      qbpp_const_str("total_ram"));
    result.info_.set("hostname", qbpp_const_str("hostname"));
    result.info_.set("version",  qbpp_const_str("version"));
    result.info_.set("run_time", std::to_string(run_time));
    result.info_.set("solver",   "GurobiSolver");
    result.info_.set("gurobi_version", detail::gurobi_version_str());
    result.info_.set("status",         detail::gurobi_status_name(status));
    result.info_.set("var_count",      std::to_string(model_.var_count()));
    result.info_.set("term_count",     std::to_string(model_.term_count()));
    result.info_.set("solution_count", std::to_string(sol_count));

    try {
      double bound = grb_model_().get(GRB_DoubleAttr_ObjBound);
      result.info_.set("bound", std::to_string(bound));
    } catch (GRBException&) {}
    try {
      double gap = grb_model_().get(GRB_DoubleAttr_MIPGap);
      result.info_.set("mip_gap", std::to_string(gap));
    } catch (GRBException&) {}
    try {
      double nodes = grb_model_().get(GRB_DoubleAttr_NodeCount);
      result.info_.set("node_count", std::to_string(static_cast<long long>(nodes)));
    } catch (GRBException&) {}
    try {
      double iters = grb_model_().get(GRB_DoubleAttr_IterCount);
      result.info_.set("iter_count", std::to_string(static_cast<long long>(iters)));
    } catch (GRBException&) {}

    return result;
  }
};

}  // namespace gurobi

using gurobi::GurobiSolver;
using gurobi::GurobiSol;

}  // namespace qbpp
