/// @file qbpp.hpp
/// @brief QUBO++ main header
/// @version 2026.04.28

// Accept `#define MAXDEG <N>` as an alias for `#define MAXDEG<N>` (N ∈ {2,4,6}).
// Writing `#define MAXDEG 4` used to silently fall back to m0 mode.
#if defined(MAXDEG)
#if MAXDEG == 2
#define MAXDEG2
#elif MAXDEG == 4
#define MAXDEG4
#elif MAXDEG == 6
#define MAXDEG6
#else
#error "MAXDEG must be 2, 4, or 6 (e.g. #define MAXDEG 4, or #define MAXDEG4)"
#endif
#endif
// Stage D-5a: in-place ArrayBase ops no longer silently promote non-Expr LHS to Expr;
// they now throw. This verifies that the promotion path is dead code before removal.
// Stage D-6a: Array<Dim,T> binary ops (+, -, *) dispatch at compile time via
// `if constexpr` on T/U, calling qbpp_array_<t>_<op>_array_<u> directly instead
// of going through ArrayBase::operator+/-/* + array_dispatch::<op> runtime switch.
// Stage D-4a: migrated from qbpp_ary_* to per-type qbpp_array_<type>_* ABI.

#pragma once

#include <array>
#include <cstdint>
#include <cstdlib>
#include <cstring>
#include <iostream>
#include <numeric>
#include <stdexcept>
#include <string>
#include <thread>
#include <type_traits>
#include <unordered_map>
#include <variant>
#include <vector>

// __int128 stream output (must be global, before namespace qbpp)
// Exclude from CUDA compilation (nvcc has its own __int128 handling)
#if defined(__SIZEOF_INT128__) && !defined(__CUDACC__)
inline std::ostream& operator<<(std::ostream& os, __int128 v) {
  if (v == 0) return os << '0';
  if (v < 0) { os << '-'; v = -v; }
  std::string s;
  while (v > 0) { s += static_cast<char>('0' + static_cast<int>(v % 10)); v /= 10; }
  return os << std::string(s.rbegin(), s.rend());
}
#endif

// --- Integer type shorthand macros ---
// Define one of these before including this header:
//   INTEGER_TYPE_C32E32   → coeff_t=int32_t,       energy_t=int32_t
//   INTEGER_TYPE_C32E64   → coeff_t=int32_t,       energy_t=int64_t  (default)
//   INTEGER_TYPE_C64E64   → coeff_t=int64_t,       energy_t=int64_t
//   INTEGER_TYPE_C64E128  → coeff_t=int64_t,       energy_t=int128_t
//   INTEGER_TYPE_C128E128 → coeff_t=int128_t,      energy_t=int128_t
//   INTEGER_TYPE_CPP_INT  → coeff_t=cpp_int,       energy_t=cpp_int
#ifdef INTEGER_TYPE_C32E32
#define COEFF_TYPE int32_t
#define ENERGY_TYPE int32_t
#endif
#ifdef INTEGER_TYPE_C32E64
#define COEFF_TYPE int32_t
#define ENERGY_TYPE int64_t
#endif
#ifdef INTEGER_TYPE_C64E64
#define COEFF_TYPE int64_t
#define ENERGY_TYPE int64_t
#endif
#ifdef INTEGER_TYPE_C64E128
#define COEFF_TYPE int64_t
#define ENERGY_TYPE __int128
#endif
#ifdef INTEGER_TYPE_C128E128
#define COEFF_TYPE __int128
#define ENERGY_TYPE __int128
#endif

// Boost include must be outside namespace
#ifdef INTEGER_TYPE_CPP_INT
#define BOOST_MP_NO_ET
#include <boost/multiprecision/cpp_int.hpp>
#endif

namespace qbpp {

// ---------------------------------------------------------------------------
// Type definitions
// ---------------------------------------------------------------------------

using vindex_t = uint32_t;

/// All bits 1 — reserved (VarVoid)
constexpr vindex_t vindex_limit = ~vindex_t(0);

/// MSB = negation bit
constexpr vindex_t vindex_neg_bit = vindex_t(1) << 31;

/// Mask to extract base index (clear negation bit)
constexpr vindex_t vindex_mask = ~vindex_neg_bit;

#ifdef __SIZEOF_INT128__
using int128_t = __int128;
#endif

/// cpp_int type — define INTEGER_TYPE_CPP_INT to enable
#ifdef INTEGER_TYPE_CPP_INT
using cpp_int = boost::multiprecision::number<
    boost::multiprecision::cpp_int_backend<>,
    boost::multiprecision::et_off>;
using coeff_t = cpp_int;
using energy_t = cpp_int;
#else
struct cpp_int {};  // stub
#ifdef COEFF_TYPE
using coeff_t = COEFF_TYPE;
#else
using coeff_t = int32_t;
#endif
#ifdef ENERGY_TYPE
using energy_t = ENERGY_TYPE;
#else
using energy_t = int64_t;
#endif
#endif

/// ABI-stable arbitrary precision integer for .so boundary
struct abi_bigint {
  int32_t sign;
  uint32_t size;
  uint64_t* limbs;

  abi_bigint() noexcept : sign(0), size(0), limbs(nullptr) {}

#ifdef INTEGER_TYPE_CPP_INT
  // NOLINTNEXTLINE(google-explicit-constructor)
  abi_bigint(const cpp_int& x) : sign(0), size(0), limbs(nullptr) {
    if (x == 0) return;
    sign = (x > 0) ? 1 : -1;
    cpp_int abs_x = boost::multiprecision::abs(x);
    auto bit_count = static_cast<uint32_t>(boost::multiprecision::msb(abs_x)) + 1;
    size = (bit_count + 63) / 64;
    limbs = static_cast<uint64_t*>(std::malloc(size * sizeof(uint64_t)));
    if (!limbs) throw std::bad_alloc();
    cpp_int mask = (cpp_int(1) << 64) - 1;
    for (uint32_t i = 0; i < size; ++i) {
      limbs[i] = (abs_x & mask).template convert_to<uint64_t>();
      abs_x >>= 64;
    }
  }
  explicit operator cpp_int() const {
    if (sign == 0 || size == 0) return cpp_int(0);
    cpp_int result = 0;
    for (uint32_t i = size; i > 0; --i) {
      result <<= 64;
      result |= limbs[i - 1];
    }
    if (sign < 0) result = -result;
    return result;
  }
#endif

  // From integer literal (int64_t) — always available
  // NOLINTNEXTLINE(google-explicit-constructor)
  abi_bigint(int64_t v) noexcept : sign(0), size(0), limbs(nullptr) {
    if (v == 0) return;
    sign = (v > 0) ? 1 : -1;
    uint64_t abs_v = (v > 0) ? static_cast<uint64_t>(v)
                              : static_cast<uint64_t>(-(v + 1)) + 1ULL;
    size = 1;
    limbs = static_cast<uint64_t*>(std::malloc(sizeof(uint64_t)));
    limbs[0] = abs_v;
  }

  abi_bigint(const abi_bigint& o) : sign(o.sign), size(o.size), limbs(nullptr) {
    if (size > 0) {
      limbs = static_cast<uint64_t*>(std::malloc(size * sizeof(uint64_t)));
      if (!limbs) throw std::bad_alloc();
      std::memcpy(limbs, o.limbs, size * sizeof(uint64_t));
    }
  }
  abi_bigint(abi_bigint&& o) noexcept : sign(o.sign), size(o.size), limbs(o.limbs) {
    o.sign = 0; o.size = 0; o.limbs = nullptr;
  }
  abi_bigint& operator=(const abi_bigint& o) {
    if (this != &o) {
      std::free(limbs);
      sign = o.sign; size = o.size;
      if (size > 0) {
        limbs = static_cast<uint64_t*>(std::malloc(size * sizeof(uint64_t)));
        if (!limbs) throw std::bad_alloc();
        std::memcpy(limbs, o.limbs, size * sizeof(uint64_t));
      } else { limbs = nullptr; }
    }
    return *this;
  }
  abi_bigint& operator=(abi_bigint&& o) noexcept {
    if (this != &o) {
      std::free(limbs);
      sign = o.sign; size = o.size; limbs = o.limbs;
      o.sign = 0; o.size = 0; o.limbs = nullptr;
    }
    return *this;
  }
  ~abi_bigint() { std::free(limbs); }

  std::string _str() const {
#ifdef INTEGER_TYPE_CPP_INT
    return cpp_int(*this).str();
#else
    return "0";
#endif
  }
};

/// Flat types for .so ABI boundary (cpp_int → abi_bigint)
using flat_coeff_t =
    std::conditional_t<std::is_same_v<coeff_t, cpp_int>, abi_bigint, coeff_t>;
using flat_energy_t =
    std::conditional_t<std::is_same_v<energy_t, cpp_int>, abi_bigint, energy_t>;

/// ABI argument types: value for fixed types, pointer for cpp_int
#ifdef INTEGER_TYPE_CPP_INT
using flat_energy_arg = const abi_bigint*;
using flat_coeff_arg  = const abi_bigint*;
inline energy_t _to_energy(flat_energy_arg c) { return static_cast<energy_t>(*c); }
inline coeff_t  _to_coeff(flat_coeff_arg c)   { return static_cast<coeff_t>(*c); }
#else
using flat_energy_arg = flat_energy_t;
using flat_coeff_arg  = flat_coeff_t;
inline energy_t _to_energy(flat_energy_arg c) { return static_cast<energy_t>(c); }
inline coeff_t  _to_coeff(flat_coeff_arg c)   { return static_cast<coeff_t>(c); }
#endif

/// RAII wrappers: create flat_*_t on stack, auto-convert to arg (value or pointer)
/// Temporaries survive until semicolon → safe for multiple args in one call.
#ifdef INTEGER_TYPE_CPP_INT
struct FlatEnergy {
  flat_energy_t val;
  FlatEnergy(energy_t v) : val(v) {}
  operator flat_energy_arg() const { return &val; }
};
struct FlatCoeff {
  flat_coeff_t val;
  FlatCoeff(coeff_t v) : val(v) {}
  operator flat_coeff_arg() const { return &val; }
};
#else
struct FlatEnergy {
  flat_energy_t val;
  FlatEnergy(energy_t v) : val(v) {}
  operator flat_energy_arg() const { return val; }
};
struct FlatCoeff {
  flat_coeff_t val;
  FlatCoeff(coeff_t v) : val(v) {}
  operator flat_coeff_arg() const { return val; }
};
#endif

/// Read flat value back to native type
inline energy_t _from_flat(const flat_energy_t& f) { return static_cast<energy_t>(f); }
inline coeff_t _from_flat_c(const flat_coeff_t& f) { return static_cast<coeff_t>(f); }

/// _to_string: dispatches to std::to_string, cpp_int .str(), or custom __int128 version
template <typename T>
inline std::string _to_string(T v) {
  if constexpr (std::is_same_v<std::decay_t<T>, cpp_int>)
    return v.str();
  else
    return std::to_string(v);
}

#ifdef __SIZEOF_INT128__
template <>
inline std::string _to_string<__int128>(__int128 v) {
  if (v == 0) return "0";
  std::string s;
  bool neg = (v < 0);
  if (neg) v = -v;
  while (v > 0) { s += static_cast<char>('0' + static_cast<int>(v % 10)); v /= 10; }
  if (neg) s += '-';
  return std::string(s.rbegin(), s.rend());
}
#endif

/// QBPP_DIE: fatal error handler. Prints a message to stderr and aborts.
/// The library .so files are linked with -static-libstdc++, so C++ exceptions
/// thrown inside them cannot be caught by user code (the user executable has
/// a different std::runtime_error typeinfo). All library-internal fatal errors
/// therefore use this macro instead of throwing.
///   QBPP_DIE("Division by zero");
///   QBPP_DIE("Variable limit exceeded (" << limit << ")");
#ifndef QBPP_DIE
#define QBPP_DIE(msg) do { \
    std::cerr << "qbpp: " << msg << std::endl; \
    std::abort(); \
  } while (0)
#endif

/// Parse a decimal string into coeff_t.
/// Works uniformly for every coeff_t (int16_t..int128_t, cpp_int), so user
/// code can stay type-agnostic across INTEGER_TYPE_* builds. Accepts an
/// optional leading '+' / '-'. Throws std::invalid_argument on malformed
/// input and std::out_of_range if the value does not fit in coeff_t.
inline coeff_t integer(const char* s) {
#ifdef INTEGER_TYPE_CPP_INT
  if (!s) throw std::invalid_argument("qbpp::integer: null string");
  const char* p = s;
  while (*p == ' ' || *p == '\t') ++p;
  if (*p == '+') ++p;  // cpp_int constructor doesn't accept leading '+'
  return cpp_int(p);
#else
  if (!s || !*s) throw std::invalid_argument("qbpp::integer: empty string");
  const char* p = s;
  while (*p == ' ' || *p == '\t') ++p;
  bool neg = false;
  if (*p == '-') { neg = true; ++p; }
  else if (*p == '+') { ++p; }
  if (*p < '0' || *p > '9')
    throw std::invalid_argument(std::string("qbpp::integer: invalid string: ") + s);

#ifdef __SIZEOF_INT128__
  using W = __int128;
  // W_MAX = 2^127 - 1, written without relying on numeric_limits<__int128>
  constexpr W W_MAX = (((W(1) << 126) - 1) << 1) + 1;
#else
  using W = int64_t;
  constexpr W W_MAX = std::numeric_limits<int64_t>::max();
#endif

  W v = 0;
  for (; *p; ++p) {
    if (*p < '0' || *p > '9')
      throw std::invalid_argument(std::string("qbpp::integer: invalid character in: ") + s);
    int d = *p - '0';
    if (v > (W_MAX - d) / 10)
      throw std::out_of_range(std::string("qbpp::integer: value overflows parser width: ") + s);
    v = v * 10 + d;
  }

  // Range check against coeff_t (skipped when coeff_t is the scratch width).
  if constexpr (sizeof(coeff_t) * 8 < sizeof(W) * 8) {
    constexpr int bits = sizeof(coeff_t) * 8;
    const W hi = W(1) << (bits - 1);         // |coeff_t::min|
    const W limit = neg ? hi : (hi - 1);     // positive max is one less
    if (v > limit)
      throw std::out_of_range(std::string("qbpp::integer: value out of range for coeff_t: ") + s);
  }

  if (neg) v = -v;
  return static_cast<coeff_t>(v);
#endif
}

inline coeff_t integer(const std::string& s) { return integer(s.c_str()); }

/// THROW_MESSAGE: variadic string builder for exceptions
template <typename... Args>
inline std::string _throw_message_impl(Args&&... args) {
  std::string s;
  ((s += [](auto&& a) -> std::string {
    using T = std::decay_t<decltype(a)>;
    if constexpr (std::is_same_v<T, std::string>) return a;
    else if constexpr (std::is_same_v<T, const char*>) return a;
    else if constexpr (std::is_arithmetic_v<T>) return std::to_string(a);
    else return "?";
  }(std::forward<Args>(args))), ...);
  return s;
}
#ifndef THROW_MESSAGE
#define THROW_MESSAGE(...) qbpp::_throw_message_impl(__VA_ARGS__)
#endif

/// Version and license info — declared after QBPP_LAZY macro below

// ---------------------------------------------------------------------------
// .so name selection based on coeff_t / energy_t
// ---------------------------------------------------------------------------

/// Returns the correct qbpp_*.so name for the current type + VarArray mode.
/// VarArray mode suffix: m0 (default/unspecified), m2, m4, m6.
/// Filename intentionally has NO `lib` prefix: `-lqbpp_*` must not find these
/// via the linker (they are dlopen-only; linking statically would double-load).
#ifndef __CUDACC__
inline const char* qbpp_lib_name() {
// VarArray mode suffix
#if defined(MAXDEG6)
#define QBPP_MODE_SUFFIX "m6"
#elif defined(MAXDEG4)
#define QBPP_MODE_SUFFIX "m4"
#elif defined(MAXDEG2)
#define QBPP_MODE_SUFFIX "m2"
#else
#define QBPP_MODE_SUFFIX "m0"
#endif
#define QBPP_LIB_SUFFIX ".so"
#if defined(INTEGER_TYPE_CPP_INT)
  return "qbpp_cppint" QBPP_MODE_SUFFIX QBPP_LIB_SUFFIX;
#elif defined(INTEGER_TYPE_C32E32)
  return "qbpp_c32e32" QBPP_MODE_SUFFIX QBPP_LIB_SUFFIX;
#elif defined(INTEGER_TYPE_C64E64)
  return "qbpp_c64e64" QBPP_MODE_SUFFIX QBPP_LIB_SUFFIX;
#elif defined(INTEGER_TYPE_C64E128)
  return "qbpp_c64e128" QBPP_MODE_SUFFIX QBPP_LIB_SUFFIX;
#elif defined(INTEGER_TYPE_C128E128)
  return "qbpp_c128e128" QBPP_MODE_SUFFIX QBPP_LIB_SUFFIX;
#else
  constexpr size_t cs = sizeof(coeff_t), es = sizeof(energy_t);
  if constexpr (cs == 4 && es == 4) return "qbpp_c32e32" QBPP_MODE_SUFFIX QBPP_LIB_SUFFIX;
  if constexpr (cs == 4 && es == 8) return "qbpp_c32e64" QBPP_MODE_SUFFIX QBPP_LIB_SUFFIX;
  if constexpr (cs == 8 && es == 8) return "qbpp_c64e64" QBPP_MODE_SUFFIX QBPP_LIB_SUFFIX;
  if constexpr (cs == 8 && es == 16) return "qbpp_c64e128" QBPP_MODE_SUFFIX QBPP_LIB_SUFFIX;
  if constexpr (cs == 16 && es == 16) return "qbpp_c128e128" QBPP_MODE_SUFFIX QBPP_LIB_SUFFIX;
  return nullptr;
#endif
#undef QBPP_LIB_SUFFIX
#undef QBPP_MODE_SUFFIX
}
#endif

// ---------------------------------------------------------------------------
// Lazy dlopen dispatch — each C ABI function resolved on first call
// ---------------------------------------------------------------------------

#ifndef __CUDACC__
// dlfcn.h must be included outside namespace qbpp
#endif
}  // namespace qbpp (temporary close for dlfcn include)
#ifndef __CUDACC__
#include <dlfcn.h>
#endif
namespace qbpp {
#if !defined(__CUDACC__) && !defined(QBPP_STANDALONE)

namespace detail {

/// Get the shared .so handle (opened once, cached).
/// Search order:
///   1. Bare name — resolved via LD_LIBRARY_PATH, caller's DT_RUNPATH
///      (e.g. $ORIGIN/../lib for in-tree test binaries), and ld.so.cache
///      (APT install registers /usr/lib/qbpp/ via /etc/ld.so.conf.d/qbpp.conf).
///   2. Absolute "/usr/lib/qbpp/" + name — hard fallback for APT installs on
///      systems where ldconfig has not yet been run.
inline void*& qbpp_so_handle() {
  static void* h = nullptr;
  if (!h) {
    const char* name = qbpp_lib_name();
    if (!name) {
      std::cerr << "QUBO++: unsupported coeff_t/energy_t combination\n";
      std::abort();
    }
    h = dlopen(name, RTLD_NOW | RTLD_GLOBAL);
    if (!h) {
      h = dlopen((std::string("/usr/lib/qbpp/") + name).c_str(),
                 RTLD_NOW | RTLD_GLOBAL);
    }
    if (!h) {
      std::cerr << "QUBO++: failed to load " << name << ": " << dlerror() << "\n";
      std::abort();
    }
  }
  return h;
}

/// Resolve a symbol from the .so (cached per call site via static local)
template <typename FuncPtr>
inline FuncPtr _resolve(const char* symbol) {
  void* p = dlsym(qbpp_so_handle(), symbol);
  if (!p) {
    std::cerr << "QUBO++: symbol not found: " << symbol << "\n";
    std::abort();
  }
  return reinterpret_cast<FuncPtr>(p);
}

}  // namespace detail

/// Macro: define a lazy-binding inline wrapper for a C ABI function.
/// On first call, dlsym resolves the function pointer; subsequent calls use cached pointer.
#define QBPP_LAZY(ret, name, params, args) \
  inline ret name params { \
    using FP = ret(*) params; \
    static FP fp = detail::_resolve<FP>(#name); \
    return fp args; \
  }
#define QBPP_LAZY_VOID(name, params, args) \
  inline void name params { \
    using FP = void(*) params; \
    static FP fp = detail::_resolve<FP>(#name); \
    fp args; \
  }
// Variant that resolves a different symbol name (used for v2 migration)
#define QBPP_LAZY_AS(ret, name, symbol, params, args) \
  inline ret name params { \
    using FP = ret(*) params; \
    static FP fp = detail::_resolve<FP>(symbol); \
    return fp args; \
  }
#define QBPP_LAZY_VOID_AS(name, symbol, params, args) \
  inline void name params { \
    using FP = void(*) params; \
    static FP fp = detail::_resolve<FP>(symbol); \
    fp args; \
  }
#else
// CUDA / standalone tools: use regular extern "C" declarations (no dlopen)
#define QBPP_LAZY(ret, name, params, args) extern "C" ret name params;
#define QBPP_LAZY_VOID(name, params, args) extern "C" void name params;
#define QBPP_LAZY_AS(ret, name, symbol, params, args) extern "C" ret name params;
#define QBPP_LAZY_VOID_AS(name, symbol, params, args) extern "C" void name params;
#endif

// ---------------------------------------------------------------------------
// VarBase2 — 2-variable index pair for C ABI (trivial POD, extern "C" safe)
// ---------------------------------------------------------------------------
struct VarBase2 {
  vindex_t v[2] = {vindex_limit, vindex_limit};
  static constexpr vindex_t VOID = vindex_limit;
  uint32_t degree() const {
    if (v[0] == VOID) return 0;
    if (v[1] == VOID) return 1;
    return 2;
  }
};

// ---------------------------------------------------------------------------
// C ABI — lazy-binding wrappers (resolved from qbpp_*.so at runtime via dlopen)
// ---------------------------------------------------------------------------

// Version and license info
QBPP_LAZY(const char*, qbpp_const_str, (const char* key), (key))
QBPP_LAZY(size_t, qbpp_max_var_count, (), ())
QBPP_LAZY(size_t, qbpp_gpu_max_var_count, (), ())
QBPP_LAZY_VOID(qbpp_floating_checkin, (), ())

// Var management
QBPP_LAZY(vindex_t, qbpp_new_var, (const char* name), (name))
QBPP_LAZY(vindex_t, qbpp_new_var_array, (const char* name, const size_t* shape, size_t ndim), (name, shape, ndim))
QBPP_LAZY(const char*, qbpp_auto_var_name, (), ())
QBPP_LAZY(const char*, qbpp_var_str, (vindex_t index), (index))
QBPP_LAZY(vindex_t, qbpp_var_count, (), ())
QBPP_LAZY_VOID(qbpp_var_reset, (), ())

// Term management
QBPP_LAZY(void*, qbpp_term_create, (flat_energy_arg coeff), (coeff))
QBPP_LAZY(void*, qbpp_term_create_var, (flat_energy_arg coeff, vindex_t v), (coeff, v))
QBPP_LAZY(void*, qbpp_term_create_var_var, (flat_energy_arg coeff, vindex_t v1, vindex_t v2), (coeff, v1, v2))
QBPP_LAZY(void*, qbpp_term_create_vararray, (flat_energy_arg coeff, VarBase2 vb, const vindex_t* extra), (coeff, vb, extra))
QBPP_LAZY(void*, qbpp_term_clone, (const void* t), (t))
QBPP_LAZY_VOID(qbpp_term_destroy, (void* t), (t))
QBPP_LAZY_VOID(qbpp_term_mul_var, (void* t, vindex_t v), (t, v))
QBPP_LAZY_VOID(qbpp_term_mul_coeff, (void* t, flat_energy_arg c), (t, c))
QBPP_LAZY(void*, qbpp_term_mul_term, (const void* a, const void* b), (a, b))
QBPP_LAZY(void*, qbpp_term_mul_term_move, (void* a, const void* b), (a, b))
QBPP_LAZY_VOID(qbpp_term_negate, (void* t), (t))
QBPP_LAZY(const char*, qbpp_term_str, (const void* t), (t))
QBPP_LAZY_VOID(qbpp_term_coeff, (const void* t, flat_energy_t* out), (t, out))
QBPP_LAZY(uint32_t, qbpp_term_degree, (const void* t), (t))
QBPP_LAZY(uint32_t, qbpp_term_var_at, (const void* t, uint32_t i), (t, i))

// Expr management
QBPP_LAZY(void*, qbpp_expr_create, (), ())
QBPP_LAZY(void*, qbpp_expr_create_int, (flat_energy_arg c), (c))
QBPP_LAZY(void*, qbpp_expr_create_var, (vindex_t v), (v))
QBPP_LAZY(void*, qbpp_expr_create_term, (void* t, int take_ownership), (t, take_ownership))
QBPP_LAZY(void*, qbpp_expr_clone, (const void* e), (e))
QBPP_LAZY(uint32_t, qbpp_expr_attr, (const void* e), (e))
QBPP_LAZY_VOID(qbpp_expr_destroy, (void* e), (e))
QBPP_LAZY_VOID(qbpp_expr_iadd_int, (void* e, flat_energy_arg c), (e, c))
QBPP_LAZY_VOID(qbpp_expr_isub_int, (void* e, flat_energy_arg c), (e, c))
QBPP_LAZY_VOID(qbpp_expr_imul_int, (void* e, flat_energy_arg c), (e, c))
QBPP_LAZY_VOID(qbpp_expr_idiv_int, (void* e, flat_energy_arg c), (e, c))
QBPP_LAZY_VOID(qbpp_term_div_coeff, (void* t, flat_energy_arg c), (t, c))
QBPP_LAZY_VOID(qbpp_expr_imul_term_direct, (void* e, qbpp::flat_energy_arg coeff, VarBase2 vb, const vindex_t* extra), (e, coeff, vb, extra))
QBPP_LAZY_VOID(qbpp_expr_imul_expr, (void* e, const void* other), (e, other))
QBPP_LAZY_VOID(qbpp_expr_imul_var, (void* e, vindex_t v), (e, v))
QBPP_LAZY_VOID(qbpp_expr_iadd_var, (void* e, vindex_t v), (e, v))
QBPP_LAZY_VOID(qbpp_expr_isub_var, (void* e, vindex_t v), (e, v))
QBPP_LAZY_VOID(qbpp_expr_iadd_term, (void* e, const void* t), (e, t))
QBPP_LAZY_VOID(qbpp_expr_iadd_term_move, (void* e, void* t), (e, t))
QBPP_LAZY_VOID(qbpp_expr_isub_term, (void* e, const void* t), (e, t))
// Raw term API (Term is user-side, data passed directly)
QBPP_LAZY(void*, qbpp_expr_create_raw_term, (flat_energy_arg coeff, const uint32_t* vars, uint32_t nvars, flat_energy_arg constant), (coeff, vars, nvars, constant))
QBPP_LAZY_VOID(qbpp_expr_iadd_raw_term, (void* e, flat_energy_arg coeff, const uint32_t* vars, uint32_t nvars), (e, coeff, vars, nvars))
QBPP_LAZY_VOID(qbpp_expr_isub_raw_term, (void* e, flat_energy_arg coeff, const uint32_t* vars, uint32_t nvars), (e, coeff, vars, nvars))
// Bulk append from Python Lazy Expr flush: constant + N terms in one FFI call.
QBPP_LAZY(void*, qbpp_expr_create_from_bulk,
  (flat_energy_arg constant, size_t n_terms, const coeff_t* coeffs,
   const uint32_t* degrees, const uint32_t* var_indices),
  (constant, n_terms, coeffs, degrees, var_indices))
QBPP_LAZY_VOID(qbpp_expr_iadd_terms_bulk,
               (void* e, flat_energy_arg constant, size_t n_terms,
                const coeff_t* coeffs, const uint32_t* degrees,
                const uint32_t* var_indices),
               (e, constant, n_terms, coeffs, degrees, var_indices))
// Move-optimized: VarArray data transferred directly
QBPP_LAZY(void*, qbpp_expr_create_move_term, (flat_energy_arg coeff, VarBase2 vb, vindex_t* extra, flat_energy_arg constant), (coeff, vb, extra, constant))
QBPP_LAZY_VOID(qbpp_expr_iadd_move_term, (void* e, flat_energy_arg coeff, VarBase2 vb, vindex_t* extra), (e, coeff, vb, extra))
QBPP_LAZY_VOID(qbpp_expr_isub_move_term, (void* e, flat_energy_arg coeff, VarBase2 vb, vindex_t* extra), (e, coeff, vb, extra))
QBPP_LAZY(void*, qbpp_expr_create_add_raw_terms, (flat_energy_arg c1, const uint32_t* v1, uint32_t n1, flat_energy_arg c2, const uint32_t* v2, uint32_t n2), (c1, v1, n1, c2, v2, n2))
QBPP_LAZY_VOID(qbpp_expr_iadd_expr, (void* e, const void* other), (e, other))
QBPP_LAZY_VOID(qbpp_expr_isub_expr, (void* e, const void* other), (e, other))
QBPP_LAZY_VOID(qbpp_expr_negate, (void* e), (e))
// Optimized creation
QBPP_LAZY(void*, qbpp_expr_create_add_var_var, (vindex_t v1, vindex_t v2), (v1, v2))
QBPP_LAZY(void*, qbpp_expr_create_add_var_int, (vindex_t v, flat_energy_arg c), (v, c))
QBPP_LAZY(void*, qbpp_expr_create_sub_int_var, (flat_energy_arg c, vindex_t v), (c, v))
QBPP_LAZY(void*, qbpp_expr_create_add_term_term, (const void* t1, const void* t2), (t1, t2))
QBPP_LAZY(void*, qbpp_expr_create_add_term_term_ml, (void* t1, const void* t2), (t1, t2))
QBPP_LAZY(void*, qbpp_expr_create_add_term_term_mm, (void* t1, void* t2), (t1, t2))
QBPP_LAZY(void*, qbpp_expr_create_sub_term_term, (const void* t1, const void* t2), (t1, t2))
QBPP_LAZY(void*, qbpp_expr_create_add_term_var, (const void* t, vindex_t v), (t, v))
QBPP_LAZY(void*, qbpp_expr_create_add_term_int, (const void* t, flat_energy_arg c), (t, c))
QBPP_LAZY(void*, qbpp_expr_create_sub_int_term, (flat_energy_arg c, const void* t), (c, t))
// Optimized clone + op
QBPP_LAZY(void*, qbpp_expr_clone_add_int, (const void* e, flat_energy_arg c), (e, c))
QBPP_LAZY(void*, qbpp_expr_clone_add_var, (const void* e, vindex_t v), (e, v))
QBPP_LAZY(void*, qbpp_expr_clone_add_term, (const void* e, const void* t), (e, t))
QBPP_LAZY(void*, qbpp_expr_clone_sub_int, (const void* e, flat_energy_arg c), (e, c))
QBPP_LAZY(void*, qbpp_expr_clone_sub_var, (const void* e, vindex_t v), (e, v))
QBPP_LAZY(void*, qbpp_expr_clone_sub_term, (const void* e, const void* t), (e, t))
QBPP_LAZY(void*, qbpp_expr_clone_sub_expr, (const void* e1, const void* e2), (e1, e2))
QBPP_LAZY(void*, qbpp_expr_clone_add_expr, (const void* e1, const void* e2), (e1, e2))
QBPP_LAZY(void*, qbpp_expr_clone_mul_int, (const void* e, flat_energy_arg c), (e, c))
QBPP_LAZY(void*, qbpp_expr_mul_expr, (const void* e1, const void* e2), (e1, e2))
QBPP_LAZY(void*, qbpp_expr_sqr, (const void* e), (e))
QBPP_LAZY_VOID(qbpp_expr_eval_map, (const void* e, const uint32_t* vars, const flat_energy_arg* vals, size_t n, flat_energy_t* out), (e, vars, vals, n, out))
QBPP_LAZY(void*, qbpp_expr_replace, (const void* e, const uint32_t* vars, const void** exprs, size_t n), (e, vars, exprs, n))
QBPP_LAZY_VOID(qbpp_expr_gcd, (const void* e, flat_energy_t* out), (e, out))
QBPP_LAZY_VOID(qbpp_expr_pos_sum, (const void* e, flat_energy_t* out), (e, out))
QBPP_LAZY_VOID(qbpp_expr_neg_sum, (const void* e, flat_energy_t* out), (e, out))
// Accessors
QBPP_LAZY(const char*, qbpp_expr_str, (const void* e), (e))
QBPP_LAZY(int, qbpp_expr_has, (const void* e, uint32_t var_index), (e, var_index))
QBPP_LAZY_VOID(qbpp_expr_constant, (const void* e, flat_energy_t* out), (e, out))
QBPP_LAZY(const void*, qbpp_expr_term_at, (const void* e, size_t i), (e, i))
QBPP_LAZY_VOID(qbpp_expr_term_at_data, (const void* e, size_t i, flat_energy_t* coeff_out, VarBase2* vb_out, const vindex_t** extra_out), (e, i, coeff_out, vb_out, extra_out))
QBPP_LAZY(size_t, qbpp_expr_term_count, (const void* e), (e))
QBPP_LAZY(size_t, qbpp_expr_term_count_degree, (const void* e, uint32_t degree), (e, degree))
QBPP_LAZY(uint32_t, qbpp_expr_max_degree, (const void* e), (e))
// Model
QBPP_LAZY(void*, qbpp_model_create, (const void* expr), (expr))
QBPP_LAZY(void*, qbpp_model_clone, (const void* model), (model))
QBPP_LAZY_VOID(qbpp_model_destroy, (void* model), (model))
QBPP_LAZY(vindex_t, qbpp_model_var_count, (const void* model), (model))
QBPP_LAZY(vindex_t, qbpp_model_var, (const void* model, vindex_t index), (model, index))
QBPP_LAZY(int, qbpp_model_has, (const void* model, uint32_t var_index), (model, var_index))
QBPP_LAZY_VOID(qbpp_model_constant, (const void* model, flat_energy_t* out), (model, out))
QBPP_LAZY(uint32_t, qbpp_model_max_degree, (const void* model), (model))
QBPP_LAZY(uint64_t, qbpp_model_term_count, (const void* model, uint32_t degree), (model, degree))
QBPP_LAZY(const vindex_t*, qbpp_model_term_vars, (const void* model, uint32_t degree), (model, degree))
QBPP_LAZY(const flat_coeff_t*, qbpp_model_coeff_array, (const void* model, uint32_t degree_minus1), (model, degree_minus1))
QBPP_LAZY_VOID(qbpp_expr_eval_with_model, (const void* expr, const void* model, const uint64_t* bits, flat_energy_t* out), (expr, model, bits, out))
QBPP_LAZY_VOID(qbpp_model_eval, (const void* model, const uint64_t* bits, flat_energy_t* out), (model, bits, out))
// Sol (opaque)
QBPP_LAZY(void*, qbpp_sol_create, (const void* model), (model))
QBPP_LAZY(void*, qbpp_sol_create_from_expr, (const void* expr), (expr))
QBPP_LAZY(void*, qbpp_sol_clone, (const void* sol), (sol))
QBPP_LAZY_VOID(qbpp_sol_destroy, (void* sol), (sol))
QBPP_LAZY(int, qbpp_sol_energy_valid, (const void* sol), (sol))
QBPP_LAZY_VOID(qbpp_sol_energy, (const void* sol, flat_energy_t* out), (sol, out))
QBPP_LAZY_VOID(qbpp_sol_set_energy, (void* sol, flat_energy_arg e), (sol, e))
QBPP_LAZY(double, qbpp_sol_tts, (const void* sol), (sol))
QBPP_LAZY_VOID(qbpp_sol_set_tts, (void* sol, double t), (sol, t))
QBPP_LAZY(uint32_t, qbpp_sol_var_count, (const void* sol), (sol))
QBPP_LAZY(const void*, qbpp_sol_model, (const void* sol), (sol))
QBPP_LAZY(int, qbpp_sol_has, (const void* sol, uint32_t var_index), (sol, var_index))
QBPP_LAZY(int, qbpp_sol_get, (const void* sol, uint32_t var_index), (sol, var_index))
QBPP_LAZY_VOID(qbpp_sol_set, (void* sol, uint32_t var_index, int value), (sol, var_index, value))
QBPP_LAZY_VOID(qbpp_sol_compute_energy, (void* sol, flat_energy_t* out), (sol, out))
QBPP_LAZY_VOID(qbpp_sol_eval_expr, (const void* sol, const void* expr, flat_energy_t* out), (sol, expr, out))
QBPP_LAZY(const uint64_t*, qbpp_sol_bits, (const void* sol), (sol))
QBPP_LAZY(uint32_t, qbpp_sol_model_var, (const void* sol, uint32_t i), (sol, i))
QBPP_LAZY_VOID(qbpp_sol_set_from_sol, (void* dst, const void* src), (dst, src))
QBPP_LAZY(const char*, qbpp_sol_str, (const void* sol), (sol))
QBPP_LAZY_VOID(qbpp_sol_steal_bits, (void* sol, void* dst_vec), (sol, dst_vec))
// Solver type selection
QBPP_LAZY(const char*, qbpp_expr_solver_type, (const void* expr), (expr))
// between / constraints
QBPP_LAZY(void*, qbpp_between, (const void* expr, flat_energy_arg min_val, flat_energy_arg max_val), (expr, min_val, max_val))
QBPP_LAZY_VOID(qbpp_array_between, (const void* arr, int arr_type, flat_energy_arg min_val, flat_energy_arg max_val, void** out, size_t n), (arr, arr_type, min_val, max_val, out, n))
QBPP_LAZY_VOID(qbpp_onehot_to_int, (const int* data, const size_t* shape, size_t ndim, int* out), (data, shape, ndim, out))
// EasySolver (opaque)
QBPP_LAZY(void*, qbpp_easy_solver_wrapper_create, (const void* model), (model))
QBPP_LAZY_VOID(qbpp_easy_solver_wrapper_destroy, (void* solver), (solver))
// Search: returns opaque result handle
QBPP_LAZY(void*, qbpp_easy_solver_wrapper_search, (void* solver, const void* params_kv), (solver, params_kv))
// Search result accessors
QBPP_LAZY_VOID(qbpp_easy_solver_result_energy, (const void* result, flat_energy_t* out), (result, out))
QBPP_LAZY(double, qbpp_easy_solver_result_tts, (const void* result), (result))
QBPP_LAZY(const uint64_t*, qbpp_easy_solver_result_bits, (const void* result), (result))
QBPP_LAZY(size_t, qbpp_easy_solver_result_topk_count, (const void* result), (result))
QBPP_LAZY_VOID(qbpp_easy_solver_result_topk_energy, (const void* result, size_t i, flat_energy_t* out), (result, i, out))
QBPP_LAZY(double, qbpp_easy_solver_result_topk_tts, (const void* result, size_t i), (result, i))
QBPP_LAZY(const uint64_t*, qbpp_easy_solver_result_topk_bits, (const void* result, size_t i), (result, i))
QBPP_LAZY_VOID(qbpp_easy_solver_result_steal_bits, (void* result, void* dst_vec), (result, dst_vec))
QBPP_LAZY_VOID(qbpp_easy_solver_result_steal_topk_bits, (void* result, size_t i, void* dst_vec), (result, i, dst_vec))
QBPP_LAZY(size_t, qbpp_easy_solver_result_info_count, (const void* result), (result))
QBPP_LAZY(const char*, qbpp_easy_solver_result_info_key, (const void* result, size_t i), (result, i))
QBPP_LAZY(const char*, qbpp_easy_solver_result_info_value, (const void* result, size_t i), (result, i))
QBPP_LAZY(void*, qbpp_easy_solver_result_to_sol, (void* result, const void* model), (result, model))
QBPP_LAZY(void*, qbpp_easy_solver_result_topk_to_sol, (void* result, size_t i, const void* model), (result, i, model))
QBPP_LAZY_VOID(qbpp_easy_solver_result_destroy, (void* result), (result))
// ExhaustiveSolver (opaque) — same result format as EasySolver
QBPP_LAZY(void*, qbpp_exhaustive_wrapper_create, (const void* model), (model))
QBPP_LAZY_VOID(qbpp_exhaustive_wrapper_destroy, (void* solver), (solver))
QBPP_LAZY(void*, qbpp_exhaustive_wrapper_search, (void* solver, const void* params_kv), (solver, params_kv))
// ExhaustiveSolver result uses same accessors as EasySolver result
// (qbpp_easy_solver_result_* functions work on both)
// ABS3Solver (opaque) — same result format as EasySolver
QBPP_LAZY(void*, qbpp_abs3_wrapper_create, (const void* model, int gpu), (model, gpu))
QBPP_LAZY_VOID(qbpp_abs3_wrapper_destroy, (void* solver), (solver))
QBPP_LAZY(void*, qbpp_abs3_wrapper_search, (void* solver, const void* params_kv), (solver, params_kv))
QBPP_LAZY_VOID(qbpp_abs3_wrapper_set_callback, (void* wrapper, double (*fn)(void* ctx, void* sol_handle, int event), void* ctx), (wrapper, fn, ctx))
QBPP_LAZY_VOID(qbpp_abs3_wrapper_hint, (void* wrapper, const uint64_t* bitarray), (wrapper, bitarray))
// Expr (opaque) — legacy API (Python ctypes still uses these)
QBPP_LAZY(void*, qbpp_varint_create, (const char* name, flat_energy_arg min_val, flat_energy_arg max_val, void** expr_out), (name, min_val, max_val, expr_out))
QBPP_LAZY(void*, qbpp_varint_create_with_vars, (const char* name, flat_energy_arg min_val, flat_energy_arg max_val, const flat_coeff_t* coeffs, const uint32_t* vars, size_t nc, void** expr_out), (name, min_val, max_val, coeffs, vars, nc, expr_out))
QBPP_LAZY_VOID(qbpp_varint_destroy, (void* vi), (vi))
QBPP_LAZY(void*, qbpp_varint_clone, (const void* vi), (vi))
QBPP_LAZY(size_t, qbpp_varint_decompose, (const void* vi, flat_energy_arg value, vindex_t* vars_out, flat_energy_t* bits_out), (vi, value, vars_out, bits_out))
QBPP_LAZY(const char*, qbpp_varint_name, (const void* vi), (vi))
QBPP_LAZY_VOID(qbpp_varint_min, (const void* vi, flat_energy_t* out), (vi, out))
QBPP_LAZY_VOID(qbpp_varint_max, (const void* vi, flat_energy_t* out), (vi, out))
QBPP_LAZY(size_t, qbpp_varint_var_count, (const void* vi), (vi))
QBPP_LAZY(uint32_t, qbpp_varint_var, (const void* vi, size_t i), (vi, i))
QBPP_LAZY_VOID(qbpp_varint_coeff, (const void* vi, size_t i, flat_coeff_t* out), (vi, i, out))
// Stage F-a: unified VarIntElem-based API (single allocation, ExprImpl at offset 0).
// Expr holds void* impl_ → VarIntElem*; the same pointer can be passed
// directly to any qbpp_expr_* function as the ExprImpl part.
QBPP_LAZY(void*, qbpp_varintelem_create, (const char* name, flat_energy_arg min_val, flat_energy_arg max_val), (name, min_val, max_val))
QBPP_LAZY(void*, qbpp_varintelem_create_with_vars, (const char* name, flat_energy_arg min_val, flat_energy_arg max_val, const flat_coeff_t* coeffs, const uint32_t* vars, size_t nc), (name, min_val, max_val, coeffs, vars, nc))
QBPP_LAZY_VOID(qbpp_varintelem_destroy, (void* p), (p))
QBPP_LAZY(void*, qbpp_varintelem_clone, (const void* p), (p))
QBPP_LAZY(size_t, qbpp_varintelem_decompose, (const void* p, flat_energy_arg value, vindex_t* vars_out, flat_energy_t* bits_out), (p, value, vars_out, bits_out))
QBPP_LAZY_VOID(qbpp_varintelem_min, (const void* p, flat_energy_t* out), (p, out))
QBPP_LAZY_VOID(qbpp_varintelem_max, (const void* p, flat_energy_t* out), (p, out))
QBPP_LAZY(size_t, qbpp_varintelem_var_count, (const void* p), (p))
QBPP_LAZY(uint32_t, qbpp_varintelem_var, (const void* p, size_t i), (p, i))
QBPP_LAZY_VOID(qbpp_varintelem_coeff, (const void* p, size_t i, flat_coeff_t* out), (p, i, out))
QBPP_LAZY_VOID(qbpp_varintelem_replace_expr, (void* p, const void* new_expr), (p, new_expr))
// Stage F-b: unified ExprExprElem-based API.
QBPP_LAZY(void*, qbpp_exprexprelem_create, (const void* penalty_h, const void* body_h), (penalty_h, body_h))
QBPP_LAZY_VOID(qbpp_exprexprelem_destroy, (void* p), (p))
QBPP_LAZY(void*, qbpp_exprexprelem_clone, (const void* p), (p))
QBPP_LAZY(const void*, qbpp_exprexprelem_get_body, (const void* p), (p))
// Expr coefficients (still needed for VarIntArrayCore)
QBPP_LAZY(size_t, qbpp_comp_coeffs_count, (flat_energy_arg min_val, flat_energy_arg max_val), (min_val, max_val))
QBPP_LAZY_VOID(qbpp_comp_coeffs, (flat_energy_arg min_val, flat_energy_arg max_val, flat_coeff_t* out), (min_val, max_val, out))
// Simplify
QBPP_LAZY(void*, qbpp_expr_simplify, (const void* e), (e))
QBPP_LAZY(void*, qbpp_expr_simplify_as_binary, (const void* e), (e))
QBPP_LAZY(void*, qbpp_expr_simplify_as_spin, (const void* e), (e))
QBPP_LAZY(void*, qbpp_expr_spin_to_binary, (const void* e), (e))
QBPP_LAZY(void*, qbpp_expr_binary_to_spin, (const void* e), (e))

// ---------------------------------------------------------------------------
// Per-type Array C ABI (qbpp_array_<type>_* prefix)
// ---------------------------------------------------------------------------
// Lifecycle / metadata / element access (all six types)
// Array<Dim, Expr> / Array<Dim, Expr> share storage with Array<Dim, Expr>
// (each element is an ExprImpl tagged via attr_), so they route through the
// qbpp_array_expr_* ABI — no separate _varint_ / _exprexpr_ symbols here.
QBPP_LAZY_VOID(qbpp_array_var_destroy,   (void* p), (p))
QBPP_LAZY_VOID(qbpp_array_int_destroy,   (void* p), (p))
QBPP_LAZY_VOID(qbpp_array_term_destroy,  (void* p), (p))
QBPP_LAZY_VOID(qbpp_array_expr_destroy,  (void* p), (p))

QBPP_LAZY(void*, qbpp_array_var_clone,      (const void* p), (p))
QBPP_LAZY(void*, qbpp_array_int_clone,      (const void* p), (p))
QBPP_LAZY(void*, qbpp_array_term_clone,     (const void* p), (p))
QBPP_LAZY(void*, qbpp_array_expr_clone,     (const void* p), (p))

QBPP_LAZY(size_t, qbpp_array_var_size,      (const void* p), (p))
QBPP_LAZY(size_t, qbpp_array_int_size,      (const void* p), (p))
QBPP_LAZY(size_t, qbpp_array_term_size,     (const void* p), (p))
QBPP_LAZY(size_t, qbpp_array_expr_size,     (const void* p), (p))

QBPP_LAZY(size_t, qbpp_array_var_ndim,      (const void* p), (p))
QBPP_LAZY(size_t, qbpp_array_int_ndim,      (const void* p), (p))
QBPP_LAZY(size_t, qbpp_array_term_ndim,     (const void* p), (p))
QBPP_LAZY(size_t, qbpp_array_expr_ndim,     (const void* p), (p))

QBPP_LAZY(const size_t*, qbpp_array_var_shape,      (const void* p), (p))
QBPP_LAZY(const size_t*, qbpp_array_int_shape,      (const void* p), (p))
QBPP_LAZY(const size_t*, qbpp_array_term_shape,     (const void* p), (p))
QBPP_LAZY(const size_t*, qbpp_array_expr_shape,     (const void* p), (p))

QBPP_LAZY(size_t, qbpp_array_var_shape_at,      (const void* p, size_t dim), (p, dim))
QBPP_LAZY(size_t, qbpp_array_int_shape_at,      (const void* p, size_t dim), (p, dim))
QBPP_LAZY(size_t, qbpp_array_term_shape_at,     (const void* p, size_t dim), (p, dim))
QBPP_LAZY(size_t, qbpp_array_expr_shape_at,     (const void* p, size_t dim), (p, dim))

// Element accessors
QBPP_LAZY(uint32_t, qbpp_array_var_get, (const void* p, size_t i), (p, i))
QBPP_LAZY(const uint32_t*, qbpp_array_var_data, (const void* p), (p))
QBPP_LAZY_VOID(qbpp_array_var_set, (void* p, size_t i, uint32_t v), (p, i, v))
QBPP_LAZY_VOID(qbpp_array_int_get, (const void* p, size_t i, flat_energy_t* out), (p, i, out))
QBPP_LAZY_VOID(qbpp_array_int_set, (void* p, size_t i, flat_energy_arg c), (p, i, c))
QBPP_LAZY(void*, qbpp_array_term_get, (const void* p, size_t i), (p, i))
QBPP_LAZY_VOID(qbpp_array_term_set, (void* p, size_t i, const void* t), (p, i, t))
QBPP_LAZY(void*, qbpp_array_expr_get, (const void* p, size_t i), (p, i))
QBPP_LAZY_VOID(qbpp_array_expr_set, (void* p, size_t i, const void* e), (p, i, e))
QBPP_LAZY(void*, qbpp_array_expr_ref, (void* p, size_t i), (p, i))
// Attr-stripping entry points (clone + reset attr_ → plain Expr):
QBPP_LAZY(void*, qbpp_array_varint_get_expr,      (const void* p, size_t i), (p, i))
QBPP_LAZY(void*, qbpp_array_exprexpr_get_penalty, (const void* p, size_t i), (p, i))

// Create
QBPP_LAZY(void*, qbpp_array_var_create_named,   (const char* name, const size_t* shape, size_t ndim), (name, shape, ndim))
QBPP_LAZY(void*, qbpp_array_var_create_unnamed, (const size_t* shape, size_t ndim), (shape, ndim))
QBPP_LAZY(void*, qbpp_array_var_create_data,    (const uint32_t* data, const size_t* shape, size_t ndim), (data, shape, ndim))
QBPP_LAZY(void*, qbpp_array_int_create_data,    (const int32_t* data, const size_t* shape, size_t ndim), (data, shape, ndim))
QBPP_LAZY(void*, qbpp_array_int_create_zero,    (const size_t* shape, size_t ndim), (shape, ndim))
QBPP_LAZY(void*, qbpp_array_term_create_data,   (const void* const* data, const size_t* shape, size_t ndim), (data, shape, ndim))
QBPP_LAZY(void*, qbpp_array_expr_create_data,   (const void* const* data, const size_t* shape, size_t ndim), (data, shape, ndim))
QBPP_LAZY(void*, qbpp_array_expr_create_zero,   (const size_t* shape, size_t ndim), (shape, ndim))
QBPP_LAZY(void*, qbpp_array_varint_create_uniform, (const char* name, const size_t* shape, size_t ndim, flat_energy_arg min_val, flat_energy_arg max_val), (name, shape, ndim, min_val, max_val))

// Subarray / clone_subview / str (per-type)
QBPP_LAZY(void*, qbpp_array_var_subarray,      (const void* p, size_t i), (p, i))
QBPP_LAZY(void*, qbpp_array_int_subarray,      (const void* p, size_t i), (p, i))
QBPP_LAZY(void*, qbpp_array_term_subarray,     (const void* p, size_t i), (p, i))
QBPP_LAZY(void*, qbpp_array_expr_subarray,     (const void* p, size_t i), (p, i))

QBPP_LAZY(void*, qbpp_array_expr_clone_subview, (const void* p, size_t offset, size_t trailing), (p, offset, trailing))
QBPP_LAZY(void*, qbpp_array_int_clone_subview,  (const void* p, size_t offset, size_t trailing), (p, offset, trailing))

QBPP_LAZY(const char*, qbpp_array_var_str,      (const void* p), (p))
QBPP_LAZY(const char*, qbpp_array_int_str,      (const void* p), (p))
QBPP_LAZY(const char*, qbpp_array_term_str,     (const void* p), (p))
QBPP_LAZY(const char*, qbpp_array_expr_str,     (const void* p), (p))

// Type-pair binary ops: 16 add + 16 sub + 16 mul
#define QBPP_DECL_BIN(op) \
  QBPP_LAZY(void*, qbpp_array_var_##op##_array_var,   (const void* a, const void* b), (a, b)) \
  QBPP_LAZY(void*, qbpp_array_var_##op##_array_int,   (const void* a, const void* b), (a, b)) \
  QBPP_LAZY(void*, qbpp_array_var_##op##_array_term,  (const void* a, const void* b), (a, b)) \
  QBPP_LAZY(void*, qbpp_array_var_##op##_array_expr,  (const void* a, const void* b), (a, b)) \
  QBPP_LAZY(void*, qbpp_array_int_##op##_array_var,   (const void* a, const void* b), (a, b)) \
  QBPP_LAZY(void*, qbpp_array_int_##op##_array_int,   (const void* a, const void* b), (a, b)) \
  QBPP_LAZY(void*, qbpp_array_int_##op##_array_term,  (const void* a, const void* b), (a, b)) \
  QBPP_LAZY(void*, qbpp_array_int_##op##_array_expr,  (const void* a, const void* b), (a, b)) \
  QBPP_LAZY(void*, qbpp_array_term_##op##_array_var,  (const void* a, const void* b), (a, b)) \
  QBPP_LAZY(void*, qbpp_array_term_##op##_array_int,  (const void* a, const void* b), (a, b)) \
  QBPP_LAZY(void*, qbpp_array_term_##op##_array_term, (const void* a, const void* b), (a, b)) \
  QBPP_LAZY(void*, qbpp_array_term_##op##_array_expr, (const void* a, const void* b), (a, b)) \
  QBPP_LAZY(void*, qbpp_array_expr_##op##_array_var,  (const void* a, const void* b), (a, b)) \
  QBPP_LAZY(void*, qbpp_array_expr_##op##_array_int,  (const void* a, const void* b), (a, b)) \
  QBPP_LAZY(void*, qbpp_array_expr_##op##_array_term, (const void* a, const void* b), (a, b)) \
  QBPP_LAZY(void*, qbpp_array_expr_##op##_array_expr, (const void* a, const void* b), (a, b))
QBPP_DECL_BIN(add)
QBPP_DECL_BIN(sub)
QBPP_DECL_BIN(mul)
#undef QBPP_DECL_BIN

// Scalar broadcast: Array<lhs> op scalar → new Array
// Note: the var*var/term*term/expr*expr scalar cases use *_s suffix in cpp
#define QBPP_DECL_SCALAR_TYPE(lhs) \
  QBPP_LAZY(void*, qbpp_array_##lhs##_add_int,  (const void* p, flat_energy_arg c), (p, c)) \
  QBPP_LAZY(void*, qbpp_array_##lhs##_add_var,  (const void* p, uint32_t v), (p, v)) \
  QBPP_LAZY(void*, qbpp_array_##lhs##_add_term, (const void* p, const void* t), (p, t)) \
  QBPP_LAZY(void*, qbpp_array_##lhs##_add_expr, (const void* p, const void* e), (p, e)) \
  QBPP_LAZY(void*, qbpp_array_##lhs##_sub_int,  (const void* p, flat_energy_arg c), (p, c)) \
  QBPP_LAZY(void*, qbpp_array_##lhs##_sub_var,  (const void* p, uint32_t v), (p, v)) \
  QBPP_LAZY(void*, qbpp_array_##lhs##_sub_term, (const void* p, const void* t), (p, t)) \
  QBPP_LAZY(void*, qbpp_array_##lhs##_sub_expr, (const void* p, const void* e), (p, e)) \
  QBPP_LAZY(void*, qbpp_array_##lhs##_mul_int,  (const void* p, flat_energy_arg c), (p, c))
QBPP_DECL_SCALAR_TYPE(var)
QBPP_DECL_SCALAR_TYPE(int)
QBPP_DECL_SCALAR_TYPE(term)
QBPP_DECL_SCALAR_TYPE(expr)
#undef QBPP_DECL_SCALAR_TYPE
// Scalar * (special: var*var → term, var*term → term, var*expr → expr, etc)
QBPP_LAZY(void*, qbpp_array_var_mul_var,   (const void* p, uint32_t v), (p, v))
QBPP_LAZY(void*, qbpp_array_var_mul_term,  (const void* p, const void* t), (p, t))
QBPP_LAZY(void*, qbpp_array_var_mul_expr,  (const void* p, const void* e), (p, e))
QBPP_LAZY(void*, qbpp_array_int_mul_var,     (const void* p, uint32_t v), (p, v))
QBPP_LAZY(void*, qbpp_array_int_mul_term,    (const void* p, const void* t), (p, t))
QBPP_LAZY(void*, qbpp_array_int_mul_expr,    (const void* p, const void* e), (p, e))
QBPP_LAZY(void*, qbpp_array_term_mul_var,    (const void* p, uint32_t v), (p, v))
QBPP_LAZY(void*, qbpp_array_term_mul_term, (const void* p, const void* t), (p, t))
QBPP_LAZY(void*, qbpp_array_term_mul_expr, (const void* p, const void* e), (p, e))
QBPP_LAZY(void*, qbpp_array_expr_mul_var,  (const void* p, uint32_t v), (p, v))
QBPP_LAZY(void*, qbpp_array_expr_mul_term,   (const void* p, const void* t), (p, t))
QBPP_LAZY(void*, qbpp_array_expr_mul_expr, (const void* p, const void* e), (p, e))

// In-place Array<Expr> op= Array<T>
QBPP_LAZY_VOID(qbpp_array_expr_add_eq_array_var,  (void* lhs, const void* rhs), (lhs, rhs))
QBPP_LAZY_VOID(qbpp_array_expr_add_eq_array_int,  (void* lhs, const void* rhs), (lhs, rhs))
QBPP_LAZY_VOID(qbpp_array_expr_add_eq_array_term, (void* lhs, const void* rhs), (lhs, rhs))
QBPP_LAZY_VOID(qbpp_array_expr_add_eq_array_expr, (void* lhs, const void* rhs), (lhs, rhs))
QBPP_LAZY_VOID(qbpp_array_expr_sub_eq_array_var,  (void* lhs, const void* rhs), (lhs, rhs))
QBPP_LAZY_VOID(qbpp_array_expr_sub_eq_array_int,  (void* lhs, const void* rhs), (lhs, rhs))
QBPP_LAZY_VOID(qbpp_array_expr_sub_eq_array_term, (void* lhs, const void* rhs), (lhs, rhs))
QBPP_LAZY_VOID(qbpp_array_expr_sub_eq_array_expr, (void* lhs, const void* rhs), (lhs, rhs))
QBPP_LAZY_VOID(qbpp_array_expr_mul_eq_array_var,  (void* lhs, const void* rhs), (lhs, rhs))
QBPP_LAZY_VOID(qbpp_array_expr_mul_eq_array_int,  (void* lhs, const void* rhs), (lhs, rhs))
QBPP_LAZY_VOID(qbpp_array_expr_mul_eq_array_term, (void* lhs, const void* rhs), (lhs, rhs))
QBPP_LAZY_VOID(qbpp_array_expr_mul_eq_array_expr, (void* lhs, const void* rhs), (lhs, rhs))
// In-place Array<Expr> op= scalar
QBPP_LAZY_VOID(qbpp_array_expr_add_eq_int,  (void* lhs, flat_energy_arg c), (lhs, c))
QBPP_LAZY_VOID(qbpp_array_expr_sub_eq_int,  (void* lhs, flat_energy_arg c), (lhs, c))
QBPP_LAZY_VOID(qbpp_array_expr_mul_eq_int,  (void* lhs, flat_energy_arg c), (lhs, c))
QBPP_LAZY_VOID(qbpp_array_expr_add_eq_var,  (void* lhs, uint32_t v), (lhs, v))
QBPP_LAZY_VOID(qbpp_array_expr_sub_eq_var,  (void* lhs, uint32_t v), (lhs, v))
QBPP_LAZY_VOID(qbpp_array_expr_mul_eq_var,  (void* lhs, uint32_t v), (lhs, v))
QBPP_LAZY_VOID(qbpp_array_expr_add_eq_term, (void* lhs, const void* t), (lhs, t))
QBPP_LAZY_VOID(qbpp_array_expr_sub_eq_term, (void* lhs, const void* t), (lhs, t))
QBPP_LAZY_VOID(qbpp_array_expr_mul_eq_term, (void* lhs, const void* t), (lhs, t))
QBPP_LAZY_VOID(qbpp_array_expr_add_eq_expr, (void* lhs, const void* e), (lhs, e))
QBPP_LAZY_VOID(qbpp_array_expr_sub_eq_expr, (void* lhs, const void* e), (lhs, e))
QBPP_LAZY_VOID(qbpp_array_expr_mul_eq_expr, (void* lhs, const void* e), (lhs, e))
// In-place Array<int>
QBPP_LAZY_VOID(qbpp_array_int_add_eq_int, (void* lhs, flat_energy_arg c), (lhs, c))
QBPP_LAZY_VOID(qbpp_array_int_sub_eq_int, (void* lhs, flat_energy_arg c), (lhs, c))
QBPP_LAZY_VOID(qbpp_array_int_mul_eq_int, (void* lhs, flat_energy_arg c), (lhs, c))
QBPP_LAZY_VOID(qbpp_array_int_div_eq_int, (void* lhs, flat_energy_arg c), (lhs, c))
QBPP_LAZY_VOID(qbpp_array_int_add_eq_array_int, (void* lhs, const void* rhs), (lhs, rhs))
QBPP_LAZY_VOID(qbpp_array_int_sub_eq_array_int, (void* lhs, const void* rhs), (lhs, rhs))
QBPP_LAZY_VOID(qbpp_array_int_mul_eq_array_int, (void* lhs, const void* rhs), (lhs, rhs))
QBPP_LAZY_VOID(qbpp_array_term_mul_eq_int, (void* lhs, flat_energy_arg c), (lhs, c))

// Unary / utility per-type
QBPP_LAZY(void*, qbpp_array_var_negate,  (const void* p), (p))
QBPP_LAZY(void*, qbpp_array_int_negate,  (const void* p), (p))
QBPP_LAZY(void*, qbpp_array_term_negate, (const void* p), (p))
QBPP_LAZY(void*, qbpp_array_expr_negate, (const void* p), (p))
QBPP_LAZY(void*, qbpp_array_var_invert,  (const void* p), (p))

QBPP_LAZY(void*, qbpp_array_expr_simplify,           (const void* p), (p))
QBPP_LAZY(void*, qbpp_array_expr_simplify_as_binary, (const void* p), (p))
QBPP_LAZY(void*, qbpp_array_expr_simplify_as_spin,   (const void* p), (p))
QBPP_LAZY(void*, qbpp_array_expr_sqr,                (const void* p), (p))

QBPP_LAZY(void*, qbpp_array_var_sum,      (const void* p), (p))
QBPP_LAZY(void*, qbpp_array_int_sum,      (const void* p), (p))
QBPP_LAZY(void*, qbpp_array_term_sum,     (const void* p), (p))
QBPP_LAZY(void*, qbpp_array_expr_sum,     (const void* p), (p))

QBPP_LAZY(void*, qbpp_array_var_vector_sum,      (const void* p, int axis), (p, axis))
QBPP_LAZY(void*, qbpp_array_int_vector_sum,      (const void* p, int axis), (p, axis))
QBPP_LAZY(void*, qbpp_array_term_vector_sum,     (const void* p, int axis), (p, axis))
QBPP_LAZY(void*, qbpp_array_expr_vector_sum,     (const void* p, int axis), (p, axis))

// Einsum: numpy-style tensor contraction.
// in_types[i]: 0=Var, 1=coeff_t, 2=Term, 3=Expr (VarInt/ExprExpr also 3).
// out_type:    0=coeff_t (all inputs must be coeff_t), 1=Expr.
// Returns ArrayImpl<OutT>* whose shape matches the subscript output labels.
QBPP_LAZY(void*, qbpp_einsum,
          (const char* subscript, int n_inputs, const int* in_types,
           const void* const* in_impls, int out_type, size_t expected_out_ndim),
          (subscript, n_inputs, in_types, in_impls, out_type, expected_out_ndim))

QBPP_LAZY(void*, qbpp_array_var_concat,  (const void* a, const void* b, int dim), (a, b, dim))
QBPP_LAZY(void*, qbpp_array_int_concat,  (const void* a, const void* b, int dim), (a, b, dim))
QBPP_LAZY(void*, qbpp_array_term_concat, (const void* a, const void* b, int dim), (a, b, dim))
QBPP_LAZY(void*, qbpp_array_expr_concat, (const void* a, const void* b, int dim), (a, b, dim))

QBPP_LAZY(void*, qbpp_array_var_view,    (const void* p, const size_t* starts, const size_t* stops, const uint8_t* squeeze, size_t ndim), (p, starts, stops, squeeze, ndim))
QBPP_LAZY(void*, qbpp_array_int_view,    (const void* p, const size_t* starts, const size_t* stops, const uint8_t* squeeze, size_t ndim), (p, starts, stops, squeeze, ndim))
QBPP_LAZY(void*, qbpp_array_term_view,   (const void* p, const size_t* starts, const size_t* stops, const uint8_t* squeeze, size_t ndim), (p, starts, stops, squeeze, ndim))
QBPP_LAZY(void*, qbpp_array_expr_view,   (const void* p, const size_t* starts, const size_t* stops, const uint8_t* squeeze, size_t ndim), (p, starts, stops, squeeze, ndim))

QBPP_LAZY(void*, qbpp_array_int_eq_int,  (const void* p, flat_energy_arg val), (p, val))
QBPP_LAZY(void*, qbpp_array_var_eq_int,  (const void* p, flat_energy_arg val), (p, val))
QBPP_LAZY(void*, qbpp_array_expr_eq_int, (const void* p, flat_energy_arg val), (p, val))
QBPP_LAZY(void*, qbpp_array_term_eq_int, (const void* p, flat_energy_arg val), (p, val))
QBPP_LAZY(void*, qbpp_array_int_between,  (const void* p, flat_energy_arg lo, flat_energy_arg hi), (p, lo, hi))
QBPP_LAZY(void*, qbpp_array_var_between,  (const void* p, flat_energy_arg lo, flat_energy_arg hi), (p, lo, hi))
QBPP_LAZY(void*, qbpp_array_expr_between, (const void* p, flat_energy_arg lo, flat_energy_arg hi), (p, lo, hi))
QBPP_LAZY(void*, qbpp_array_term_between, (const void* p, flat_energy_arg lo, flat_energy_arg hi), (p, lo, hi))
// Stage E-c: element-wise Array<{Var,Term,Expr}> == Array<coeff_t> → Array<Expr>
// (The old polymorphic qbpp_array_exprexpr_sqr_diff(a, ta, b, tb) is gone —
//  operator==(Array, Array<coeff_t>) now dispatches statically to one of
//  these three per-type C ABI entries.)
QBPP_LAZY(void*, qbpp_array_var_eq_array_int,  (const void* lhs, const void* rhs), (lhs, rhs))
QBPP_LAZY(void*, qbpp_array_term_eq_array_int, (const void* lhs, const void* rhs), (lhs, rhs))
QBPP_LAZY(void*, qbpp_array_expr_eq_array_int, (const void* lhs, const void* rhs), (lhs, rhs))
QBPP_LAZY(void*, qbpp_array_int_from_sol, (const void* sol, const void* var_arr), (sol, var_arr))
QBPP_LAZY_VOID(qbpp_array_expr_replace, (void* arr, const uint32_t* vars, const void* const* exprs, size_t n_mappings), (arr, vars, exprs, n_mappings))
QBPP_LAZY(void*, qbpp_array_expr_create_constant_int, (const size_t* shape, size_t ndim, flat_energy_arg c), (shape, ndim, c))
QBPP_LAZY(void*, qbpp_array_expr_create_constant_var, (const size_t* shape, size_t ndim, uint32_t v_index), (shape, ndim, v_index))
QBPP_LAZY(void*, qbpp_array_expr_from_expr,             (const void* src), (src))
QBPP_LAZY_VOID(qbpp_array_int_to_ints,                  (const void* src, int* out), (src, out))
QBPP_LAZY(void*, qbpp_array_int_div_int,                (const void* lhs, flat_energy_arg c), (lhs, c))
QBPP_LAZY(void*, qbpp_array_term_div_int,               (const void* lhs, flat_energy_arg c), (lhs, c))
QBPP_LAZY(void*, qbpp_array_expr_div_int,               (const void* lhs, flat_energy_arg c), (lhs, c))
QBPP_LAZY_VOID(qbpp_array_term_div_eq_int,              (void* lhs, flat_energy_arg c), (lhs, c))
QBPP_LAZY_VOID(qbpp_array_expr_div_eq_int,              (void* lhs, flat_energy_arg c), (lhs, c))
QBPP_LAZY(void*, qbpp_array_int_onehot_to_int, (const void* p, int axis), (p, axis))
QBPP_LAZY(void*, qbpp_array_int_coeffvec_mul_var, (const void* coeffs, const void* vars), (coeffs, vars))

// ---------------------------------------------------------------------------
// Forward declarations
// ---------------------------------------------------------------------------

class Var;
class Term;
class Sol;  // for operator()(const Sol&)
// Stage E-g: ArrayBase is deleted. Sol::operator()(const Array<Dim, Var>&) is
// defined after Array<Dim, T> and does not need a forward declaration.
template <size_t Dim, typename T> class Array;  // forward decl
// Expr / Expr are `using` aliases for Expr (see later in this header);
// Expr itself is declared below, so the forward type is just Expr.
class Expr;
struct MapEntry;  // for initializer_list overloads
// MapList defined after Expr class (uses Expr as value type)

// ---------------------------------------------------------------------------
// Generic operator<< for any type with ._str() method
// (._str() is internal; users should use operator<< instead.)
// ---------------------------------------------------------------------------

#ifndef __CUDACC__
template <typename T>
auto operator<<(std::ostream& os, const T& arg)
    -> decltype(arg._str(), os) {
  return os << arg._str();
}
#endif

// ---------------------------------------------------------------------------
// Var class
// ---------------------------------------------------------------------------

class Var {
  vindex_t index_ = vindex_limit;

 public:
  Var() = default;
  explicit constexpr Var(vindex_t index) : index_(index) {}

  vindex_t index() const { return index_; }
  bool is_neg() const { return (index_ & vindex_neg_bit) != 0; }
  vindex_t base_index() const { return index_ & vindex_mask; }

  std::string _str() const { return qbpp_var_str(index_); }

  bool operator==(Var v) const { return index_ == v.index_; }
  bool operator!=(Var v) const { return index_ != v.index_; }

  /// Rotate left by 1: MSB (neg bit) → LSB, giving order x < ~x < y < ~y.
  /// Compilers emit a single ROL instruction (x86: rol eax,1 / ARM: ror w0,#31).
  static vindex_t order_key(vindex_t idx) {
    return (idx << 1) | (idx >> 31);
  }
  bool operator<(Var v) const { return order_key(index_) < order_key(v.index_); }
  bool operator>(Var v) const { return order_key(index_) > order_key(v.index_); }
  bool operator<=(Var v) const { return order_key(index_) <= order_key(v.index_); }
  bool operator>=(Var v) const { return order_key(index_) >= order_key(v.index_); }

  /// Term count: a single variable is always 1 term of degree 1
  size_t term_count() const { return 1; }
  size_t term_count(uint32_t d) const { return d == 1 ? 1 : 0; }

  /// Evaluate: var(sol) → 0 or 1
  energy_t operator()(const Sol& sol) const;
};

/// Negation: ~x flips the MSB
inline Var operator~(Var v) {
  return Var(v.index() ^ vindex_neg_bit);
}

// ---------------------------------------------------------------------------
// VarBase<m> — fixed-size variable index array (for .so internal use)
// ---------------------------------------------------------------------------

template <int m>
struct VarBase {
  vindex_t v[m];
  static constexpr vindex_t VOID = vindex_limit;
  VarBase() { for (int i = 0; i < m; ++i) v[i] = VOID; }
  uint32_t degree() const {
    for (int i = 0; i < m; ++i)
      if (v[i] == VOID) return static_cast<uint32_t>(i);
    return static_cast<uint32_t>(m);
  }
};

// ---------------------------------------------------------------------------
// VarArray — compact variable index storage
//   MAXDEG2/4/6: VarBase<N> fixed-length (no heap allocation)
//   default (m0): VarBase2 + heap-allocated extra_ (variable length)
// ---------------------------------------------------------------------------

#if defined(MAXDEG6)
static constexpr uint32_t VARARRAY_CAP = 6;
#elif defined(MAXDEG4)
static constexpr uint32_t VARARRAY_CAP = 4;
#elif defined(MAXDEG2)
static constexpr uint32_t VARARRAY_CAP = 2;
#else
static constexpr uint32_t VARARRAY_CAP = 0;  // variable length
#endif

#if defined(MAXDEG2) || defined(MAXDEG4) || defined(MAXDEG6)

// ── Fixed-length VarArray ──
struct VarArray {
  VarBase<VARARRAY_CAP> base_;
  static constexpr vindex_t VOID = vindex_limit;

  VarArray() = default;
  VarArray(const VarArray&) = default;
  VarArray(VarArray&&) noexcept = default;
  VarArray& operator=(const VarArray&) = default;
  VarArray& operator=(VarArray&&) noexcept = default;
  ~VarArray() = default;

  uint32_t degree() const { return base_.degree(); }
  vindex_t  operator[](uint32_t pos) const { return base_.v[pos]; }
  vindex_t& operator[](uint32_t pos)       { return base_.v[pos]; }

  void to_flat(vindex_t* out) const {
    uint32_t d = degree();
    for (uint32_t i = 0; i < d; ++i) out[i] = base_.v[i];
  }

  void push(vindex_t v) {
    for (uint32_t i = 0; i < VARARRAY_CAP; ++i)
      if (base_.v[i] == VOID) { base_.v[i] = v; return; }
    throw std::runtime_error("VarArray: degree exceeds MAXDEG capacity ("
                              + std::to_string(VARARRAY_CAP) + ")");
  }

  void append(const VarArray& other) {
    uint32_t d1 = degree(), d2 = other.degree();
    if (d1 + d2 > VARARRAY_CAP)
      throw std::runtime_error("VarArray::append: degree exceeds MAXDEG capacity");
    for (uint32_t i = 0; i < d2; ++i)
      base_.v[d1 + i] = other[i];
  }

  // ABI boundary helpers
  VarBase2 abi_base() const { return {{base_.v[0], base_.v[1]}}; }
  VarBase2 to_abi_base() const { return abi_base(); }
  const vindex_t* abi_extra() const {
    return (degree() > 2) ? &base_.v[2] : nullptr;
  }
  const vindex_t* to_abi_extra() const { return abi_extra(); }
  void from_abi(VarBase2 vb, const vindex_t* extra) {
    base_.v[0] = vb.v[0]; base_.v[1] = vb.v[1];
    if (extra)
      for (uint32_t d = 2; extra[d - 2] != VOID && d < VARARRAY_CAP; ++d)
        base_.v[d] = extra[d - 2];
  }
};

#else

// ── Variable-length VarArray ──
struct VarArray {
  VarBase2 base_;
  vindex_t* extra_;       // heap-allocated, VOID-terminated, nullptr if degree <= 2

  static constexpr vindex_t VOID = vindex_limit;

  static size_t extra_alloc(uint32_t d) {
    return (d - 2 + 2) & ~size_t(1);
  }

  VarArray() : extra_(nullptr) {}

  VarArray(const VarArray& o) : base_(o.base_), extra_(nullptr) {
    if (o.extra_) {
      size_t n = extra_alloc(o.degree());
      extra_ = static_cast<vindex_t*>(std::malloc(n * sizeof(vindex_t)));
      std::memcpy(extra_, o.extra_, n * sizeof(vindex_t));
    }
  }
  VarArray(VarArray&& o) noexcept : base_(o.base_), extra_(o.extra_) {
    o.extra_ = nullptr; o.base_ = VarBase2();
  }
  ~VarArray() { std::free(extra_); }

  VarArray& operator=(const VarArray& o) {
    if (this != &o) {
      std::free(extra_);
      base_ = o.base_;
      extra_ = nullptr;
      if (o.extra_) {
        size_t n = extra_alloc(o.degree());
        extra_ = static_cast<vindex_t*>(std::malloc(n * sizeof(vindex_t)));
        std::memcpy(extra_, o.extra_, n * sizeof(vindex_t));
      }
    }
    return *this;
  }
  VarArray& operator=(VarArray&& o) noexcept {
    if (this != &o) {
      std::free(extra_);
      base_ = o.base_;
      extra_ = o.extra_;
      o.extra_ = nullptr; o.base_ = VarBase2();
    }
    return *this;
  }

  uint32_t degree() const {
    uint32_t d = base_.degree();
    if (d < 2 || !extra_) return d;
    d = 2;
    while (extra_[d - 2] != VOID) ++d;
    return d;
  }

  vindex_t operator[](uint32_t pos) const {
    return (pos < 2) ? base_.v[pos] : extra_[pos - 2];
  }
  vindex_t& operator[](uint32_t pos) {
    return (pos < 2) ? base_.v[pos] : extra_[pos - 2];
  }

  void to_flat(vindex_t* out) const {
    uint32_t d = degree();
    for (uint32_t i = 0; i < d; ++i) out[i] = (*this)[i];
  }

  void push(vindex_t v) {
    if (base_.v[0] == VOID) { base_.v[0] = v; return; }
    if (base_.v[1] == VOID) { base_.v[1] = v; return; }
    uint32_t d = degree();
    uint32_t idx = d - 2;
    size_t needed = extra_alloc(d + 1);
    size_t current = extra_ ? extra_alloc(d) : 0;
    if (needed > current)
      extra_ = static_cast<uint32_t*>(std::realloc(extra_, needed * 4));
    extra_[idx] = v;
    extra_[idx + 1] = VOID;
  }

  void append(const VarArray& other) {
    uint32_t d2 = other.degree();
    if (d2 == 0) return;
    uint32_t d1 = degree();
    uint32_t total = d1 + d2;

    uint32_t src = 0;
    if (d1 == 0) {
      base_.v[0] = other[0];
      base_.v[1] = (d2 >= 2) ? other[1] : VOID;
      src = (d2 >= 2) ? 2 : 1;
    } else if (d1 == 1) {
      base_.v[1] = other[0];
      src = 1;
    }
    if (total <= 2) return;

    size_t needed = extra_alloc(total);
    extra_ = static_cast<vindex_t*>(std::realloc(extra_, needed * sizeof(vindex_t)));
    for (uint32_t i = src; i < d2; ++i)
      extra_[d1 + i - 2] = other[i];
    extra_[total - 2] = VOID;
  }

  // ABI boundary helpers (variable-length: direct access)
  VarBase2 abi_base() const { return base_; }
  VarBase2 to_abi_base() const { return base_; }
  const vindex_t* abi_extra() const { return extra_; }
  const vindex_t* to_abi_extra() const { return extra_; }
  void from_abi(VarBase2 vb, const vindex_t* extra) {
    base_ = vb;
    std::free(extra_);
    extra_ = nullptr;
    if (extra) {
      uint32_t d = 2;
      while (extra[d - 2] != VOID) ++d;
      size_t n = extra_alloc(d);
      extra_ = static_cast<vindex_t*>(std::malloc(n * sizeof(vindex_t)));
      std::memcpy(extra_, extra, n * sizeof(vindex_t));
    }
  }
};

#endif  // MAXDEG

// ---------------------------------------------------------------------------
// Term class — user-side value type (coeff + VarArray)
// No .so calls for Term operations. Data copied to .so only when promoted to Expr.
// ---------------------------------------------------------------------------

class Term {
  coeff_t coeff_ = 0;
  VarArray vars_;

 public:
  Term() = default;
  Term(coeff_t c) : coeff_(c) {}
  Term(coeff_t c, Var v) : coeff_(c) { vars_.push(v.index()); }
  Term(coeff_t c, Var v1, Var v2) : coeff_(c) { vars_.push(v1.index()); vars_.push(v2.index()); }

  /// Direct access to VarArray (for .so ABI boundary — borrow, no copy)
  const VarArray& vars_ref() const { return vars_; }

  /// Construct from ABI data (VarBase2 + extra pointer)
  static Term from_vararray(coeff_t c, VarBase2 vb, const vindex_t* extra) {
    Term t;
    t.coeff_ = c;
    t.vars_.from_abi(vb, extra);
    return t;
  }

  /// Multiply by variable: t *= x
  Term& operator*=(Var v) { vars_.push(v.index()); return *this; }

  /// Multiply by coefficient: t *= 3
  Term& operator*=(coeff_t c) { coeff_ *= c; return *this; }

  /// Multiply by Term: t *= other
  Term& operator*=(const Term& other) {
    coeff_ *= other.coeff_;
    vars_.append(other.vars_);
    return *this;
  }

  /// Divide by integer: t /= 3 (throws if indivisible)
  Term& operator/=(coeff_t c) {
    if (c == 0) throw std::runtime_error("Division by zero");
    if ((coeff_ / c) * c != coeff_)
      throw std::runtime_error("Indivisible division in Term");
    coeff_ /= c;
    return *this;
  }

  /// Negate
  Term operator-() const { Term r(*this); r.coeff_ = -r.coeff_; return r; }

  uint32_t degree() const { return vars_.degree(); }
  coeff_t coeff() const { return coeff_; }
  Var var(uint32_t i) const { return Var(vars_[i]); }
  const VarArray& vars() const { return vars_; }

  /// Term count: a single term has 0 terms if coeff==0, else 1 term of its degree
  size_t term_count() const { return coeff_ == 0 ? 0 : (degree() == 0 ? 0 : 1); }
  size_t term_count(uint32_t d) const { return (coeff_ != 0 && degree() == d) ? 1 : 0; }

  bool has(Var v) const {
    vindex_t base = v.index() & vindex_mask;
    uint32_t d = vars_.degree();
    for (uint32_t i = 0; i < d; ++i)
      if ((vars_[i] & vindex_mask) == base) return true;
    return false;
  }

  /// Extract vars to flat array for .so raw term API
  std::vector<vindex_t> vars_flat() const {
    uint32_t d = vars_.degree();
    std::vector<vindex_t> v(d);
    vars_.to_flat(v.data());
    return v;
  }

  std::string _str() const {
    uint32_t d = vars_.degree();
    if (d == 0) return _to_string(coeff_);
    std::string s;
    if (coeff_ == -1) s = "-";
    else if (coeff_ != 1) s = _to_string(coeff_) + "*";
    for (uint32_t i = 0; i < d; ++i) {
      if (i > 0) s += "*";
      s += qbpp_var_str(vars_[i]);
    }
    return s;
  }

  /// Create TermImpl in .so (copy, caller owns). Single C ABI call.
  void* to_impl() const {
    return qbpp_term_create_vararray(FlatEnergy(coeff_), vars_.abi_base(), vars_.abi_extra());
  }

  /// Move VarArray data into .so (this Term becomes empty after call)
  struct ReleasedVars { VarBase2 vb; vindex_t* extra; };
  ReleasedVars release_vars() {
#if defined(MAXDEG2) || defined(MAXDEG4) || defined(MAXDEG6)
    // Fixed-length: copy to ABI format, no heap to transfer
    ReleasedVars r{vars_.abi_base(), nullptr};
    // For degree > 2, allocate extra for the .so to take ownership
    uint32_t d = vars_.degree();
    if (d > 2) {
      size_t n = (d - 2 + 2) & ~size_t(1);
      r.extra = static_cast<vindex_t*>(std::malloc(n * sizeof(vindex_t)));
      for (uint32_t i = 2; i < d; ++i) r.extra[i - 2] = vars_[i];
      r.extra[d - 2] = vindex_limit;  // VOID terminator
    }
    vars_ = VarArray();
    return r;
#else
    ReleasedVars r{vars_.base_, vars_.extra_};
    vars_.base_ = VarBase2();
    vars_.extra_ = nullptr;
    return r;
#endif
  }

  /// Evaluate: term(sol) → coeff * product(var values)
  energy_t operator()(const Sol& sol) const;
};

// ---------------------------------------------------------------------------
// Term operator overloads
// ---------------------------------------------------------------------------

/// coeff * Var → Term
inline Term operator*(coeff_t c, Var v) { return Term(c, v); }

/// Var * coeff → Term
inline Term operator*(Var v, coeff_t c) { return Term(c, v); }

/// Var * Var → Term
inline Term operator*(Var v1, Var v2) { return Term(1, v1, v2); }

/// Term * Var → Term (move)
inline Term operator*(Term&& t, Var v) {
  t *= v;
  return std::move(t);
}

/// Term * Var → Term (copy)
inline Term operator*(const Term& t, Var v) {
  Term r(t);
  r *= v;
  return r;
}

/// Var * Term → Term (move)
inline Term operator*(Var v, Term&& t) {
  t *= v;
  return std::move(t);
}

/// Var * Term → Term (copy)
inline Term operator*(Var v, const Term& t) {
  Term r(t);
  r *= v;
  return r;
}

/// coeff * Term → Term (move)
inline Term operator*(coeff_t c, Term&& t) {
  t *= c;
  return std::move(t);
}

/// coeff * Term → Term (copy)
inline Term operator*(coeff_t c, const Term& t) {
  Term r(t);
  r *= c;
  return r;
}

/// Term * coeff → Term (move)
inline Term operator*(Term&& t, coeff_t c) {
  t *= c;
  return std::move(t);
}

/// Term * coeff → Term (copy)
inline Term operator*(const Term& t, coeff_t c) {
  Term r(t);
  r *= c;
  return r;
}

/// Term / coeff → Term
inline Term operator/(Term&& t, coeff_t c) { t /= c; return std::move(t); }
inline Term operator/(const Term& t, coeff_t c) { Term r(t); r /= c; return r; }

/// Term * Term → Term
inline Term operator*(const Term& a, const Term& b) { Term r(a); r *= b; return r; }
inline Term operator*(Term&& a, const Term& b) { a *= b; return std::move(a); }
inline Term operator*(const Term& a, Term&& b) { b *= a; return std::move(b); }
inline Term operator*(Term&& a, Term&& b) { a *= b; return std::move(a); }

// Forward declarations for Expr constructors
template <typename T> class ArrayView;
template <typename T> class ConstArrayView;

// ---------------------------------------------------------------------------
// Expr class (opaque — impl in .so)
// ---------------------------------------------------------------------------

class Expr {
  void* impl_ = nullptr;

  struct impl_tag {};
  Expr(void* p, impl_tag) : impl_(p) {}

 public:
  /// Wrap raw .so pointer (takes ownership)
  explicit Expr(void* p) : impl_(p) {}
  /// Create from raw impl pointer (takes ownership) — named constructor
  static Expr from_impl(void* p) { return Expr(p); }
  /// Empty expression (constant = 0)
  Expr() : impl_(qbpp_expr_create()) {}

  /// From integer constant
  explicit Expr(coeff_t c) : impl_(qbpp_expr_create_int(FlatEnergy(c))) {}

  /// From Var (implicit — matches old API)
  Expr(Var v) : impl_(qbpp_expr_create_var(v.index())) {}


  /// From Term (copy)
  explicit Expr(const Term& t)
      : impl_(qbpp_expr_create_raw_term(FlatEnergy(t.coeff()), t.vars_flat().data(), t.degree(), FlatEnergy(0))) {}

  /// From Term (move — VarArray ownership transferred to .so)
  explicit Expr(Term&& t) {
    auto rv = t.release_vars();
    impl_ = qbpp_expr_create_move_term(FlatEnergy(t.coeff()), rv.vb, rv.extra, FlatEnergy(0));
  }

  Expr(const Expr& o) : impl_(o.impl_ ? qbpp_expr_clone(o.impl_) : nullptr) {}

  Expr(Expr&& o) noexcept : impl_(o.impl_) { o.impl_ = nullptr; }

  ~Expr() {
    if (impl_) qbpp_expr_destroy(impl_);
  }

  Expr& operator=(const Expr& o) {
    if (this != &o) {
      if (impl_) qbpp_expr_destroy(impl_);
      impl_ = o.impl_ ? qbpp_expr_clone(o.impl_) : nullptr;
    }
    return *this;
  }

  Expr& operator=(Expr&& o) noexcept {
    if (this != &o) {
      if (impl_) qbpp_expr_destroy(impl_);
      impl_ = o.impl_;
      o.impl_ = nullptr;
    }
    return *this;
  }

  // --- In-place arithmetic ---

  Expr& operator+=(coeff_t c) { qbpp_expr_iadd_int(impl_, FlatEnergy(c)); return *this; }
  Expr& operator-=(coeff_t c) { qbpp_expr_isub_int(impl_, FlatEnergy(c)); return *this; }
  Expr& operator*=(coeff_t c) { qbpp_expr_imul_int(impl_, FlatEnergy(c)); return *this; }
  Expr& operator*=(const Expr& e) { qbpp_expr_imul_expr(impl_, e.impl_); return *this; }
  Expr& operator*=(Var v) { qbpp_expr_imul_var(impl_, v.index()); return *this; }
  Expr& operator*=(const Term& t) {
    qbpp_expr_imul_term_direct(impl_, FlatEnergy(t.coeff()),
        t.vars_ref().abi_base(), t.vars_ref().abi_extra());
    return *this;
  }
  Expr& operator/=(coeff_t c) { qbpp_expr_idiv_int(impl_, FlatEnergy(c)); return *this; }

  Expr& operator+=(Var v) { qbpp_expr_iadd_var(impl_, v.index()); return *this; }
  Expr& operator-=(Var v) { qbpp_expr_isub_var(impl_, v.index()); return *this; }

  Expr& operator+=(const Term& t) { qbpp_expr_iadd_raw_term(impl_, FlatEnergy(t.coeff()), t.vars_flat().data(), t.degree()); return *this; }
  Expr& operator+=(Term&& t) {
    auto rv = t.release_vars();
    qbpp_expr_iadd_move_term(impl_, FlatEnergy(t.coeff()), rv.vb, rv.extra);
    return *this;
  }
  Expr& operator-=(const Term& t) { qbpp_expr_isub_raw_term(impl_, FlatEnergy(t.coeff()), t.vars_flat().data(), t.degree()); return *this; }
  Expr& operator-=(Term&& t) {
    auto rv = t.release_vars();
    qbpp_expr_isub_move_term(impl_, FlatEnergy(t.coeff()), rv.vb, rv.extra);
    return *this;
  }

  Expr& operator+=(const Expr& e) { qbpp_expr_iadd_expr(impl_, e.impl_); return *this; }
  Expr& operator-=(const Expr& e) { qbpp_expr_isub_expr(impl_, e.impl_); return *this; }

  /// Stage E-b: += / -= for a single-element Array<Dim, T> (e.g. constraint
  /// result). Takes element 0 as a scalar. Templated, defined after Array<Dim,T>.
  template <size_t Dim, typename T> Expr& operator+=(const Array<Dim, T>& a);
  template <size_t Dim, typename T> Expr& operator-=(const Array<Dim, T>& a);

  Expr operator-() const {
    Expr r(*this);
    qbpp_expr_negate(r.impl_);
    return r;
  }

  // --- Accessors ---

  energy_t constant() const { flat_energy_t f; qbpp_expr_constant(impl_, &f); return _from_flat(f); }
  Term term(size_t i) const {
    flat_energy_t fe; VarBase2 vb; const vindex_t* extra;
    qbpp_expr_term_at_data(impl_, i, &fe, &vb, &extra);
    return Term::from_vararray(_from_flat(fe), vb, extra);
  }
  size_t term_count() const { return qbpp_expr_term_count(impl_); }
  size_t term_count(uint32_t d) const { return qbpp_expr_term_count_degree(impl_, d); }
  uint32_t max_degree() const { return qbpp_expr_max_degree(impl_); }
  /// Upper bound: constant + sum of positive coefficients (after simplify_as_binary)
  energy_t pos_sum() const { flat_energy_t f; qbpp_expr_pos_sum(impl_, &f); return _from_flat(f); }
  /// Lower bound: constant + sum of negative coefficients (after simplify_as_binary)
  energy_t neg_sum() const { flat_energy_t f; qbpp_expr_neg_sum(impl_, &f); return _from_flat(f); }
  std::string _str() const { return qbpp_expr_str(impl_); }
  bool has(Var v) const { return qbpp_expr_has(impl_, v.index()) != 0; }
  /// Does `*this` contain all binary variables of `vi` (must be a Expr)?
  bool has_varint(const Expr& vi) const;  // deferred (uses vars() / get_var())
  void* impl() const { return impl_; }

  // --- In-place simplify (member versions) ---

  Expr& simplify() {
    void* r = qbpp_expr_simplify(impl_);
    qbpp_expr_destroy(impl_);
    impl_ = r;
    return *this;
  }
  Expr& simplify_as_binary() {
    void* r = qbpp_expr_simplify_as_binary(impl_);
    qbpp_expr_destroy(impl_);
    impl_ = r;
    return *this;
  }
  Expr& simplify_as_spin() {
    void* r = qbpp_expr_simplify_as_spin(impl_);
    qbpp_expr_destroy(impl_);
    impl_ = r;
    return *this;
  }

  /// In-place spin_to_binary
  Expr& spin_to_binary() {
    void* r = qbpp_expr_spin_to_binary(impl_);
    qbpp_expr_destroy(impl_); impl_ = r; return *this;
  }
  /// In-place binary_to_spin
  Expr& binary_to_spin() {
    void* r = qbpp_expr_binary_to_spin(impl_);
    qbpp_expr_destroy(impl_); impl_ = r; return *this;
  }

  /// In-place sqr: f = f * f
  Expr& sqr() {
    void* r = qbpp_expr_sqr(impl_);
    qbpp_expr_destroy(impl_);
    impl_ = r;
    return *this;
  }

  /// Evaluate: expr(sol) → energy value
  energy_t operator()(const Sol& sol) const;

  /// Evaluate with MapList — defined after MapList
  template <typename ML> energy_t operator()(const ML& ml) const;
  energy_t operator()(std::initializer_list<MapEntry> ml) const;

  /// Replace variables with MapList — defined after MapList
  template <typename ML> Expr& replace(const ML& ml);
  Expr& replace(std::initializer_list<MapEntry> ml);

  // ---------------------------------------------------------------------
  // Expr-specific accessors (valid only when this Expr was created via
  // var_int(...).between(...) or carries a Expr attr_). Aborts at runtime
  // if the underlying ExprImpl is not tagged as a Expr.
  //
  // The Expr identity is carried by ExprImpl::attr_ inside the .so; the
  // actual metadata (range, binary-variable coefficients) lives in a
  // singleton VarIntSet. These methods dispatch through qbpp_varintelem_*
  // which performs the attr_ check.
  // ---------------------------------------------------------------------
  /// Runtime type checks (attr_ inspection, no abort).
  /// `is_varint()` → this Expr was constructed via var_int(...).between(...).
  /// `is_exprexpr()` → this Expr was constructed via `==` / range constraint.
  bool is_varint() const {
    uint32_t a = qbpp_expr_attr(impl_);
    return a != 0xFFFFFFFFu && (a & 0x80000000u) == 0;
  }
  bool is_exprexpr() const {
    uint32_t a = qbpp_expr_attr(impl_);
    return a != 0xFFFFFFFFu && (a & 0x80000000u) != 0;
  }

  energy_t min_val() const { flat_energy_t f; qbpp_varintelem_min(impl_, &f); return _from_flat(f); }
  energy_t max_val() const { flat_energy_t f; qbpp_varintelem_max(impl_, &f); return _from_flat(f); }
  size_t   var_count() const { return qbpp_varintelem_var_count(impl_); }
  coeff_t  coeff(size_t i) const { flat_coeff_t f; qbpp_varintelem_coeff(impl_, i, &f); return _from_flat_c(f); }
  Var      get_var(size_t i) const { return Var(qbpp_varintelem_var(impl_, i)); }
  Var      operator[](size_t i) const { return Var(qbpp_varintelem_var(impl_, i)); }
  /// Array accessors — deferred after Array<Dim,T> definition.
  Array<1, Var>     vars() const;
  Array<1, coeff_t> coeffs() const;

  // ---------------------------------------------------------------------
  // Constraint body accessor (valid only when this Expr carries an
  // ExprExpr attr_, i.e. was created via `e == v`, `l <= e <= u`, or
  // similar). Aborts at runtime on a non-ExprExpr value. The Python side
  // exposes the same as a property: `e.body`.
  // ---------------------------------------------------------------------
  Expr body() const {
    return Expr(qbpp_expr_clone(qbpp_exprexprelem_get_body(impl_)));
  }
  /// Convenience: `f.body(sol)` — equivalent to `f.body()(sol)`.
  energy_t body(const Sol& sol) const { return body()(sol); }
};

// ---------------------------------------------------------------------------
// Expr binary operators — each uses the most direct .so call
// ---------------------------------------------------------------------------

// --- operator+ ---

// Expr + Expr
inline Expr operator+(Expr&& a, const Expr& b) { a += b; return std::move(a); }
inline Expr operator+(const Expr& a, const Expr& b) { return Expr(qbpp_expr_clone_add_expr(a.impl(), b.impl())); }
// Expr + Term
inline Expr operator+(Expr&& a, const Term& t) { a += t; return std::move(a); }
inline Expr operator+(const Expr& a, const Term& t) { Expr r(a); r += t; return r; }
// Term + Expr
inline Expr operator+(const Term& t, Expr&& a) { a += t; return std::move(a); }
inline Expr operator+(const Term& t, const Expr& a) { Expr r(a); r += t; return r; }
// Expr + Var
inline Expr operator+(Expr&& a, Var v) { a += v; return std::move(a); }
inline Expr operator+(const Expr& a, Var v) { return Expr(qbpp_expr_clone_add_var(a.impl(), v.index())); }
// Var + Expr
inline Expr operator+(Var v, const Expr& a) { return Expr(qbpp_expr_clone_add_var(a.impl(), v.index())); }
// Expr + int
inline Expr operator+(Expr&& a, coeff_t c) { a += c; return std::move(a); }
inline Expr operator+(const Expr& a, coeff_t c) { return Expr(qbpp_expr_clone_add_int(a.impl(), FlatEnergy(c))); }
// int + Expr
inline Expr operator+(coeff_t c, const Expr& a) { return Expr(qbpp_expr_clone_add_int(a.impl(), FlatEnergy(c))); }
// Term + Term (1 .so call)
inline Expr operator+(const Term& a, const Term& b) {
  return Expr(qbpp_expr_create_add_raw_terms(
      FlatEnergy(a.coeff()), a.vars_flat().data(), a.degree(),
      FlatEnergy(b.coeff()), b.vars_flat().data(), b.degree()));
}
// Term + Var
inline Expr operator+(const Term& t, Var v) { Expr r(t); r += Expr(v); return r; }
inline Expr operator+(Var v, const Term& t) { return t + v; }
// Term + int
inline Expr operator+(const Term& t, coeff_t c) {
  return Expr(qbpp_expr_create_raw_term(FlatEnergy(t.coeff()), t.vars_flat().data(), t.degree(), FlatEnergy(c)));
}
inline Expr operator+(coeff_t c, const Term& t) { return t + c; }
// Var + Var (1 .so call)
inline Expr operator+(Var a, Var b) { return Expr(qbpp_expr_create_add_var_var(a.index(), b.index())); }
// Var + int / int + Var (1 .so call)
inline Expr operator+(Var v, coeff_t c) { return Expr(qbpp_expr_create_add_var_int(v.index(), FlatEnergy(c))); }
inline Expr operator+(coeff_t c, Var v) { return Expr(qbpp_expr_create_add_var_int(v.index(), FlatEnergy(c))); }

// --- operator- ---

// Expr - Expr
inline Expr operator-(Expr&& a, const Expr& b) { a -= b; return std::move(a); }
inline Expr operator-(const Expr& a, const Expr& b) { return Expr(qbpp_expr_clone_sub_expr(a.impl(), b.impl())); }
// Expr - Term
inline Expr operator-(Expr&& a, const Term& t) { a -= t; return std::move(a); }
inline Expr operator-(const Expr& a, const Term& t) { Expr r(a); r -= t; return r; }
// Term - Expr
inline Expr operator-(const Term& t, const Expr& a) { Expr r(t); r -= a; return r; }
// Expr - Var
inline Expr operator-(Expr&& a, Var v) { a -= v; return std::move(a); }
inline Expr operator-(const Expr& a, Var v) { return Expr(qbpp_expr_clone_sub_var(a.impl(), v.index())); }
// Var - Expr
inline Expr operator-(Var v, const Expr& a) { Expr r(v); r -= a; return r; }
// Expr - int
inline Expr operator-(Expr&& a, coeff_t c) { a -= c; return std::move(a); }
inline Expr operator-(const Expr& a, coeff_t c) { return Expr(qbpp_expr_clone_sub_int(a.impl(), FlatEnergy(c))); }
// int - Expr
inline Expr operator-(coeff_t c, const Expr& a) { Expr r(c); r -= a; return r; }
// Term - Term (1 .so call)
inline Expr operator-(const Term& a, const Term& b) { Expr r(a); r -= b; return r; }
// Term - Var
inline Expr operator-(const Term& t, Var v) { Expr r(t); r -= v; return r; }
// Var - Term
inline Expr operator-(Var v, const Term& t) { Expr r(v); r -= t; return r; }
// Term - int
inline Expr operator-(const Term& t, coeff_t c) { return t + (-c); }
// int - Term
inline Expr operator-(coeff_t c, const Term& t) { Expr r(c); r -= t; return r; }
// Var - Var
inline Expr operator-(Var a, Var b) { Expr r(a); r -= b; return r; }
// Var - int
inline Expr operator-(Var v, coeff_t c) { return Expr(qbpp_expr_create_add_var_int(v.index(), FlatEnergy(-c))); }
// int - Var
inline Expr operator-(coeff_t c, Var v) { return Expr(qbpp_expr_create_sub_int_var(FlatEnergy(c), v.index())); }

// --- operator* ---
// Expr * coeff
inline Expr operator*(Expr&& a, coeff_t c) { a *= c; return std::move(a); }
inline Expr operator*(const Expr& a, coeff_t c) { return Expr(qbpp_expr_clone_mul_int(a.impl(), FlatEnergy(c))); }
inline Expr operator*(coeff_t c, Expr&& a) { a *= c; return std::move(a); }
inline Expr operator*(coeff_t c, const Expr& a) { return Expr(qbpp_expr_clone_mul_int(a.impl(), FlatEnergy(c))); }
// Expr * Expr
inline Expr operator*(const Expr& a, const Expr& b) { return Expr(qbpp_expr_mul_expr(a.impl(), b.impl())); }
// Expr * Var / Var * Expr
inline Expr operator*(const Expr& a, Var v) { return Expr(qbpp_expr_mul_expr(a.impl(), Expr(v).impl())); }
inline Expr operator*(Var v, const Expr& a) { return a * v; }
// Expr * Term / Term * Expr
inline Expr operator*(const Expr& a, const Term& t) { return Expr(qbpp_expr_mul_expr(a.impl(), Expr(t).impl())); }
inline Expr operator*(const Term& t, const Expr& a) { return a * t; }

// Expr / coeff (integer division, throws if indivisible)
inline Expr operator/(Expr&& a, coeff_t c) { a /= c; return std::move(a); }
inline Expr operator/(const Expr& a, coeff_t c) { Expr r(a); r /= c; return r; }

// --- sqr (optimized special case of Expr * Expr) ---
inline Expr sqr(const Expr& e) { return Expr(qbpp_expr_sqr(e.impl())); }

// --- toExpr ---

// --- gcd ---

/// Greatest common divisor of all coefficients and constant
inline energy_t gcd(const Expr& e) {
  flat_energy_t f; qbpp_expr_gcd(e.impl(), &f); return _from_flat(f);
}

/// Convert ExprType to Expr (explicit conversion).
/// Scalar overloads; Expr / Expr overloads are deferred until after
/// those classes are defined (see below).
inline Expr toExpr(const Expr& e) { return e; }
inline Expr toExpr(const Term& t) { return Expr(t); }
inline Expr toExpr(Var v) { return Expr(v); }
inline Expr toExpr(coeff_t c) { return Expr(c); }


// --- simplify ---
/// Merge duplicate terms, remove zeros
inline Expr simplify(const Expr& e) { return Expr(qbpp_expr_simplify(e.impl())); }
/// Binary (0/1): ~x→(1-x), x*x→x, x*~x→0, merge
inline Expr simplify_as_binary(const Expr& e) { return Expr(qbpp_expr_simplify_as_binary(e.impl())); }
/// Spin (±1): ~s→-s, s*s→1, merge
inline Expr simplify_as_spin(const Expr& e) { return Expr(qbpp_expr_simplify_as_spin(e.impl())); }

// --- spin/binary conversion ---

/// spin_to_binary: replace each spin variable s with (2s - 1)
inline Expr spin_to_binary(const Expr& e) { return Expr(qbpp_expr_spin_to_binary(e.impl())); }
/// binary_to_spin: replace each binary variable x with (x+1)/2, multiply by 2^d
inline Expr binary_to_spin(const Expr& e) { return Expr(qbpp_expr_binary_to_spin(e.impl())); }

// ---------------------------------------------------------------------------
// Term needs release() for Expr(Term&&)
// ---------------------------------------------------------------------------

// (Defined here because Expr is now complete)

// ---------------------------------------------------------------------------
// Type tags for Array batch dispatch
// ---------------------------------------------------------------------------

static_assert(sizeof(Expr) == sizeof(void*), "Expr must be pointer-sized");
static_assert(sizeof(Var)  == sizeof(vindex_t), "Var must be vindex_t-sized");

constexpr int QBPP_EXPR = 0;
constexpr int QBPP_VAR  = 1;
constexpr int QBPP_TERM = 2;

namespace detail {

/// Convert coeff_t* to flat_coeff_t* (identity if same, otherwise abi_bigint conversion)
inline const flat_coeff_t* to_flat_coeffs(const coeff_t* p, size_t n,
                                            std::vector<flat_coeff_t>& buf) {
  if constexpr (std::is_same_v<coeff_t, flat_coeff_t>) {
    (void)n; (void)buf;
    return reinterpret_cast<const flat_coeff_t*>(p);
  } else {
    buf.resize(n);
    for (size_t i = 0; i < n; ++i) buf[i] = flat_coeff_t(p[i]);
    return buf.data();
  }
}

}  // namespace detail

// ---------------------------------------------------------------------------
// Expr / Expr — both are Expr (using aliases).
//
// An Expr carries a `uint32_t attr_` tag inside the .so: plain Expr, Expr,
// or Expr. The corresponding metadata lives in singleton sets
// (VarIntSet / ExprExprSet) accessed through the member functions already
// defined on Expr (min_val, max_val, var_count, coeff, get_var, operator*,
// ...). Expr and Expr are kept as type alias names so function
// signatures and return types continue to communicate intent.
// ---------------------------------------------------------------------------

/// Construct an Expr (= Expr with Expr attr_) from penalty + body.
/// Internal helper; user-facing ways to create an Expr are `expr == val`
/// and range constraints `lo <= expr <= hi`.
inline Expr _make_exprexpr(const Expr& penalty, const Expr& body) {
  return Expr(qbpp_exprexprelem_create(penalty.impl(), body.impl()));
}

// ---------------------------------------------------------------------------
// Expr — integer variable encoded as sum of binary variables
// ---------------------------------------------------------------------------

// ---------------------------------------------------------------------------
// Expr — alias for Expr, plus factory helpers
// ---------------------------------------------------------------------------

/// Expr is a name for "an Expr created via var_int(...).between(...)";
/// it shares its C++ type with Expr but has a Expr attr_ tag inside the
/// underlying ExprImpl. Accessor methods like `min_val()`, `var_count()`,
/// and `operator[](i)` are defined on Expr and dispatch through the attr_.

/// Construct a Expr (= Expr with Expr attr_). Creates fresh binary
/// variables and registers the range metadata in VarIntSet.
inline Expr _make_varint(const std::string& name, energy_t min_val, energy_t max_val) {
  if (max_val < min_val)
    throw std::invalid_argument("Expr: max_val must be >= min_val");
  return Expr(qbpp_varintelem_create(name.c_str(),
                                     FlatEnergy(min_val),
                                     FlatEnergy(max_val)));
}

/// Construct a Expr that shares an existing binary-variable array (used
/// internally by VarIntArrayCore::between for array-element construction).
inline Expr _make_varint_with_vars(const std::string& name, energy_t min_val, energy_t max_val,
                                    const std::vector<coeff_t>& coeffs, const Var* vars_begin) {
  std::vector<vindex_t> vidx(coeffs.size());
  for (size_t i = 0; i < coeffs.size(); ++i) vidx[i] = vars_begin[i].index();
  std::vector<flat_coeff_t> cbuf;
  return Expr(qbpp_varintelem_create_with_vars(
      name.c_str(), FlatEnergy(min_val), FlatEnergy(max_val),
      detail::to_flat_coeffs(coeffs.data(), coeffs.size(), cbuf),
      vidx.data(), coeffs.size()));
}

/// Placeholder for delayed Expr construction (holds name only)
class VarIntCore {
 public:
  std::string name_;
  explicit VarIntCore(const std::string& name) : name_(name) {}

  /// var_int("x").between(min, max) → Expr (= Expr with Expr attr_)
  Expr between(energy_t min_val, energy_t max_val) const {
    return _make_varint(name_, min_val, max_val);
  }
};

/// Holds array shape + name for deferred Expr array construction
template <size_t Dim>
class VarIntArrayCore {
  std::string name_;
  std::vector<size_t> shape_;
 public:
  VarIntArrayCore(std::string name, std::vector<size_t> shape)
      : name_(std::move(name)), shape_(std::move(shape)) {}

  /// var_int("x", 2, 3).between(0, 7) → Array<Dim, Expr>
  /// (implementation deferred after Array class definition)
  Array<Dim, Expr> between(energy_t min_val, energy_t max_val) const;

  /// Each element has different min/max (flat vectors)
  Array<Dim, Expr> between(const std::vector<int>& min_vals, const std::vector<int>& max_vals) const;
};

/// VarIntCore == val → constant Expr (placeholder, NOT a constraint)
inline Expr operator==(VarIntCore&& core, energy_t val) {
  return _make_varint(core.name_, val, val);
}

/// VarIntArrayCore == val → Array<Dim, Expr> (deferred after Array class)
template <size_t Dim>
Array<Dim, Expr> operator==(VarIntArrayCore<Dim>&& core, energy_t val);

/// Factory: var_int("x") → VarIntCore (named)
inline VarIntCore var_int(const std::string& name) {
  return VarIntCore(name);
}

/// Factory: var_int() → VarIntCore (unnamed, auto-named by .so)
inline VarIntCore var_int() {
  return VarIntCore(qbpp_auto_var_name());
}

/// Factory: var_int("x", 2, 3) → VarIntArrayCore<sizeof...(Dims)> (deferred)
template <typename... Dims>
inline VarIntArrayCore<sizeof...(Dims)> var_int(const std::string& name, Dims... dims) {
  static_assert(sizeof...(dims) > 0);
  return VarIntArrayCore<sizeof...(Dims)>(name, {static_cast<size_t>(dims)...});
}

/// Unnamed var_int array: var_int(2, 3) → VarIntArrayCore<2>
template <typename... Dims,
          typename = std::enable_if_t<(sizeof...(Dims) > 0) && (std::is_integral_v<Dims> && ...)>>
inline VarIntArrayCore<sizeof...(Dims)> var_int(Dims... dims) {
  return VarIntArrayCore<sizeof...(Dims)>(qbpp_auto_var_name(), {static_cast<size_t>(dims)...});
}

/// Support: min <= var_int("x") <= max → Expr
inline std::pair<energy_t, VarIntCore> operator<=(energy_t min_val, VarIntCore&& core) {
  return {min_val, std::move(core)};
}
inline Expr operator<=(std::pair<energy_t, VarIntCore>&& p, energy_t max_val) {
  return _make_varint(p.second.name_, p.first, max_val);
}

/// Support: min <= var_int("x", 2, 3) <= max → Array<Dim, Expr>
template <size_t Dim>
inline std::pair<energy_t, VarIntArrayCore<Dim>> operator<=(energy_t min_val, VarIntArrayCore<Dim>&& core) {
  return {min_val, std::move(core)};
}
/// (deferred after Array class)
template <size_t Dim>
Array<Dim, Expr> operator<=(std::pair<energy_t, VarIntArrayCore<Dim>>&& p, energy_t max_val);


// ---------------------------------------------------------------------------
// Model — wraps simplified Expr for solvers (opaque, impl in .so)
// ---------------------------------------------------------------------------

class Model {
  void* impl_ = nullptr;

 public:
  /// Create from Expr (should be simplified first)
  explicit Model(const Expr& expr) : impl_(qbpp_model_create(expr.impl())) {}

  ~Model() { if (impl_) qbpp_model_destroy(impl_); }

  Model(const Model& o) : impl_(o.impl_ ? qbpp_model_clone(o.impl_) : nullptr) {}
  Model& operator=(const Model& o) {
    if (this != &o) {
      if (impl_) qbpp_model_destroy(impl_);
      impl_ = o.impl_ ? qbpp_model_clone(o.impl_) : nullptr;
    }
    return *this;
  }
  Model(Model&& o) noexcept : impl_(o.impl_) { o.impl_ = nullptr; }
  Model& operator=(Model&& o) noexcept {
    if (this != &o) { if (impl_) qbpp_model_destroy(impl_); impl_ = o.impl_; o.impl_ = nullptr; }
    return *this;
  }

  void* impl() const { return impl_; }

  /// Number of variables in the model
  vindex_t var_count() const { return qbpp_model_var_count(impl_); }

  /// Get base variable index at position i
  Var var(vindex_t i) const { return Var(qbpp_model_var(impl_, i)); }

  /// Check if variable is in this model
  bool has(Var v) const { return qbpp_model_has(impl_, v.index()) != 0; }
  bool has_varint(const Expr& vi) const;  // deferred

  /// Constant term
  energy_t constant() const { flat_energy_t f; qbpp_model_constant(impl_, &f); return _from_flat(f); }

  /// Maximum term degree
  uint32_t max_degree() const { return qbpp_model_max_degree(impl_); }

  /// Total number of terms (all degrees)
  size_t term_count() const {
    size_t total = 0;
    for (uint32_t d = 1; d <= max_degree(); ++d) total += term_count(d);
    return total;
  }

  /// Number of terms of degree d
  uint64_t term_count(uint32_t d) const { return qbpp_model_term_count(impl_, d); }

  /// Flat variable index array for degree (d+1): [tid*(d+1)+k] = model_index
  const vindex_t* term_vars(uint32_t d) const { return qbpp_model_term_vars(impl_, d); }

  /// Coefficient array for degree (d+1): [tid] = coefficient
  const flat_coeff_t* coeff_array(uint32_t d) const { return qbpp_model_coeff_array(impl_, d); }

  std::string _str() const {
    return "Model(vars=" + std::to_string(var_count()) +
           ", max_deg=" + std::to_string(max_degree()) +
           ", const=" + _to_string(constant()) + ")";
  }
};

// ---------------------------------------------------------------------------
// Sol — solution: Model + bit vector + energy
// ---------------------------------------------------------------------------

class Sol {
  void* impl_ = nullptr;

 public:
  Sol() = default;
  Sol(const Sol& o) : impl_(o.impl_ ? qbpp_sol_clone(o.impl_) : nullptr) {}
  Sol(Sol&& o) noexcept : impl_(o.impl_) { o.impl_ = nullptr; }
  Sol& operator=(const Sol& o) {
    if (this != &o) { if (impl_) qbpp_sol_destroy(impl_); impl_ = o.impl_ ? qbpp_sol_clone(o.impl_) : nullptr; }
    return *this;
  }
  Sol& operator=(Sol&& o) noexcept {
    if (this != &o) { if (impl_) qbpp_sol_destroy(impl_); impl_ = o.impl_; o.impl_ = nullptr; }
    return *this;
  }
  ~Sol() { if (impl_) qbpp_sol_destroy(impl_); }

  /// Construct from Model (all-zero solution)
  explicit Sol(const Model& model) : impl_(qbpp_sol_create(model.impl())) {}

  /// Construct from Expr (simplify_as_binary, all-zero solution)
  explicit Sol(const Expr& expr) : impl_(qbpp_sol_create_from_expr(expr.impl())) {}

  /// Internal: construct from raw .so handle (takes ownership)
  explicit Sol(void* handle) : impl_(handle) {}

  void* impl() const { return impl_; }

  // Accessors
  energy_t energy() const { flat_energy_t f; qbpp_sol_energy(impl_, &f); return _from_flat(f); }
  void energy(energy_t e) { qbpp_sol_set_energy(impl_, FlatEnergy(e)); }
  double tts() const { return qbpp_sol_tts(impl_); }
  void tts(double t) { qbpp_sol_set_tts(impl_, t); }
  vindex_t var_count() const { return qbpp_sol_var_count(impl_); }
  const uint64_t* bitarray() const { return qbpp_sol_bits(impl_); }

  /// Check if variable is in this model
  bool has(Var v) const { return qbpp_sol_has(impl_, v.index()) != 0; }
  bool has_varint(const Expr& vi) const;  // deferred

  /// Get variable value by Var (handles negation, throws if not in model)
  coeff_t get(Var v) const { return qbpp_sol_get(impl_, v.index()); }

  /// Set variable value by Var (throws if not in model)
  void set(Var v, bool value) { qbpp_sol_set(impl_, v.index(), value ? 1 : 0); }

  /// Evaluate model's own expression
  energy_t comp_energy() const {
    flat_energy_t f; qbpp_sol_compute_energy(const_cast<void*>(impl_), &f); return _from_flat(f);
  }

  /// Evaluate an arbitrary Expr
  energy_t eval(const Expr& expr) const {
    flat_energy_t f; qbpp_sol_eval_expr(impl_, expr.impl(), &f); return _from_flat(f);
  }

  /// Functor: sol(var) → value
  energy_t operator()(Var v) const { return get(v); }

  /// Functor: sol(term/expr) → evaluate
  energy_t operator()(const Term& t) const { return eval(Expr(t)); }
  energy_t operator()(const Expr& expr) const { return eval(expr); }

  // Stage E-e: the ArrayBase-taking Sol::operator() is gone. Only the typed
  // overload Sol::operator()(const Array<Dim, Var>&) -> Array<Dim, coeff_t>
  // remains (declared inside the Array<Dim, T> region below, because it
  // mentions Array<Dim, T> in the template).

  /// Functor: sol(Array<Dim, Var>) → Array<Dim, coeff_t>
  template <size_t Dim>
  Array<Dim, coeff_t> operator()(const Array<Dim, Var>& arr) const;

  /// Copy variable values from another Sol
  Sol& set(const Sol& other) { qbpp_sol_set_from_sol(impl_, other.impl_); return *this; }

  /// Set variable values from MapList (defined after MapList)
  template <typename ML, typename = std::enable_if_t<!std::is_base_of_v<Sol, std::decay_t<ML>>>>
  Sol& set(const ML& ml);
  Sol& set(std::initializer_list<MapEntry> ml);

  /// Copy from Sol, then derive values using MapList
  template <typename ML, typename = std::enable_if_t<!std::is_base_of_v<Sol, std::decay_t<ML>>>>
  Sol& set(const Sol& other, const ML& ml);
  Sol& set(const Sol& other, std::initializer_list<MapEntry> ml);

  /// Get model var at index i
  Var model_var(vindex_t i) const { return Var(qbpp_sol_model_var(impl_, i)); }

  std::string _str() const {
    std::string s = _to_string(energy()) + ":{";
    for (vindex_t i = 0; i < var_count(); ++i) {
      if (i > 0) s += ",";
      Var v = model_var(i);
      s += "{";
      s += v._str();
      s += ",";
      s += _to_string(get(v));
      s += "}";
    }
    return s + "}";
  }

  friend std::ostream& operator<<(std::ostream& os, const Sol& sol) {
    return os << sol._str();
  }
};

/// Out-of-line: var(sol), term(sol), expr(sol)
/// Expr/Expr inherit Expr::operator()(const Sol&) directly.
inline energy_t Var::operator()(const Sol& sol) const { return sol.get(*this); }
inline energy_t Term::operator()(const Sol& sol) const { return sol.eval(Expr(*this)); }
inline energy_t Expr::operator()(const Sol& sol) const { return sol.eval(*this); }


// ---------------------------------------------------------------------------
// KeyValue / KeyValueVector / Params — ABI-safe parameter passing
// ---------------------------------------------------------------------------

/// ABI boundary key-value pair (NULL-terminated array)
struct KeyValue {
  const char* key;
  const char* value;
};

/// strdup-managed NULL-terminated KeyValue array
class KeyValueVector {
 public:
  KeyValueVector() {
    capacity_ = 4;
    data_ = static_cast<KeyValue*>(std::malloc(capacity_ * sizeof(KeyValue)));
    data_[0] = {nullptr, nullptr};
    size_ = 0;
  }

  /// Helper for mixed-type initializer list values
  struct ParamValue {
    std::string s;
    ParamValue(const char* v) : s(v) {}
    ParamValue(const std::string& v) : s(v) {}
    ParamValue(int v) : s(std::to_string(v)) {}
    ParamValue(double v) : s(std::to_string(v)) {}
    ParamValue(long v) : s(std::to_string(v)) {}
  };

  /// Construct from initializer list: {{"key1", val1}, {"key2", val2}}
  /// Values can be const char*, string, int, double, or long.
  KeyValueVector(std::initializer_list<std::pair<std::string, ParamValue>> init)
      : KeyValueVector() {
    for (auto& [k, v] : init) set(k.c_str(), v.s.c_str());
  }

  ~KeyValueVector() {
    if (data_) {
      for (size_t i = 0; i < size_; ++i) {
        std::free(const_cast<char*>(data_[i].key));
        std::free(const_cast<char*>(data_[i].value));
      }
      std::free(data_);
    }
  }

  KeyValueVector(const KeyValueVector&) = delete;
  KeyValueVector& operator=(const KeyValueVector&) = delete;

  KeyValueVector(KeyValueVector&& o) noexcept
      : data_(o.data_), size_(o.size_), capacity_(o.capacity_) {
    o.data_ = nullptr; o.size_ = 0; o.capacity_ = 0;
  }
  KeyValueVector& operator=(KeyValueVector&& o) noexcept {
    if (this != &o) {
      this->~KeyValueVector();
      data_ = o.data_; size_ = o.size_; capacity_ = o.capacity_;
      o.data_ = nullptr; o.size_ = 0; o.capacity_ = 0;
    }
    return *this;
  }

  void set(const std::string& key, const std::string& value) {
    set(key.c_str(), value.c_str());
  }

  void operator()(const char* key, const char* value) { set(key, value); }
  void operator()(const std::string& key, const std::string& value) {
    set(key.c_str(), value.c_str());
  }
  template <typename V, typename = std::enable_if_t<std::is_arithmetic_v<V>>>
  void operator()(const char* key, V value) {
    set(key, std::to_string(value).c_str());
  }

  void set(const char* key, const char* value) {
    for (size_t i = 0; i < size_; ++i) {
      if (std::strcmp(data_[i].key, key) == 0) {
        std::free(const_cast<char*>(data_[i].value));
        data_[i].value = ::strdup(value);
        return;
      }
    }
    if (size_ + 1 >= capacity_) {
      capacity_ *= 2;
      data_ = static_cast<KeyValue*>(
          std::realloc(data_, capacity_ * sizeof(KeyValue)));
    }
    data_[size_].key = ::strdup(key);
    data_[size_].value = ::strdup(value);
    ++size_;
    data_[size_] = {nullptr, nullptr};
  }

  const char* get(const char* key) const {
    for (size_t i = 0; i < size_; ++i)
      if (std::strcmp(data_[i].key, key) == 0) return data_[i].value;
    return nullptr;
  }

  bool contains(const char* key) const { return get(key) != nullptr; }
  const KeyValue* data() const { return data_; }
  size_t size() const { return size_; }

  /// Iterators for range-based for loop
  const KeyValue* begin() const { return data_; }
  const KeyValue* end() const { return data_ + size_; }

  std::string _str() const {
    std::string s = "{";
    for (size_t i = 0; i < size_; ++i) {
      if (i > 0) s += ",";
      s += "{\""; s += data_[i].key;
      s += "\", \""; s += data_[i].value;
      s += "\"}";
    }
    return s + "}";
  }

 private:
  KeyValue* data_ = nullptr;
  size_t size_ = 0;
  size_t capacity_ = 0;
};

/// Params — KeyValueVector + optional hint solution
class Params : public KeyValueVector {
 public:
  using KeyValueVector::KeyValueVector;  // inherit constructors
  Params() = default;
  Params(KeyValueVector&& kv) : KeyValueVector(std::move(kv)) {}

  /// Set a hint solution for the next search()
  void hint(const Sol& sol) {
    hint_bitarray_ = sol.bitarray();
    hint_var_count_ = sol.var_count();
  }

  bool has_hint() const { return hint_bitarray_ != nullptr; }
  const uint64_t* hint_bitarray() const { return hint_bitarray_; }
  vindex_t hint_var_count() const { return hint_var_count_; }

 private:
  const uint64_t* hint_bitarray_ = nullptr;
  vindex_t hint_var_count_ = 0;
};

// ---------------------------------------------------------------------------
// SolverSol — Sol + collected solutions + solver info
// ---------------------------------------------------------------------------

/// Common result type for all solvers (EasySolver, ExhaustiveSolver, ABS3Solver).
class SolverSol : public Sol {
 public:
  std::vector<Sol> sols;
  KeyValueVector info_;

  explicit SolverSol(void* sol_handle) : Sol(sol_handle) {}

  size_t size() const { return sols.size(); }
  const KeyValueVector& info() const { return info_; }

  auto begin() const { return sols.begin(); }
  auto end() const { return sols.end(); }
};

// ---------------------------------------------------------------------------
// Constraint operators — all implemented in .so
// ---------------------------------------------------------------------------

/// expr == val → Expr(sqr(expr - val), expr)
inline Expr operator==(const Expr& expr, energy_t val) {
  return _make_exprexpr(sqr(expr - Expr(static_cast<coeff_t>(val))), expr);
}
inline Expr operator==(energy_t val, const Expr& expr) { return expr == val; }

// ---------------------------------------------------------------------------
// Inf — infinity for range constraints
// ---------------------------------------------------------------------------

/// Inf class for representing +inf and -inf in range constraints.
/// +inf is replaced by expr.pos_sum(), -inf by expr.neg_sum().
class Inf {
  bool positive_ = true;
 public:
  Inf() = default;
  bool is_positive() const { return positive_; }
  bool is_negative() const { return !positive_; }
  Inf operator+() const { return *this; }
  Inf operator-() const { Inf i; i.positive_ = !positive_; return i; }
};

inline const Inf inf;

/// Expr == val (defined here because operator==(Expr,energy_t) is now visible)
/// _between(expr, min, max) → Expr (single .so call; internal — public API is
/// the `l <= expr <= u` operator chain).
inline Expr _between(const Expr& expr, energy_t min_val, energy_t max_val) {
  return _make_exprexpr(Expr(qbpp_between(expr.impl(), FlatEnergy(min_val), FlatEnergy(max_val))), expr);
}

/// min <= expr <= +inf → _between(expr, min, expr.pos_sum())
inline Expr operator<=(const std::pair<energy_t, Expr>& p, Inf val) {
  if (val.is_negative())
    throw std::invalid_argument("RHS of operator<= must not be -inf");
  return _between(p.second, p.first, p.second.pos_sum());
}

/// -inf <= expr → pair(expr.neg_sum(), expr)
inline std::pair<energy_t, Expr> operator<=(Inf val, const Expr& expr) {
  if (val.is_positive())
    throw std::invalid_argument("LHS of operator<= must not be +inf");
  return {expr.neg_sum(), expr};
}

/// min <= expr <= max → Expr (works for plain Expr and for Expr,
/// because Expr is just Expr with a Expr attr_).
inline std::pair<energy_t, Expr> operator<=(energy_t min_val, const Expr& expr) {
  return {min_val, expr};
}
inline Expr operator<=(std::pair<energy_t, Expr>&& p, energy_t max_val) {
  return _between(p.second, p.first, max_val);
}

// ---------------------------------------------------------------------------
// MapList — variable-to-expression mapping (used for eval and replace)
// ---------------------------------------------------------------------------

/// MapEntry: allows implicit int→Expr conversion for MapList
struct MapEntry {
  std::variant<Var, Expr> key;
  Expr value;
  MapEntry(Var v, const Expr& e) : key(v), value(e) {}
  MapEntry(Var v, Var v2) : key(v), value(Expr(v2)) {}
  MapEntry(Var v, const Term& t) : key(v), value(Expr(t)) {}
  MapEntry(Var v, int i) : key(v), value(Expr(static_cast<coeff_t>(i))) {}
  template <typename T, typename = std::enable_if_t<!std::is_same_v<T, int> && std::is_same_v<T, energy_t>>>
  MapEntry(Var v, T i) : key(v), value(Expr(i)) {}
  MapEntry(Expr v, const Expr& e) : key(v), value(e) {}
  MapEntry(Expr v, Var v2) : key(v), value(Expr(v2)) {}
  MapEntry(Expr v, const Term& t) : key(v), value(Expr(t)) {}
  MapEntry(Expr v, int i) : key(v), value(Expr(static_cast<coeff_t>(i))) {}
  template <typename T, typename = std::enable_if_t<!std::is_same_v<T, int> && std::is_same_v<T, energy_t>>>
  MapEntry(Expr v, T i) : key(v), value(Expr(i)) {}
};
using MapList = std::vector<MapEntry>;

namespace detail {

/// Expand MapList to flat Var→energy_t pairs (for eval: each Expr must be constant)
inline std::vector<std::pair<Var, energy_t>> expand_maplist_eval(const MapList& ml) {
  std::vector<std::pair<Var, energy_t>> result;
  for (const auto& entry : ml) {
    energy_t val = entry.value.constant();
    std::visit([&](auto&& arg) {
      using T = std::decay_t<decltype(arg)>;
      if constexpr (std::is_same_v<T, Var>) {
        Var base(arg.index() & vindex_mask);
        energy_t base_val = (arg.index() & vindex_neg_bit) ? (1 - val) : val;
        result.push_back({base, base_val});
      } else {
        // Expr: decompose integer value into binary variables via .so
        size_t nc = arg.var_count();
        std::vector<vindex_t> vars(nc);
        std::vector<flat_energy_t> bits(nc);
        qbpp_varintelem_decompose(arg.impl(), FlatEnergy(val), vars.data(), bits.data());
        for (size_t i = 0; i < nc; ++i)
          result.push_back({Var(vars[i]), _from_flat(bits[i])});
      }
    }, entry.key);
  }
  return result;
}

/// Expand MapList to flat Var→Expr pairs (for replace)
inline std::vector<std::pair<Var, Expr>> expand_maplist_replace(const MapList& ml) {
  std::vector<std::pair<Var, Expr>> result;
  for (const auto& entry : ml) {
    std::visit([&](auto&& arg) {
      using T = std::decay_t<decltype(arg)>;
      if constexpr (std::is_same_v<T, Var>) {
        result.push_back({arg, entry.value});
      } else {
        // Expr: decompose integer value into binary variables via .so
        energy_t val = entry.value.constant();
        size_t nc = arg.var_count();
        std::vector<vindex_t> vars(nc);
        std::vector<flat_energy_t> bits(nc);
        qbpp_varintelem_decompose(arg.impl(), FlatEnergy(val), vars.data(), bits.data());
        for (size_t i = 0; i < nc; ++i)
          result.push_back({Var(vars[i]), Expr(_from_flat(bits[i]))});
      }
    }, entry.key);
  }
  return result;
}

}  // namespace detail

/// Evaluate expression with variable assignments (Expr values must be integer constants).
/// Internal — the public API is `expr(ml)` via Expr::operator()(const ML&).
inline energy_t _eval(const Expr& expr, const MapList& ml) {
  auto expanded = detail::expand_maplist_eval(ml);
  std::vector<vindex_t> vars(expanded.size());
  std::vector<flat_energy_t> vals(expanded.size());
  for (size_t i = 0; i < expanded.size(); ++i) {
    vars[i] = expanded[i].first.index();
    vals[i] = flat_energy_t(expanded[i].second);
  }
#ifdef INTEGER_TYPE_CPP_INT
  std::vector<flat_energy_arg> args(vals.size());
  for (size_t i = 0; i < vals.size(); ++i) args[i] = &vals[i];
  flat_energy_t out;
  qbpp_expr_eval_map(expr.impl(), vars.data(), args.data(), expanded.size(), &out);
#else
  flat_energy_t out;
  qbpp_expr_eval_map(expr.impl(), vars.data(), vals.data(), expanded.size(), &out);
#endif
  return _from_flat(out);
}

/// Replace variables in expression (Expr values can be any expression)
inline Expr replace(const Expr& expr, const MapList& ml) {
  auto expanded = detail::expand_maplist_replace(ml);
  std::vector<vindex_t> vars(expanded.size());
  std::vector<const void*> exprs(expanded.size());
  for (size_t i = 0; i < expanded.size(); ++i) {
    vars[i] = expanded[i].first.index();
    exprs[i] = expanded[i].second.impl();
  }
  return Expr(qbpp_expr_replace(expr.impl(), vars.data(), exprs.data(), expanded.size()));
}
inline Expr replace(const Expr& expr, std::initializer_list<MapEntry> il) {
  return replace(expr, MapList(il));
}

/// Expr member functions (deferred — depend on MapList)
template <typename ML>
inline energy_t Expr::operator()(const ML& ml) const {
  if constexpr (std::is_base_of_v<Sol, ML>)
    return static_cast<const Sol&>(ml).eval(*this);
  else
    return _eval(*this, ml);
}
inline energy_t Expr::operator()(std::initializer_list<MapEntry> il) const { return _eval(*this, MapList(il)); }
template <typename ML>
inline Expr& Expr::replace(const ML& ml) { *this = qbpp::replace(*this, ml); return *this; }
inline Expr& Expr::replace(std::initializer_list<MapEntry> il) { *this = qbpp::replace(*this, MapList(il)); return *this; }

/// Sol initializer_list overloads
inline Sol& Sol::set(std::initializer_list<MapEntry> il) { MapList m(il); return set(m); }
inline Sol& Sol::set(const Sol& other, std::initializer_list<MapEntry> il) { MapList m(il); return set(other, m); }

#ifndef __CUDACC__
/// operator<< for MapList
inline std::ostream& operator<<(std::ostream& os, const MapList& ml) {
  os << "{";
  for (size_t i = 0; i < ml.size(); ++i) {
    if (i > 0) os << ", ";
    std::visit([&](auto&& k) { os << k; }, ml[i].key);
    os << ": " << ml[i].value;
  }
  return os << "}";
}
#endif

/// Sol member functions (deferred — depend on MapList)
template <typename ML, typename>
inline Sol& Sol::set(const ML& ml) {
  auto expanded = detail::expand_maplist_eval(ml);
  for (auto& [v, val] : expanded) set(v, static_cast<bool>(val));
  comp_energy();
  return *this;
}

template <typename ML, typename>
inline Sol& Sol::set(const Sol& other, const ML& ml) {
  set(other);
  for (const auto& entry : ml) {
    energy_t val = other.eval(entry.value);
    MapList single;
    std::visit([&](auto&& k) { single.push_back({k, Expr(val)}); }, entry.key);
    auto expanded = detail::expand_maplist_eval(single);
    for (auto& [v, bval] : expanded) set(v, static_cast<bool>(bval));
  }
  comp_energy();
  return *this;
}

// ===========================================================================
// Array — Opaque Array (non-template, .so-backed)
// ===========================================================================

/// Type tags for Array element type (matches .so ArrayType enum)
enum ArrayType { ARRAY_EXPR = 0, ARRAY_VAR = 1, ARRAY_TERM = 2, ARRAY_COEFF = 3, ARRAY_VARINT = 4, ARRAY_EXPREXPR = 5 };

// ---------------------------------------------------------------------------
// Stage D-9 / E-f / E-g (2026-04-16):
//
//   ArrayBase, ArrayVTable, detail::array_vtable_*, array_vtable<T>,
//   class Element, ArrayBase::Proxy, namespace array_dispatch —
//   all deleted.
//
// Array<Dim, T> is now a standalone template class holding only
// `void* so_impl_`. Every lifetime, metadata and arithmetic operation
// dispatches at compile time via `if constexpr` on T. There is no
// runtime type-tag, vtable pointer, or virtual method anywhere on
// the Array path. ArrayType enum (above) is still kept: a few .so ABI
// entry points (eq_int / between) accept an int tag on the boundary,
// and Array<Dim, T>::type() returns the compile-time enum value.
// ---------------------------------------------------------------------------


// ---------------------------------------------------------------------------
// Stage E-e: SolArrayResult is gone. Sol::operator()(Array<Dim, Var>) now
// returns a plain Array<Dim, coeff_t>. The old hybrid "convertible to
// energy_t in scalar context while behaving as a multi-element array"
// masked bugs where a vector result was silently coerced to its first
// element. Callers that want a single value should pass a single Var
// (Sol::operator()(Var) -> energy_t) or extract .get(0) explicitly.
// ---------------------------------------------------------------------------

/// Traits: how to read element T at flat index i from a raw ArrayImpl<T>*.
/// Stage E-a: the old `get(const ArrayBase&, i)` overloads were removed —
/// every caller knows the raw void* from Array<Dim, T>::impl() and dispatches
/// statically on T, so ArrayBase is no longer in the read path.
template <typename T> struct array_element;
template <> struct array_element<Var> {
  static Var get_from(void* impl, size_t i) { return Var(qbpp_array_var_get(impl, i)); }
};
template <> struct array_element<Term> {
  static Term get_from(void* impl, size_t i) {
    void* h = qbpp_array_term_get(impl, i);
    flat_energy_t fe; qbpp_term_coeff(h, &fe);
    coeff_t c = static_cast<coeff_t>(fe);
    uint32_t d = qbpp_term_degree(h);
    Term t(c);
    for (uint32_t k = 0; k < d; ++k) t *= Var(qbpp_term_var_at(h, k));
    qbpp_term_destroy(h);
    return t;
  }
};
template <> struct array_element<Expr> {
  // Expr and Expr are aliases for Expr; they all share storage and
  // dispatch through the same specialization.
  static Expr get_from(void* impl, size_t i) { return Expr::from_impl(qbpp_array_expr_get(impl, i)); }
};
template <> struct array_element<coeff_t> {
  static coeff_t get_from(void* impl, size_t i) { flat_energy_t f; qbpp_array_int_get(impl, i, &f); return static_cast<coeff_t>(f); }
};

/// Traits: result type of Array<A> op Array<B>
template <typename A, typename B> struct array_mul_result { using type = Expr; };
template <> struct array_mul_result<Var, Var>     { using type = Term; };
template <> struct array_mul_result<Var, Term>    { using type = Term; };
template <> struct array_mul_result<Term, Var>    { using type = Term; };
template <> struct array_mul_result<Term, Term>   { using type = Term; };
template <> struct array_mul_result<coeff_t, Var>     { using type = Term; };
template <> struct array_mul_result<Var, coeff_t>     { using type = Term; };
template <> struct array_mul_result<coeff_t, Term>    { using type = Term; };
template <> struct array_mul_result<Term, coeff_t>    { using type = Term; };
template <> struct array_mul_result<coeff_t, coeff_t> { using type = coeff_t; };

// ===========================================================================
// ExprView<Dim, T> — non-owning view into an Array's Expr-like elements
// Holds borrowed impl_ pointer + flat offset for multi-dimensional [] chaining.
// Stage D-8B: templated over T (Expr / Expr / Expr) to eliminate the
// runtime type_tag_ branching that was previously used in operator[] and
// to_array. All dispatch is now compile-time.
// ===========================================================================

// ===========================================================================
// ArrayExprRef — scalar element proxy for Array<Dim, Expr>[i]...[k].
// Enables in-place mutation (`arr[...] += e`, `arr[...] = e`) for any depth
// via ExprView<1,Expr>::operator[] and Array<1,Expr>::operator[].
// Reads clone out as Expr; implicitly converts to Expr for arithmetic.
// Defined before ExprView so that ExprView<1, Expr>::operator[] can return it.
// ===========================================================================
class ArrayExprRef {
  void* impl_;    // borrowed ArrayImpl<ExprImpl>*
  size_t idx_;

  Expr read() const { return Expr::from_impl(qbpp_array_expr_get(impl_, idx_)); }
  void  write(const Expr& e) { qbpp_array_expr_set(impl_, idx_, e.impl()); }

 public:
  ArrayExprRef(void* impl, size_t idx) : impl_(impl), idx_(idx) {}

  // Read: implicit conversion to Expr (enables arr[i] in arithmetic).
  operator Expr() const { return read(); }

  // Functor form: arr[i](sol) → value.
  energy_t operator()(const Sol& sol) const { return read()(sol); }

  // Stream output: arr[i] prints like its Expr value.
  // Use ._str() directly because the generic `os << Expr` helper is
  // disabled under __CUDACC__ (it pulls in SFINAE templates).
  friend std::ostream& operator<<(std::ostream& os, const ArrayExprRef& r) {
    return os << r.read()._str();
  }

  // Direct assignment.
  ArrayExprRef& operator=(const Expr& e)     { write(e); return *this; }
  ArrayExprRef& operator=(const Term& t)     { write(Expr(t)); return *this; }
  ArrayExprRef& operator=(Var v)             { write(Expr(v)); return *this; }
  ArrayExprRef& operator=(coeff_t c)         { write(Expr(c)); return *this; }
  ArrayExprRef& operator=(const ArrayExprRef& o) { write(o.read()); return *this; }

  // Compound assignment: load, apply Expr's op, store back.
  template <typename U> ArrayExprRef& operator+=(const U& rhs) { Expr e = read(); e += rhs; write(e); return *this; }
  template <typename U> ArrayExprRef& operator-=(const U& rhs) { Expr e = read(); e -= rhs; write(e); return *this; }
  template <typename U> ArrayExprRef& operator*=(const U& rhs) { Expr e = read(); e *= rhs; write(e); return *this; }
  template <typename U> ArrayExprRef& operator/=(const U& rhs) { Expr e = read(); e /= rhs; write(e); return *this; }
};

template <size_t Dim, typename T>
class ExprView {
  void* impl_;      // borrowed ArrayImpl* (not owned)
  size_t offset_;   // flat index offset into exprs[]
  size_t stride_;   // stride for current dimension

public:
  template <size_t D, typename U> friend class Array;
  template <size_t D, typename U> friend class ExprView;

  ExprView(void* impl, size_t offset, size_t stride)
      : impl_(impl), offset_(offset), stride_(stride) {}

  decltype(auto) operator[](size_t i) const {
    if constexpr (Dim == 1) {
      // Expr: return a writeback proxy so `arr[i][j] OP= ...` works for any depth.
      if constexpr (std::is_same_v<T, Expr>)
        return ArrayExprRef(impl_, offset_ + i);
      else
        return Expr::from_impl(qbpp_array_expr_get(impl_, offset_ + i));
    } else {
      // Current dim index in the original array = ndim - Dim - 1.
      size_t nd = qbpp_array_expr_ndim(impl_);
      size_t next_dim_size = qbpp_array_expr_shape_at(impl_, nd - Dim);
      size_t next_stride = stride_ / next_dim_size;
      return ExprView<Dim-1, T>(impl_, offset_ + i * stride_, next_stride);
    }
  }

  /// Conversion to Array<Dim, T> (clones the subview). Stage E-d: the old
  /// ArrayBase return is gone — callers get a typed Array back.
  Array<Dim, T> to_array() const {
    return Array<Dim, T>::from_impl(qbpp_array_expr_clone_subview(impl_, offset_, Dim));
  }
  operator Array<Dim, T>() const { return to_array(); }

  // Arithmetic — materialize via to_array() then delegate to Array<Dim, T>.
  // Lets `view * scalar`, `view + arr`, `view * view` etc. work without
  // forcing the user to call to_array() explicitly. Template arg deduction
  // doesn't trigger user-defined conversions, so plain Array overloads alone
  // would not pick up a view operand.
  template <typename U> auto operator+(const U& rhs) const { return to_array() + rhs; }
  template <typename U> auto operator-(const U& rhs) const { return to_array() - rhs; }
  template <typename U> auto operator*(const U& rhs) const { return to_array() * rhs; }
  auto operator-() const { return -to_array(); }
};

// ===========================================================================
// ArrayCoeffRef — scalar element proxy for Array<Dim, coeff_t>[i]...[k].
// Enables in-place mutation (`arr[...] = c`, `arr[...] += c`) at any depth
// via IntView<1>::operator[] and Array<1, coeff_t>::operator[].
// Implicitly converts to coeff_t for arithmetic.
// ===========================================================================
class ArrayCoeffRef {
  void* impl_;    // borrowed ArrayImpl<coeff_t>*
  size_t idx_;

  coeff_t read() const {
    flat_energy_t f;
    qbpp_array_int_get(impl_, idx_, &f);
    return static_cast<coeff_t>(f);
  }
  void write(coeff_t c) { qbpp_array_int_set(impl_, idx_, FlatEnergy(c)); }

 public:
  ArrayCoeffRef(void* impl, size_t idx) : impl_(impl), idx_(idx) {}

  // Read: implicit conversion to coeff_t.
  operator coeff_t() const { return read(); }

  friend std::ostream& operator<<(std::ostream& os, const ArrayCoeffRef& r) {
    return os << _to_string(r.read());
  }

  // Direct assignment.
  ArrayCoeffRef& operator=(coeff_t c)            { write(c); return *this; }
  ArrayCoeffRef& operator=(const ArrayCoeffRef& o) { write(o.read()); return *this; }

  // Compound assignment.
  ArrayCoeffRef& operator+=(coeff_t c) { write(read() + c); return *this; }
  ArrayCoeffRef& operator-=(coeff_t c) { write(read() - c); return *this; }
  ArrayCoeffRef& operator*=(coeff_t c) { write(read() * c); return *this; }
  ArrayCoeffRef& operator/=(coeff_t c) { write(read() / c); return *this; }
};

// ===========================================================================
// IntView<Dim> — non-owning view into an Array<N, coeff_t>'s elements.
// Parallel to ExprView<Dim, Expr> but for coeff_t arrays. Holds a borrowed
// impl_ pointer + flat offset for multi-dimensional [] chaining without
// cloning the sub-array.
// ===========================================================================
template <size_t Dim>
class IntView {
  void* impl_;
  size_t offset_;
  size_t stride_;

 public:
  template <size_t D, typename U> friend class Array;
  template <size_t D> friend class IntView;

  IntView(void* impl, size_t offset, size_t stride)
      : impl_(impl), offset_(offset), stride_(stride) {}

  decltype(auto) operator[](size_t i) const {
    if constexpr (Dim == 1) {
      return ArrayCoeffRef(impl_, offset_ + i);
    } else {
      size_t nd = qbpp_array_int_ndim(impl_);
      size_t next_dim_size = qbpp_array_int_shape_at(impl_, nd - Dim);
      size_t next_stride = stride_ / next_dim_size;
      return IntView<Dim - 1>(impl_, offset_ + i * stride_, next_stride);
    }
  }

  Array<Dim, coeff_t> to_array() const {
    return Array<Dim, coeff_t>::from_impl(qbpp_array_int_clone_subview(impl_, offset_, Dim));
  }
  operator Array<Dim, coeff_t>() const { return to_array(); }

  // Arithmetic — see ExprView comment.
  template <typename U> auto operator+(const U& rhs) const { return to_array() + rhs; }
  template <typename U> auto operator-(const U& rhs) const { return to_array() - rhs; }
  template <typename U> auto operator*(const U& rhs) const { return to_array() * rhs; }
  auto operator-() const { return -to_array(); }
};

// ===========================================================================
// VarView<Dim> — non-owning, header-side view for Array<N, Var> subarrays.
//
// Two modes, selected at view construction:
//   - Contiguous (base_ valid, data_ = nullptr): element = base_ + flat_off.
//     The common case: a fresh `qbpp::var("x", N, M, ...)` is laid out
//     contiguously, so `x[i][j]` becomes pure integer arithmetic.
//   - Data-pointer (base_ = vindex_limit, data_ non-null): element =
//     data_[flat_off]. Covers sliced / scattered Var arrays where the
//     vindex_t values are not consecutive.
//
// Either way, hot loops like `x[i][j] * f[...] * x[k][l]` avoid the old
// per-subarray .so call + ArrayImplVar heap alloc.
// ===========================================================================
template <size_t Dim>
class VarView {
  vindex_t base_;           // vindex_limit iff data_ is active
  const uint32_t* data_;    // nullptr iff base_ is active
  std::array<size_t, Dim> shape_;
  std::array<size_t, Dim> strides_;   // strides_[k] = prod(shape_[k+1..Dim-1])

 public:
  template <size_t D> friend class VarView;
  template <size_t D, typename U> friend class Array;

  VarView() : base_(vindex_limit), data_(nullptr) {
    shape_.fill(0); strides_.fill(0);
  }
  // Contiguous view.
  VarView(vindex_t base,
          const std::array<size_t, Dim>& sh,
          const std::array<size_t, Dim>& st)
      : base_(base), data_(nullptr), shape_(sh), strides_(st) {}
  // Data-pointer view.
  VarView(const uint32_t* data,
          const std::array<size_t, Dim>& sh,
          const std::array<size_t, Dim>& st)
      : base_(vindex_limit), data_(data), shape_(sh), strides_(st) {}

  size_t ndim()  const { return Dim; }
  size_t size()  const { return shape_[0]; }
  size_t shape(size_t k) const { return shape_[k]; }
  size_t total() const {
    size_t t = 1;
    for (auto s : shape_) t *= s;
    return t;
  }

  decltype(auto) operator[](size_t i) const {
    if constexpr (Dim == 1) {
      if (base_ != vindex_limit)
        return Var(base_ + static_cast<vindex_t>(i * strides_[0]));
      return Var(data_[i * strides_[0]]);
    } else {
      std::array<size_t, Dim - 1> sh, st;
      for (size_t k = 0; k < Dim - 1; ++k) {
        sh[k] = shape_[k + 1];
        st[k] = strides_[k + 1];
      }
      if (base_ != vindex_limit)
        return VarView<Dim - 1>(
            base_ + static_cast<vindex_t>(i * strides_[0]), sh, st);
      return VarView<Dim - 1>(data_ + i * strides_[0], sh, st);
    }
  }

  struct Iterator {
    const VarView* v_;
    size_t idx_;
    Iterator(const VarView* v, size_t idx) : v_(v), idx_(idx) {}
    auto operator*() const { return (*v_)[idx_]; }
    Iterator& operator++() { ++idx_; return *this; }
    bool operator!=(const Iterator& o) const { return idx_ != o.idx_; }
  };
  Iterator begin() const { return Iterator(this, 0); }
  Iterator end()   const { return Iterator(this, size()); }

  /// Materialize as Array<Dim, Var> (creates a new .so ArrayImplVar that
  /// holds the same vindex_t range). Needed when passing the view to APIs
  /// that take Array<Dim, Var>; the hot-loop path doesn't need this.
  Array<Dim, Var> to_array() const {
    size_t t = total();
    std::vector<uint32_t> flat(t);
    std::array<size_t, Dim> idx{};
    for (size_t f = 0; f < t; ++f) {
      size_t off = 0;
      for (size_t k = 0; k < Dim; ++k) off += idx[k] * strides_[k];
      flat[f] = (base_ != vindex_limit)
                    ? base_ + static_cast<uint32_t>(off)
                    : data_[off];
      for (ssize_t k = static_cast<ssize_t>(Dim) - 1; k >= 0; --k) {
        if (++idx[k] < shape_[k]) break;
        idx[k] = 0;
      }
    }
    return Array<Dim, Var>::from_impl(
        qbpp_array_var_create_data(flat.data(), shape_.data(), Dim));
  }
  operator Array<Dim, Var>() const { return to_array(); }

  // Arithmetic — see ExprView comment.
  template <typename U> auto operator+(const U& rhs) const { return to_array() + rhs; }
  template <typename U> auto operator-(const U& rhs) const { return to_array() - rhs; }
  template <typename U> auto operator*(const U& rhs) const { return to_array() * rhs; }
  auto operator-() const { return -to_array(); }

  friend std::ostream& operator<<(std::ostream& os, const VarView& v) {
    return os << v.to_array();
  }
};

// Reverse: scalar/Array op view → materialize the view and dispatch normally.
template <typename U, size_t D, typename T>
inline auto operator+(const U& lhs, const ExprView<D, T>& v) { return lhs + v.to_array(); }
template <typename U, size_t D, typename T>
inline auto operator-(const U& lhs, const ExprView<D, T>& v) { return lhs - v.to_array(); }
template <typename U, size_t D, typename T>
inline auto operator*(const U& lhs, const ExprView<D, T>& v) { return lhs * v.to_array(); }
template <typename U, size_t D>
inline auto operator+(const U& lhs, const IntView<D>& v) { return lhs + v.to_array(); }
template <typename U, size_t D>
inline auto operator-(const U& lhs, const IntView<D>& v) { return lhs - v.to_array(); }
template <typename U, size_t D>
inline auto operator*(const U& lhs, const IntView<D>& v) { return lhs * v.to_array(); }
template <typename U, size_t D>
inline auto operator+(const U& lhs, const VarView<D>& v) { return lhs + v.to_array(); }
template <typename U, size_t D>
inline auto operator-(const U& lhs, const VarView<D>& v) { return lhs - v.to_array(); }
template <typename U, size_t D>
inline auto operator*(const U& lhs, const VarView<D>& v) { return lhs * v.to_array(); }

// ===========================================================================
// Array<Dim, T> — compile-time dimensioned array, standalone (Stage D-9)
// ===========================================================================
//
// Stage E-f/E-g: Array<Dim, T> no longer derives from ArrayBase. It holds
// only `void* so_impl_` (an ArrayImpl<T>* owned by this object). Every
// lifetime, metadata and arithmetic operation is dispatched at compile time
// via `if constexpr` on T. There is no runtime type-tag, vtable pointer or
// virtual method anywhere on the Array path.

// ---------------------------------------------------------------------------
// Tuple-indexing markers for Array::operator()(Args...)
// ---------------------------------------------------------------------------
// Usage examples:
//   a(1, 2, 3)                        // fix all axes → scalar
//   a(1)                              // fix axis 0, trailing axes default to all
//   a(qbpp::all, j)                   // keep axis 0, fix axis 1 (like col())
//   a(qbpp::slice(1, 3), 2, qbpp::all, 1)  // range 1:3, fix 2, keep :, fix 1
//   a(qbpp::slice(qbpp::end - 5, qbpp::end))  // last 5 elements (MATLAB-like)
// ---------------------------------------------------------------------------

struct all_t {};
inline constexpr all_t all{};

struct end_t { int64_t offset = 0; };
inline constexpr end_t end{0};
inline constexpr end_t operator-(end_t e, int64_t n) { return end_t{e.offset - n}; }
inline constexpr end_t operator+(end_t e, int64_t n) { return end_t{e.offset + n}; }

/// Index value: either a literal integer (offset=0) or an end-based expression.
struct idx_t {
  bool is_end = false;
  int64_t value = 0;
  constexpr idx_t() = default;
  constexpr idx_t(int v)     : is_end(false), value(v) {}
  constexpr idx_t(long v)    : is_end(false), value(v) {}
  constexpr idx_t(long long v) : is_end(false), value(v) {}
  constexpr idx_t(size_t v)  : is_end(false), value(static_cast<int64_t>(v)) {}
  constexpr idx_t(end_t e)   : is_end(true),  value(e.offset) {}
  size_t resolve(size_t axis_size) const {
    int64_t r = is_end ? static_cast<int64_t>(axis_size) + value : value;
    return static_cast<size_t>(r);
  }
};

/// Range marker: a contiguous slice [from, to) on one axis.
struct slice_t { idx_t from, to; };
template <typename A, typename B>
inline constexpr slice_t slice(A from, B to) { return slice_t{idx_t(from), idx_t(to)}; }

/// Single-element slice [i, i+1) — keeps the dimension at size 1.
/// Useful when you want one specific row/column without collapsing the axis,
/// e.g. as input to `concat`. Works for both plain integers and `qbpp::end`-
/// based expressions.
/// Examples:
///   a(qbpp::slice(0), qbpp::all)             // first row, kept as 2-D
///   a(qbpp::slice(qbpp::end - 1), qbpp::all) // last row,  kept as 2-D
template <typename A>
inline constexpr slice_t slice(A i) { return slice_t{idx_t(i), idx_t(i + 1)}; }

// Trait: true if T is an accepted tuple-index argument.
template <typename T> struct is_index_arg : std::false_type {};
template <> struct is_index_arg<int>           : std::true_type {};
template <> struct is_index_arg<long>          : std::true_type {};
template <> struct is_index_arg<long long>     : std::true_type {};
template <> struct is_index_arg<size_t>        : std::true_type {};
template <> struct is_index_arg<end_t>         : std::true_type {};
template <> struct is_index_arg<all_t>         : std::true_type {};
template <> struct is_index_arg<slice_t>       : std::true_type {};
template <typename T> constexpr bool is_index_arg_v = is_index_arg<std::decay_t<T>>::value;

// Count how many of the given argument types keep a dimension (slice/all = keep).
template <typename... Args>
constexpr size_t count_keep() {
  return (0 + ... + ((std::is_same_v<std::decay_t<Args>, all_t> ||
                      std::is_same_v<std::decay_t<Args>, slice_t>) ? 1 : 0));
}

// Process a single argument into starts[d]/stops[d]/squeeze[d] for axis d.
template <typename Arg>
inline void _fill_index(Arg arg, size_t axis_size,
                        size_t& start, size_t& stop, uint8_t& squeeze) {
  using A = std::decay_t<Arg>;
  if constexpr (std::is_same_v<A, all_t>) {
    start = 0; stop = axis_size; squeeze = 0;
  } else if constexpr (std::is_same_v<A, slice_t>) {
    start = arg.from.resolve(axis_size);
    stop  = arg.to.resolve(axis_size);
    squeeze = 0;
  } else {
    // integral or end_t → fix axis
    idx_t ix(arg);
    size_t s = ix.resolve(axis_size);
    start = s; stop = s + 1; squeeze = 1;
  }
}

template <size_t Dim, typename T>
class Array {
  static_assert(Dim >= 1, "Array dimension must be >= 1");

 protected:
  void* so_impl_;  // per-type ArrayImpl<T>* (owned)
  // Fast-path cache used only when T == Var. Populated in from_impl() and
  // copied on copy/move. If the Var array is contiguous (the common case
  // for a freshly created `var("x", ...)`), _var_base_ holds the first
  // vindex_t and operator[] does pure arithmetic. For non-contiguous Var
  // arrays (e.g. returned by slice), _var_base_ is vindex_limit and
  // _var_data_ points at the .so's flat storage for direct lookup. Memory
  // overhead is small (sizeof(vindex_t)+sizeof(ptr)+2*Dim*sizeof(size_t))
  // and only matters when T == Var.
  vindex_t _var_base_ = vindex_limit;
  const uint32_t* _var_data_ = nullptr;
  std::array<size_t, Dim> _var_shape_{};
  std::array<size_t, Dim> _var_strides_{};

 private:
  // Per-type destroy / clone selected at compile time. Expr and Expr
  // share storage with Expr (ArrayImpl<ExprImpl>), so they route through the
  // qbpp_array_expr_* ABI — the element's attr_ carries the Expr/Expr
  // identity.
  static void _destroy(void* p) {
    if (!p) return;
    if constexpr (std::is_same_v<T, Var>)          qbpp_array_var_destroy(p);
    else if constexpr (std::is_same_v<T, coeff_t>) qbpp_array_int_destroy(p);
    else if constexpr (std::is_same_v<T, Term>)    qbpp_array_term_destroy(p);
    else                                           qbpp_array_expr_destroy(p);
  }
  static void* _clone(const void* p) {
    if (!p) return nullptr;
    if constexpr (std::is_same_v<T, Var>)          return qbpp_array_var_clone(p);
    else if constexpr (std::is_same_v<T, coeff_t>) return qbpp_array_int_clone(p);
    else if constexpr (std::is_same_v<T, Term>)    return qbpp_array_term_clone(p);
    else                                           return qbpp_array_expr_clone(p);
  }

 public:
  Array() : so_impl_(nullptr) {}
  ~Array() { _destroy(so_impl_); }
  Array(Array&& o) noexcept
      : so_impl_(o.so_impl_),
        _var_base_(o._var_base_),
        _var_data_(o._var_data_),
        _var_shape_(o._var_shape_),
        _var_strides_(o._var_strides_) {
    o.so_impl_ = nullptr;
  }
  Array(const Array& o)
      : so_impl_(_clone(o.so_impl_)),
        _var_shape_(o._var_shape_),
        _var_strides_(o._var_strides_) {
    // Cloned .so handle — need to refresh data pointer to the new storage.
    if constexpr (std::is_same_v<T, Var>) {
      if (so_impl_) {
        _var_base_ = o._var_base_;
        _var_data_ = (o._var_base_ == vindex_limit)
                         ? qbpp_array_var_data(so_impl_)
                         : nullptr;
      }
    }
  }
  Array& operator=(Array&& o) noexcept {
    if (this != &o) {
      _destroy(so_impl_);
      so_impl_      = o.so_impl_; o.so_impl_ = nullptr;
      _var_base_    = o._var_base_;
      _var_data_    = o._var_data_;
      _var_shape_   = o._var_shape_;
      _var_strides_ = o._var_strides_;
    }
    return *this;
  }
  Array& operator=(const Array& o) {
    if (this != &o) {
      _destroy(so_impl_);
      so_impl_      = _clone(o.so_impl_);
      _var_shape_   = o._var_shape_;
      _var_strides_ = o._var_strides_;
      if constexpr (std::is_same_v<T, Var>) {
        _var_base_ = o._var_base_;
        _var_data_ = (o._var_base_ == vindex_limit && so_impl_)
                         ? qbpp_array_var_data(so_impl_)
                         : nullptr;
      }
    }
    return *this;
  }

  /// Construct an Array taking ownership of a raw ArrayImpl<T>* returned by
  /// the .so (qbpp_array_<t>_create_*, qbpp_array_<t>_clone, or any binary
  /// op that produces the same underlying type). The caller must have
  /// already ensured the pointer matches T. This is the single construction
  /// path used by every factory / operator / subarray site in the header.
  static Array from_impl(void* impl) {
    Array a;
    a.so_impl_ = impl;
    if constexpr (std::is_same_v<T, Var>) {
      if (impl) {
        for (size_t k = 0; k < Dim; ++k)
          a._var_shape_[k] = qbpp_array_var_shape_at(impl, k);
        size_t prod = 1;
        for (ssize_t k = static_cast<ssize_t>(Dim) - 1; k >= 0; --k) {
          a._var_strides_[k] = prod;
          prod *= a._var_shape_[k];
        }
        size_t total = prod;
        const uint32_t* data = qbpp_array_var_data(impl);
        vindex_t first = data[0];
        // Contiguity check: if data[i] == first + i for all i, the fast
        // base+stride arithmetic works. Otherwise fall back to direct
        // pointer reads (still no .so call per access in the hot loop).
        bool contiguous = true;
        for (size_t i = 1; i < total; ++i) {
          if (data[i] != first + static_cast<uint32_t>(i)) {
            contiguous = false;
            break;
          }
        }
        if (contiguous) {
          a._var_base_ = first;
          a._var_data_ = nullptr;
        } else {
          a._var_base_ = vindex_limit;
          a._var_data_ = data;
        }
      }
    }
    return a;
  }

  /// Raw handle accessor (read-only). Needed by the C ABI glue.
  void* impl() const { return so_impl_; }

  /// Metadata — compile-time dispatched per T.
  size_t ndim() const {
    if (!so_impl_) return 0;
    if constexpr (std::is_same_v<T, Var>)          return qbpp_array_var_ndim(so_impl_);
    else if constexpr (std::is_same_v<T, coeff_t>) return qbpp_array_int_ndim(so_impl_);
    else if constexpr (std::is_same_v<T, Term>)    return qbpp_array_term_ndim(so_impl_);
    else                                           return qbpp_array_expr_ndim(so_impl_);
  }
  size_t total() const {
    if (!so_impl_) return 0;
    if constexpr (std::is_same_v<T, Var>)          return qbpp_array_var_size(so_impl_);
    else if constexpr (std::is_same_v<T, coeff_t>) return qbpp_array_int_size(so_impl_);
    else if constexpr (std::is_same_v<T, Term>)    return qbpp_array_term_size(so_impl_);
    else                                           return qbpp_array_expr_size(so_impl_);
  }
  size_t shape(size_t dim) const {
    if (!so_impl_) return 0;
    if constexpr (std::is_same_v<T, Var>)          return qbpp_array_var_shape_at(so_impl_, dim);
    else if constexpr (std::is_same_v<T, coeff_t>) return qbpp_array_int_shape_at(so_impl_, dim);
    else if constexpr (std::is_same_v<T, Term>)    return qbpp_array_term_shape_at(so_impl_, dim);
    else                                           return qbpp_array_expr_shape_at(so_impl_, dim);
  }
  size_t size() const { return so_impl_ ? shape(0) : 0; }
  bool empty() const { return !so_impl_ || total() == 0; }

  /// String — used by operator<<. The .so-owned string is returned as a
  /// const char*; we copy it into a std::string because downstream demo
  /// code expects a string rather than a borrowed pointer.
  std::string _str() const {
    if (!so_impl_) return "{}";
    const char* s = nullptr;
    if constexpr (std::is_same_v<T, Var>)          s = qbpp_array_var_str(so_impl_);
    else if constexpr (std::is_same_v<T, coeff_t>) s = qbpp_array_int_str(so_impl_);
    else if constexpr (std::is_same_v<T, Term>)    s = qbpp_array_term_str(so_impl_);
    else                                           s = qbpp_array_expr_str(so_impl_);
    return s ? std::string(s) : std::string("{}");
  }
  friend std::ostream& operator<<(std::ostream& os, const Array& a) { return os << a._str(); }

  /// ArrayType enum tag (compile-time constant). Legacy accessor used by a
  /// handful of .so ABI entry points that still take an int tag.
  constexpr int type() const {
    if constexpr (std::is_same_v<T, Var>)          return ARRAY_VAR;
    else if constexpr (std::is_same_v<T, coeff_t>) return ARRAY_COEFF;
    else if constexpr (std::is_same_v<T, Term>)    return ARRAY_TERM;
    else if constexpr (std::is_same_v<T, Expr>)    return ARRAY_EXPR;
    else if constexpr (std::is_same_v<T, Expr>)  return ARRAY_VARINT;
    else                                           return ARRAY_EXPREXPR;
  }

  // operator[]: returns sub-array or element proxy
  decltype(auto) operator[](size_t i) const {
    if constexpr (Dim == 1) {
      // For Array<1, Expr>, return a proxy supporting in-place mutation
      // (arr[i] *= x, arr[i] = e). It converts to Expr on read.
      if constexpr (std::is_same_v<T, Expr>) {
        return ArrayExprRef(const_cast<void*>(impl()), i);
      } else if constexpr (std::is_same_v<T, coeff_t>) {
        // Array<1, coeff_t>: write-back proxy supporting `arr[i] = c`.
        return ArrayCoeffRef(const_cast<void*>(impl()), i);
      } else if constexpr (std::is_same_v<T, Var>) {
        // Fast path — pure arithmetic (contiguous) or direct pointer read
        // (sliced). Either way, no .so call, no heap alloc.
        if (_var_base_ != vindex_limit)
          return Var(_var_base_ + static_cast<vindex_t>(i * _var_strides_[0]));
        return Var(_var_data_[i * _var_strides_[0]]);
      } else {
        // Term: value via element-access traits.
        return array_element<T>::get_from(impl(), i);
      }
    } else if constexpr (std::is_same_v<T, Var>) {
      // Fast path — no .so call, no heap alloc.
      std::array<size_t, Dim - 1> sh, st;
      for (size_t k = 0; k < Dim - 1; ++k) {
        sh[k] = _var_shape_[k + 1];
        st[k] = _var_strides_[k + 1];
      }
      if (_var_base_ != vindex_limit)
        return VarView<Dim - 1>(
            _var_base_ + static_cast<vindex_t>(i * _var_strides_[0]), sh, st);
      return VarView<Dim - 1>(_var_data_ + i * _var_strides_[0], sh, st);
    } else if constexpr (std::is_same_v<T, Expr>) {
      // For mutable types: return a view that shares the same impl_ (no clone)
      // ExprView holds the original impl_ and an offset for flat indexing
      // stride for dim 0 = total / shape(0)
      size_t s = total() / shape(0);
      return ExprView<Dim-1, T>(const_cast<void*>(impl()), i * s, s / (Dim > 1 ? shape(1) : 1));
    } else if constexpr (std::is_same_v<T, coeff_t>) {
      // Array<Dim, coeff_t> for Dim>1: return IntView (shares impl, no clone)
      // so chained writes like `arr[i][j] = c` mutate the original array.
      size_t s = total() / shape(0);
      return IntView<Dim-1>(const_cast<void*>(impl()), i * s, s / (Dim > 1 ? shape(1) : 1));
    } else {
      // Stage D-6d: compile-time dispatch for Term (clone subarray).
      void* sub = nullptr;
      if constexpr (std::is_same_v<T, Term>)    sub = qbpp_array_term_subarray(impl(), i);
      else                                       sub = qbpp_array_expr_subarray(impl(), i);
      return Array<Dim-1, T>::from_impl(sub);
    }
  }

  // Explicit get for flat index (always returns T by value)
  T get(size_t i) const { return array_element<T>::get_from(impl(), i); }

  // Functor: arr(sol) → evaluate
  energy_t operator()(const Sol& sol) const { return sol.get(Var(qbpp_array_var_get(impl(), 0))); }

  // Iterator (over first dimension)
  struct Iterator {
    const Array* arr_;
    size_t idx_;
    Iterator(const Array* arr, size_t idx) : arr_(arr), idx_(idx) {}
    auto operator*() const { return (*arr_)[idx_]; }
    Iterator& operator++() { ++idx_; return *this; }
    bool operator!=(const Iterator& o) const { return idx_ != o.idx_; }
  };
  Iterator begin() const { return Iterator(this, 0); }
  Iterator end() const { return Iterator(this, size()); }

  // Element write-back for Array<1, Expr> is via `arr[i] = expr` (ArrayExprRef).

  // --- In-place scalar ops (Stage D-7e static dispatch) ---
  // Supported T: for +=/-= only coeff_t/Expr/Expr/Expr (for Var/Term LHS
  // the element type would change, so they're = delete'd via static_assert).
  Array<Dim, T>& operator+=(coeff_t c) {
    if constexpr (std::is_same_v<T, coeff_t>) qbpp_array_int_add_eq_int(this->impl(), FlatEnergy(c));
    else if constexpr (std::is_same_v<T, Var> || std::is_same_v<T, Term>)
      static_assert(sizeof(T) == 0, "Array<Var/Term> += coeff_t: element type would change. Use `auto r = arr + c;` instead.");
    else qbpp_array_expr_add_eq_int(this->impl(), FlatEnergy(c));
    return *this;
  }
  Array<Dim, T>& operator-=(coeff_t c) {
    if constexpr (std::is_same_v<T, coeff_t>) qbpp_array_int_sub_eq_int(this->impl(), FlatEnergy(c));
    else if constexpr (std::is_same_v<T, Var> || std::is_same_v<T, Term>)
      static_assert(sizeof(T) == 0, "Array<Var/Term> -= coeff_t: element type would change.");
    else qbpp_array_expr_sub_eq_int(this->impl(), FlatEnergy(c));
    return *this;
  }
  Array<Dim, T>& operator*=(coeff_t c) {
    if constexpr (std::is_same_v<T, coeff_t>) qbpp_array_int_mul_eq_int(this->impl(), FlatEnergy(c));
    else if constexpr (std::is_same_v<T, Term>) qbpp_array_term_mul_eq_int(this->impl(), FlatEnergy(c));
    else if constexpr (std::is_same_v<T, Var>)
      static_assert(sizeof(T) == 0, "Array<Var> *= coeff_t: result is Term. Use `auto r = arr * c;` instead.");
    else qbpp_array_expr_mul_eq_int(this->impl(), FlatEnergy(c));
    return *this;
  }
  Array<Dim, T>& operator/=(coeff_t c) {
    if constexpr (std::is_same_v<T, coeff_t>) qbpp_array_int_div_eq_int(this->impl(), FlatEnergy(c));
    else if constexpr (std::is_same_v<T, Term>) qbpp_array_term_div_eq_int(this->impl(), FlatEnergy(c));
    else if constexpr (std::is_same_v<T, Var>)
      static_assert(sizeof(T) == 0, "Array<Var> /= coeff_t: Var has no coefficient to divide.");
    else qbpp_array_expr_div_eq_int(this->impl(), FlatEnergy(c));
    return *this;
  }
  Array<Dim, T>& operator+=(Var v) {
    if constexpr (std::is_same_v<T, Var> || std::is_same_v<T, Term> || std::is_same_v<T, coeff_t>)
      static_assert(sizeof(T) == 0, "Array<Var/Term/coeff_t> += Var: element type would change.");
    else qbpp_array_expr_add_eq_var(this->impl(), v.index());
    return *this;
  }
  Array<Dim, T>& operator-=(Var v) {
    if constexpr (std::is_same_v<T, Var> || std::is_same_v<T, Term> || std::is_same_v<T, coeff_t>)
      static_assert(sizeof(T) == 0, "Array<Var/Term/coeff_t> -= Var: element type would change.");
    else qbpp_array_expr_sub_eq_var(this->impl(), v.index());
    return *this;
  }
  Array<Dim, T>& operator+=(const Expr& e) {
    if constexpr (std::is_same_v<T, Var> || std::is_same_v<T, Term> || std::is_same_v<T, coeff_t>)
      static_assert(sizeof(T) == 0, "Array<Var/Term/coeff_t> += Expr: element type would change.");
    else qbpp_array_expr_add_eq_expr(this->impl(), e.impl());
    return *this;
  }
  Array<Dim, T>& operator-=(const Expr& e) {
    if constexpr (std::is_same_v<T, Var> || std::is_same_v<T, Term> || std::is_same_v<T, coeff_t>)
      static_assert(sizeof(T) == 0, "Array<Var/Term/coeff_t> -= Expr: element type would change.");
    else qbpp_array_expr_sub_eq_expr(this->impl(), e.impl());
    return *this;
  }
  Array<Dim, T>& operator+=(const Term& t) {
    if constexpr (std::is_same_v<T, Var> || std::is_same_v<T, Term> || std::is_same_v<T, coeff_t>)
      static_assert(sizeof(T) == 0, "Array<Var/Term/coeff_t> += Term: element type would change.");
    else {
      void* h = t.to_impl();
      qbpp_array_expr_add_eq_term(this->impl(), h);
      qbpp_term_destroy(h);
    }
    return *this;
  }
  Array<Dim, T>& operator-=(const Term& t) {
    if constexpr (std::is_same_v<T, Var> || std::is_same_v<T, Term> || std::is_same_v<T, coeff_t>)
      static_assert(sizeof(T) == 0, "Array<Var/Term/coeff_t> -= Term: element type would change.");
    else {
      void* h = t.to_impl();
      qbpp_array_expr_sub_eq_term(this->impl(), h);
      qbpp_term_destroy(h);
    }
    return *this;
  }

  // --- Array<T> + Array<U> (same Dim, compile-time dispatch, Stage D-6a) ---
  template <typename U>
  Array<Dim, Expr> operator+(const Array<Dim, U>& o) const {
    constexpr bool t_is_var   = std::is_same_v<T, Var>;
    constexpr bool t_is_term  = std::is_same_v<T, Term>;
    constexpr bool t_is_coeff = std::is_same_v<T, coeff_t>;
    constexpr bool u_is_var   = std::is_same_v<U, Var>;
    constexpr bool u_is_term  = std::is_same_v<U, Term>;
    constexpr bool u_is_coeff = std::is_same_v<U, coeff_t>;
    void* r = nullptr;
    if constexpr (t_is_var && u_is_var)         r = qbpp_array_var_add_array_var(impl(), o.impl());
    else if constexpr (t_is_var && u_is_term)   r = qbpp_array_var_add_array_term(impl(), o.impl());
    else if constexpr (t_is_var && u_is_coeff)  r = qbpp_array_var_add_array_int(impl(), o.impl());
    else if constexpr (t_is_var)                r = qbpp_array_var_add_array_expr(impl(), o.impl());
    else if constexpr (t_is_term && u_is_var)   r = qbpp_array_term_add_array_var(impl(), o.impl());
    else if constexpr (t_is_term && u_is_term)  r = qbpp_array_term_add_array_term(impl(), o.impl());
    else if constexpr (t_is_term && u_is_coeff) r = qbpp_array_term_add_array_int(impl(), o.impl());
    else if constexpr (t_is_term)               r = qbpp_array_term_add_array_expr(impl(), o.impl());
    else if constexpr (t_is_coeff && u_is_var)  r = qbpp_array_int_add_array_var(impl(), o.impl());
    else if constexpr (t_is_coeff && u_is_term) r = qbpp_array_int_add_array_term(impl(), o.impl());
    else if constexpr (t_is_coeff && u_is_coeff)r = qbpp_array_int_add_array_int(impl(), o.impl());
    else if constexpr (t_is_coeff)              r = qbpp_array_int_add_array_expr(impl(), o.impl());
    else if constexpr (u_is_var)                r = qbpp_array_expr_add_array_var(impl(), o.impl());
    else if constexpr (u_is_term)               r = qbpp_array_expr_add_array_term(impl(), o.impl());
    else if constexpr (u_is_coeff)              r = qbpp_array_expr_add_array_int(impl(), o.impl());
    else                                        r = qbpp_array_expr_add_array_expr(impl(), o.impl());
    return Array<Dim, Expr>::from_impl(r);
  }
  template <typename U>
  Array<Dim, Expr> operator-(const Array<Dim, U>& o) const {
    constexpr bool t_is_var   = std::is_same_v<T, Var>;
    constexpr bool t_is_term  = std::is_same_v<T, Term>;
    constexpr bool t_is_coeff = std::is_same_v<T, coeff_t>;
    constexpr bool u_is_var   = std::is_same_v<U, Var>;
    constexpr bool u_is_term  = std::is_same_v<U, Term>;
    constexpr bool u_is_coeff = std::is_same_v<U, coeff_t>;
    void* r = nullptr;
    if constexpr (t_is_var && u_is_var)         r = qbpp_array_var_sub_array_var(impl(), o.impl());
    else if constexpr (t_is_var && u_is_term)   r = qbpp_array_var_sub_array_term(impl(), o.impl());
    else if constexpr (t_is_var && u_is_coeff)  r = qbpp_array_var_sub_array_int(impl(), o.impl());
    else if constexpr (t_is_var)                r = qbpp_array_var_sub_array_expr(impl(), o.impl());
    else if constexpr (t_is_term && u_is_var)   r = qbpp_array_term_sub_array_var(impl(), o.impl());
    else if constexpr (t_is_term && u_is_term)  r = qbpp_array_term_sub_array_term(impl(), o.impl());
    else if constexpr (t_is_term && u_is_coeff) r = qbpp_array_term_sub_array_int(impl(), o.impl());
    else if constexpr (t_is_term)               r = qbpp_array_term_sub_array_expr(impl(), o.impl());
    else if constexpr (t_is_coeff && u_is_var)  r = qbpp_array_int_sub_array_var(impl(), o.impl());
    else if constexpr (t_is_coeff && u_is_term) r = qbpp_array_int_sub_array_term(impl(), o.impl());
    else if constexpr (t_is_coeff && u_is_coeff)r = qbpp_array_int_sub_array_int(impl(), o.impl());
    else if constexpr (t_is_coeff)              r = qbpp_array_int_sub_array_expr(impl(), o.impl());
    else if constexpr (u_is_var)                r = qbpp_array_expr_sub_array_var(impl(), o.impl());
    else if constexpr (u_is_term)               r = qbpp_array_expr_sub_array_term(impl(), o.impl());
    else if constexpr (u_is_coeff)              r = qbpp_array_expr_sub_array_int(impl(), o.impl());
    else                                        r = qbpp_array_expr_sub_array_expr(impl(), o.impl());
    return Array<Dim, Expr>::from_impl(r);
  }
  // Type-pair-specific Array * Array (compile-time dispatch).
  template <typename U>
  Array<Dim, typename array_mul_result<T, U>::type> operator*(const Array<Dim, U>& o) const {
    using R = typename array_mul_result<T, U>::type;
    constexpr bool t_is_var   = std::is_same_v<T, Var>;
    constexpr bool t_is_term  = std::is_same_v<T, Term>;
    constexpr bool t_is_coeff = std::is_same_v<T, coeff_t>;
    constexpr bool u_is_var   = std::is_same_v<U, Var>;
    constexpr bool u_is_term  = std::is_same_v<U, Term>;
    constexpr bool u_is_coeff = std::is_same_v<U, coeff_t>;
    void* r = nullptr;
    if constexpr (t_is_var && u_is_var)         r = qbpp_array_var_mul_array_var(impl(), o.impl());
    else if constexpr (t_is_var && u_is_term)   r = qbpp_array_var_mul_array_term(impl(), o.impl());
    else if constexpr (t_is_var && u_is_coeff)  r = qbpp_array_var_mul_array_int(impl(), o.impl());
    else if constexpr (t_is_var)                r = qbpp_array_var_mul_array_expr(impl(), o.impl());
    else if constexpr (t_is_term && u_is_var)   r = qbpp_array_term_mul_array_var(impl(), o.impl());
    else if constexpr (t_is_term && u_is_term)  r = qbpp_array_term_mul_array_term(impl(), o.impl());
    else if constexpr (t_is_term && u_is_coeff) r = qbpp_array_term_mul_array_int(impl(), o.impl());
    else if constexpr (t_is_term)               r = qbpp_array_term_mul_array_expr(impl(), o.impl());
    else if constexpr (t_is_coeff && u_is_var)  r = qbpp_array_int_mul_array_var(impl(), o.impl());
    else if constexpr (t_is_coeff && u_is_term) r = qbpp_array_int_mul_array_term(impl(), o.impl());
    else if constexpr (t_is_coeff && u_is_coeff)r = qbpp_array_int_mul_array_int(impl(), o.impl());
    else if constexpr (t_is_coeff)              r = qbpp_array_int_mul_array_expr(impl(), o.impl());
    else if constexpr (u_is_var)                r = qbpp_array_expr_mul_array_var(impl(), o.impl());
    else if constexpr (u_is_term)               r = qbpp_array_expr_mul_array_term(impl(), o.impl());
    else if constexpr (u_is_coeff)              r = qbpp_array_expr_mul_array_int(impl(), o.impl());
    else                                        r = qbpp_array_expr_mul_array_expr(impl(), o.impl());
    return Array<Dim, R>::from_impl(r);
  }

  // Stage E-g: ArrayBase is deleted. The old `= delete` placeholders for
  // Array<Dim,T> op ArrayBase are gone with it.

  // --- Scalar broadcast (compile-time dispatch, Stage D-6b) ---
  // 4-way static dispatch on T ∈ {Var, coeff_t, Term, else→Expr}.
  // Expr / Expr fall through to the qbpp_array_expr_* path because they
  // store ExprImpl internally.
#define QBPP_SCALAR_OP_COEFF(op_name, op_sym, ret)                                  \
  Array<Dim, ret> operator op_sym (coeff_t c) const {                               \
    void* r = nullptr;                                                              \
    if constexpr (std::is_same_v<T, Var>)         r = qbpp_array_var_##op_name##_int(impl(), FlatEnergy(c));  \
    else if constexpr (std::is_same_v<T, coeff_t>)r = qbpp_array_int_##op_name##_int(impl(), FlatEnergy(c));  \
    else if constexpr (std::is_same_v<T, Term>)   r = qbpp_array_term_##op_name##_int(impl(), FlatEnergy(c)); \
    else                                          r = qbpp_array_expr_##op_name##_int(impl(), FlatEnergy(c)); \
    return Array<Dim, ret>::from_impl(r);    \
  }
#define QBPP_SCALAR_OP_VAR(op_name, op_sym, ret)                                    \
  Array<Dim, ret> operator op_sym (Var v) const {                                   \
    void* r = nullptr;                                                              \
    if constexpr (std::is_same_v<T, Var>)         r = qbpp_array_var_##op_name##_var(impl(), v.index());  \
    else if constexpr (std::is_same_v<T, coeff_t>)r = qbpp_array_int_##op_name##_var(impl(), v.index());  \
    else if constexpr (std::is_same_v<T, Term>)   r = qbpp_array_term_##op_name##_var(impl(), v.index()); \
    else                                          r = qbpp_array_expr_##op_name##_var(impl(), v.index()); \
    return Array<Dim, ret>::from_impl(r);    \
  }
#define QBPP_SCALAR_OP_TERM(op_name, op_sym, ret)                                   \
  Array<Dim, ret> operator op_sym (const Term& t) const {                           \
    void* h = t.to_impl();                                                          \
    void* r = nullptr;                                                              \
    if constexpr (std::is_same_v<T, Var>)         r = qbpp_array_var_##op_name##_term(impl(), h);  \
    else if constexpr (std::is_same_v<T, coeff_t>)r = qbpp_array_int_##op_name##_term(impl(), h);  \
    else if constexpr (std::is_same_v<T, Term>)   r = qbpp_array_term_##op_name##_term(impl(), h); \
    else                                          r = qbpp_array_expr_##op_name##_term(impl(), h); \
    qbpp_term_destroy(h);                                                           \
    return Array<Dim, ret>::from_impl(r);    \
  }
#define QBPP_SCALAR_OP_EXPR(op_name, op_sym, ret)                                   \
  Array<Dim, ret> operator op_sym (const Expr& e) const {                           \
    void* r = nullptr;                                                              \
    if constexpr (std::is_same_v<T, Var>)         r = qbpp_array_var_##op_name##_expr(impl(), e.impl());  \
    else if constexpr (std::is_same_v<T, coeff_t>)r = qbpp_array_int_##op_name##_expr(impl(), e.impl());  \
    else if constexpr (std::is_same_v<T, Term>)   r = qbpp_array_term_##op_name##_expr(impl(), e.impl()); \
    else                                          r = qbpp_array_expr_##op_name##_expr(impl(), e.impl()); \
    return Array<Dim, ret>::from_impl(r);    \
  }

  QBPP_SCALAR_OP_COEFF(add, +, Expr)
  QBPP_SCALAR_OP_COEFF(sub, -, Expr)
  // Array<T> * coeff_t: result type depends on T (array_mul_result<T, coeff_t>)
  auto operator*(coeff_t c) const {
    using R = typename array_mul_result<T, coeff_t>::type;
    void* r = nullptr;
    if constexpr (std::is_same_v<T, Var>)         r = qbpp_array_var_mul_int(impl(), FlatEnergy(c));
    else if constexpr (std::is_same_v<T, coeff_t>)r = qbpp_array_int_mul_int(impl(), FlatEnergy(c));
    else if constexpr (std::is_same_v<T, Term>)   r = qbpp_array_term_mul_int(impl(), FlatEnergy(c));
    else                                          r = qbpp_array_expr_mul_int(impl(), FlatEnergy(c));
    return Array<Dim, R>::from_impl(r);
  }
  QBPP_SCALAR_OP_VAR(add, +, Expr)
  QBPP_SCALAR_OP_VAR(sub, -, Expr)
  // Array<T> * Var: result type depends on T
  auto operator*(Var v) const {
    using R = typename array_mul_result<T, Var>::type;
    void* r = nullptr;
    if constexpr (std::is_same_v<T, Var>)         r = qbpp_array_var_mul_var(impl(), v.index());
    else if constexpr (std::is_same_v<T, coeff_t>)r = qbpp_array_int_mul_var(impl(), v.index());
    else if constexpr (std::is_same_v<T, Term>)   r = qbpp_array_term_mul_var(impl(), v.index());
    else                                          r = qbpp_array_expr_mul_var(impl(), v.index());
    return Array<Dim, R>::from_impl(r);
  }
  QBPP_SCALAR_OP_TERM(add, +, Expr)
  QBPP_SCALAR_OP_TERM(sub, -, Expr)
  QBPP_SCALAR_OP_TERM(mul, *, Expr)
  QBPP_SCALAR_OP_EXPR(add, +, Expr)
  QBPP_SCALAR_OP_EXPR(sub, -, Expr)
  QBPP_SCALAR_OP_EXPR(mul, *, Expr)

#undef QBPP_SCALAR_OP_COEFF
#undef QBPP_SCALAR_OP_VAR
#undef QBPP_SCALAR_OP_TERM
#undef QBPP_SCALAR_OP_EXPR

  // Unary minus (compile-time dispatch, Stage D-6c)
  Array<Dim, Expr> operator-() const {
    void* r = nullptr;
    if constexpr (std::is_same_v<T, Var>)          r = qbpp_array_var_negate(impl());
    else if constexpr (std::is_same_v<T, coeff_t>) r = qbpp_array_int_negate(impl());
    else if constexpr (std::is_same_v<T, Term>)    r = qbpp_array_term_negate(impl());
    else                                           r = qbpp_array_expr_negate(impl());
    return Array<Dim, Expr>::from_impl(r);
  }

  // Simplify / sqr — promote non-Expr input to Expr via add-eq-array, then run
  // on Expr. For Expr LHS we skip the temporary. (Stage D-6c)
public:
  // Returns an owned ArrayImplExpr*; caller must destroy it after use.
  // Public so templated concat<T,U> (D-7) can promote non-Expr sides uniformly.
  void* _promote_to_expr_array() const {
    if constexpr (std::is_same_v<T, Expr>) {
      return qbpp_array_expr_from_expr(impl());
    } else {
      // Var / Term / coeff_t: create zero Expr array, then add-eq.
      size_t nd = ndim();
      std::vector<size_t> sh(nd);
      for (size_t i = 0; i < nd; ++i) sh[i] = shape(i);
      void* r = qbpp_array_expr_create_zero(sh.data(), nd);
      if constexpr (std::is_same_v<T, Var>)          qbpp_array_expr_add_eq_array_var(r, impl());
      else if constexpr (std::is_same_v<T, coeff_t>) qbpp_array_expr_add_eq_array_int(r, impl());
      else                                           qbpp_array_expr_add_eq_array_term(r, impl());
      return r;
    }
  }

public:
  Array<Dim, Expr> simplify() const {
    if constexpr (std::is_same_v<T, Expr>) {
      return Array<Dim, Expr>::from_impl(qbpp_array_expr_simplify(impl()));
    } else {
      void* tmp = _promote_to_expr_array();
      void* r = qbpp_array_expr_simplify(tmp);
      qbpp_array_expr_destroy(tmp);
      return Array<Dim, Expr>::from_impl(r);
    }
  }
  Array<Dim, Expr> simplify_as_binary() const {
    if constexpr (std::is_same_v<T, Expr>) {
      return Array<Dim, Expr>::from_impl(qbpp_array_expr_simplify_as_binary(impl()));
    } else {
      void* tmp = _promote_to_expr_array();
      void* r = qbpp_array_expr_simplify_as_binary(tmp);
      qbpp_array_expr_destroy(tmp);
      return Array<Dim, Expr>::from_impl(r);
    }
  }
  Array<Dim, Expr> simplify_as_spin() const {
    if constexpr (std::is_same_v<T, Expr>) {
      return Array<Dim, Expr>::from_impl(qbpp_array_expr_simplify_as_spin(impl()));
    } else {
      void* tmp = _promote_to_expr_array();
      void* r = qbpp_array_expr_simplify_as_spin(tmp);
      qbpp_array_expr_destroy(tmp);
      return Array<Dim, Expr>::from_impl(r);
    }
  }
  Array<Dim, Expr> sqr() const {
    if constexpr (std::is_same_v<T, Expr>) {
      return Array<Dim, Expr>::from_impl(qbpp_array_expr_sqr(impl()));
    } else {
      void* tmp = _promote_to_expr_array();
      void* r = qbpp_array_expr_sqr(tmp);
      qbpp_array_expr_destroy(tmp);
      return Array<Dim, Expr>::from_impl(r);
    }
  }

  /// Stage E-d: replace variables in each element using a MapList. Only
  /// valid for Array<Dim, Expr> — for other element types, produce a clear
  /// compile-time error via static_assert inside the instantiated template.
  template <typename ML>
  Array& replace(const ML& ml) {
    static_assert(std::is_same_v<T, Expr>,
      "Array<T>::replace(ml) requires T == Expr. Use `qbpp::replace(lhs, ml)` "
      "or rebuild the array via an Expr arithmetic expression first.");
    auto expanded = detail::expand_maplist_replace(ml);
    size_t nm = expanded.size();
    std::vector<uint32_t> vars(nm);
    std::vector<const void*> exprs(nm);
    for (size_t i = 0; i < nm; ++i) {
      vars[i] = expanded[i].first.index();
      exprs[i] = expanded[i].second.impl();
    }
    qbpp_array_expr_replace(impl(), vars.data(), exprs.data(), nm);
    return *this;
  }
  Array& replace(std::initializer_list<MapEntry> ml) { return replace(MapList(ml)); }

  // Sum (reduce all → Expr) — Stage D-6d static dispatch.
  // Expr / Expr share storage with Expr (see _destroy for details).
  Expr sum() const {
    void* r = nullptr;
    if constexpr (std::is_same_v<T, Var>)            r = qbpp_array_var_sum(impl());
    else if constexpr (std::is_same_v<T, coeff_t>)   r = qbpp_array_int_sum(impl());
    else if constexpr (std::is_same_v<T, Term>)      r = qbpp_array_term_sum(impl());
    else                                             r = qbpp_array_expr_sum(impl());
    return Expr::from_impl(r);
  }

  // vector_sum(axis): reduce one axis → Array<Dim-1, Expr> (Stage D-6e)
  // Result is Array<Dim-1, coeff_t> when T == coeff_t, else Array<Dim-1, Expr>.
  template <size_t D = Dim, typename = std::enable_if_t<(D > 1)>>
  auto vector_sum(int axis = -1) const {
    if (axis < 0) axis = static_cast<int>(Dim) - 1;
    using R = std::conditional_t<std::is_same_v<T, coeff_t>, coeff_t, Expr>;
    void* r = nullptr;
    if constexpr (std::is_same_v<T, Var>)            r = qbpp_array_var_vector_sum(impl(), axis);
    else if constexpr (std::is_same_v<T, coeff_t>)   r = qbpp_array_int_vector_sum(impl(), axis);
    else if constexpr (std::is_same_v<T, Term>)      r = qbpp_array_term_vector_sum(impl(), axis);
    else                                             r = qbpp_array_expr_vector_sum(impl(), axis);
    return Array<Dim - 1, R>::from_impl(r);
  }

  // Internal: unified view C ABI dispatch (used by operator() and head/tail).
  void* _view_impl(const size_t* starts, const size_t* stops,
                   const uint8_t* squeeze, size_t ndim) const {
    if constexpr (std::is_same_v<T, Var>)          return qbpp_array_var_view(impl(), starts, stops, squeeze, ndim);
    else if constexpr (std::is_same_v<T, coeff_t>) return qbpp_array_int_view(impl(), starts, stops, squeeze, ndim);
    else if constexpr (std::is_same_v<T, Term>)    return qbpp_array_term_view(impl(), starts, stops, squeeze, ndim);
    else                                           return qbpp_array_expr_view(impl(), starts, stops, squeeze, ndim);
  }

  // Tuple indexing: a(i), a(i, j), a(all, j), a(slice(1, 3), k), a(slice(end-5, end))
  // Returns Array<OutDim, T> where OutDim = Dim - (fixed-axis count).
  template <typename... Args,
            typename = std::enable_if_t<(sizeof...(Args) > 0) &&
                                        (is_index_arg_v<Args> && ...)>>
  auto operator()(Args... args) const {
    static_assert(sizeof...(Args) <= Dim, "too many indices for Array");
    constexpr size_t NArgs = sizeof...(Args);
    constexpr size_t OutDim = count_keep<Args...>() + (Dim - NArgs);

    size_t starts[Dim], stops[Dim];
    uint8_t squeeze[Dim] = {};
    // Fill given axes
    size_t d = 0;
    ((_fill_index(args, this->shape(d), starts[d], stops[d], squeeze[d]), ++d), ...);
    // Trailing axes default to all
    for (size_t a = NArgs; a < Dim; ++a) {
      starts[a] = 0; stops[a] = this->shape(a); squeeze[a] = 0;
    }
    void* r = this->_view_impl(starts, stops, squeeze, Dim);
    if constexpr (OutDim == 0) {
      // All axes fixed → return scalar element.
      return array_element<T>::get_from(r, 0);
    } else {
      return Array<OutDim, T>::from_impl(r);
    }
  }

  // Constraint
  // Constraint: defined after ArrayBase operator== is declared
  Array<Dim, Expr> operator==(energy_t val) const;
};

// ~Array<Dim, Var>
template <size_t Dim>
inline Array<Dim, Var> operator~(const Array<Dim, Var>& a) {
  return Array<Dim, Var>::from_impl(qbpp_array_var_invert(a.impl()));
}

// Scalar op Array (reverse)
template <size_t Dim, typename T> inline Array<Dim, Expr> operator+(coeff_t c, const Array<Dim, T>& a) { return a + c; }
template <size_t Dim, typename T> inline Array<Dim, Expr> operator+(Var v, const Array<Dim, T>& a) { return a + v; }
template <size_t Dim, typename T> inline Array<Dim, Expr> operator+(const Term& t, const Array<Dim, T>& a) { return a + t; }
template <size_t Dim, typename T> inline Array<Dim, Expr> operator+(const Expr& e, const Array<Dim, T>& a) { return a + e; }
// Stage D-6e: route reverse scalar subtraction through Array<Dim,T>::operator-()
// and Array<Dim,Expr>::operator+(scalar), both of which now use static dispatch.
template <size_t Dim, typename T> inline Array<Dim, Expr> operator-(coeff_t c, const Array<Dim, T>& a) { return -a + c; }
template <size_t Dim, typename T> inline Array<Dim, Expr> operator-(Var v, const Array<Dim, T>& a) { return -a + v; }
template <size_t Dim, typename T> inline Array<Dim, Expr> operator-(const Term& t, const Array<Dim, T>& a) { return -a + t; }
template <size_t Dim, typename T> inline Array<Dim, Expr> operator-(const Expr& e, const Array<Dim, T>& a) { return -a + e; }
template <size_t Dim, typename T> inline auto operator*(coeff_t c, const Array<Dim, T>& a) { return a * c; }
template <size_t Dim, typename T> inline auto operator*(Var v, const Array<Dim, T>& a) { return a * v; }
template <size_t Dim, typename T> inline Array<Dim, Expr> operator*(const Term& t, const Array<Dim, T>& a) { return a * t; }
template <size_t Dim, typename T> inline Array<Dim, Expr> operator*(const Expr& e, const Array<Dim, T>& a) { return a * e; }

// User-side parallelism helpers.
//
// Use these when the structure does not fit `qbpp::einsum` / `qbpp::sum` /
// `qbpp::vector_sum` and you need to drive parallelism from your own code
// (e.g. an outer (i,j) loop over a non-tensor pattern with an inner Term
// accumulation). Each thread receives its own `local` accumulator so all
// `+=` writes stay thread-local; results are combined sequentially after
// the parallel region.
//
//   qbpp::par_for(0, n*n, [&](size_t idx) { ...side effects only... });
//
//   auto obj = qbpp::par_reduce<qbpp::Expr>(
//       0, n*n, [&](size_t idx, qbpp::Expr& local) {
//         uint32_t i = idx / n, j = idx % n;
//         for (uint32_t k = 0; k < n; ++k)
//           for (uint32_t l = 0; l < n; ++l)
//             local += flow[i][j] * dist[k][l] * x[i][k] * x[j][l];
//       });
//
// `threads = 0` (default) → std::thread::hardware_concurrency().
template <typename F>
inline void par_for(size_t begin, size_t end, F&& body, unsigned threads = 0) {
  if (begin >= end) return;
  size_t total = end - begin;
  unsigned hw = threads ? threads : std::thread::hardware_concurrency();
  if (hw == 0) hw = 1;
  if (hw == 1 || total < 2) {
    for (size_t i = begin; i < end; ++i) body(i);
    return;
  }
  if (hw > total) hw = static_cast<unsigned>(total);
  std::vector<std::thread> ths;
  ths.reserve(hw);
  for (unsigned tid = 0; tid < hw; ++tid) {
    ths.emplace_back([begin, total, hw, tid, &body] {
      size_t b = begin + static_cast<size_t>(tid) * total / hw;
      size_t e = begin + static_cast<size_t>(tid + 1) * total / hw;
      for (size_t i = b; i < e; ++i) body(i);
    });
  }
  for (auto& t : ths) t.join();
}

template <typename T, typename F>
inline T par_reduce(size_t begin, size_t end, F&& body, unsigned threads = 0) {
  T result{};
  if (begin >= end) return result;
  size_t total = end - begin;
  unsigned hw = threads ? threads : std::thread::hardware_concurrency();
  if (hw == 0) hw = 1;
  if (hw == 1 || total < 2) {
    for (size_t i = begin; i < end; ++i) body(i, result);
    return result;
  }
  if (hw > total) hw = static_cast<unsigned>(total);
  std::vector<T> locals(hw);
  std::vector<std::thread> ths;
  ths.reserve(hw);
  for (unsigned tid = 0; tid < hw; ++tid) {
    ths.emplace_back([begin, total, hw, tid, &body, &locals] {
      size_t b = begin + static_cast<size_t>(tid) * total / hw;
      size_t e = begin + static_cast<size_t>(tid + 1) * total / hw;
      T& local = locals[tid];
      for (size_t i = b; i < e; ++i) body(i, local);
    });
  }
  for (auto& t : ths) t.join();
  for (auto& l : locals) result += l;
  return result;
}

// Array sum/simplify global functions
template <size_t Dim, typename T>
inline Expr sum(const Array<Dim, T>& a) { return a.sum(); }
template <size_t Dim, typename T>
inline Array<Dim, Expr> simplify(const Array<Dim, T>& a) { return a.simplify(); }
template <size_t Dim, typename T>
inline Array<Dim, Expr> simplify_as_binary(const Array<Dim, T>& a) { return a.simplify_as_binary(); }
template <size_t Dim, typename T>
inline Array<Dim, Expr> simplify_as_spin(const Array<Dim, T>& a) { return a.simplify_as_spin(); }
template <size_t Dim, typename T>
inline Array<Dim, Expr> sqr(const Array<Dim, T>& a) { return a.sqr(); }




// Factory functions — scalar (same as legacy, returns Var/Expr directly)
inline Var var(const std::string& name) {
  vindex_t index = qbpp_new_var(name.c_str());
  if (index == vindex_limit) throw std::runtime_error("Variable creation failed.");
  return Var(index);
}
/// Unnamed var: var() → single Var with auto-name {0}, {1}, ...
inline Var var() {
  vindex_t index = qbpp_new_var(nullptr);
  if (index == vindex_limit) throw std::runtime_error("Variable creation failed.");
  return Var(index);
}
inline Expr expr() { return Expr(); }

// Factory functions — array (returns Array<Dim, T>)
template <typename... Dims,
          typename = std::enable_if_t<(sizeof...(Dims) > 0) && (std::is_integral_v<Dims> && ...)>>
inline Array<sizeof...(Dims), Var> var(const std::string& name, Dims... dims) {
  size_t sh[] = {static_cast<size_t>(dims)...};
  return Array<sizeof...(Dims), Var>::from_impl(
      qbpp_array_var_create_named(name.c_str(), sh, sizeof...(dims)));
}

/// Unnamed var array: var(3, 4) → Array<2, Var> with auto-name
template <typename... Dims,
          typename = std::enable_if_t<(sizeof...(Dims) > 0) && (std::is_integral_v<Dims> && ...)>>
inline Array<sizeof...(Dims), Var> var(Dims... dims) {
  size_t sh[] = {static_cast<size_t>(dims)...};
  return Array<sizeof...(Dims), Var>::from_impl(
      qbpp_array_var_create_named(nullptr, sh, sizeof...(dims)));
}

template <typename... Dims,
          typename = std::enable_if_t<(sizeof...(Dims) > 0) && (std::is_integral_v<Dims> && ...)>>
inline Array<sizeof...(Dims), Expr> expr(Dims... dims) {
  size_t sh[] = {static_cast<size_t>(dims)...};
  return Array<sizeof...(Dims), Expr>::from_impl(
      qbpp_array_expr_create_zero(sh, sizeof...(dims)));
}

/// Zero-array factory: array<T>(dim0, dim1, ...) → Array<N, T> of zeros.
/// Template parameter T is required; T must be coeff_t (any integral type
/// maps to coeff_t) or Expr.
/// Examples:
///   auto a = qbpp::array<coeff_t>(3, 4);  // Array<2, coeff_t>
///   auto b = qbpp::array<Expr>(3, 4);     // Array<2, Expr>
template <typename T, typename... Dims,
          typename = std::enable_if_t<(sizeof...(Dims) > 0) && (std::is_integral_v<Dims> && ...)>>
inline auto array(Dims... dims) {
  size_t sh[] = {static_cast<size_t>(dims)...};
  constexpr size_t N = sizeof...(Dims);
  if constexpr (std::is_same_v<T, Expr>) {
    return Array<N, Expr>::from_impl(qbpp_array_expr_create_zero(sh, N));
  } else if constexpr (std::is_integral_v<T> || std::is_same_v<T, coeff_t>) {
    return Array<N, coeff_t>::from_impl(qbpp_array_int_create_zero(sh, N));
  } else {
    static_assert(std::is_same_v<T, Expr> || std::is_integral_v<T> || std::is_same_v<T, coeff_t>,
                  "qbpp::array<T>(dims...) requires T = coeff_t (integral) or Expr");
  }
}


// --- Expr += ArrayBase deferred implementations ---
template <size_t Dim, typename T>
inline Expr& Expr::operator+=(const Array<Dim, T>& a) { return *this += Expr(a.get(0)); }
template <size_t Dim, typename T>
inline Expr& Expr::operator-=(const Array<Dim, T>& a) { return *this -= Expr(a.get(0)); }

// --- Expr <= Array (COEFF) support ---
// Stage E-g: the old ArrayBase::Proxy is gone along with ArrayBase. The
// remaining typed overloads below (Array<Dim, coeff_t> <= / operator<= on
// integer arrays) cover every supported constraint shape.

/// Helper: extract std::vector<int> from Array<Dim, coeff_t> via bulk C ABI.
/// Stage E-b: no longer takes ArrayBase — callers must pass a typed integer
/// array (e.g. the result of qbpp::array(...)).
template <size_t ArrDim>
inline std::vector<int> to_int_vector(const Array<ArrDim, coeff_t>& arr) {
  size_t n = arr.total();
  std::vector<int> v(n);
  if (n > 0) qbpp_array_int_to_ints(arr.impl(), v.data());
  return v;
}

/// Array<Dim, coeff_t> <= VarIntArrayCore → pair
template <size_t Dim>
inline std::pair<std::vector<int>, VarIntArrayCore<Dim>> operator<=(const Array<Dim, coeff_t>& min_arr, VarIntArrayCore<Dim>&& core) {
  return {to_int_vector(min_arr), std::move(core)};
}
/// pair<vector<int>, VarIntArrayCore> <= Array<Dim, coeff_t>
template <size_t Dim>
inline Array<Dim, Expr> operator<=(std::pair<std::vector<int>, VarIntArrayCore<Dim>>&& p, const Array<Dim, coeff_t>& max_arr) {
  return p.second.between(p.first, to_int_vector(max_arr));
}
/// pair<energy_t, VarIntArrayCore> <= Array<Dim, coeff_t> (uniform min, per-element max)
template <size_t Dim>
inline Array<Dim, Expr> operator<=(std::pair<energy_t, VarIntArrayCore<Dim>>&& p, const Array<Dim, coeff_t>& max_arr) {
  auto max_v = to_int_vector(max_arr);
  size_t n = max_v.size();
  std::vector<int> min_data(n, static_cast<int>(p.first));
  return p.second.between(min_data, max_v);
}

/// Deferred: VarIntArrayCore::between() implementations (needs Array)
template <size_t Dim>
inline Array<Dim, Expr> operator==(VarIntArrayCore<Dim>&& core, energy_t val) {
  return core.between(val, val);
}
template <size_t Dim>
inline Array<Dim, Expr> operator<=(std::pair<energy_t, VarIntArrayCore<Dim>>&& p, energy_t max_val) {
  return p.second.between(p.first, max_val);
}

template <size_t Dim>
inline Array<Dim, Expr> VarIntArrayCore<Dim>::between(energy_t min_val, energy_t max_val) const {
  return Array<Dim, Expr>::from_impl(
      qbpp_array_varint_create_uniform(name_.c_str(), shape_.data(), shape_.size(),
                                       FlatEnergy(min_val), FlatEnergy(max_val)));
}

template <size_t Dim>
inline Array<Dim, Expr> VarIntArrayCore<Dim>::between(const std::vector<int>& min_vals, const std::vector<int>& max_vals) const {
  size_t num_elems = 1;
  for (auto d : shape_) num_elems *= d;
  if (min_vals.size() != num_elems || max_vals.size() != num_elems)
    throw std::invalid_argument("Expr array: min/max size mismatch");

  // Stage F-a: build per-element Expr (each owns a VarIntElem*) and pass
  // the array of VarIntElem* to the new from_elems C ABI which deep-copies.
  std::vector<const void*> elem_ptrs(num_elems);
  std::vector<Expr> temp;
  temp.reserve(num_elems);

  std::vector<size_t> strides(shape_.size());
  if (!shape_.empty()) {
    strides.back() = 1;
    for (int i = static_cast<int>(shape_.size()) - 2; i >= 0; --i)
      strides[i] = strides[i + 1] * shape_[i + 1];
  }

  for (size_t idx = 0; idx < num_elems; ++idx) {
    std::string n = name_;
    size_t rem = idx;
    for (size_t d = 0; d < shape_.size(); ++d) {
      n += "[" + std::to_string(rem / strides[d]) + "]";
      rem %= strides[d];
    }
    temp.push_back(_make_varint(n,
        static_cast<energy_t>(min_vals[idx]),
        static_cast<energy_t>(max_vals[idx])));
    elem_ptrs[idx] = temp.back().impl();
  }
  return Array<Dim, Expr>::from_impl(
      qbpp_array_expr_create_data(elem_ptrs.data(), shape_.data(), shape_.size()));
}

// --- qbpp::array() — generic array factory ---
//
// Each literal-initializer overload is templated on T. T defaults to the
// element type that is naturally deducible from the initializer ("type
// deduction"), but can be overridden explicitly to widen the element type:
//
//   qbpp::array({1, 2, 3})         → Array<1, coeff_t>     (T deduced)
//   qbpp::array<coeff_t>({1,2,3})  → Array<1, coeff_t>     (T explicit)
//   qbpp::array<Expr>({1, 2, 3})   → Array<1, Expr>        (int → Expr)
//   qbpp::array<Var>({x, y})       → Array<1, Var>         (T explicit)
//   qbpp::array<Term>({x, y})      → Array<1, Term>        (Var → Term)
//   qbpp::array<Expr>({x, y})      → Array<1, Expr>        (Var → Expr)

namespace _array_factory {
  /// Build an Array<1, Expr> from any container of Expr-convertible values.
  template <typename It>
  inline void* expr_array_from_range(It first, It last) {
    std::vector<Expr> tmp;
    tmp.reserve(std::distance(first, last));
    for (auto it = first; it != last; ++it) tmp.emplace_back(Expr(*it));
    std::vector<void*> handles; handles.reserve(tmp.size());
    for (auto& e : tmp) handles.push_back(e.impl());
    size_t sh = handles.size();
    return qbpp_array_expr_create_data(handles.data(), &sh, 1);
  }
}

/// 1D from initializer list of int
template <typename T = coeff_t>
inline auto array(std::initializer_list<int> vals) {
  static_assert(std::is_integral_v<T> || std::is_same_v<T, coeff_t> || std::is_same_v<T, Expr>,
                "qbpp::array<T>({int...}): T must be coeff_t (integral) or Expr");
  if constexpr (std::is_same_v<T, Expr>) {
    return Array<1, Expr>::from_impl(_array_factory::expr_array_from_range(vals.begin(), vals.end()));
  } else {
    std::vector<int> v(vals);
    size_t sh = v.size();
    return Array<1, coeff_t>::from_impl(qbpp_array_int_create_data(v.data(), &sh, 1));
  }
}

/// 1D from initializer list of Var
template <typename T = Var>
inline auto array(std::initializer_list<Var> vals) {
  static_assert(std::is_same_v<T, Var> || std::is_same_v<T, Term> || std::is_same_v<T, Expr>,
                "qbpp::array<T>({Var...}): T must be Var, Term, or Expr");
  if constexpr (std::is_same_v<T, Var>) {
    size_t n = vals.size();
    std::vector<vindex_t> idx; idx.reserve(n);
    for (auto v : vals) idx.push_back(v.index());
    size_t sh = n;
    return Array<1, Var>::from_impl(qbpp_array_var_create_data(idx.data(), &sh, 1));
  } else if constexpr (std::is_same_v<T, Term>) {
    std::vector<Term> tmp; tmp.reserve(vals.size());
    for (auto v : vals) tmp.emplace_back(Term(coeff_t(1), v));
    std::vector<void*> handles; handles.reserve(tmp.size());
    for (auto& t : tmp) handles.push_back(t.to_impl());
    size_t sh = handles.size();
    auto* r = qbpp_array_term_create_data(handles.data(), &sh, 1);
    for (auto h : handles) qbpp_term_destroy(h);
    return Array<1, Term>::from_impl(r);
  } else {  // T == Expr
    return Array<1, Expr>::from_impl(_array_factory::expr_array_from_range(vals.begin(), vals.end()));
  }
}

/// 1D from initializer list of Expr
template <typename T = Expr>
inline auto array(std::initializer_list<Expr> vals) {
  static_assert(std::is_same_v<T, Expr>,
                "qbpp::array<T>({Expr...}): T must be Expr");
  size_t n = vals.size();
  std::vector<void*> handles; handles.reserve(n);
  for (const auto& e : vals) handles.push_back(e.impl());
  size_t sh = n;
  return Array<1, Expr>::from_impl(qbpp_array_expr_create_data(handles.data(), &sh, 1));
}

/// 2D from nested initializer list of int
template <typename T = coeff_t>
inline auto array(std::initializer_list<std::initializer_list<int>> vals) {
  static_assert(std::is_integral_v<T> || std::is_same_v<T, coeff_t> || std::is_same_v<T, Expr>,
                "qbpp::array<T>({{int...}...}): T must be coeff_t (integral) or Expr");
  size_t rows = vals.size();
  size_t cols = vals.begin()->size();
  std::vector<int> flat; flat.reserve(rows * cols);
  for (auto& row : vals) {
    if (row.size() != cols) throw std::invalid_argument("array: ragged rows");
    flat.insert(flat.end(), row.begin(), row.end());
  }
  size_t sh[] = {rows, cols};
  if constexpr (std::is_same_v<T, Expr>) {
    std::vector<Expr> tmp; tmp.reserve(flat.size());
    for (int x : flat) tmp.emplace_back(Expr(static_cast<coeff_t>(x)));
    std::vector<void*> handles; handles.reserve(tmp.size());
    for (auto& e : tmp) handles.push_back(e.impl());
    return Array<2, Expr>::from_impl(qbpp_array_expr_create_data(handles.data(), sh, 2));
  } else {
    return Array<2, coeff_t>::from_impl(qbpp_array_int_create_data(flat.data(), sh, 2));
  }
}

/// 1D from std::vector<int>
template <typename T = coeff_t>
inline auto array(const std::vector<int>& vals) {
  static_assert(std::is_integral_v<T> || std::is_same_v<T, coeff_t> || std::is_same_v<T, Expr>,
                "qbpp::array<T>(vector<int>): T must be coeff_t (integral) or Expr");
  if constexpr (std::is_same_v<T, Expr>) {
    return Array<1, Expr>::from_impl(_array_factory::expr_array_from_range(vals.begin(), vals.end()));
  } else {
    size_t sh = vals.size();
    return Array<1, coeff_t>::from_impl(qbpp_array_int_create_data(vals.data(), &sh, 1));
  }
}


// Stage E-g: ArrayBase itself is deleted. The old `= delete` free-function
// placeholders that used to trap legacy ArrayBase callers are gone with it
// — callers must use the templated Array<Dim,T> overloads defined above.

/// Typed vector_sum: Array<Dim, T> → Array<Dim-1, Expr> (or coeff_t for T=coeff_t)
/// Uses Array<Dim,T>::vector_sum compile-time dispatch (Stage D-6e).
template <size_t Dim, typename T, typename = std::enable_if_t<(Dim >= 2)>>
inline auto vector_sum(const Array<Dim, T>& a, int axis = -1) {
  return a.vector_sum(axis);
}


// --- concat: Array × Array (Stage D-7: templated static dispatch) ---
// Same-type path uses qbpp_array_<t>_concat directly. Mixed types promote
// both sides to Array<Expr> via the existing _promote_to_expr_array helper.
template <size_t Dim, typename T, typename U>
inline auto concat(const Array<Dim, T>& a, const Array<Dim, U>& b, int dim = 0) {
  if constexpr (std::is_same_v<T, U>) {
    void* r = nullptr;
    if constexpr (std::is_same_v<T, Var>)          r = qbpp_array_var_concat(a.impl(), b.impl(), dim);
    else if constexpr (std::is_same_v<T, coeff_t>) r = qbpp_array_int_concat(a.impl(), b.impl(), dim);
    else if constexpr (std::is_same_v<T, Term>)    r = qbpp_array_term_concat(a.impl(), b.impl(), dim);
    else                                           r = qbpp_array_expr_concat(a.impl(), b.impl(), dim);
    return Array<Dim, T>::from_impl(r);
  } else {
    // Promote both to Array<Expr> via temporary impls.
    auto ae = a._promote_to_expr_array();
    auto be = b._promote_to_expr_array();
    void* r = qbpp_array_expr_concat(ae, be, dim);
    qbpp_array_expr_destroy(ae);
    qbpp_array_expr_destroy(be);
    return Array<Dim, Expr>::from_impl(r);
  }
}

// Stage D-8A: polymorphic concat(ArrayBase, ArrayBase) deleted.
// All concat paths now go through templated concat<Dim,T,U>.
// (Stage E-g removed the ArrayBase-taking delete placeholder as well.)

// --- concat: scalar × Array / Array × scalar ---
// Helper: create a 1-element Array<1, Expr> from a scalar value
namespace detail {
inline Array<1, Expr> scalar_to_array(coeff_t c) {
  void* eh = qbpp_expr_create_int(FlatEnergy(c));
  const void* ptr = eh;
  size_t sh = 1;
  void* arr = qbpp_array_expr_create_data(&ptr, &sh, 1);
  qbpp_expr_destroy(eh);
  return Array<1, Expr>::from_impl(arr);
}
inline Array<1, Expr> scalar_to_array(Var v) {
  void* eh = qbpp_expr_create_var(v.index());
  const void* ptr = eh;
  size_t sh = 1;
  void* arr = qbpp_array_expr_create_data(&ptr, &sh, 1);
  qbpp_expr_destroy(eh);
  return Array<1, Expr>::from_impl(arr);
}
// Helper: create a broadcast Array (shape matches arr with dim=1) filled with scalar.
// Uses bulk C ABI (par_for inside .so) instead of element-wise creation.
template <size_t Dim, typename T>
inline Array<Dim, Expr> scalar_broadcast(const Array<Dim, T>& arr, coeff_t c, int dim) {
  std::array<size_t, Dim> sh;
  for (size_t i = 0; i < Dim; ++i) sh[i] = arr.shape(i);
  sh[dim] = 1;
  return Array<Dim, Expr>::from_impl(
      qbpp_array_expr_create_constant_int(sh.data(), Dim, FlatEnergy(c)));
}
template <size_t Dim, typename T>
inline Array<Dim, Expr> scalar_broadcast(const Array<Dim, T>& arr, Var v, int dim) {
  std::array<size_t, Dim> sh;
  for (size_t i = 0; i < Dim; ++i) sh[i] = arr.shape(i);
  sh[dim] = 1;
  return Array<Dim, Expr>::from_impl(
      qbpp_array_expr_create_constant_var(sh.data(), Dim, v.index()));
}
}  // namespace detail

/// concat(scalar, Array) → prepend scalar as 1-element row
template <size_t Dim, typename T, typename S,
          typename = std::enable_if_t<std::is_arithmetic_v<S> || std::is_same_v<S, Var>>>
inline auto concat(const S& scalar, const Array<Dim, T>& arr) {
  if constexpr (Dim == 1) {
    return concat(detail::scalar_to_array(scalar), arr);
  } else {
    return concat(detail::scalar_broadcast(arr, scalar, 0), arr, 0);
  }
}

/// concat(Array, scalar) → append scalar as 1-element row
template <size_t Dim, typename T, typename S,
          typename = std::enable_if_t<std::is_arithmetic_v<S> || std::is_same_v<S, Var>>>
inline auto concat(const Array<Dim, T>& arr, const S& scalar) {
  if constexpr (Dim == 1) {
    return concat(arr, detail::scalar_to_array(scalar));
  } else {
    return concat(arr, detail::scalar_broadcast(arr, scalar, 0), 0);
  }
}

/// concat(scalar, Array, dim) → prepend along dim
template <size_t Dim, typename T, typename S,
          typename = std::enable_if_t<std::is_arithmetic_v<S> || std::is_same_v<S, Var>>>
inline auto concat(const S& scalar, const Array<Dim, T>& arr, int dim) {
  if constexpr (Dim == 1) {
    (void)dim;
    return concat(detail::scalar_to_array(scalar), arr);
  } else {
    return concat(detail::scalar_broadcast(arr, scalar, dim), arr, dim);
  }
}

/// concat(Array, scalar, dim) → append along dim
template <size_t Dim, typename T, typename S,
          typename = std::enable_if_t<std::is_arithmetic_v<S> || std::is_same_v<S, Var>>>
inline auto concat(const Array<Dim, T>& arr, const S& scalar, int dim) {
  if constexpr (Dim == 1) {
    (void)dim;
    return concat(arr, detail::scalar_to_array(scalar));
  } else {
    return concat(arr, detail::scalar_broadcast(arr, scalar, dim), dim);
  }
}

// --- Global slice / row / col / head / tail ---
// Use the templated versions defined below (slice<Dim,T>, row<Dim,T>, col<Dim,T>).
// Stage D-7b deleted the polymorphic ArrayBase versions; Stage E-g removed
// the = delete placeholders along with class ArrayBase itself.


// --- Array constraint operators ---

/// Deferred: Array<Dim,T> == energy_t → Array<Dim, Expr>
/// penalty[i] = sqr(elem[i] - val), body[i] = elem[i].
template <size_t Dim, typename T>
inline Array<Dim, Expr> Array<Dim, T>::operator==(energy_t val) const {
  void* r = nullptr;
  if constexpr (std::is_same_v<T, coeff_t>) r = qbpp_array_int_eq_int (impl(), FlatEnergy(val));
  else if constexpr (std::is_same_v<T, Var>)    r = qbpp_array_var_eq_int (impl(), FlatEnergy(val));
  else if constexpr (std::is_same_v<T, Term>)   r = qbpp_array_term_eq_int(impl(), FlatEnergy(val));
  else if constexpr (std::is_same_v<T, Expr>)   r = qbpp_array_expr_eq_int(impl(), FlatEnergy(val));
  else {
    // Expr / Expr: promote to Expr array first, then eq_int.
    void* tmp = _promote_to_expr_array();
    r = qbpp_array_expr_eq_int(tmp, FlatEnergy(val));
    qbpp_array_expr_destroy(tmp);
  }
  return Array<Dim, Expr>::from_impl(r);
}

/// Stage E-b: Array<Dim,T> == Array<Dim,coeff_t> → Array<Dim, Expr>
/// penalty[i] = sqr(lhs[i] - rhs[i]), body[i] = lhs[i]. RHS must be coeff_t.
template <size_t Dim, typename T, typename U>
inline Array<Dim, Expr> operator==(const Array<Dim, T>& lhs,
                                        const Array<Dim, U>& rhs) {
  static_assert(std::is_same_v<U, coeff_t>,
    "Array == Array requires RHS to be Array<coeff_t>");
  static_assert(!std::is_same_v<T, coeff_t>,
    "Array == Array requires LHS to contain variables (Var/Term/Expr/Expr/Expr)");
  void* r = nullptr;
  if constexpr (std::is_same_v<T, Var>)       r = qbpp_array_var_eq_array_int (lhs.impl(), rhs.impl());
  else if constexpr (std::is_same_v<T, Term>) r = qbpp_array_term_eq_array_int(lhs.impl(), rhs.impl());
  else if constexpr (std::is_same_v<T, Expr>) r = qbpp_array_expr_eq_array_int(lhs.impl(), rhs.impl());
  else {
    // Expr / Expr: promote LHS to Expr array first, then eq_array_int.
    void* tmp = lhs._promote_to_expr_array();
    r = qbpp_array_expr_eq_array_int(tmp, rhs.impl());
    qbpp_array_expr_destroy(tmp);
  }
  return Array<Dim, Expr>::from_impl(r);
}

/// min <= Array<Dim,T> → pair for chained <= max
template <size_t Dim, typename T>
inline std::pair<energy_t, Array<Dim, T>> operator<=(energy_t min_val, const Array<Dim, T>& arr) {
  return {min_val, arr};
}

/// pair<energy_t, Array<Dim,T>> <= max → Array<Dim, Expr>
/// penalty[i] = between(elem[i], min, max), body[i] = elem[i].
template <size_t Dim, typename T>
inline Array<Dim, Expr> operator<=(std::pair<energy_t, Array<Dim, T>>&& p, energy_t max_val) {
  const auto& arr = p.second;
  void* r = nullptr;
  if constexpr (std::is_same_v<T, coeff_t>) r = qbpp_array_int_between (arr.impl(), FlatEnergy(p.first), FlatEnergy(max_val));
  else if constexpr (std::is_same_v<T, Var>)    r = qbpp_array_var_between (arr.impl(), FlatEnergy(p.first), FlatEnergy(max_val));
  else if constexpr (std::is_same_v<T, Term>)   r = qbpp_array_term_between(arr.impl(), FlatEnergy(p.first), FlatEnergy(max_val));
  else if constexpr (std::is_same_v<T, Expr>)   r = qbpp_array_expr_between(arr.impl(), FlatEnergy(p.first), FlatEnergy(max_val));
  else {
    void* tmp = arr._promote_to_expr_array();
    r = qbpp_array_expr_between(tmp, FlatEnergy(p.first), FlatEnergy(max_val));
    qbpp_array_expr_destroy(tmp);
  }
  return Array<Dim, Expr>::from_impl(r);
}

// --- Sol::operator()(Array) deferred implementation ---
// (sol(Array<Var>) bulk evaluation — uses parallel C ABI, not element-wise loop)

// --- has_varint() deferred implementations ---
// `vi` must carry a Expr attr_ so that var_count() / get_var(i) dispatch
// into the VarIntSet metadata (aborts otherwise).
inline bool Expr::has_varint(const Expr& vi) const {
  for (size_t i = 0; i < vi.var_count(); ++i)
    if (!has(vi.get_var(i))) return false;
  return true;
}
inline bool Model::has_varint(const Expr& vi) const {
  for (size_t i = 0; i < vi.var_count(); ++i)
    if (!has(vi.get_var(i))) return false;
  return true;
}
inline bool Sol::has_varint(const Expr& vi) const {
  for (size_t i = 0; i < vi.var_count(); ++i)
    if (!has(vi.get_var(i))) return false;
  return true;
}
// --- Expr-specific Expr methods deferred after Array<Dim, T> ---
inline Array<1, Var> Expr::vars() const {
  size_t n = var_count();
  std::vector<uint32_t> v(n);
  for (size_t i = 0; i < n; ++i) v[i] = get_var(i).index();
  size_t sh = n;
  return Array<1, Var>::from_impl(qbpp_array_var_create_data(v.data(), &sh, 1));
}
inline Array<1, coeff_t> Expr::coeffs() const {
  size_t n = var_count();
  std::vector<int> c(n);
  for (size_t i = 0; i < n; ++i) c[i] = static_cast<int>(coeff(i));
  size_t sh = n;
  return Array<1, coeff_t>::from_impl(qbpp_array_int_create_data(c.data(), &sh, 1));
}

// --- Sol deferred implementation (Stage E-e: typed only) ---
/// sol(Array<Dim, Var>) → Array<Dim, coeff_t>
template <size_t Dim>
inline Array<Dim, coeff_t> Sol::operator()(const Array<Dim, Var>& arr) const {
  return Array<Dim, coeff_t>::from_impl(qbpp_array_int_from_sol(impl_, arr.impl()));
}

// --- onehot_to_int ---
// Decode a one-hot encoded Array<Dim, coeff_t> along the specified axis.
// axis = -1 (default): decode along the last axis. Negative indices supported.
// Output shape = input shape with the specified axis removed.
// Returns -1 for slices that are not valid one-hot vectors.
// Stage E-b: typed-only; the old ArrayBase overload is gone.

/// onehot_to_int: Array<1, coeff_t> → coeff_t (scalar)
inline coeff_t onehot_to_int(const Array<1, coeff_t>& arr) {
  void* r = qbpp_array_int_onehot_to_int(arr.impl(), 0);
  flat_energy_t fe;
  qbpp_array_int_get(r, 0, &fe);
  qbpp_array_int_destroy(r);
  return static_cast<coeff_t>(fe);
}

/// onehot_to_int: Array<Dim, coeff_t> → Array<Dim-1, coeff_t> (Dim >= 2)
template <size_t Dim, typename = std::enable_if_t<(Dim >= 2)>>
inline Array<Dim-1, coeff_t> onehot_to_int(const Array<Dim, coeff_t>& arr, int axis = -1) {
  if (axis < 0) axis = static_cast<int>(arr.ndim()) + axis;
  return Array<Dim-1, coeff_t>::from_impl(qbpp_array_int_onehot_to_int(arr.impl(), axis));
}

// Stage E-d: Array<Dim, Expr>::replace is defined inline inside the template
// class. The old ArrayBase::replace was removed along with the runtime
// Expr-only guard it used to enforce.

// ---------------------------------------------------------------------------
// einsum — numpy-style tensor contraction over Array<Dim, T>.
//
//   qbpp::einsum<2>("ij,jk->ik", A, B)   → Array<2, Expr>
//   qbpp::einsum<0>("i,i->",     v, w)   → Expr  (scalar, OutDim == 0)
//
// OutDim must equal the number of output labels in the subscript. When every
// input is Array<*, coeff_t> the result uses coeff_t; otherwise Expr.
// VarInt / ExprExpr inputs are treated as their underlying Expr arrays.
// ---------------------------------------------------------------------------
namespace einsum_detail {

template <typename T>
constexpr int type_tag() {
  if constexpr (std::is_same_v<T, Var>) return 0;
  else if constexpr (std::is_same_v<T, coeff_t>) return 1;
  else if constexpr (std::is_same_v<T, Term>) return 2;
  else return 3;  // Expr / VarInt / ExprExpr all share ArrayImplExpr storage
}

}  // namespace einsum_detail

template <size_t OutDim, size_t... Ds, typename... Ts>
inline auto einsum(const char* subscript, const Array<Ds, Ts>&... arrs) {
  constexpr size_t N = sizeof...(Ts);
  static_assert(N >= 1, "einsum requires at least one input array");
  constexpr bool all_coeff = (std::is_same_v<Ts, coeff_t> && ...);
  constexpr int out_type = all_coeff ? 0 : 1;

  int types_arr[N] = { einsum_detail::type_tag<Ts>()... };
  const void* impls_arr[N] = { arrs.impl()... };
  void* r = qbpp_einsum(subscript, static_cast<int>(N),
                         types_arr, impls_arr, out_type, OutDim);

  if constexpr (OutDim == 0) {
    if constexpr (all_coeff) {
      flat_energy_t fe;
      qbpp_array_int_get(r, 0, &fe);
      qbpp_array_int_destroy(r);
      return static_cast<coeff_t>(fe);
    } else {
      void* e = qbpp_array_expr_get(r, 0);
      qbpp_array_expr_destroy(r);
      return Expr::from_impl(e);
    }
  } else {
    if constexpr (all_coeff) {
      return Array<OutDim, coeff_t>::from_impl(r);
    } else {
      return Array<OutDim, Expr>::from_impl(r);
    }
  }
}

}  // namespace qbpp
