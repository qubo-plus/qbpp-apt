/// @file qbpp_defs.hpp
/// @author Koji Nakano
/// @brief Header file for qbpp library definitions.
/// @version 2026.03.04
/// @details This file contains definitions and utility functions used in the
/// qbpp library.
#pragma once

#ifndef __CUDACC__
#include <boost/multiprecision/cpp_int.hpp>
#include <boost/random/taus88.hpp>
#include <boost/random/uniform_real_distribution.hpp>
#endif
#include <atomic>
#include <cstdint>
#include <cstdio>
#include <iomanip>
#include <limits>
#include <random>
#include <string>

#ifndef qbpp_message
#define qbpp_message(x) x
#endif

namespace qbpp {

/// @brief Variable index type.
/// @note Currently fixed to uint32_t for ABI stability.
///       To support uint64_t in future, change this typedef and recompile
///       both library and user code together.
using vindex_t = uint32_t;

constexpr vindex_t vindex_limit = std::numeric_limits<vindex_t>::max();
constexpr vindex_t vindex_neg_bit =
    vindex_t(1) << (std::numeric_limits<vindex_t>::digits - 1);
constexpr vindex_t vindex_mask = ~vindex_neg_bit;
constexpr size_t SEQ_THRESHOLD = 1000;
}  // namespace qbpp

extern "C" {
// str functions (実装は qbpp_license_manager.hpp にある)
const char* qbpp_const_str(const char* param);
// var functions
qbpp::vindex_t qbpp_new_var(const char* name);
const char* qbpp_var_str(qbpp::vindex_t index);
qbpp::vindex_t qbpp_var_set_size();
void qbpp_var_reset();
qbpp::vindex_t qbpp_increment_unnamed_var_count();

// bitvector functions
void* qbpp_bitvector_create(qbpp::vindex_t bit_count);
void* qbpp_bitvector_create_from_array(qbpp::vindex_t bit_count,
                                       const uint64_t* bit_array);
void* qbpp_bitvector_copy(const void* src);
void qbpp_bitvector_destroy(void* bv);
void qbpp_bitvector_set(void* bv, qbpp::vindex_t index, bool value);
bool qbpp_bitvector_get(const void* bv, qbpp::vindex_t index);
void qbpp_bitvector_flip(void* bv, qbpp::vindex_t index);
uint64_t qbpp_bitvector_get64(const void* bv, qbpp::vindex_t index64);
void qbpp_bitvector_set64(void* bv, qbpp::vindex_t index64, uint64_t value);
void qbpp_bitvector_clear(void* bv);
qbpp::vindex_t qbpp_bitvector_popcount(const void* bv);
qbpp::vindex_t qbpp_bitvector_size(const void* bv);
qbpp::vindex_t qbpp_bitvector_size64(const void* bv);
bool qbpp_bitvector_equal(const void* a, const void* b);
bool qbpp_bitvector_less_than(const void* a, const void* b);
const uint64_t* qbpp_bitvector_bits_ptr(const void* bv);
char* qbpp_bitvector_str(const void* bv);

// iv_mapper functions
void* qbpp_iv_mapper_create(qbpp::vindex_t var_count, const uint8_t* var_flags);
void qbpp_iv_mapper_destroy(void* mapper);
qbpp::vindex_t qbpp_iv_mapper_var_count(const void* mapper);
qbpp::vindex_t qbpp_iv_mapper_index(const void* mapper, qbpp::vindex_t var);
qbpp::vindex_t qbpp_iv_mapper_var(const void* mapper, qbpp::vindex_t index);
int qbpp_iv_mapper_has(const void* mapper, qbpp::vindex_t var);

// hash function
uint64_t qbpp_hash(size_t size, const uint64_t* data);

// license functions
void qbpp_license_key(const char* license_key);
const char* qbpp_license_info_str(bool activate, bool deactivate,
                                  uint32_t time_out, bool details);
size_t qbpp_max_var_count();
size_t qbpp_gpu_max_var_count();
}

namespace qbpp {

#ifndef __CUDACC__
/// @brief Thread-local random engine based on taus88
class RandomEngine {
  boost::random::taus88 rng_;

  explicit RandomEngine(uint32_t base_seed = 0) {
    uint32_t rd_seed = static_cast<uint32_t>(std::random_device{}());
    rng_.seed(rd_seed ^ base_seed);
  }

  static uint32_t assign_thread_id() {
    static std::atomic<uint32_t> counter{0};
    return counter++;
  }

  static RandomEngine& instance() {
    thread_local static RandomEngine engine(assign_thread_id());
    return engine;
  }

 public:
  static uint32_t gen32() { return instance().rng_(); }

  static uint64_t gen64() {
    auto& e = instance();
    return (static_cast<uint64_t>(e.rng_()) << 32) | e.rng_();
  }

  static double gen_double() {
    boost::random::uniform_real_distribution<double> dist(0.0, 1.0);
    return dist(instance().rng_);
  }

  static void set_seed(uint32_t seed) { instance().rng_.seed(seed); }
};
#endif

inline uint32_t random_gen32() {
#ifdef __CUDACC__
  return 0;  // not available in device code
#else
  return RandomEngine::gen32();
#endif
}

inline uint64_t random_gen64() {
#ifdef __CUDACC__
  return 0;
#else
  return RandomEngine::gen64();
#endif
}

inline double random_gen_double() {
#ifdef __CUDACC__
  return 0.0;
#else
  return RandomEngine::gen_double();
#endif
}

inline void random_set_seed(uint32_t seed) {
#ifndef __CUDACC__
  RandomEngine::set_seed(seed);
#else
  (void)seed;
#endif
}

template <typename T>
T random_gen(T n) {
  if constexpr (sizeof(T) <= 4 && std::is_integral_v<T>) {
    if (n <= 0) return 0;
    // bias-free limit
    constexpr uint32_t R = std::numeric_limits<uint32_t>::max();
    uint32_t limit = (R / static_cast<uint32_t>(n)) * static_cast<uint32_t>(n);

    uint32_t r;
    do {
      r = random_gen32();
    } while (r >= limit);
    return static_cast<T>(r % static_cast<uint32_t>(n));
  }

  else if constexpr (sizeof(T) <= 8 && std::is_integral_v<T>) {
    if (n <= 0) return 0;
    // bias-free limit
    constexpr uint64_t R = std::numeric_limits<uint64_t>::max();
    uint64_t limit = (R / static_cast<uint64_t>(n)) * static_cast<uint64_t>(n);

    uint64_t r;
    do {
      r = random_gen64();
    } while (r >= limit);
    return static_cast<T>(r % static_cast<uint64_t>(n));
  }
#ifdef __CUDACC__
  else if constexpr (sizeof(T) > 8) {
    static_assert(sizeof(T) == 0, "Unsupported type in random_gen");
  }
#else
  else if constexpr (boost::multiprecision::number_category<T>::value ==
                     boost::multiprecision::number_kind_integer) {
    if (n <= 0) return 0;
    size_t bitlen = boost::multiprecision::msb(n);
    T value;
    do {
      value = 0;
      size_t bits = 0;
      while (bits <= bitlen) {
        uint32_t r = random_gen32();
        for (int i = 0; i < 32 && bits <= bitlen; ++i, ++bits) {
          if (r & (1u << i)) value |= T(1) << bits;
        }
      }
    } while (value >= n);
    return value;
  } else {
    static_assert(sizeof(T) == 0, "Unsupported type in random_gen");
  }
#endif
}

/// @brief ライセンスの状態を表す列挙型
/// @note int32_tの値をとる．
enum class LicenseStatus : int32_t {
  Empty = 0,          // 未チェック
  Error = 1,          // キーが無効 / 削除済み / フォーマット不正
  Unlicensed = 2,     // ライセンスなし / 未アクティベート / サーバー到達不可
  Expired = 3,        // ライセンスまたはトライアルが期限切れ
  Fallback = 4,       // Floating locked/cooldown（ライセンス有効だが一時的に制限）
  AnonymousTrial = 5, // 匿名トライアル
  Licensed = 6,       // 有効なライセンス
};

/// @brief ライセンスキーを設定する関数
inline void license_key(const char* license_key = nullptr) {
  qbpp_license_key(license_key);
}

/// @brief ライセンス情報を文字列で取得する関数
/// @param activate_if_needed 必要に応じてアクティベートするか
/// @param deactivate ディアクティベートするか
/// @param time_out タイムアウト時間（秒）
/// @param details 詳細表示するか
/// @param license_key ライセンスキーを指定する場合は、ここで設定
/// @return ライセンス情報の文字列
/// @note ライセンスキーを指定しない場合、環境変数QBPP_LICENSE_KEYを使用
inline std::string license_info(bool activate_if_needed = false,
                                bool deactivate = false, uint32_t time_out = 20,
                                bool details = false,
                                const char* license_key = nullptr) {
  if (license_key != nullptr) qbpp_license_key(license_key);
  return qbpp_license_info_str(activate_if_needed, deactivate, time_out,
                               details);
}

}  // namespace qbpp
