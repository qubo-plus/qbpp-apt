/// @file easy_solver.hpp
/// @brief EasySolver — opaque wrapper (impl in qbpp_*.so)
/// @version 2026.04.13

#pragma once

#include "qbpp.hpp"

namespace qbpp {
namespace easy_solver {

/// EasySolverSol — SolverSol alias for EasySolver
using EasySolverSol = SolverSol;

/// EasySolver — opaque wrapper (all impl in qbpp_*.so)
class EasySolver {
  void* impl_ = nullptr;
  Model model_;

  EasySolver(const EasySolver&) = delete;
  EasySolver& operator=(const EasySolver&) = delete;

 public:
  explicit EasySolver(Model&& model)
      : impl_(nullptr), model_(std::move(model)) {
    if (model_.var_count() == 0)
      throw std::runtime_error("EasySolver: expression has no variables");
    impl_ = qbpp_easy_solver_wrapper_create(model_.impl());
  }

  explicit EasySolver(const Expr& expr)
      : EasySolver(Model(expr)) {}

  /// Construct from Array (sums all elements)
  template <size_t Dim, typename T>
  explicit EasySolver(const Array<Dim, T>& arr)
      : EasySolver(sum(arr)) {}

  ~EasySolver() {
    if (impl_) qbpp_easy_solver_wrapper_destroy(impl_);
  }

  vindex_t var_count() const { return model_.var_count(); }
  const Model& model() const { return model_; }

  SolverSol search() { Params p; return search(p); }
  SolverSol search(Params&& params) { return search(params); }

  SolverSol search(Params& params) {
    if (params.has_hint())
      throw std::runtime_error("EasySolver does not support hint");
    void* r = qbpp_easy_solver_wrapper_search(impl_, params.data());

    SolverSol result(qbpp_easy_solver_result_to_sol(r, model_.impl()));

    size_t tk_n = qbpp_easy_solver_result_topk_count(r);
    for (size_t i = 0; i < tk_n; ++i) {
      result.sols.push_back(Sol(qbpp_easy_solver_result_topk_to_sol(r, i, model_.impl())));
    }

    size_t info_n = qbpp_easy_solver_result_info_count(r);
    for (size_t i = 0; i < info_n; ++i) {
      result.info_.set(qbpp_easy_solver_result_info_key(r, i),
                        qbpp_easy_solver_result_info_value(r, i));
    }

    qbpp_easy_solver_result_destroy(r);
    return result;
  }
};

}  // namespace easy_solver

using easy_solver::EasySolver;
using easy_solver::EasySolverSol;

}  // namespace qbpp
