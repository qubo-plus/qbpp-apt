/// @file abs3_solver.hpp
/// @brief ABS3Solver — opaque wrapper (impl in qbpp_*.so)
/// @details GPU+CPU hybrid solver. GPU auto-detect with CPU fallback.
///          Supports virtual callback for custom behavior.
/// @version 2026.04.13

#pragma once

#include <mutex>
#include <optional>

#include "qbpp.hpp"

namespace qbpp {
namespace abs3_solver {

/// Callback event types
enum class CallbackEvent : int {
  Start = 0,        ///< Called once at the beginning of search()
  BestUpdated = 1,  ///< Called whenever a new best solution is found
  Timer = 2         ///< Called periodically at a configurable interval
};

/// ABS3SolverSol — SolverSol alias for ABS3Solver
using ABS3SolverSol = SolverSol;

/// ABS3Solver — opaque wrapper with virtual callback support
class ABS3Solver {
  void* impl_ = nullptr;
  Model model_;

  // Callback state (mutable: modified from const callback context)
  mutable std::optional<Sol> current_best_sol_;
  mutable CallbackEvent current_event_ = CallbackEvent::Start;
  mutable double pending_timer_ = -1.0;
  mutable bool timer_changed_ = false;
  mutable std::mutex callback_mutex_;

  ABS3Solver(const ABS3Solver&) = delete;
  ABS3Solver& operator=(const ABS3Solver&) = delete;

  /// Static trampoline: .so callback → virtual callback()
  static double callback_trampoline_(void* ctx, void* sol_handle, int event) {
    auto* self = static_cast<ABS3Solver*>(ctx);
    std::lock_guard<std::mutex> lock(self->callback_mutex_);
    self->current_best_sol_.emplace(sol_handle);
    self->current_event_ = static_cast<CallbackEvent>(event);
    self->timer_changed_ = false;
    self->callback();
    self->current_best_sol_.reset();
    return self->timer_changed_ ? self->pending_timer_ : -1.0;
  }

 public:
  /// gpu: -1=auto, 0=CPU only, >0=use N GPUs
  explicit ABS3Solver(Model&& model, int gpu = -1)
      : impl_(nullptr), model_(std::move(model)) {
    if (model_.var_count() == 0)
      throw std::runtime_error("ABS3Solver: expression has no variables");
    impl_ = qbpp_abs3_wrapper_create(model_.impl(), gpu);
    qbpp_abs3_wrapper_set_callback(impl_, &callback_trampoline_,
                                    const_cast<ABS3Solver*>(this));
  }

  explicit ABS3Solver(const Expr& expr, int gpu = -1)
      : ABS3Solver(Model(expr), gpu) {}

  virtual ~ABS3Solver() {
    if (impl_) qbpp_abs3_wrapper_destroy(impl_);
  }

  vindex_t var_count() const { return model_.var_count(); }
  const Model& model() const { return model_; }

  // =========================================================
  // Callback accessors (valid only inside callback())
  // =========================================================

  const Sol& best_sol() const { return *current_best_sol_; }
  CallbackEvent event() const { return current_event_; }

  void timer(double seconds) const {
    pending_timer_ = seconds > 0 ? seconds : 0;
    timer_changed_ = true;
  }

  // =========================================================
  // Virtual callback (override for custom behavior)
  // =========================================================

  virtual void callback() const {}

  void hint(const Sol& sol) const {
    qbpp_abs3_wrapper_hint(impl_, sol.bitarray());
  }

  // =========================================================
  // Search
  // =========================================================

  SolverSol search() { Params p; return search(p); }
  SolverSol search(Params&& params) { return search(params); }

  SolverSol search(Params& params) {
    if (params.hint_bitarray()) {
      if (params.hint_var_count() != model_.var_count())
        throw std::runtime_error("ABS3Solver::search: hint var_count mismatch");
      qbpp_abs3_wrapper_hint(impl_, params.hint_bitarray());
    }
    void* r = qbpp_abs3_wrapper_search(impl_, params.data());

    SolverSol result(qbpp_easy_solver_result_to_sol(r, model_.impl()));

    size_t tk_n = qbpp_easy_solver_result_topk_count(r);
    for (size_t i = 0; i < tk_n; ++i) {
      result.sols.push_back(Sol(qbpp_easy_solver_result_topk_to_sol(r, i, model_.impl())));
    }

    size_t info_n = qbpp_easy_solver_result_info_count(r);
    for (size_t i = 0; i < info_n; ++i) {
      result.info_.set(qbpp_easy_solver_result_info_key(r, i),
                        qbpp_easy_solver_result_info_value(r, i));
    }

    qbpp_easy_solver_result_destroy(r);
    return result;
  }
};

}  // namespace abs3_solver

using abs3_solver::ABS3Solver;
using abs3_solver::ABS3SolverSol;
using abs3_solver::CallbackEvent;

}  // namespace qbpp
